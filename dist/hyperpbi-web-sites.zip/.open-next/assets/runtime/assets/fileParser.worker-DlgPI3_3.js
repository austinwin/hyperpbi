/*! xlsx.js (C) 2013-present SheetJS -- http://sheetjs.com */
var Lr = 1200, rc = [874, 932, 936, 949, 950, 1250, 1251, 1252, 1253, 1254, 1255, 1256, 1257, 1258, 1e4], w0 = {
  0: 1252,
  /* ANSI */
  1: 65001,
  /* DEFAULT */
  2: 65001,
  /* SYMBOL */
  77: 1e4,
  /* MAC */
  128: 932,
  /* SHIFTJIS */
  129: 949,
  /* HANGUL */
  130: 1361,
  /* JOHAB */
  134: 936,
  /* GB2312 */
  136: 950,
  /* CHINESEBIG5 */
  161: 1253,
  /* GREEK */
  162: 1254,
  /* TURKISH */
  163: 1258,
  /* VIETNAMESE */
  177: 1255,
  /* HEBREW */
  178: 1256,
  /* ARABIC */
  186: 1257,
  /* BALTIC */
  204: 1251,
  /* RUSSIAN */
  222: 874,
  /* THAI */
  238: 1250,
  /* EASTEUROPE */
  255: 1252,
  /* OEM */
  69: 6969
  /* MISC */
}, F0 = function(e) {
  rc.indexOf(e) != -1 && (w0[0] = e);
};
function ac() {
  F0(1252);
}
var $r = function(e) {
  Lr = e, F0(e);
};
function ni() {
  $r(1200), ac();
}
function Z0(e) {
  for (var a = [], r = 0, t = e.length; r < t; ++r) a[r] = e.charCodeAt(r);
  return a;
}
function ii(e) {
  for (var a = [], r = 0; r < e.length >> 1; ++r) a[r] = String.fromCharCode(e.charCodeAt(2 * r) + (e.charCodeAt(2 * r + 1) << 8));
  return a.join("");
}
function tc(e) {
  for (var a = [], r = 0; r < e.length >> 1; ++r) a[r] = String.fromCharCode(e[2 * r] + (e[2 * r + 1] << 8));
  return a.join("");
}
function si(e) {
  for (var a = [], r = 0; r < e.length >> 1; ++r) a[r] = String.fromCharCode(e.charCodeAt(2 * r + 1) + (e.charCodeAt(2 * r) << 8));
  return a.join("");
}
var Ga = function(e) {
  var a = e.charCodeAt(0), r = e.charCodeAt(1);
  return a == 255 && r == 254 ? ii(e.slice(2)) : a == 254 && r == 255 ? si(e.slice(2)) : a == 65279 ? e.slice(1) : e;
}, Tt = function(a) {
  return String.fromCharCode(a);
}, q0 = function(a) {
  return String.fromCharCode(a);
}, nc = null, sa = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
function Q0(e) {
  for (var a = "", r = 0, t = 0, n = 0, i = 0, c = 0, s = 0, f = 0, o = 0; o < e.length; )
    r = e.charCodeAt(o++), i = r >> 2, t = e.charCodeAt(o++), c = (r & 3) << 4 | t >> 4, n = e.charCodeAt(o++), s = (t & 15) << 2 | n >> 6, f = n & 63, isNaN(t) ? s = f = 64 : isNaN(n) && (f = 64), a += sa.charAt(i) + sa.charAt(c) + sa.charAt(s) + sa.charAt(f);
  return a;
}
function Rr(e) {
  var a = "", r = 0, t = 0, n = 0, i = 0, c = 0, s = 0, f = 0;
  if (e.slice(0, 5) == "data:") {
    var o = e.slice(0, 1024).indexOf(";base64,");
    o > -1 && (e = e.slice(o + 8));
  }
  e = e.replace(/[^\w\+\/\=]/g, "");
  for (var o = 0; o < e.length; )
    i = sa.indexOf(e.charAt(o++)), c = sa.indexOf(e.charAt(o++)), r = i << 2 | c >> 4, a += String.fromCharCode(r), s = sa.indexOf(e.charAt(o++)), t = (c & 15) << 4 | s >> 2, s !== 64 && (a += String.fromCharCode(t)), f = sa.indexOf(e.charAt(o++)), n = (s & 3) << 6 | f, f !== 64 && (a += String.fromCharCode(n));
  return a;
}
var ye = /* @__PURE__ */ (function() {
  return typeof Buffer < "u" && typeof process < "u" && typeof process.versions < "u" && !!process.versions.node;
})(), ua = /* @__PURE__ */ (function() {
  if (typeof Buffer < "u") {
    var e = !Buffer.from;
    if (!e) try {
      Buffer.from("foo", "utf8");
    } catch {
      e = !0;
    }
    return e ? function(a, r) {
      return r ? new Buffer(a, r) : new Buffer(a);
    } : Buffer.from.bind(Buffer);
  }
  return function() {
  };
})(), tt = /* @__PURE__ */ (function() {
  if (typeof Buffer > "u") return !1;
  var e = ua([65, 0]);
  if (!e) return !1;
  var a = e.toString("utf16le");
  return a.length == 1;
})();
function fa(e) {
  return ye ? Buffer.alloc ? Buffer.alloc(e) : new Buffer(e) : typeof Uint8Array < "u" ? new Uint8Array(e) : new Array(e);
}
function en(e) {
  return ye ? Buffer.allocUnsafe ? Buffer.allocUnsafe(e) : new Buffer(e) : typeof Uint8Array < "u" ? new Uint8Array(e) : new Array(e);
}
var Dr = function(a) {
  return ye ? ua(a, "binary") : a.split("").map(function(r) {
    return r.charCodeAt(0) & 255;
  });
};
function aa(e) {
  if (Array.isArray(e)) return e.map(function(t) {
    return String.fromCharCode(t);
  }).join("");
  for (var a = [], r = 0; r < e.length; ++r) a[r] = String.fromCharCode(e[r]);
  return a.join("");
}
function A0(e) {
  if (typeof ArrayBuffer > "u") throw new Error("Unsupported");
  if (e instanceof ArrayBuffer) return A0(new Uint8Array(e));
  for (var a = new Array(e.length), r = 0; r < e.length; ++r) a[r] = e[r];
  return a;
}
var ia = ye ? function(e) {
  return Buffer.concat(e.map(function(a) {
    return Buffer.isBuffer(a) ? a : ua(a);
  }));
} : function(e) {
  if (typeof Uint8Array < "u") {
    var a = 0, r = 0;
    for (a = 0; a < e.length; ++a) r += e[a].length;
    var t = new Uint8Array(r), n = 0;
    for (a = 0, r = 0; a < e.length; r += n, ++a)
      n = e[a].length, e[a] instanceof Uint8Array ? t.set(e[a], r) : typeof e[a] == "string" ? t.set(new Uint8Array(Dr(e[a])), r) : t.set(new Uint8Array(e[a]), r);
    return t;
  }
  return [].concat.apply([], e.map(function(i) {
    return Array.isArray(i) ? i : [].slice.call(i);
  }));
};
function ic(e) {
  for (var a = [], r = 0, t = e.length + 250, n = fa(e.length + 255), i = 0; i < e.length; ++i) {
    var c = e.charCodeAt(i);
    if (c < 128) n[r++] = c;
    else if (c < 2048)
      n[r++] = 192 | c >> 6 & 31, n[r++] = 128 | c & 63;
    else if (c >= 55296 && c < 57344) {
      c = (c & 1023) + 64;
      var s = e.charCodeAt(++i) & 1023;
      n[r++] = 240 | c >> 8 & 7, n[r++] = 128 | c >> 2 & 63, n[r++] = 128 | s >> 6 & 15 | (c & 3) << 4, n[r++] = 128 | s & 63;
    } else
      n[r++] = 224 | c >> 12 & 15, n[r++] = 128 | c >> 6 & 63, n[r++] = 128 | c & 63;
    r > t && (a.push(n.slice(0, r)), r = 0, n = fa(65535), t = 65530);
  }
  return a.push(n.slice(0, r)), ia(a);
}
var wr = /\u0000/g, $a = /[\u0001-\u0006]/g;
function Na(e) {
  for (var a = "", r = e.length - 1; r >= 0; ) a += e.charAt(r--);
  return a;
}
function Xr(e, a) {
  var r = "" + e;
  return r.length >= a ? r : Ie("0", a - r.length) + r;
}
function y0(e, a) {
  var r = "" + e;
  return r.length >= a ? r : Ie(" ", a - r.length) + r;
}
function Nt(e, a) {
  var r = "" + e;
  return r.length >= a ? r : r + Ie(" ", a - r.length);
}
function sc(e, a) {
  var r = "" + Math.round(e);
  return r.length >= a ? r : Ie("0", a - r.length) + r;
}
function cc(e, a) {
  var r = "" + e;
  return r.length >= a ? r : Ie("0", a - r.length) + r;
}
var rn = /* @__PURE__ */ Math.pow(2, 32);
function Da(e, a) {
  if (e > rn || e < -rn) return sc(e, a);
  var r = Math.round(e);
  return cc(r, a);
}
function Pt(e, a) {
  return a = a || 0, e.length >= 7 + a && (e.charCodeAt(a) | 32) === 103 && (e.charCodeAt(a + 1) | 32) === 101 && (e.charCodeAt(a + 2) | 32) === 110 && (e.charCodeAt(a + 3) | 32) === 101 && (e.charCodeAt(a + 4) | 32) === 114 && (e.charCodeAt(a + 5) | 32) === 97 && (e.charCodeAt(a + 6) | 32) === 108;
}
var an = [
  ["Sun", "Sunday"],
  ["Mon", "Monday"],
  ["Tue", "Tuesday"],
  ["Wed", "Wednesday"],
  ["Thu", "Thursday"],
  ["Fri", "Friday"],
  ["Sat", "Saturday"]
], i0 = [
  ["J", "Jan", "January"],
  ["F", "Feb", "February"],
  ["M", "Mar", "March"],
  ["A", "Apr", "April"],
  ["M", "May", "May"],
  ["J", "Jun", "June"],
  ["J", "Jul", "July"],
  ["A", "Aug", "August"],
  ["S", "Sep", "September"],
  ["O", "Oct", "October"],
  ["N", "Nov", "November"],
  ["D", "Dec", "December"]
];
function fc(e) {
  return e || (e = {}), e[0] = "General", e[1] = "0", e[2] = "0.00", e[3] = "#,##0", e[4] = "#,##0.00", e[9] = "0%", e[10] = "0.00%", e[11] = "0.00E+00", e[12] = "# ?/?", e[13] = "# ??/??", e[14] = "m/d/yy", e[15] = "d-mmm-yy", e[16] = "d-mmm", e[17] = "mmm-yy", e[18] = "h:mm AM/PM", e[19] = "h:mm:ss AM/PM", e[20] = "h:mm", e[21] = "h:mm:ss", e[22] = "m/d/yy h:mm", e[37] = "#,##0 ;(#,##0)", e[38] = "#,##0 ;[Red](#,##0)", e[39] = "#,##0.00;(#,##0.00)", e[40] = "#,##0.00;[Red](#,##0.00)", e[45] = "mm:ss", e[46] = "[h]:mm:ss", e[47] = "mmss.0", e[48] = "##0.0E+0", e[49] = "@", e[56] = '"上午/下午 "hh"時"mm"分"ss"秒 "', e;
}
var ge = {
  0: "General",
  1: "0",
  2: "0.00",
  3: "#,##0",
  4: "#,##0.00",
  9: "0%",
  10: "0.00%",
  11: "0.00E+00",
  12: "# ?/?",
  13: "# ??/??",
  14: "m/d/yy",
  15: "d-mmm-yy",
  16: "d-mmm",
  17: "mmm-yy",
  18: "h:mm AM/PM",
  19: "h:mm:ss AM/PM",
  20: "h:mm",
  21: "h:mm:ss",
  22: "m/d/yy h:mm",
  37: "#,##0 ;(#,##0)",
  38: "#,##0 ;[Red](#,##0)",
  39: "#,##0.00;(#,##0.00)",
  40: "#,##0.00;[Red](#,##0.00)",
  45: "mm:ss",
  46: "[h]:mm:ss",
  47: "mmss.0",
  48: "##0.0E+0",
  49: "@",
  56: '"上午/下午 "hh"時"mm"分"ss"秒 "'
}, tn = {
  5: 37,
  6: 38,
  7: 39,
  8: 40,
  //  5 -> 37 ...  8 -> 40
  23: 0,
  24: 0,
  25: 0,
  26: 0,
  // 23 ->  0 ... 26 ->  0
  27: 14,
  28: 14,
  29: 14,
  30: 14,
  31: 14,
  // 27 -> 14 ... 31 -> 14
  50: 14,
  51: 14,
  52: 14,
  53: 14,
  54: 14,
  // 50 -> 14 ... 58 -> 14
  55: 14,
  56: 14,
  57: 14,
  58: 14,
  59: 1,
  60: 2,
  61: 3,
  62: 4,
  // 59 ->  1 ... 62 ->  4
  67: 9,
  68: 10,
  // 67 ->  9 ... 68 -> 10
  69: 12,
  70: 13,
  71: 14,
  // 69 -> 12 ... 71 -> 14
  72: 14,
  73: 15,
  74: 16,
  75: 17,
  // 72 -> 14 ... 75 -> 17
  76: 20,
  77: 21,
  78: 22,
  // 76 -> 20 ... 78 -> 22
  79: 45,
  80: 46,
  81: 47,
  // 79 -> 45 ... 81 -> 47
  82: 0
  // 82 ->  0 ... 65536 -> 0 (omitted)
}, oc = {
  //  5 -- Currency,   0 decimal, black negative
  5: '"$"#,##0_);\\("$"#,##0\\)',
  63: '"$"#,##0_);\\("$"#,##0\\)',
  //  6 -- Currency,   0 decimal, red   negative
  6: '"$"#,##0_);[Red]\\("$"#,##0\\)',
  64: '"$"#,##0_);[Red]\\("$"#,##0\\)',
  //  7 -- Currency,   2 decimal, black negative
  7: '"$"#,##0.00_);\\("$"#,##0.00\\)',
  65: '"$"#,##0.00_);\\("$"#,##0.00\\)',
  //  8 -- Currency,   2 decimal, red   negative
  8: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
  66: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
  // 41 -- Accounting, 0 decimal, No Symbol
  41: '_(* #,##0_);_(* \\(#,##0\\);_(* "-"_);_(@_)',
  // 42 -- Accounting, 0 decimal, $  Symbol
  42: '_("$"* #,##0_);_("$"* \\(#,##0\\);_("$"* "-"_);_(@_)',
  // 43 -- Accounting, 2 decimal, No Symbol
  43: '_(* #,##0.00_);_(* \\(#,##0.00\\);_(* "-"??_);_(@_)',
  // 44 -- Accounting, 2 decimal, $  Symbol
  44: '_("$"* #,##0.00_);_("$"* \\(#,##0.00\\);_("$"* "-"??_);_(@_)'
};
function bt(e, a, r) {
  for (var t = e < 0 ? -1 : 1, n = e * t, i = 0, c = 1, s = 0, f = 1, o = 0, l = 0, v = Math.floor(n); o < a && (v = Math.floor(n), s = v * c + i, l = v * o + f, !(n - v < 5e-8)); )
    n = 1 / (n - v), i = c, c = s, f = o, o = l;
  if (l > a && (o > a ? (l = f, s = i) : (l = o, s = c)), !r) return [0, t * s, l];
  var x = Math.floor(t * s / l);
  return [x, t * s - x * l, l];
}
function lc(e) {
  var a = e.toPrecision(16);
  if (a.indexOf("e") > -1) {
    var r = a.slice(0, a.indexOf("e"));
    return r = r.indexOf(".") > -1 ? r.slice(0, r.slice(0, 2) == "0." ? 17 : 16) : r.slice(0, 15) + Ie("0", r.length - 15), r + a.slice(a.indexOf("e"));
  }
  var t = a.indexOf(".") > -1 ? a.slice(0, a.slice(0, 2) == "0." ? 17 : 16) : a.slice(0, 15) + Ie("0", a.length - 15);
  return Number(t);
}
function jr(e, a, r) {
  if (e > 2958465 || e < 0) return null;
  e = lc(e);
  var t = e | 0, n = Math.floor(86400 * (e - t)), i = 0, c = [], s = { D: t, T: n, u: 86400 * (e - t) - n, y: 0, m: 0, d: 0, H: 0, M: 0, S: 0, q: 0 };
  if (Math.abs(s.u) < 1e-6 && (s.u = 0), a && a.date1904 && (t += 1462), s.u > 0.9999 && (s.u = 0, ++n == 86400 && (s.T = n = 0, ++t, ++s.D)), t === 60)
    c = r ? [1317, 10, 29] : [1900, 2, 29], i = 3;
  else if (t === 0)
    c = r ? [1317, 8, 29] : [1900, 1, 0], i = 6;
  else {
    t > 60 && --t;
    var f = new Date(1900, 0, 1);
    f.setDate(f.getDate() + t - 1), c = [f.getFullYear(), f.getMonth() + 1, f.getDate()], i = f.getDay(), t < 60 && (i = (i + 6) % 7), r && (i = dc(f, c));
  }
  return s.y = c[0], s.m = c[1], s.d = c[2], s.S = n % 60, n = Math.floor(n / 60), s.M = n % 60, n = Math.floor(n / 60), s.H = n, s.q = i, s;
}
function S0(e) {
  return e.indexOf(".") == -1 ? e : e.replace(/(?:\.0*|(\.\d*[1-9])0+)$/, "$1");
}
function uc(e) {
  return e.indexOf("E") == -1 ? e : e.replace(/(?:\.0*|(\.\d*[1-9])0+)[Ee]/, "$1E").replace(/(E[+-])(\d)$/, "$10$2");
}
function hc(e) {
  var a = e < 0 ? 12 : 11, r = S0(e.toFixed(12));
  return r.length <= a || (r = e.toPrecision(10), r.length <= a) ? r : e.toExponential(5);
}
function xc(e) {
  var a = S0(e.toFixed(11));
  return a.length > (e < 0 ? 12 : 11) || a === "0" || a === "-0" ? e.toPrecision(6) : a;
}
function nt(e) {
  if (!isFinite(e)) return isNaN(e) ? "#NUM!" : "#DIV/0!";
  var a = Math.floor(Math.log(Math.abs(e)) * Math.LOG10E), r;
  return a >= -4 && a <= -1 ? r = e.toPrecision(10 + a) : Math.abs(a) <= 9 ? r = hc(e) : a === 10 ? r = e.toFixed(10).substr(0, 12) : r = xc(e), S0(uc(r.toUpperCase()));
}
function Ea(e, a) {
  switch (typeof e) {
    case "string":
      return e;
    case "boolean":
      return e ? "TRUE" : "FALSE";
    case "number":
      return (e | 0) === e ? e.toString(10) : nt(e);
    case "undefined":
      return "";
    case "object":
      if (e == null) return "";
      if (e instanceof Date) return Fr(14, ar(e, a && a.date1904), a);
  }
  throw new Error("unsupported value in General format: " + e);
}
function dc(e, a) {
  a[0] -= 581;
  var r = e.getDay();
  return e < 60 && (r = (r + 6) % 7), r;
}
function vc(e, a, r, t) {
  var n = "", i = 0, c = 0, s = r.y, f, o = 0;
  switch (e) {
    case 98:
      s = r.y + 543;
    /* falls through */
    case 121:
      switch (a.length) {
        case 1:
        case 2:
          f = s % 100, o = 2;
          break;
        default:
          f = s % 1e4, o = 4;
          break;
      }
      break;
    case 109:
      switch (a.length) {
        case 1:
        case 2:
          f = r.m, o = a.length;
          break;
        case 3:
          return i0[r.m - 1][1];
        case 5:
          return i0[r.m - 1][0];
        default:
          return i0[r.m - 1][2];
      }
      break;
    case 100:
      switch (a.length) {
        case 1:
        case 2:
          f = r.d, o = a.length;
          break;
        case 3:
          return an[r.q][0];
        default:
          return an[r.q][1];
      }
      break;
    case 104:
      switch (a.length) {
        case 1:
        case 2:
          f = 1 + (r.H + 11) % 12, o = a.length;
          break;
        default:
          throw "bad hour format: " + a;
      }
      break;
    case 72:
      switch (a.length) {
        case 1:
        case 2:
          f = r.H, o = a.length;
          break;
        default:
          throw "bad hour format: " + a;
      }
      break;
    case 77:
      switch (a.length) {
        case 1:
        case 2:
          f = r.M, o = a.length;
          break;
        default:
          throw "bad minute format: " + a;
      }
      break;
    case 115:
      if (a != "s" && a != "ss" && a != ".0" && a != ".00" && a != ".000") throw "bad second format: " + a;
      return r.u === 0 && (a == "s" || a == "ss") ? Xr(r.S, a.length) : (t >= 2 ? c = t === 3 ? 1e3 : 100 : c = t === 1 ? 10 : 1, i = Math.round(c * (r.S + r.u)), i >= 60 * c && (i = 0), a === "s" ? i === 0 ? "0" : "" + i / c : (n = Xr(i, 2 + t), a === "ss" ? n.substr(0, 2) : "." + n.substr(2, a.length - 1)));
    case 90:
      switch (a) {
        case "[h]":
        case "[hh]":
          f = r.D * 24 + r.H;
          break;
        case "[m]":
        case "[mm]":
          f = (r.D * 24 + r.H) * 60 + r.M;
          break;
        case "[s]":
        case "[ss]":
          f = ((r.D * 24 + r.H) * 60 + r.M) * 60 + (t == 0 ? Math.round(r.S + r.u) : r.S);
          break;
        default:
          throw "bad abstime format: " + a;
      }
      o = a.length === 3 ? 1 : 2;
      break;
    case 101:
      f = s, o = 1;
      break;
  }
  var l = o > 0 ? Xr(f, o) : "";
  return l;
}
function qr(e) {
  var a = 3;
  if (e.length <= a) return e;
  for (var r = e.length % a, t = e.substr(0, r); r != e.length; r += a) t += (t.length > 0 ? "," : "") + e.substr(r, a);
  return t;
}
var ci = /%/g;
function pc(e, a, r) {
  var t = a.replace(ci, ""), n = a.length - t.length;
  return ea(e, t, r * Math.pow(10, 2 * n)) + Ie("%", n);
}
function gc(e, a, r) {
  for (var t = a.length - 1; a.charCodeAt(t - 1) === 44; ) --t;
  return ea(e, a.substr(0, t), r / Math.pow(10, 3 * (a.length - t)));
}
function fi(e, a) {
  var r, t = e.indexOf("E") - e.indexOf(".") - 1;
  if (e.match(/^#+0.0E\+0$/)) {
    if (a == 0) return "0.0E+0";
    if (a < 0) return "-" + fi(e, -a);
    var n = e.indexOf(".");
    n === -1 && (n = e.indexOf("E"));
    var i = Math.floor(Math.log(a) * Math.LOG10E) % n;
    if (i < 0 && (i += n), r = (a / Math.pow(10, i)).toPrecision(t + 1 + (n + i) % n), r.indexOf("e") === -1) {
      var c = Math.floor(Math.log(a) * Math.LOG10E);
      for (r.indexOf(".") === -1 ? r = r.charAt(0) + "." + r.substr(1) + "E+" + (c - r.length + i) : r += "E+" + (c - i); r.substr(0, 2) === "0."; )
        r = r.charAt(0) + r.substr(2, n) + "." + r.substr(2 + n), r = r.replace(/^0+([1-9])/, "$1").replace(/^0+\./, "0.");
      r = r.replace(/\+-/, "-");
    }
    r = r.replace(/^([+-]?)(\d*)\.(\d*)[Ee]/, function(s, f, o, l) {
      return f + o + l.substr(0, (n + i) % n) + "." + l.substr(i) + "E";
    });
  } else r = a.toExponential(t);
  return e.match(/E\+00$/) && r.match(/e[+-]\d$/) && (r = r.substr(0, r.length - 1) + "0" + r.charAt(r.length - 1)), e.match(/E\-/) && r.match(/e\+/) && (r = r.replace(/e\+/, "e")), r.replace("e", "E");
}
var oi = /# (\?+)( ?)\/( ?)(\d+)/;
function mc(e, a, r) {
  var t = parseInt(e[4], 10), n = Math.round(a * t), i = Math.floor(n / t), c = n - i * t, s = t;
  return r + (i === 0 ? "" : "" + i) + " " + (c === 0 ? Ie(" ", e[1].length + 1 + e[4].length) : y0(c, e[1].length) + e[2] + "/" + e[3] + Xr(s, e[4].length));
}
function _c(e, a, r) {
  return r + (a === 0 ? "" : "" + a) + Ie(" ", e[1].length + 2 + e[4].length);
}
var li = /^#*0*\.([0#]+)/, ui = /\)[^)]*[0#]/, hi = /\(###\) ###\\?-####/;
function mr(e) {
  for (var a = "", r, t = 0; t != e.length; ++t) switch (r = e.charCodeAt(t)) {
    case 35:
      break;
    case 63:
      a += " ";
      break;
    case 48:
      a += "0";
      break;
    default:
      a += String.fromCharCode(r);
  }
  return a;
}
function nn(e, a) {
  var r = Math.pow(10, a);
  return "" + Math.round(e * r) / r;
}
function sn(e, a) {
  var r = e - Math.floor(e), t = Math.pow(10, a);
  return a < ("" + Math.round(r * t)).length ? 0 : Math.round(r * t);
}
function Tc(e, a) {
  return a < ("" + Math.round((e - Math.floor(e)) * Math.pow(10, a))).length ? 1 : 0;
}
function Ec(e) {
  return e < 2147483647 && e > -2147483648 ? "" + (e >= 0 ? e | 0 : e - 1 | 0) : "" + Math.floor(e);
}
function Pr(e, a, r) {
  if (e.charCodeAt(0) === 40 && !a.match(ui)) {
    var t = a.replace(/\( */, "").replace(/ \)/, "").replace(/\)/, "");
    return r >= 0 ? Pr("n", t, r) : "(" + Pr("n", t, -r) + ")";
  }
  if (a.charCodeAt(a.length - 1) === 44) return gc(e, a, r);
  if (a.indexOf("%") !== -1) return pc(e, a, r);
  if (a.indexOf("E") !== -1) return fi(a, r);
  if (a.charCodeAt(0) === 36) return "$" + Pr(e, a.substr(a.charAt(1) == " " ? 2 : 1), r);
  var n, i, c, s, f = Math.abs(r), o = r < 0 ? "-" : "";
  if (a.match(/^00+$/)) return o + Da(f, a.length);
  if (a.match(/^[#?]+$/))
    return n = Da(r, 0), n === "0" && (n = ""), n.length > a.length ? n : mr(a.substr(0, a.length - n.length)) + n;
  if (i = a.match(oi)) return mc(i, f, o);
  if (a.match(/^#+0+$/)) return o + Da(f, a.length - a.indexOf("0"));
  if (i = a.match(li))
    return n = nn(r, i[1].length).replace(/^([^\.]+)$/, "$1." + mr(i[1])).replace(/\.$/, "." + mr(i[1])).replace(/\.(\d*)$/, function(p, _) {
      return "." + _ + Ie("0", mr(
        /*::(*/
        i[1]
      ).length - _.length);
    }), a.indexOf("0.") !== -1 ? n : n.replace(/^0\./, ".");
  if (a = a.replace(/^#+([0.])/, "$1"), i = a.match(/^(0*)\.(#*)$/))
    return o + nn(f, i[2].length).replace(/\.(\d*[1-9])0*$/, ".$1").replace(/^(-?\d*)$/, "$1.").replace(/^0\./, i[1].length ? "0." : ".");
  if (i = a.match(/^#{1,3},##0(\.?)$/)) return o + qr(Da(f, 0));
  if (i = a.match(/^#,##0\.([#0]*0)$/))
    return r < 0 ? "-" + Pr(e, a, -r) : qr("" + (Math.floor(r) + Tc(r, i[1].length))) + "." + Xr(sn(r, i[1].length), i[1].length);
  if (i = a.match(/^#,#*,#0/)) return Pr(e, a.replace(/^#,#*,/, ""), r);
  if (i = a.match(/^([0#]+)(\\?-([0#]+))+$/))
    return n = Na(Pr(e, a.replace(/[\\-]/g, ""), r)), c = 0, Na(Na(a.replace(/\\/g, "")).replace(/[0#]/g, function(p) {
      return c < n.length ? n.charAt(c++) : p === "0" ? "0" : "";
    }));
  if (a.match(hi))
    return n = Pr(e, "##########", r), "(" + n.substr(0, 3) + ") " + n.substr(3, 3) + "-" + n.substr(6);
  var l = "";
  if (i = a.match(/^([#0?]+)( ?)\/( ?)([#0?]+)/))
    return c = Math.min(
      /*::String(*/
      i[4].length,
      7
    ), s = bt(f, Math.pow(10, c) - 1, !1), n = "" + o, l = ea(
      "n",
      /*::String(*/
      i[1],
      s[1]
    ), l.charAt(l.length - 1) == " " && (l = l.substr(0, l.length - 1) + "0"), n += l + /*::String(*/
    i[2] + "/" + /*::String(*/
    i[3], l = Nt(s[2], c), l.length < i[4].length && (l = mr(i[4].substr(i[4].length - l.length)) + l), n += l, n;
  if (i = a.match(/^# ([#0?]+)( ?)\/( ?)([#0?]+)/))
    return c = Math.min(Math.max(i[1].length, i[4].length), 7), s = bt(f, Math.pow(10, c) - 1, !0), o + (s[0] || (s[1] ? "" : "0")) + " " + (s[1] ? y0(s[1], c) + i[2] + "/" + i[3] + Nt(s[2], c) : Ie(" ", 2 * c + 1 + i[2].length + i[3].length));
  if (i = a.match(/^[#0?]+$/))
    return n = Da(r, 0), a.length <= n.length ? n : mr(a.substr(0, a.length - n.length)) + n;
  if (i = a.match(/^([#0?]+)\.([#0]+)$/)) {
    n = "" + r.toFixed(Math.min(i[2].length, 10)).replace(/([^0])0+$/, "$1"), c = n.indexOf(".");
    var v = a.indexOf(".") - c, x = a.length - n.length - v;
    return mr(a.substr(0, v) + n + a.substr(a.length - x));
  }
  if (i = a.match(/^00,000\.([#0]*0)$/))
    return c = sn(r, i[1].length), r < 0 ? "-" + Pr(e, a, -r) : qr(Ec(r)).replace(/^\d,\d{3}$/, "0$&").replace(/^\d*$/, function(p) {
      return "00," + (p.length < 3 ? Xr(0, 3 - p.length) : "") + p;
    }) + "." + Xr(c, i[1].length);
  switch (a) {
    case "###,##0.00":
      return Pr(e, "#,##0.00", r);
    case "###,###":
    case "##,###":
    case "#,###":
      var u = qr(Da(f, 0));
      return u !== "0" ? o + u : "";
    case "###,###.00":
      return Pr(e, "###,##0.00", r).replace(/^0\./, ".");
    case "#,###.00":
      return Pr(e, "#,##0.00", r).replace(/^0\./, ".");
  }
  throw new Error("unsupported format |" + a + "|");
}
function kc(e, a, r) {
  for (var t = a.length - 1; a.charCodeAt(t - 1) === 44; ) --t;
  return ea(e, a.substr(0, t), r / Math.pow(10, 3 * (a.length - t)));
}
function wc(e, a, r) {
  var t = a.replace(ci, ""), n = a.length - t.length;
  return ea(e, t, r * Math.pow(10, 2 * n)) + Ie("%", n);
}
function xi(e, a) {
  var r, t = e.indexOf("E") - e.indexOf(".") - 1;
  if (e.match(/^#+0.0E\+0$/)) {
    if (a == 0) return "0.0E+0";
    if (a < 0) return "-" + xi(e, -a);
    var n = e.indexOf(".");
    n === -1 && (n = e.indexOf("E"));
    var i = Math.floor(Math.log(a) * Math.LOG10E) % n;
    if (i < 0 && (i += n), r = (a / Math.pow(10, i)).toPrecision(t + 1 + (n + i) % n), !r.match(/[Ee]/)) {
      var c = Math.floor(Math.log(a) * Math.LOG10E);
      r.indexOf(".") === -1 ? r = r.charAt(0) + "." + r.substr(1) + "E+" + (c - r.length + i) : r += "E+" + (c - i), r = r.replace(/\+-/, "-");
    }
    r = r.replace(/^([+-]?)(\d*)\.(\d*)[Ee]/, function(s, f, o, l) {
      return f + o + l.substr(0, (n + i) % n) + "." + l.substr(i) + "E";
    });
  } else r = a.toExponential(t);
  return e.match(/E\+00$/) && r.match(/e[+-]\d$/) && (r = r.substr(0, r.length - 1) + "0" + r.charAt(r.length - 1)), e.match(/E\-/) && r.match(/e\+/) && (r = r.replace(/e\+/, "e")), r.replace("e", "E");
}
function Yr(e, a, r) {
  if (e.charCodeAt(0) === 40 && !a.match(ui)) {
    var t = a.replace(/\( */, "").replace(/ \)/, "").replace(/\)/, "");
    return r >= 0 ? Yr("n", t, r) : "(" + Yr("n", t, -r) + ")";
  }
  if (a.charCodeAt(a.length - 1) === 44) return kc(e, a, r);
  if (a.indexOf("%") !== -1) return wc(e, a, r);
  if (a.indexOf("E") !== -1) return xi(a, r);
  if (a.charCodeAt(0) === 36) return "$" + Yr(e, a.substr(a.charAt(1) == " " ? 2 : 1), r);
  var n, i, c, s, f = Math.abs(r), o = r < 0 ? "-" : "";
  if (a.match(/^00+$/)) return o + Xr(f, a.length);
  if (a.match(/^[#?]+$/))
    return n = "" + r, r === 0 && (n = ""), n.length > a.length ? n : mr(a.substr(0, a.length - n.length)) + n;
  if (i = a.match(oi)) return _c(i, f, o);
  if (a.match(/^#+0+$/)) return o + Xr(f, a.length - a.indexOf("0"));
  if (i = a.match(li))
    return n = ("" + r).replace(/^([^\.]+)$/, "$1." + mr(i[1])).replace(/\.$/, "." + mr(i[1])), n = n.replace(/\.(\d*)$/, function(p, _) {
      return "." + _ + Ie("0", mr(i[1]).length - _.length);
    }), a.indexOf("0.") !== -1 ? n : n.replace(/^0\./, ".");
  if (a = a.replace(/^#+([0.])/, "$1"), i = a.match(/^(0*)\.(#*)$/))
    return o + ("" + f).replace(/\.(\d*[1-9])0*$/, ".$1").replace(/^(-?\d*)$/, "$1.").replace(/^0\./, i[1].length ? "0." : ".");
  if (i = a.match(/^#{1,3},##0(\.?)$/)) return o + qr("" + f);
  if (i = a.match(/^#,##0\.([#0]*0)$/))
    return r < 0 ? "-" + Yr(e, a, -r) : qr("" + r) + "." + Ie("0", i[1].length);
  if (i = a.match(/^#,#*,#0/)) return Yr(e, a.replace(/^#,#*,/, ""), r);
  if (i = a.match(/^([0#]+)(\\?-([0#]+))+$/))
    return n = Na(Yr(e, a.replace(/[\\-]/g, ""), r)), c = 0, Na(Na(a.replace(/\\/g, "")).replace(/[0#]/g, function(p) {
      return c < n.length ? n.charAt(c++) : p === "0" ? "0" : "";
    }));
  if (a.match(hi))
    return n = Yr(e, "##########", r), "(" + n.substr(0, 3) + ") " + n.substr(3, 3) + "-" + n.substr(6);
  var l = "";
  if (i = a.match(/^([#0?]+)( ?)\/( ?)([#0?]+)/))
    return c = Math.min(
      /*::String(*/
      i[4].length,
      7
    ), s = bt(f, Math.pow(10, c) - 1, !1), n = "" + o, l = ea(
      "n",
      /*::String(*/
      i[1],
      s[1]
    ), l.charAt(l.length - 1) == " " && (l = l.substr(0, l.length - 1) + "0"), n += l + /*::String(*/
    i[2] + "/" + /*::String(*/
    i[3], l = Nt(s[2], c), l.length < i[4].length && (l = mr(i[4].substr(i[4].length - l.length)) + l), n += l, n;
  if (i = a.match(/^# ([#0?]+)( ?)\/( ?)([#0?]+)/))
    return c = Math.min(Math.max(i[1].length, i[4].length), 7), s = bt(f, Math.pow(10, c) - 1, !0), o + (s[0] || (s[1] ? "" : "0")) + " " + (s[1] ? y0(s[1], c) + i[2] + "/" + i[3] + Nt(s[2], c) : Ie(" ", 2 * c + 1 + i[2].length + i[3].length));
  if (i = a.match(/^[#0?]+$/))
    return n = "" + r, a.length <= n.length ? n : mr(a.substr(0, a.length - n.length)) + n;
  if (i = a.match(/^([#0]+)\.([#0]+)$/)) {
    n = "" + r.toFixed(Math.min(i[2].length, 10)).replace(/([^0])0+$/, "$1"), c = n.indexOf(".");
    var v = a.indexOf(".") - c, x = a.length - n.length - v;
    return mr(a.substr(0, v) + n + a.substr(a.length - x));
  }
  if (i = a.match(/^00,000\.([#0]*0)$/))
    return r < 0 ? "-" + Yr(e, a, -r) : qr("" + r).replace(/^\d,\d{3}$/, "0$&").replace(/^\d*$/, function(p) {
      return "00," + (p.length < 3 ? Xr(0, 3 - p.length) : "") + p;
    }) + "." + Xr(0, i[1].length);
  switch (a) {
    case "###,###":
    case "##,###":
    case "#,###":
      var u = qr("" + f);
      return u !== "0" ? o + u : "";
    default:
      if (a.match(/\.[0#?]*$/)) return Yr(e, a.slice(0, a.lastIndexOf(".")), r) + mr(a.slice(a.lastIndexOf(".")));
  }
  throw new Error("unsupported format |" + a + "|");
}
function ea(e, a, r) {
  return (r | 0) === r ? Yr(e, a, r) : Pr(e, a, r);
}
function Fc(e) {
  for (var a = [], r = !1, t = 0, n = 0; t < e.length; ++t) switch (
    /*cc=*/
    e.charCodeAt(t)
  ) {
    case 34:
      r = !r;
      break;
    case 95:
    case 42:
    case 92:
      ++t;
      break;
    case 59:
      a[a.length] = e.substr(n, t - n), n = t + 1;
  }
  if (a[a.length] = e.substr(n), r === !0) throw new Error("Format |" + e + "| unterminated string ");
  return a;
}
var di = /\[[HhMmSs\u0E0A\u0E19\u0E17]*\]/;
function Ur(e) {
  for (var a = 0, r = "", t = ""; a < e.length; )
    switch (r = e.charAt(a)) {
      case "G":
        Pt(e, a) && (a += 6), a++;
        break;
      case '"':
        for (
          ;
          /*cc=*/
          e.charCodeAt(++a) !== 34 && a < e.length;
        )
          ;
        ++a;
        break;
      case "\\":
        a += 2;
        break;
      case "_":
        a += 2;
        break;
      case "@":
        ++a;
        break;
      case "B":
      case "b":
        if (e.charAt(a + 1) === "1" || e.charAt(a + 1) === "2") return !0;
      /* falls through */
      case "M":
      case "D":
      case "Y":
      case "H":
      case "S":
      case "E":
      /* falls through */
      case "m":
      case "d":
      case "y":
      case "h":
      case "s":
      case "e":
      case "g":
        return !0;
      case "A":
      case "a":
      case "上":
        if (e.substr(a, 3).toUpperCase() === "A/P" || e.substr(a, 5).toUpperCase() === "AM/PM" || e.substr(a, 5).toUpperCase() === "上午/下午") return !0;
        ++a;
        break;
      case "[":
        for (t = r; e.charAt(a++) !== "]" && a < e.length; ) t += e.charAt(a);
        if (t.match(di)) return !0;
        break;
      case ".":
      /* falls through */
      case "0":
      case "#":
        for (; a < e.length && ("0#?.,E+-%".indexOf(r = e.charAt(++a)) > -1 || r == "\\" && e.charAt(a + 1) == "-" && "0#".indexOf(e.charAt(a + 2)) > -1); )
          ;
        break;
      case "?":
        for (; e.charAt(++a) === r; )
          ;
        break;
      case "*":
        ++a, (e.charAt(a) == " " || e.charAt(a) == "*") && ++a;
        break;
      case "(":
      case ")":
        ++a;
        break;
      case "1":
      case "2":
      case "3":
      case "4":
      case "5":
      case "6":
      case "7":
      case "8":
      case "9":
        for (; a < e.length && "0123456789".indexOf(e.charAt(++a)) > -1; )
          ;
        break;
      case " ":
        ++a;
        break;
      default:
        ++a;
        break;
    }
  return !1;
}
function Ac(e, a, r, t) {
  for (var n = [], i = "", c = 0, s = "", f = "t", o, l, v, x = "H"; c < e.length; )
    switch (s = e.charAt(c)) {
      case "G":
        if (!Pt(e, c)) throw new Error("unrecognized character " + s + " in " + e);
        n[n.length] = { t: "G", v: "General" }, c += 7;
        break;
      case '"':
        for (i = ""; (v = e.charCodeAt(++c)) !== 34 && c < e.length; ) i += String.fromCharCode(v);
        n[n.length] = { t: "t", v: i }, ++c;
        break;
      case "\\":
        var u = e.charAt(++c), p = u === "(" || u === ")" ? u : "t";
        n[n.length] = { t: p, v: u }, ++c;
        break;
      case "_":
        n[n.length] = { t: "t", v: " " }, c += 2;
        break;
      case "@":
        n[n.length] = { t: "T", v: a }, ++c;
        break;
      case "B":
      case "b":
        if (e.charAt(c + 1) === "1" || e.charAt(c + 1) === "2") {
          if (o == null && (o = jr(a, r, e.charAt(c + 1) === "2"), o == null))
            return "";
          n[n.length] = { t: "X", v: e.substr(c, 2) }, f = s, c += 2;
          break;
        }
      /* falls through */
      case "M":
      case "D":
      case "Y":
      case "H":
      case "S":
      case "E":
        s = s.toLowerCase();
      /* falls through */
      case "m":
      case "d":
      case "y":
      case "h":
      case "s":
      case "e":
      case "g":
        if (a < 0 || o == null && (o = jr(a, r), o == null))
          return "";
        for (i = s; ++c < e.length && e.charAt(c).toLowerCase() === s; ) i += s;
        s === "m" && f.toLowerCase() === "h" && (s = "M"), s === "h" && (s = x), n[n.length] = { t: s, v: i }, f = s;
        break;
      case "A":
      case "a":
      case "上":
        var _ = { t: s, v: s };
        if (o == null && (o = jr(a, r)), e.substr(c, 3).toUpperCase() === "A/P" ? (o != null && (_.v = o.H >= 12 ? e.charAt(c + 2) : s), _.t = "T", x = "h", c += 3) : e.substr(c, 5).toUpperCase() === "AM/PM" ? (o != null && (_.v = o.H >= 12 ? "PM" : "AM"), _.t = "T", c += 5, x = "h") : e.substr(c, 5).toUpperCase() === "上午/下午" ? (o != null && (_.v = o.H >= 12 ? "下午" : "上午"), _.t = "T", c += 5, x = "h") : (_.t = "t", ++c), o == null && _.t === "T") return "";
        n[n.length] = _, f = s;
        break;
      case "[":
        for (i = s; e.charAt(c++) !== "]" && c < e.length; ) i += e.charAt(c);
        if (i.slice(-1) !== "]") throw 'unterminated "[" block: |' + i + "|";
        if (i.match(di)) {
          if (o == null && (o = jr(a, r), o == null))
            return "";
          n[n.length] = { t: "Z", v: i.toLowerCase() }, f = i.charAt(1);
        } else i.indexOf("$") > -1 && (i = (i.match(/\$([^-\[\]]*)/) || [])[1] || "$", Ur(e) || (n[n.length] = { t: "t", v: i }));
        break;
      /* Numbers */
      case ".":
        if (o != null) {
          for (i = s; ++c < e.length && (s = e.charAt(c)) === "0"; ) i += s;
          n[n.length] = { t: "s", v: i };
          break;
        }
      /* falls through */
      case "0":
      case "#":
        for (i = s; ++c < e.length && "0#?.,E+-%".indexOf(s = e.charAt(c)) > -1; ) i += s;
        n[n.length] = { t: "n", v: i };
        break;
      case "?":
        for (i = s; e.charAt(++c) === s; ) i += s;
        n[n.length] = { t: s, v: i }, f = s;
        break;
      case "*":
        ++c, (e.charAt(c) == " " || e.charAt(c) == "*") && ++c;
        break;
      // **
      case "(":
      case ")":
        n[n.length] = { t: t === 1 ? "t" : s, v: s }, ++c;
        break;
      case "1":
      case "2":
      case "3":
      case "4":
      case "5":
      case "6":
      case "7":
      case "8":
      case "9":
        for (i = s; c < e.length && "0123456789".indexOf(e.charAt(++c)) > -1; ) i += e.charAt(c);
        n[n.length] = { t: "D", v: i };
        break;
      case " ":
        n[n.length] = { t: s, v: s }, ++c;
        break;
      case "$":
        n[n.length] = { t: "t", v: "$" }, ++c;
        break;
      default:
        if (",$-+/():!^&'~{}<>=€acfijklopqrtuvwxzP".indexOf(s) === -1) throw new Error("unrecognized character " + s + " in " + e);
        n[n.length] = { t: "t", v: s }, ++c;
        break;
    }
  var d = 0, h = 0, E;
  for (c = n.length - 1, f = "t"; c >= 0; --c)
    switch (n[c].t) {
      case "h":
      case "H":
        n[c].t = x, f = "h", d < 1 && (d = 1);
        break;
      case "s":
        (E = n[c].v.match(/\.0+$/)) && (h = Math.max(h, E[0].length - 1), d = 4), d < 3 && (d = 3);
      /* falls through */
      case "d":
      case "y":
      case "e":
        f = n[c].t;
        break;
      case "M":
        f = n[c].t, d < 2 && (d = 2);
        break;
      case "m":
        f === "s" && (n[c].t = "M", d < 2 && (d = 2));
        break;
      case "X":
        break;
      case "Z":
        d < 1 && n[c].v.match(/[Hh]/) && (d = 1), d < 2 && n[c].v.match(/[Mm]/) && (d = 2), d < 3 && n[c].v.match(/[Ss]/) && (d = 3);
    }
  var g;
  switch (d) {
    case 0:
      break;
    case 1:
    case 2:
    case 3:
      o.u >= 0.5 && (o.u = 0, ++o.S), o.S >= 60 && (o.S = 0, ++o.M), o.M >= 60 && (o.M = 0, ++o.H), o.H >= 24 && (o.H = 0, ++o.D, g = jr(o.D), g.u = o.u, g.S = o.S, g.M = o.M, g.H = o.H, o = g);
      break;
    case 4:
      switch (h) {
        case 1:
          o.u = Math.round(o.u * 10) / 10;
          break;
        case 2:
          o.u = Math.round(o.u * 100) / 100;
          break;
        case 3:
          o.u = Math.round(o.u * 1e3) / 1e3;
          break;
      }
      o.u >= 1 && (o.u = 0, ++o.S), o.S >= 60 && (o.S = 0, ++o.M), o.M >= 60 && (o.M = 0, ++o.H), o.H >= 24 && (o.H = 0, ++o.D, g = jr(o.D), g.u = o.u, g.S = o.S, g.M = o.M, g.H = o.H, o = g);
      break;
  }
  var C = "", P;
  for (c = 0; c < n.length; ++c)
    switch (n[c].t) {
      case "t":
      case "T":
      case " ":
      case "D":
        break;
      case "X":
        n[c].v = "", n[c].t = ";";
        break;
      case "d":
      case "m":
      case "y":
      case "h":
      case "H":
      case "M":
      case "s":
      case "e":
      case "b":
      case "Z":
        n[c].v = vc(n[c].t.charCodeAt(0), n[c].v, o, h), n[c].t = "t";
        break;
      case "n":
      case "?":
        for (P = c + 1; n[P] != null && ((s = n[P].t) === "?" || s === "D" || (s === " " || s === "t") && n[P + 1] != null && (n[P + 1].t === "?" || n[P + 1].t === "t" && n[P + 1].v === "/") || n[c].t === "(" && (s === " " || s === "n" || s === ")") || s === "t" && (n[P].v === "/" || n[P].v === " " && n[P + 1] != null && n[P + 1].t == "?")); )
          n[c].v += n[P].v, n[P] = { v: "", t: ";" }, ++P;
        C += n[c].v, c = P - 1;
        break;
      case "G":
        n[c].t = "t", n[c].v = Ea(a, r);
        break;
    }
  var M = "", I, N;
  if (C.length > 0) {
    C.charCodeAt(0) == 40 ? (I = a < 0 && C.charCodeAt(0) === 45 ? -a : a, N = ea("n", C, I)) : (I = a < 0 && t > 1 ? -a : a, N = ea("n", C, I), I < 0 && n[0] && n[0].t == "t" && (N = N.substr(1), n[0].v = "-" + n[0].v)), P = N.length - 1;
    var O = n.length;
    for (c = 0; c < n.length; ++c) if (n[c] != null && n[c].t != "t" && n[c].v.indexOf(".") > -1) {
      O = c;
      break;
    }
    var B = n.length;
    if (O === n.length && N.indexOf("E") === -1) {
      for (c = n.length - 1; c >= 0; --c)
        n[c] == null || "n?".indexOf(n[c].t) === -1 || (P >= n[c].v.length - 1 ? (P -= n[c].v.length, n[c].v = N.substr(P + 1, n[c].v.length)) : P < 0 ? n[c].v = "" : (n[c].v = N.substr(0, P + 1), P = -1), n[c].t = "t", B = c);
      P >= 0 && B < n.length && (n[B].v = N.substr(0, P + 1) + n[B].v);
    } else if (O !== n.length && N.indexOf("E") === -1) {
      for (P = N.indexOf(".") - 1, c = O; c >= 0; --c)
        if (!(n[c] == null || "n?".indexOf(n[c].t) === -1)) {
          for (l = n[c].v.indexOf(".") > -1 && c === O ? n[c].v.indexOf(".") - 1 : n[c].v.length - 1, M = n[c].v.substr(l + 1); l >= 0; --l)
            P >= 0 && (n[c].v.charAt(l) === "0" || n[c].v.charAt(l) === "#") && (M = N.charAt(P--) + M);
          n[c].v = M, n[c].t = "t", B = c;
        }
      for (P >= 0 && B < n.length && (n[B].v = N.substr(0, P + 1) + n[B].v), P = N.indexOf(".") + 1, c = O; c < n.length; ++c)
        if (!(n[c] == null || "n?(".indexOf(n[c].t) === -1 && c !== O)) {
          for (l = n[c].v.indexOf(".") > -1 && c === O ? n[c].v.indexOf(".") + 1 : 0, M = n[c].v.substr(0, l); l < n[c].v.length; ++l)
            P < N.length && (M += N.charAt(P++));
          n[c].v = M, n[c].t = "t", B = c;
        }
    }
  }
  for (c = 0; c < n.length; ++c) n[c] != null && "n?".indexOf(n[c].t) > -1 && (I = t > 1 && a < 0 && c > 0 && n[c - 1].v === "-" ? -a : a, n[c].v = ea(n[c].t, n[c].v, I), n[c].t = "t");
  var b = "";
  for (c = 0; c !== n.length; ++c) n[c] != null && (b += n[c].v);
  return b;
}
var cn = /\[(=|>[=]?|<[>=]?)(-?\d+(?:\.\d*)?)\]/;
function fn(e, a) {
  if (a == null) return !1;
  var r = parseFloat(a[2]);
  switch (a[1]) {
    case "=":
      if (e == r) return !0;
      break;
    case ">":
      if (e > r) return !0;
      break;
    case "<":
      if (e < r) return !0;
      break;
    case "<>":
      if (e != r) return !0;
      break;
    case ">=":
      if (e >= r) return !0;
      break;
    case "<=":
      if (e <= r) return !0;
      break;
  }
  return !1;
}
function yc(e, a) {
  var r = Fc(e), t = r.length, n = r[t - 1].indexOf("@");
  if (t < 4 && n > -1 && --t, r.length > 4) throw new Error("cannot find right format for |" + r.join("|") + "|");
  if (typeof a != "number") return [4, r.length === 4 || n > -1 ? r[r.length - 1] : "@"];
  switch (typeof a == "number" && !isFinite(a) && (a = 0), r.length) {
    case 1:
      r = n > -1 ? ["General", "General", "General", r[0]] : [r[0], r[0], r[0], "@"];
      break;
    case 2:
      r = n > -1 ? [r[0], r[0], r[0], r[1]] : [r[0], r[1], r[0], "@"];
      break;
    case 3:
      r = n > -1 ? [r[0], r[1], r[0], r[2]] : [r[0], r[1], r[2], "@"];
      break;
  }
  var i = a > 0 ? r[0] : a < 0 ? r[1] : r[2];
  if (r[0].indexOf("[") === -1 && r[1].indexOf("[") === -1) return [t, i];
  if (r[0].match(/\[[=<>]/) != null || r[1].match(/\[[=<>]/) != null) {
    var c = r[0].match(cn), s = r[1].match(cn);
    return fn(a, c) ? [t, r[0]] : fn(a, s) ? [t, r[1]] : [t, r[c != null && s != null ? 2 : 1]];
  }
  return [t, i];
}
function Fr(e, a, r) {
  r == null && (r = {});
  var t = "";
  switch (typeof e) {
    case "string":
      e == "m/d/yy" && r.dateNF ? t = r.dateNF : t = e;
      break;
    case "number":
      e == 14 && r.dateNF ? t = r.dateNF : t = (r.table != null ? r.table : ge)[e], t == null && (t = r.table && r.table[tn[e]] || ge[tn[e]]), t == null && (t = oc[e] || "General");
      break;
  }
  if (Pt(t, 0)) return Ea(a, r);
  a instanceof Date && (a = ar(a, r.date1904));
  var n = yc(t, a);
  if (Pt(n[1])) return Ea(a, r);
  if (a === !0) a = "TRUE";
  else if (a === !1) a = "FALSE";
  else {
    if (a === "" || a == null) return "";
    if (isNaN(a) && n[1].indexOf("0") > -1) return "#NUM!";
    if (!isFinite(a) && n[1].indexOf("0") > -1) return "#DIV/0!";
  }
  return Ac(n[1], a, r, n[0]);
}
function C0(e, a) {
  if (typeof a != "number") {
    a = +a || -1;
    for (var r = 0; r < 392; ++r) {
      if (ge[r] == null) {
        a < 0 && (a = r);
        continue;
      }
      if (ge[r] == e) {
        a = r;
        break;
      }
    }
    a < 0 && (a = 391);
  }
  return ge[a] = e, a;
}
function Sc(e) {
  for (var a = 0; a != 392; ++a)
    e[a] !== void 0 && C0(e[a], a);
}
function vi() {
  ge = fc();
}
var v0 = {
  format: Fr,
  load: C0,
  _table: ge,
  load_table: Sc,
  parse_date_code: jr,
  is_date: Ur,
  get_table: function() {
    return v0._table = ge;
  }
}, Cc = {
  5: '"$"#,##0_);\\("$"#,##0\\)',
  6: '"$"#,##0_);[Red]\\("$"#,##0\\)',
  7: '"$"#,##0.00_);\\("$"#,##0.00\\)',
  8: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
  23: "General",
  24: "General",
  25: "General",
  26: "General",
  27: "m/d/yy",
  28: "m/d/yy",
  29: "m/d/yy",
  30: "m/d/yy",
  31: "m/d/yy",
  32: "h:mm:ss",
  33: "h:mm:ss",
  34: "h:mm:ss",
  35: "h:mm:ss",
  36: "m/d/yy",
  41: '_(* #,##0_);_(* (#,##0);_(* "-"_);_(@_)',
  42: '_("$"* #,##0_);_("$"* (#,##0);_("$"* "-"_);_(@_)',
  43: '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)',
  44: '_("$"* #,##0.00_);_("$"* (#,##0.00);_("$"* "-"??_);_(@_)',
  50: "m/d/yy",
  51: "m/d/yy",
  52: "m/d/yy",
  53: "m/d/yy",
  54: "m/d/yy",
  55: "m/d/yy",
  56: "m/d/yy",
  57: "m/d/yy",
  58: "m/d/yy",
  59: "0",
  60: "0.00",
  61: "#,##0",
  62: "#,##0.00",
  63: '"$"#,##0_);\\("$"#,##0\\)',
  64: '"$"#,##0_);[Red]\\("$"#,##0\\)',
  65: '"$"#,##0.00_);\\("$"#,##0.00\\)',
  66: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
  67: "0%",
  68: "0.00%",
  69: "# ?/?",
  70: "# ??/??",
  71: "m/d/yy",
  72: "m/d/yy",
  73: "d-mmm-yy",
  74: "d-mmm",
  75: "mmm-yy",
  76: "h:mm",
  77: "h:mm:ss",
  78: "m/d/yy h:mm",
  79: "mm:ss",
  80: "[h]:mm:ss",
  81: "mmss.0"
}, Lt = /[dD]+|[mM]+|[yYeE]+|[Hh]+|[Ss]+/g;
function Dc(e) {
  var a = typeof e == "number" ? ge[e] : e;
  return a = a.replace(Lt, "(\\d+)"), Lt.lastIndex = 0, new RegExp("^" + a + "$");
}
function Ic(e, a, r) {
  var t = -1, n = -1, i = -1, c = -1, s = -1, f = -1;
  (a.match(Lt) || []).forEach(function(v, x) {
    var u = parseInt(r[x + 1], 10);
    switch (v.toLowerCase().charAt(0)) {
      case "y":
        t = u;
        break;
      case "d":
        i = u;
        break;
      case "h":
        c = u;
        break;
      case "s":
        f = u;
        break;
      case "m":
        c >= 0 ? s = u : n = u;
        break;
    }
  }), Lt.lastIndex = 0, f >= 0 && s == -1 && n >= 0 && (s = n, n = -1);
  var o = ("" + (t >= 0 ? t : (/* @__PURE__ */ new Date()).getFullYear())).slice(-4) + "-" + ("00" + (n >= 1 ? n : 1)).slice(-2) + "-" + ("00" + (i >= 1 ? i : 1)).slice(-2);
  o.length == 7 && (o = "0" + o), o.length == 8 && (o = "20" + o);
  var l = ("00" + (c >= 0 ? c : 0)).slice(-2) + ":" + ("00" + (s >= 0 ? s : 0)).slice(-2) + ":" + ("00" + (f >= 0 ? f : 0)).slice(-2);
  return c == -1 && s == -1 && f == -1 ? o : t == -1 && n == -1 && i == -1 ? l : o + "T" + l;
}
var Oc = {
  "d.m": "d\\.m"
  // Issue #2571 Google Sheets writes invalid format 'd.m', correct format is 'd"."m' or 'd\\.m'
};
function ga(e, a) {
  return C0(Oc[e] || e, a);
}
var on = /* @__PURE__ */ (function() {
  var e = {};
  e.version = "1.2.0";
  function a() {
    for (var I = 0, N = new Array(256), O = 0; O != 256; ++O)
      I = O, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, N[O] = I;
    return typeof Int32Array < "u" ? new Int32Array(N) : N;
  }
  var r = a();
  function t(I) {
    var N = 0, O = 0, B = 0, b = typeof Int32Array < "u" ? new Int32Array(4096) : new Array(4096);
    for (B = 0; B != 256; ++B) b[B] = I[B];
    for (B = 0; B != 256; ++B)
      for (O = I[B], N = 256 + B; N < 4096; N += 256) O = b[N] = O >>> 8 ^ I[O & 255];
    var G = [];
    for (B = 1; B != 16; ++B) G[B - 1] = typeof Int32Array < "u" && typeof b.subarray == "function" ? b.subarray(B * 256, B * 256 + 256) : b.slice(B * 256, B * 256 + 256);
    return G;
  }
  var n = t(r), i = n[0], c = n[1], s = n[2], f = n[3], o = n[4], l = n[5], v = n[6], x = n[7], u = n[8], p = n[9], _ = n[10], d = n[11], h = n[12], E = n[13], g = n[14];
  function C(I, N) {
    for (var O = N ^ -1, B = 0, b = I.length; B < b; ) O = O >>> 8 ^ r[(O ^ I.charCodeAt(B++)) & 255];
    return ~O;
  }
  function P(I, N) {
    for (var O = N ^ -1, B = I.length - 15, b = 0; b < B; ) O = g[I[b++] ^ O & 255] ^ E[I[b++] ^ O >> 8 & 255] ^ h[I[b++] ^ O >> 16 & 255] ^ d[I[b++] ^ O >>> 24] ^ _[I[b++]] ^ p[I[b++]] ^ u[I[b++]] ^ x[I[b++]] ^ v[I[b++]] ^ l[I[b++]] ^ o[I[b++]] ^ f[I[b++]] ^ s[I[b++]] ^ c[I[b++]] ^ i[I[b++]] ^ r[I[b++]];
    for (B += 15; b < B; ) O = O >>> 8 ^ r[(O ^ I[b++]) & 255];
    return ~O;
  }
  function M(I, N) {
    for (var O = N ^ -1, B = 0, b = I.length, G = 0, z = 0; B < b; )
      G = I.charCodeAt(B++), G < 128 ? O = O >>> 8 ^ r[(O ^ G) & 255] : G < 2048 ? (O = O >>> 8 ^ r[(O ^ (192 | G >> 6 & 31)) & 255], O = O >>> 8 ^ r[(O ^ (128 | G & 63)) & 255]) : G >= 55296 && G < 57344 ? (G = (G & 1023) + 64, z = I.charCodeAt(B++) & 1023, O = O >>> 8 ^ r[(O ^ (240 | G >> 8 & 7)) & 255], O = O >>> 8 ^ r[(O ^ (128 | G >> 2 & 63)) & 255], O = O >>> 8 ^ r[(O ^ (128 | z >> 6 & 15 | (G & 3) << 4)) & 255], O = O >>> 8 ^ r[(O ^ (128 | z & 63)) & 255]) : (O = O >>> 8 ^ r[(O ^ (224 | G >> 12 & 15)) & 255], O = O >>> 8 ^ r[(O ^ (128 | G >> 6 & 63)) & 255], O = O >>> 8 ^ r[(O ^ (128 | G & 63)) & 255]);
    return ~O;
  }
  return e.table = r, e.bstr = C, e.buf = P, e.str = M, e;
})(), Oe = /* @__PURE__ */ (function() {
  var a = (
    /*::(*/
    {}
  );
  a.version = "1.2.2";
  function r(m, A) {
    for (var T = m.split("/"), k = A.split("/"), F = 0, S = 0, H = Math.min(T.length, k.length); F < H; ++F) {
      if (S = T[F].length - k[F].length) return S;
      if (T[F] != k[F]) return T[F] < k[F] ? -1 : 1;
    }
    return T.length - k.length;
  }
  function t(m) {
    if (m.charAt(m.length - 1) == "/") return m.slice(0, -1).indexOf("/") === -1 ? m : t(m.slice(0, -1));
    var A = m.lastIndexOf("/");
    return A === -1 ? m : m.slice(0, A + 1);
  }
  function n(m) {
    if (m.charAt(m.length - 1) == "/") return n(m.slice(0, -1));
    var A = m.lastIndexOf("/");
    return A === -1 ? m : m.slice(A + 1);
  }
  function i(m, A) {
    typeof A == "string" && (A = new Date(A));
    var T = A.getHours();
    T = T << 6 | A.getMinutes(), T = T << 5 | A.getSeconds() >>> 1, m.write_shift(2, T);
    var k = A.getFullYear() - 1980;
    k = k << 4 | A.getMonth() + 1, k = k << 5 | A.getDate(), m.write_shift(2, k);
  }
  function c(m) {
    var A = m.read_shift(2) & 65535, T = m.read_shift(2) & 65535, k = /* @__PURE__ */ new Date(), F = T & 31;
    T >>>= 5;
    var S = T & 15;
    T >>>= 4, k.setMilliseconds(0), k.setFullYear(T + 1980), k.setMonth(S - 1), k.setDate(F);
    var H = A & 31;
    A >>>= 5;
    var K = A & 63;
    return A >>>= 6, k.setHours(A), k.setMinutes(K), k.setSeconds(H << 1), k;
  }
  function s(m) {
    rr(m, 0);
    for (var A = (
      /*::(*/
      {}
    ), T = 0; m.l <= m.length - 4; ) {
      var k = m.read_shift(2), F = m.read_shift(2), S = m.l + F, H = {};
      switch (k) {
        /* UNIX-style Timestamps */
        case 21589:
          T = m.read_shift(1), T & 1 && (H.mtime = m.read_shift(4)), F > 5 && (T & 2 && (H.atime = m.read_shift(4)), T & 4 && (H.ctime = m.read_shift(4))), H.mtime && (H.mt = new Date(H.mtime * 1e3));
          break;
        /* ZIP64 Extended Information Field */
        case 1:
          {
            var K = m.read_shift(4), U = m.read_shift(4);
            H.usz = U * Math.pow(2, 32) + K, K = m.read_shift(4), U = m.read_shift(4), H.csz = U * Math.pow(2, 32) + K;
          }
          break;
      }
      m.l = S, A[k] = H;
    }
    return A;
  }
  var f;
  function o() {
    return f || (f = Rc);
  }
  function l(m, A) {
    if (m[0] == 80 && m[1] == 75) return J0(m, A);
    if ((m[0] | 32) == 109 && (m[1] | 32) == 105) return js(m, A);
    if (m.length < 512) throw new Error("CFB file size " + m.length + " < 512");
    var T = 3, k = 512, F = 0, S = 0, H = 0, K = 0, U = 0, W = [], V = (
      /*::(*/
      m.slice(0, 512)
    );
    rr(V, 0);
    var Z = v(V);
    switch (T = Z[0], T) {
      case 3:
        k = 512;
        break;
      case 4:
        k = 4096;
        break;
      case 0:
        if (Z[1] == 0) return J0(m, A);
      /* falls through */
      default:
        throw new Error("Major Version: Expected 3 or 4 saw " + T);
    }
    k !== 512 && (V = /*::(*/
    m.slice(0, k), rr(
      V,
      28
      /* blob.l */
    ));
    var ee = m.slice(0, k);
    x(V, T);
    var oe = V.read_shift(4, "i");
    if (T === 3 && oe !== 0) throw new Error("# Directory Sectors: Expected 0 saw " + oe);
    V.l += 4, H = V.read_shift(4, "i"), V.l += 4, V.chk("00100000", "Mini Stream Cutoff Size: "), K = V.read_shift(4, "i"), F = V.read_shift(4, "i"), U = V.read_shift(4, "i"), S = V.read_shift(4, "i");
    for (var q = -1, ae = 0; ae < 109 && (q = V.read_shift(4, "i"), !(q < 0)); ++ae)
      W[ae] = q;
    var we = u(m, k);
    d(U, S, we, k, W);
    var Ve = E(we, H, W, k);
    H < Ve.length && (Ve[H].name = "!Directory"), F > 0 && K !== z && (Ve[K].name = "!MiniFAT"), Ve[W[0]].name = "!FAT", Ve.fat_addrs = W, Ve.ssz = k;
    var Ge = {}, lr = [], Ha = [], Wa = [];
    g(H, Ve, we, lr, F, Ge, Ha, K), p(Ha, Wa, lr), lr.shift();
    var Va = {
      FileIndex: Ha,
      FullPaths: Wa
    };
    return A && A.raw && (Va.raw = { header: ee, sectors: we }), Va;
  }
  function v(m) {
    if (m[m.l] == 80 && m[m.l + 1] == 75) return [0, 0];
    m.chk(ce, "Header Signature: "), m.l += 16;
    var A = m.read_shift(2, "u");
    return [m.read_shift(2, "u"), A];
  }
  function x(m, A) {
    var T = 9;
    switch (m.l += 2, T = m.read_shift(2)) {
      case 9:
        if (A != 3) throw new Error("Sector Shift: Expected 9 saw " + T);
        break;
      case 12:
        if (A != 4) throw new Error("Sector Shift: Expected 12 saw " + T);
        break;
      default:
        throw new Error("Sector Shift: Expected 9 or 12 saw " + T);
    }
    m.chk("0600", "Mini Sector Shift: "), m.chk("000000000000", "Reserved: ");
  }
  function u(m, A) {
    for (var T = Math.ceil(m.length / A) - 1, k = [], F = 1; F < T; ++F) k[F - 1] = m.slice(F * A, (F + 1) * A);
    return k[T - 1] = m.slice(T * A), k;
  }
  function p(m, A, T) {
    for (var k = 0, F = 0, S = 0, H = 0, K = 0, U = T.length, W = [], V = []; k < U; ++k)
      W[k] = V[k] = k, A[k] = T[k];
    for (; K < V.length; ++K)
      k = V[K], F = m[k].L, S = m[k].R, H = m[k].C, W[k] === k && (F !== -1 && W[F] !== F && (W[k] = W[F]), S !== -1 && W[S] !== S && (W[k] = W[S])), H !== -1 && (W[H] = k), F !== -1 && k != W[k] && (W[F] = W[k], V.lastIndexOf(F) < K && V.push(F)), S !== -1 && k != W[k] && (W[S] = W[k], V.lastIndexOf(S) < K && V.push(S));
    for (k = 1; k < U; ++k) W[k] === k && (S !== -1 && W[S] !== S ? W[k] = W[S] : F !== -1 && W[F] !== F && (W[k] = W[F]));
    for (k = 1; k < U; ++k)
      if (m[k].type !== 0) {
        if (K = k, K != W[K]) do
          K = W[K], A[k] = A[K] + "/" + A[k];
        while (K !== 0 && W[K] !== -1 && K != W[K]);
        W[k] = -1;
      }
    for (A[0] += "/", k = 1; k < U; ++k)
      m[k].type !== 2 && (A[k] += "/");
  }
  function _(m, A, T) {
    for (var k = m.start, F = m.size, S = [], H = k; T && F > 0 && H >= 0; )
      S.push(A.slice(H * G, H * G + G)), F -= G, H = pa(T, H * 4);
    return S.length === 0 ? Qe(0) : ia(S).slice(0, m.size);
  }
  function d(m, A, T, k, F) {
    var S = z;
    if (m === z) {
      if (A !== 0) throw new Error("DIFAT chain shorter than expected");
    } else if (m !== -1) {
      var H = T[m], K = (k >>> 2) - 1;
      if (!H) return;
      for (var U = 0; U < K && (S = pa(H, U * 4)) !== z; ++U)
        F.push(S);
      A >= 1 && d(pa(H, k - 4), A - 1, T, k, F);
    }
  }
  function h(m, A, T, k, F) {
    var S = [], H = [];
    F || (F = []);
    var K = k - 1, U = 0, W = 0;
    for (U = A; U >= 0; ) {
      F[U] = !0, S[S.length] = U, H.push(m[U]);
      var V = T[Math.floor(U * 4 / k)];
      if (W = U * 4 & K, k < 4 + W) throw new Error("FAT boundary crossed: " + U + " 4 " + k);
      if (!m[V]) break;
      U = pa(m[V], W);
    }
    return { nodes: S, data: gn([H]) };
  }
  function E(m, A, T, k) {
    var F = m.length, S = [], H = [], K = [], U = [], W = k - 1, V = 0, Z = 0, ee = 0, oe = 0;
    for (V = 0; V < F; ++V)
      if (K = [], ee = V + A, ee >= F && (ee -= F), !H[ee]) {
        U = [];
        var q = [];
        for (Z = ee; Z >= 0; ) {
          q[Z] = !0, H[Z] = !0, K[K.length] = Z, U.push(m[Z]);
          var ae = T[Math.floor(Z * 4 / k)];
          if (oe = Z * 4 & W, k < 4 + oe) throw new Error("FAT boundary crossed: " + Z + " 4 " + k);
          if (!m[ae] || (Z = pa(m[ae], oe), q[Z])) break;
        }
        S[ee] = { nodes: K, data: gn([U]) };
      }
    return S;
  }
  function g(m, A, T, k, F, S, H, K) {
    for (var U = 0, W = k.length ? 2 : 0, V = A[m].data, Z = 0, ee = 0, oe; Z < V.length; Z += 128) {
      var q = (
        /*::(*/
        V.slice(Z, Z + 128)
      );
      rr(q, 64), ee = q.read_shift(2), oe = N0(q, 0, ee - W), k.push(oe);
      var ae = {
        name: oe,
        type: q.read_shift(1),
        color: q.read_shift(1),
        L: q.read_shift(4, "i"),
        R: q.read_shift(4, "i"),
        C: q.read_shift(4, "i"),
        clsid: q.read_shift(16),
        state: q.read_shift(4, "i"),
        start: 0,
        size: 0
      }, we = q.read_shift(2) + q.read_shift(2) + q.read_shift(2) + q.read_shift(2);
      we !== 0 && (ae.ct = C(q, q.l - 8));
      var Ve = q.read_shift(2) + q.read_shift(2) + q.read_shift(2) + q.read_shift(2);
      Ve !== 0 && (ae.mt = C(q, q.l - 8)), ae.start = q.read_shift(4, "i"), ae.size = q.read_shift(4, "i"), ae.size < 0 && ae.start < 0 && (ae.size = ae.type = 0, ae.start = z, ae.name = ""), ae.type === 5 ? (U = ae.start, F > 0 && U !== z && (A[U].name = "!StreamData")) : ae.size >= 4096 ? (ae.storage = "fat", A[ae.start] === void 0 && (A[ae.start] = h(T, ae.start, A.fat_addrs, A.ssz)), A[ae.start].name = ae.name, ae.content = A[ae.start].data.slice(0, ae.size)) : (ae.storage = "minifat", ae.size < 0 ? ae.size = 0 : U !== z && ae.start !== z && A[U] && (ae.content = _(ae, A[U].data, (A[K] || {}).data))), ae.content && rr(ae.content, 0), S[oe] = ae, H.push(ae);
    }
  }
  function C(m, A) {
    return new Date((Ir(m, A + 4) / 1e7 * Math.pow(2, 32) + Ir(m, A) / 1e7 - 11644473600) * 1e3);
  }
  function P(m, A) {
    return o(), l(f.readFileSync(m), A);
  }
  function M(m, A) {
    var T = A && A.type;
    switch (T || ye && Buffer.isBuffer(m) && (T = "buffer"), T || "base64") {
      case "file":
        return P(m, A);
      case "base64":
        return l(Dr(Rr(m)), A);
      case "binary":
        return l(Dr(m), A);
    }
    return l(
      /*::typeof blob == 'string' ? new Buffer(blob, 'utf-8') : */
      m,
      A
    );
  }
  function I(m, A) {
    var T = A || {}, k = T.root || "Root Entry";
    if (m.FullPaths || (m.FullPaths = []), m.FileIndex || (m.FileIndex = []), m.FullPaths.length !== m.FileIndex.length) throw new Error("inconsistent CFB structure");
    m.FullPaths.length === 0 && (m.FullPaths[0] = k + "/", m.FileIndex[0] = { name: k, type: 5 }), T.CLSID && (m.FileIndex[0].clsid = T.CLSID), N(m);
  }
  function N(m) {
    var A = "Sh33tJ5";
    if (!Oe.find(m, "/" + A)) {
      var T = Qe(4);
      T[0] = 55, T[1] = T[3] = 50, T[2] = 54, m.FileIndex.push({ name: A, type: 2, content: T, size: 4, L: 69, R: 69, C: 69 }), m.FullPaths.push(m.FullPaths[0] + A), O(m);
    }
  }
  function O(m, A) {
    I(m);
    for (var T = !1, k = !1, F = m.FullPaths.length - 1; F >= 0; --F) {
      var S = m.FileIndex[F];
      switch (S.type) {
        case 0:
          k ? T = !0 : (m.FileIndex.pop(), m.FullPaths.pop());
          break;
        case 1:
        case 2:
        case 5:
          k = !0, isNaN(S.R * S.L * S.C) && (T = !0), S.R > -1 && S.L > -1 && S.R == S.L && (T = !0);
          break;
        default:
          T = !0;
          break;
      }
    }
    if (!(!T && !A)) {
      var H = new Date(1987, 1, 19), K = 0, U = Object.create ? /* @__PURE__ */ Object.create(null) : {}, W = [];
      for (F = 0; F < m.FullPaths.length; ++F)
        U[m.FullPaths[F]] = !0, m.FileIndex[F].type !== 0 && W.push([m.FullPaths[F], m.FileIndex[F]]);
      for (F = 0; F < W.length; ++F) {
        var V = t(W[F][0]);
        for (k = U[V]; !k; ) {
          for (; t(V) && !U[t(V)]; ) V = t(V);
          W.push([V, {
            name: n(V).replace("/", ""),
            type: 1,
            clsid: he,
            ct: H,
            mt: H,
            content: null
          }]), U[V] = !0, V = t(W[F][0]), k = U[V];
        }
      }
      for (W.sort(function(oe, q) {
        return r(oe[0], q[0]);
      }), m.FullPaths = [], m.FileIndex = [], F = 0; F < W.length; ++F)
        m.FullPaths[F] = W[F][0], m.FileIndex[F] = W[F][1];
      for (F = 0; F < W.length; ++F) {
        var Z = m.FileIndex[F], ee = m.FullPaths[F];
        if (Z.name = n(ee).replace("/", ""), Z.L = Z.R = Z.C = -(Z.color = 1), Z.size = Z.content ? Z.content.length : 0, Z.start = 0, Z.clsid = Z.clsid || he, F === 0)
          Z.C = W.length > 1 ? 1 : -1, Z.size = 0, Z.type = 5;
        else if (ee.slice(-1) == "/") {
          for (K = F + 1; K < W.length && t(m.FullPaths[K]) != ee; ++K) ;
          for (Z.C = K >= W.length ? -1 : K, K = F + 1; K < W.length && t(m.FullPaths[K]) != t(ee); ++K) ;
          Z.R = K >= W.length ? -1 : K, Z.type = 1;
        } else
          t(m.FullPaths[F + 1] || "") == t(ee) && (Z.R = F + 1), Z.type = 2;
      }
    }
  }
  function B(m, A) {
    var T = A || {};
    if (T.fileType == "mad") return Js(m, T);
    switch (O(m), T.fileType) {
      case "zip":
        return Gs(m, T);
    }
    var k = (function(oe) {
      for (var q = 0, ae = 0, we = 0; we < oe.FileIndex.length; ++we) {
        var Ve = oe.FileIndex[we];
        if (Ve.content) {
          var Ge = Ve.content.length;
          Ge > 0 && (Ge < 4096 ? q += Ge + 63 >> 6 : ae += Ge + 511 >> 9);
        }
      }
      for (var lr = oe.FullPaths.length + 3 >> 2, Ha = q + 7 >> 3, Wa = q + 127 >> 7, Va = Ha + ae + lr + Wa, da = Va + 127 >> 7, n0 = da <= 109 ? 0 : Math.ceil((da - 109) / 127); Va + da + n0 + 127 >> 7 > da; ) n0 = ++da <= 109 ? 0 : Math.ceil((da - 109) / 127);
      var Zr = [1, n0, da, Wa, lr, ae, q, 0];
      return oe.FileIndex[0].size = q << 6, Zr[7] = (oe.FileIndex[0].start = Zr[0] + Zr[1] + Zr[2] + Zr[3] + Zr[4] + Zr[5]) + (Zr[6] + 7 >> 3), Zr;
    })(m), F = Qe(k[7] << 9), S = 0, H = 0;
    {
      for (S = 0; S < 8; ++S) F.write_shift(1, j[S]);
      for (S = 0; S < 8; ++S) F.write_shift(2, 0);
      for (F.write_shift(2, 62), F.write_shift(2, 3), F.write_shift(2, 65534), F.write_shift(2, 9), F.write_shift(2, 6), S = 0; S < 3; ++S) F.write_shift(2, 0);
      for (F.write_shift(4, 0), F.write_shift(4, k[2]), F.write_shift(4, k[0] + k[1] + k[2] + k[3] - 1), F.write_shift(4, 0), F.write_shift(4, 4096), F.write_shift(4, k[3] ? k[0] + k[1] + k[2] - 1 : z), F.write_shift(4, k[3]), F.write_shift(-4, k[1] ? k[0] - 1 : z), F.write_shift(4, k[1]), S = 0; S < 109; ++S) F.write_shift(-4, S < k[2] ? k[1] + S : -1);
    }
    if (k[1])
      for (H = 0; H < k[1]; ++H) {
        for (; S < 236 + H * 127; ++S) F.write_shift(-4, S < k[2] ? k[1] + S : -1);
        F.write_shift(-4, H === k[1] - 1 ? z : H + 1);
      }
    var K = function(oe) {
      for (H += oe; S < H - 1; ++S) F.write_shift(-4, S + 1);
      oe && (++S, F.write_shift(-4, z));
    };
    for (H = S = 0, H += k[1]; S < H; ++S) F.write_shift(-4, J.DIFSECT);
    for (H += k[2]; S < H; ++S) F.write_shift(-4, J.FATSECT);
    K(k[3]), K(k[4]);
    for (var U = 0, W = 0, V = m.FileIndex[0]; U < m.FileIndex.length; ++U)
      V = m.FileIndex[U], V.content && (W = V.content.length, !(W < 4096) && (V.start = H, K(W + 511 >> 9)));
    for (K(k[6] + 7 >> 3); F.l & 511; ) F.write_shift(-4, J.ENDOFCHAIN);
    for (H = S = 0, U = 0; U < m.FileIndex.length; ++U)
      V = m.FileIndex[U], V.content && (W = V.content.length, !(!W || W >= 4096) && (V.start = H, K(W + 63 >> 6)));
    for (; F.l & 511; ) F.write_shift(-4, J.ENDOFCHAIN);
    for (S = 0; S < k[4] << 2; ++S) {
      var Z = m.FullPaths[S];
      if (!Z || Z.length === 0) {
        for (U = 0; U < 17; ++U) F.write_shift(4, 0);
        for (U = 0; U < 3; ++U) F.write_shift(4, -1);
        for (U = 0; U < 12; ++U) F.write_shift(4, 0);
        continue;
      }
      V = m.FileIndex[S], S === 0 && (V.start = V.size ? V.start - 1 : z);
      var ee = S === 0 && T.root || V.name;
      if (ee.length > 31 && (console.error("Name " + ee + " will be truncated to " + ee.slice(0, 31)), ee = ee.slice(0, 31)), W = 2 * (ee.length + 1), F.write_shift(64, ee, "utf16le"), F.write_shift(2, W), F.write_shift(1, V.type), F.write_shift(1, V.color), F.write_shift(-4, V.L), F.write_shift(-4, V.R), F.write_shift(-4, V.C), V.clsid) F.write_shift(16, V.clsid, "hex");
      else for (U = 0; U < 4; ++U) F.write_shift(4, 0);
      F.write_shift(4, V.state || 0), F.write_shift(4, 0), F.write_shift(4, 0), F.write_shift(4, 0), F.write_shift(4, 0), F.write_shift(4, V.start), F.write_shift(4, V.size), F.write_shift(4, 0);
    }
    for (S = 1; S < m.FileIndex.length; ++S)
      if (V = m.FileIndex[S], V.size >= 4096)
        if (F.l = V.start + 1 << 9, ye && Buffer.isBuffer(V.content))
          V.content.copy(F, F.l, 0, V.size), F.l += V.size + 511 & -512;
        else {
          for (U = 0; U < V.size; ++U) F.write_shift(1, V.content[U]);
          for (; U & 511; ++U) F.write_shift(1, 0);
        }
    for (S = 1; S < m.FileIndex.length; ++S)
      if (V = m.FileIndex[S], V.size > 0 && V.size < 4096)
        if (ye && Buffer.isBuffer(V.content))
          V.content.copy(F, F.l, 0, V.size), F.l += V.size + 63 & -64;
        else {
          for (U = 0; U < V.size; ++U) F.write_shift(1, V.content[U]);
          for (; U & 63; ++U) F.write_shift(1, 0);
        }
    if (ye)
      F.l = F.length;
    else
      for (; F.l < F.length; ) F.write_shift(1, 0);
    return F;
  }
  function b(m, A) {
    var T = m.FullPaths.map(function(U) {
      return U.toUpperCase();
    }), k = T.map(function(U) {
      var W = U.split("/");
      return W[W.length - (U.slice(-1) == "/" ? 2 : 1)];
    }), F = !1;
    A.charCodeAt(0) === 47 ? (F = !0, A = T[0].slice(0, -1) + A) : F = A.indexOf("/") !== -1;
    var S = A.toUpperCase(), H = F === !0 ? T.indexOf(S) : k.indexOf(S);
    if (H !== -1) return m.FileIndex[H];
    var K = !S.match($a);
    for (S = S.replace(wr, ""), K && (S = S.replace($a, "!")), H = 0; H < T.length; ++H)
      if ((K ? T[H].replace($a, "!") : T[H]).replace(wr, "") == S || (K ? k[H].replace($a, "!") : k[H]).replace(wr, "") == S) return m.FileIndex[H];
    return null;
  }
  var G = 64, z = -2, ce = "d0cf11e0a1b11ae1", j = [208, 207, 17, 224, 161, 177, 26, 225], he = "00000000000000000000000000000000", J = {
    /* 2.1 Compund File Sector Numbers and Types */
    MAXREGSECT: -6,
    DIFSECT: -4,
    FATSECT: -3,
    ENDOFCHAIN: z,
    FREESECT: -1,
    /* 2.2 Compound File Header */
    HEADER_SIGNATURE: ce,
    HEADER_MINOR_VERSION: "3e00",
    MAXREGSID: -6,
    NOSTREAM: -1,
    HEADER_CLSID: he,
    /* 2.6.1 Compound File Directory Entry */
    EntryTypes: ["unknown", "storage", "stream", "lockbytes", "property", "root"]
  };
  function ne(m, A, T) {
    o();
    var k = B(m, T);
    f.writeFileSync(A, k);
  }
  function pe(m) {
    for (var A = new Array(m.length), T = 0; T < m.length; ++T) A[T] = String.fromCharCode(m[T]);
    return A.join("");
  }
  function X(m, A) {
    var T = B(m, A);
    switch (A && A.type || "buffer") {
      case "file":
        return o(), f.writeFileSync(A.filename, T), T;
      case "binary":
        return typeof T == "string" ? T : pe(T);
      case "base64":
        return Q0(typeof T == "string" ? T : pe(T));
      case "buffer":
        if (ye) return Buffer.isBuffer(T) ? T : ua(T);
      /* falls through */
      case "array":
        return typeof T == "string" ? Dr(T) : T;
    }
    return T;
  }
  var Te;
  function _e(m) {
    try {
      var A = m.InflateRaw, T = new A();
      if (T._processChunk(new Uint8Array([3, 0]), T._finishFlushFlag), T.bytesRead) Te = m;
      else throw new Error("zlib does not expose bytesRead");
    } catch (k) {
      console.error("cannot use native zlib: " + (k.message || k));
    }
  }
  function de(m, A) {
    if (!Te) return Y0(m, A);
    var T = Te.InflateRaw, k = new T(), F = k._processChunk(m.slice(m.l), k._finishFlushFlag);
    return m.l += k.bytesRead, F;
  }
  function fe(m) {
    return Te ? Te.deflateRawSync(m) : Er(m);
  }
  var ke = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], me = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258], Fe = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
  function y(m) {
    var A = (m << 1 | m << 11) & 139536 | (m << 5 | m << 15) & 558144;
    return (A >> 16 | A >> 8 | A) & 255;
  }
  for (var L = typeof Uint8Array < "u", R = L ? new Uint8Array(256) : [], D = 0; D < 256; ++D) R[D] = y(D);
  function Y(m, A) {
    var T = R[m & 255];
    return A <= 8 ? T >>> 8 - A : (T = T << 8 | R[m >> 8 & 255], A <= 16 ? T >>> 16 - A : (T = T << 8 | R[m >> 16 & 255], T >>> 24 - A));
  }
  function w(m, A) {
    var T = A & 7, k = A >>> 3;
    return (m[k] | (T <= 6 ? 0 : m[k + 1] << 8)) >>> T & 3;
  }
  function te(m, A) {
    var T = A & 7, k = A >>> 3;
    return (m[k] | (T <= 5 ? 0 : m[k + 1] << 8)) >>> T & 7;
  }
  function ie(m, A) {
    var T = A & 7, k = A >>> 3;
    return (m[k] | (T <= 4 ? 0 : m[k + 1] << 8)) >>> T & 15;
  }
  function Q(m, A) {
    var T = A & 7, k = A >>> 3;
    return (m[k] | (T <= 3 ? 0 : m[k + 1] << 8)) >>> T & 31;
  }
  function ve(m, A) {
    var T = A & 7, k = A >>> 3;
    return (m[k] | (T <= 1 ? 0 : m[k + 1] << 8)) >>> T & 127;
  }
  function xe(m, A, T) {
    var k = A & 7, F = A >>> 3, S = (1 << T) - 1, H = m[F] >>> k;
    return T < 8 - k || (H |= m[F + 1] << 8 - k, T < 16 - k) || (H |= m[F + 2] << 16 - k, T < 24 - k) || (H |= m[F + 3] << 24 - k), H & S;
  }
  function Ee(m, A, T) {
    var k = A & 7, F = A >>> 3;
    return k <= 5 ? m[F] |= (T & 7) << k : (m[F] |= T << k & 255, m[F + 1] = (T & 7) >> 8 - k), A + 3;
  }
  function Le(m, A, T) {
    var k = A & 7, F = A >>> 3;
    return T = (T & 1) << k, m[F] |= T, A + 1;
  }
  function He(m, A, T) {
    var k = A & 7, F = A >>> 3;
    return T <<= k, m[F] |= T & 255, T >>>= 8, m[F + 1] = T, A + 8;
  }
  function $e(m, A, T) {
    var k = A & 7, F = A >>> 3;
    return T <<= k, m[F] |= T & 255, T >>>= 8, m[F + 1] = T & 255, m[F + 2] = T >>> 8, A + 16;
  }
  function ue(m, A) {
    var T = m.length, k = 2 * T > A ? 2 * T : A + 5, F = 0;
    if (T >= A) return m;
    if (ye) {
      var S = en(k);
      if (m.copy) m.copy(S);
      else for (; F < m.length; ++F) S[F] = m[F];
      return S;
    } else if (L) {
      var H = new Uint8Array(k);
      if (H.set) H.set(m);
      else for (; F < T; ++F) H[F] = m[F];
      return H;
    }
    return m.length = k, m;
  }
  function De(m) {
    for (var A = new Array(m), T = 0; T < m; ++T) A[T] = 0;
    return A;
  }
  function re(m, A, T) {
    var k = 1, F = 0, S = 0, H = 0, K = 0, U = m.length, W = L ? new Uint16Array(32) : De(32);
    for (S = 0; S < 32; ++S) W[S] = 0;
    for (S = U; S < T; ++S) m[S] = 0;
    U = m.length;
    var V = L ? new Uint16Array(U) : De(U);
    for (S = 0; S < U; ++S)
      W[F = m[S]]++, k < F && (k = F), V[S] = 0;
    for (W[0] = 0, S = 1; S <= k; ++S) W[S + 16] = K = K + W[S - 1] << 1;
    for (S = 0; S < U; ++S)
      K = m[S], K != 0 && (V[S] = W[K + 16]++);
    var Z = 0;
    for (S = 0; S < U; ++S)
      if (Z = m[S], Z != 0)
        for (K = Y(V[S], k) >> k - Z, H = (1 << k + 4 - Z) - 1; H >= 0; --H)
          A[K | H << Z] = Z & 15 | S << 4;
    return k;
  }
  var yr = L ? new Uint16Array(512) : De(512), gr = L ? new Uint16Array(32) : De(32);
  if (!L) {
    for (var We = 0; We < 512; ++We) yr[We] = 0;
    for (We = 0; We < 32; ++We) gr[We] = 0;
  }
  (function() {
    for (var m = [], A = 0; A < 32; A++) m.push(5);
    re(m, gr, 32);
    var T = [];
    for (A = 0; A <= 143; A++) T.push(8);
    for (; A <= 255; A++) T.push(9);
    for (; A <= 279; A++) T.push(7);
    for (; A <= 287; A++) T.push(8);
    re(T, yr, 288);
  })();
  var Vr = /* @__PURE__ */ (function() {
    for (var A = L ? new Uint8Array(32768) : [], T = 0, k = 0; T < Fe.length - 1; ++T)
      for (; k < Fe[T + 1]; ++k) A[k] = T;
    for (; k < 32768; ++k) A[k] = 29;
    var F = L ? new Uint8Array(259) : [];
    for (T = 0, k = 0; T < me.length - 1; ++T)
      for (; k < me[T + 1]; ++k) F[k] = T;
    function S(K, U) {
      for (var W = 0; W < K.length; ) {
        var V = Math.min(65535, K.length - W), Z = W + V == K.length;
        for (U.write_shift(1, +Z), U.write_shift(2, V), U.write_shift(2, ~V & 65535); V-- > 0; ) U[U.l++] = K[W++];
      }
      return U.l;
    }
    function H(K, U) {
      for (var W = 0, V = 0, Z = L ? new Uint16Array(32768) : []; V < K.length; ) {
        var ee = (
          /* data.length - boff; */
          Math.min(65535, K.length - V)
        );
        if (ee < 10) {
          for (W = Ee(U, W, +(V + ee == K.length)), W & 7 && (W += 8 - (W & 7)), U.l = W / 8 | 0, U.write_shift(2, ee), U.write_shift(2, ~ee & 65535); ee-- > 0; ) U[U.l++] = K[V++];
          W = U.l * 8;
          continue;
        }
        W = Ee(U, W, +(V + ee == K.length) + 2);
        for (var oe = 0; ee-- > 0; ) {
          var q = K[V];
          oe = (oe << 5 ^ q) & 32767;
          var ae = -1, we = 0;
          if ((ae = Z[oe]) && (ae |= V & -32768, ae > V && (ae -= 32768), ae < V))
            for (; K[ae + we] == K[V + we] && we < 250; ) ++we;
          if (we > 2) {
            q = F[we], q <= 22 ? W = He(U, W, R[q + 1] >> 1) - 1 : (He(U, W, 3), W += 5, He(U, W, R[q - 23] >> 5), W += 3);
            var Ve = q < 8 ? 0 : q - 4 >> 2;
            Ve > 0 && ($e(U, W, we - me[q]), W += Ve), q = A[V - ae], W = He(U, W, R[q] >> 3), W -= 3;
            var Ge = q < 4 ? 0 : q - 2 >> 1;
            Ge > 0 && ($e(U, W, V - ae - Fe[q]), W += Ge);
            for (var lr = 0; lr < we; ++lr)
              Z[oe] = V & 32767, oe = (oe << 5 ^ K[V]) & 32767, ++V;
            ee -= we - 1;
          } else
            q <= 143 ? q = q + 48 : W = Le(U, W, 1), W = He(U, W, R[q]), Z[oe] = V & 32767, ++V;
        }
        W = He(U, W, 0) - 1;
      }
      return U.l = (W + 7) / 8 | 0, U.l;
    }
    return function(U, W) {
      return U.length < 8 ? S(U, W) : H(U, W);
    };
  })();
  function Er(m) {
    var A = Qe(50 + Math.floor(m.length * 1.1)), T = Vr(m, A);
    return A.slice(0, T);
  }
  var se = L ? new Uint16Array(32768) : De(32768), be = L ? new Uint16Array(32768) : De(32768), Ye = L ? new Uint16Array(128) : De(128), je = 1, Jr = 1;
  function xa(m, A) {
    var T = Q(m, A) + 257;
    A += 5;
    var k = Q(m, A) + 1;
    A += 5;
    var F = ie(m, A) + 4;
    A += 4;
    for (var S = 0, H = L ? new Uint8Array(19) : De(19), K = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], U = 1, W = L ? new Uint8Array(8) : De(8), V = L ? new Uint8Array(8) : De(8), Z = H.length, ee = 0; ee < F; ++ee)
      H[ke[ee]] = S = te(m, A), U < S && (U = S), W[S]++, A += 3;
    var oe = 0;
    for (W[0] = 0, ee = 1; ee <= U; ++ee) V[ee] = oe = oe + W[ee - 1] << 1;
    for (ee = 0; ee < Z; ++ee) (oe = H[ee]) != 0 && (K[ee] = V[oe]++);
    var q = 0;
    for (ee = 0; ee < Z; ++ee)
      if (q = H[ee], q != 0) {
        oe = R[K[ee]] >> 8 - q;
        for (var ae = (1 << 7 - q) - 1; ae >= 0; --ae) Ye[oe | ae << q] = q & 7 | ee << 3;
      }
    var we = [];
    for (U = 1; we.length < T + k; )
      switch (oe = Ye[ve(m, A)], A += oe & 7, oe >>>= 3) {
        case 16:
          for (S = 3 + w(m, A), A += 2, oe = we[we.length - 1]; S-- > 0; ) we.push(oe);
          break;
        case 17:
          for (S = 3 + te(m, A), A += 3; S-- > 0; ) we.push(0);
          break;
        case 18:
          for (S = 11 + ve(m, A), A += 7; S-- > 0; ) we.push(0);
          break;
        default:
          we.push(oe), U < oe && (U = oe);
          break;
      }
    var Ve = we.slice(0, T), Ge = we.slice(T);
    for (ee = T; ee < 286; ++ee) Ve[ee] = 0;
    for (ee = k; ee < 30; ++ee) Ge[ee] = 0;
    return je = re(Ve, se, 286), Jr = re(Ge, be, 30), A;
  }
  function mt(m, A) {
    if (m[0] == 3 && !(m[1] & 3))
      return [fa(A), 2];
    for (var T = 0, k = 0, F = en(A || 1 << 18), S = 0, H = F.length >>> 0, K = 0, U = 0; (k & 1) == 0; ) {
      if (k = te(m, T), T += 3, k >>> 1)
        k >> 1 == 1 ? (K = 9, U = 5) : (T = xa(m, T), K = je, U = Jr);
      else {
        T & 7 && (T += 8 - (T & 7));
        var W = m[T >>> 3] | m[(T >>> 3) + 1] << 8;
        if (T += 32, W > 0)
          for (!A && H < S + W && (F = ue(F, S + W), H = F.length); W-- > 0; )
            F[S++] = m[T >>> 3], T += 8;
        continue;
      }
      for (; ; ) {
        !A && H < S + 32767 && (F = ue(F, S + 32767), H = F.length);
        var V = xe(m, T, K), Z = k >>> 1 == 1 ? yr[V] : se[V];
        if (T += Z & 15, Z >>>= 4, (Z >>> 8 & 255) === 0) F[S++] = Z;
        else {
          if (Z == 256) break;
          Z -= 257;
          var ee = Z < 8 ? 0 : Z - 4 >> 2;
          ee > 5 && (ee = 0);
          var oe = S + me[Z];
          ee > 0 && (oe += xe(m, T, ee), T += ee), V = xe(m, T, U), Z = k >>> 1 == 1 ? gr[V] : be[V], T += Z & 15, Z >>>= 4;
          var q = Z < 4 ? 0 : Z - 2 >> 1, ae = Fe[Z];
          for (q > 0 && (ae += xe(m, T, q), T += q), !A && H < oe && (F = ue(F, oe + 100), H = F.length); S < oe; )
            F[S] = F[S - ae], ++S;
        }
      }
    }
    return A ? [F, T + 7 >>> 3] : [F.slice(0, S), T + 7 >>> 3];
  }
  function Y0(m, A) {
    var T = m.slice(m.l || 0), k = mt(T, A);
    return m.l += k[1], k[0];
  }
  function j0(m, A) {
    if (m)
      typeof console < "u" && console.error(A);
    else throw new Error(A);
  }
  function J0(m, A) {
    var T = (
      /*::(*/
      m
    );
    rr(T, 0);
    var k = [], F = [], S = {
      FileIndex: k,
      FullPaths: F
    };
    I(S, { root: A.root });
    for (var H = T.length - 4; (T[H] != 80 || T[H + 1] != 75 || T[H + 2] != 5 || T[H + 3] != 6) && H >= 0; ) --H;
    T.l = H + 4, T.l += 4;
    var K = T.read_shift(2);
    T.l += 6;
    var U = T.read_shift(4);
    for (T.l = U, H = 0; H < K; ++H) {
      T.l += 20;
      var W = T.read_shift(4), V = T.read_shift(4), Z = T.read_shift(2), ee = T.read_shift(2), oe = T.read_shift(2);
      T.l += 8;
      var q = T.read_shift(4), ae = s(
        /*::(*/
        T.slice(T.l + Z, T.l + Z + ee)
        /*:: :any)*/
      );
      T.l += Z + ee + oe;
      var we = T.l;
      T.l = q + 4, ae && ae[1] && ((ae[1] || {}).usz && (V = ae[1].usz), (ae[1] || {}).csz && (W = ae[1].csz)), Vs(T, W, V, S, ae), T.l = we;
    }
    return S;
  }
  function Vs(m, A, T, k, F) {
    m.l += 2;
    var S = m.read_shift(2), H = m.read_shift(2), K = c(m);
    if (S & 8257) throw new Error("Unsupported ZIP encryption");
    for (var U = m.read_shift(4), W = m.read_shift(4), V = m.read_shift(4), Z = m.read_shift(2), ee = m.read_shift(2), oe = "", q = 0; q < Z; ++q) oe += String.fromCharCode(m[m.l++]);
    if (ee) {
      var ae = s(
        /*::(*/
        m.slice(m.l, m.l + ee)
        /*:: :any)*/
      );
      (ae[21589] || {}).mt && (K = ae[21589].mt), (ae[1] || {}).usz && (V = ae[1].usz), (ae[1] || {}).csz && (W = ae[1].csz), F && ((F[21589] || {}).mt && (K = F[21589].mt), (F[1] || {}).usz && (V = F[1].usz), (F[1] || {}).csz && (W = F[1].csz));
    }
    m.l += ee;
    var we = m.slice(m.l, m.l + W);
    switch (H) {
      case 8:
        we = de(m, V);
        break;
      case 0:
        m.l += W;
        break;
      // TODO: scan for magic number
      default:
        throw new Error("Unsupported ZIP Compression method " + H);
    }
    var Ve = !1;
    S & 8 && (U = m.read_shift(4), U == 134695760 && (U = m.read_shift(4), Ve = !0), W = m.read_shift(4), V = m.read_shift(4)), W != A && j0(Ve, "Bad compressed size: " + A + " != " + W), V != T && j0(Ve, "Bad uncompressed size: " + T + " != " + V), t0(k, oe, we, { unsafe: !0, mt: K });
  }
  function Gs(m, A) {
    var T = A || {}, k = [], F = [], S = Qe(1), H = T.compression ? 8 : 0, K = 0, U = 0, W = 0, V = 0, Z = 0, ee = m.FullPaths[0], oe = ee, q = m.FileIndex[0], ae = [], we = 0;
    for (U = 1; U < m.FullPaths.length; ++U)
      if (oe = m.FullPaths[U].slice(ee.length), q = m.FileIndex[U], !(!q.size || !q.content || Array.isArray(q.content) && q.content.length == 0 || oe == "Sh33tJ5")) {
        var Ve = V, Ge = Qe(oe.length);
        for (W = 0; W < oe.length; ++W) Ge.write_shift(1, oe.charCodeAt(W) & 127);
        Ge = Ge.slice(0, Ge.l), ae[Z] = typeof q.content == "string" ? on.bstr(q.content, 0) : on.buf(
          /*::((*/
          q.content,
          0
        );
        var lr = typeof q.content == "string" ? Dr(q.content) : q.content;
        H == 8 && (lr = fe(lr)), S = Qe(30), S.write_shift(4, 67324752), S.write_shift(2, 20), S.write_shift(2, K), S.write_shift(2, H), q.mt ? i(S, q.mt) : S.write_shift(4, 0), S.write_shift(-4, ae[Z]), S.write_shift(4, lr.length), S.write_shift(
          4,
          /*::(*/
          q.content.length
        ), S.write_shift(2, Ge.length), S.write_shift(2, 0), V += S.length, k.push(S), V += Ge.length, k.push(Ge), V += lr.length, k.push(lr), S = Qe(46), S.write_shift(4, 33639248), S.write_shift(2, 0), S.write_shift(2, 20), S.write_shift(2, K), S.write_shift(2, H), S.write_shift(4, 0), S.write_shift(-4, ae[Z]), S.write_shift(4, lr.length), S.write_shift(
          4,
          /*::(*/
          q.content.length
        ), S.write_shift(2, Ge.length), S.write_shift(2, 0), S.write_shift(2, 0), S.write_shift(2, 0), S.write_shift(2, 0), S.write_shift(4, 0), S.write_shift(4, Ve), we += S.l, F.push(S), we += Ge.length, F.push(Ge), ++Z;
      }
    return S = Qe(22), S.write_shift(4, 101010256), S.write_shift(2, 0), S.write_shift(2, 0), S.write_shift(2, Z), S.write_shift(2, Z), S.write_shift(4, we), S.write_shift(4, V), S.write_shift(2, 0), ia([ia(k), ia(F), S]);
  }
  var _t = {
    htm: "text/html",
    xml: "text/xml",
    gif: "image/gif",
    jpg: "image/jpeg",
    png: "image/png",
    mso: "application/x-mso",
    thmx: "application/vnd.ms-officetheme",
    sh33tj5: "application/octet-stream"
  };
  function $s(m, A) {
    if (m.ctype) return m.ctype;
    var T = m.name || "", k = T.match(/\.([^\.]+)$/);
    return k && _t[k[1]] || A && (k = (T = A).match(/[\.\\]([^\.\\])+$/), k && _t[k[1]]) ? _t[k[1]] : "application/octet-stream";
  }
  function Xs(m) {
    for (var A = Q0(m), T = [], k = 0; k < A.length; k += 76) T.push(A.slice(k, k + 76));
    return T.join(`\r
`) + `\r
`;
  }
  function zs(m) {
    var A = m.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7E-\xFF=]/g, function(W) {
      var V = W.charCodeAt(0).toString(16).toUpperCase();
      return "=" + (V.length == 1 ? "0" + V : V);
    });
    A = A.replace(/ $/mg, "=20").replace(/\t$/mg, "=09"), A.charAt(0) == `
` && (A = "=0D" + A.slice(1)), A = A.replace(/\r(?!\n)/mg, "=0D").replace(/\n\n/mg, `
=0A`).replace(/([^\r\n])\n/mg, "$1=0A");
    for (var T = [], k = A.split(`\r
`), F = 0; F < k.length; ++F) {
      var S = k[F];
      if (S.length == 0) {
        T.push("");
        continue;
      }
      for (var H = 0; H < S.length; ) {
        var K = 76, U = S.slice(H, H + K);
        U.charAt(K - 1) == "=" ? K-- : U.charAt(K - 2) == "=" ? K -= 2 : U.charAt(K - 3) == "=" && (K -= 3), U = S.slice(H, H + K), H += K, H < S.length && (U += "="), T.push(U);
      }
    }
    return T.join(`\r
`);
  }
  function Ks(m) {
    for (var A = [], T = 0; T < m.length; ++T) {
      for (var k = m[T]; T <= m.length && k.charAt(k.length - 1) == "="; ) k = k.slice(0, k.length - 1) + m[++T];
      A.push(k);
    }
    for (var F = 0; F < A.length; ++F) A[F] = A[F].replace(/[=][0-9A-Fa-f]{2}/g, function(S) {
      return String.fromCharCode(parseInt(S.slice(1), 16));
    });
    return Dr(A.join(`\r
`));
  }
  function Ys(m, A, T) {
    for (var k = "", F = "", S = "", H, K = 0; K < 10; ++K) {
      var U = A[K];
      if (!U || U.match(/^\s*$/)) break;
      var W = U.match(/^([^:]*?):\s*([^\s].*)$/);
      if (W) switch (W[1].toLowerCase()) {
        case "content-location":
          k = W[2].trim();
          break;
        case "content-type":
          S = W[2].trim();
          break;
        case "content-transfer-encoding":
          F = W[2].trim();
          break;
      }
    }
    switch (++K, F.toLowerCase()) {
      case "base64":
        H = Dr(Rr(A.slice(K).join("")));
        break;
      case "quoted-printable":
        H = Ks(A.slice(K));
        break;
      default:
        throw new Error("Unsupported Content-Transfer-Encoding " + F);
    }
    var V = t0(m, k.slice(T.length), H, { unsafe: !0 });
    S && (V.ctype = S);
  }
  function js(m, A) {
    if (pe(m.slice(0, 13)).toLowerCase() != "mime-version:") throw new Error("Unsupported MAD header");
    var T = A && A.root || "", k = (ye && Buffer.isBuffer(m) ? m.toString("binary") : pe(m)).split(`\r
`), F = 0, S = "";
    for (F = 0; F < k.length; ++F)
      if (S = k[F], !!/^Content-Location:/i.test(S) && (S = S.slice(S.indexOf("file")), T || (T = S.slice(0, S.lastIndexOf("/") + 1)), S.slice(0, T.length) != T))
        for (; T.length > 0 && (T = T.slice(0, T.length - 1), T = T.slice(0, T.lastIndexOf("/") + 1), S.slice(0, T.length) != T); )
          ;
    var H = (k[1] || "").match(/boundary="(.*?)"/);
    if (!H) throw new Error("MAD cannot find boundary");
    var K = "--" + (H[1] || ""), U = [], W = [], V = {
      FileIndex: U,
      FullPaths: W
    };
    I(V);
    var Z, ee = 0;
    for (F = 0; F < k.length; ++F) {
      var oe = k[F];
      oe !== K && oe !== K + "--" || (ee++ && Ys(V, k.slice(Z, F), T), Z = F);
    }
    return V;
  }
  function Js(m, A) {
    var T = A || {}, k = T.boundary || "SheetJS";
    k = "------=" + k;
    for (var F = [
      "MIME-Version: 1.0",
      'Content-Type: multipart/related; boundary="' + k.slice(2) + '"',
      "",
      "",
      ""
    ], S = m.FullPaths[0], H = S, K = m.FileIndex[0], U = 1; U < m.FullPaths.length; ++U)
      if (H = m.FullPaths[U].slice(S.length), K = m.FileIndex[U], !(!K.size || !K.content || H == "Sh33tJ5")) {
        H = H.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7E-\xFF]/g, function(we) {
          return "_x" + we.charCodeAt(0).toString(16) + "_";
        }).replace(/[\u0080-\uFFFF]/g, function(we) {
          return "_u" + we.charCodeAt(0).toString(16) + "_";
        });
        for (var W = K.content, V = ye && Buffer.isBuffer(W) ? W.toString("binary") : pe(W), Z = 0, ee = Math.min(1024, V.length), oe = 0, q = 0; q <= ee; ++q) (oe = V.charCodeAt(q)) >= 32 && oe < 128 && ++Z;
        var ae = Z >= ee * 4 / 5;
        F.push(k), F.push("Content-Location: " + (T.root || "file:///C:/SheetJS/") + H), F.push("Content-Transfer-Encoding: " + (ae ? "quoted-printable" : "base64")), F.push("Content-Type: " + $s(K, H)), F.push(""), F.push(ae ? zs(V) : Xs(V));
      }
    return F.push(k + `--\r
`), F.join(`\r
`);
  }
  function Zs(m) {
    var A = {};
    return I(A, m), A;
  }
  function t0(m, A, T, k) {
    var F = k && k.unsafe;
    F || I(m);
    var S = !F && Oe.find(m, A);
    if (!S) {
      var H = m.FullPaths[0];
      A.slice(0, H.length) == H ? H = A : (H.slice(-1) != "/" && (H += "/"), H = (H + A).replace("//", "/")), S = { name: n(A), type: 2 }, m.FileIndex.push(S), m.FullPaths.push(H), F || Oe.utils.cfb_gc(m);
    }
    return S.content = T, S.size = T ? T.length : 0, k && (k.CLSID && (S.clsid = k.CLSID), k.mt && (S.mt = k.mt), k.ct && (S.ct = k.ct)), S;
  }
  function qs(m, A) {
    I(m);
    var T = Oe.find(m, A);
    if (T) {
      for (var k = 0; k < m.FileIndex.length; ++k) if (m.FileIndex[k] == T)
        return m.FileIndex.splice(k, 1), m.FullPaths.splice(k, 1), !0;
    }
    return !1;
  }
  function Qs(m, A, T) {
    I(m);
    var k = Oe.find(m, A);
    if (k) {
      for (var F = 0; F < m.FileIndex.length; ++F) if (m.FileIndex[F] == k)
        return m.FileIndex[F].name = n(T), m.FullPaths[F] = T, !0;
    }
    return !1;
  }
  function ec(m) {
    O(m, !0);
  }
  return a.find = b, a.read = M, a.parse = l, a.write = X, a.writeFile = ne, a.utils = {
    cfb_new: Zs,
    cfb_add: t0,
    cfb_del: qs,
    cfb_mov: Qs,
    cfb_gc: ec,
    ReadShift: Ka,
    CheckField: Ui,
    prep_blob: rr,
    bconcat: ia,
    use_zlib: _e,
    _deflateRaw: Er,
    _inflateRaw: Y0,
    consts: J
  }, a;
})(), Rc;
function Nc(e) {
  if (typeof Deno < "u") return Deno.readFileSync(e);
  if (typeof $ < "u" && typeof File < "u" && typeof Folder < "u") try {
    var a = File(e);
    a.open("r"), a.encoding = "binary";
    var r = a.read();
    return a.close(), r;
  } catch (t) {
    if (!t.message || t.message.indexOf("onstruct") == -1) throw t;
  }
  throw new Error("Cannot access file " + e);
}
function Br(e) {
  for (var a = Object.keys(e), r = [], t = 0; t < a.length; ++t) Object.prototype.hasOwnProperty.call(e, a[t]) && r.push(a[t]);
  return r;
}
function D0(e) {
  for (var a = [], r = Br(e), t = 0; t !== r.length; ++t) a[e[r[t]]] = r[t];
  return a;
}
var pi = /* @__PURE__ */ Date.UTC(1899, 11, 30, 0, 0, 0), Pc = /* @__PURE__ */ Date.UTC(1899, 11, 31, 0, 0, 0), bc = /* @__PURE__ */ Date.UTC(1904, 0, 1, 0, 0, 0);
function ar(e, a) {
  var r = /* @__PURE__ */ e.getTime(), t = (r - pi) / (1440 * 60 * 1e3);
  return a ? (t -= 1462, t < -1402 ? t - 1 : t) : t < 60 ? t - 1 : t;
}
function ca(e) {
  if (e >= 60 && e < 61) return e;
  var a = /* @__PURE__ */ new Date();
  return a.setTime((e > 60 ? e : e + 1) * 24 * 60 * 60 * 1e3 + pi), a;
}
function Lc(e) {
  var a = 0, r = 0, t = !1, n = e.match(/P([0-9\.]+Y)?([0-9\.]+M)?([0-9\.]+D)?T([0-9\.]+H)?([0-9\.]+M)?([0-9\.]+S)?/);
  if (!n) throw new Error("|" + e + "| is not an ISO8601 Duration");
  for (var i = 1; i != n.length; ++i)
    if (n[i]) {
      switch (r = 1, i > 3 && (t = !0), n[i].slice(n[i].length - 1)) {
        case "Y":
          throw new Error("Unsupported ISO Duration Field: " + n[i].slice(n[i].length - 1));
        case "D":
          r *= 24;
        /* falls through */
        case "H":
          r *= 60;
        /* falls through */
        case "M":
          if (t) r *= 60;
          else throw new Error("Unsupported ISO Duration Field: M");
      }
      a += r * parseInt(n[i], 10);
    }
  return a;
}
var Bc = /^(\d+):(\d+)(:\d+)?(\.\d+)?$/, Mc = /^(\d+)-(\d+)-(\d+)$/, gi = /^(\d+)-(\d+)-(\d+)[T ](\d+):(\d+)(:\d+)?(\.\d+)?$/;
function fr(e, a) {
  if (e instanceof Date) return e;
  var r = e.match(Bc);
  if (r) return new Date((a ? bc : Pc) + ((parseInt(r[1], 10) * 60 + parseInt(r[2], 10)) * 60 + (r[3] ? parseInt(r[3].slice(1), 10) : 0)) * 1e3 + (r[4] ? parseInt((r[4] + "000").slice(1, 4), 10) : 0));
  if (r = e.match(Mc), r) return new Date(Date.UTC(+r[1], +r[2] - 1, +r[3], 0, 0, 0, 0));
  if (r = e.match(gi), r) return new Date(Date.UTC(+r[1], +r[2] - 1, +r[3], +r[4], +r[5], r[6] && parseInt(r[6].slice(1), 10) || 0, r[7] && parseInt((r[7] + "0000").slice(1, 4), 10) || 0));
  var t = new Date(e);
  return t;
}
function ka(e, a) {
  if (ye && Buffer.isBuffer(e)) {
    if (a && tt) {
      if (e[0] == 255 && e[1] == 254) return Xa(e.slice(2).toString("utf16le"));
      if (e[1] == 254 && e[2] == 255) return Xa(si(e.slice(2).toString("binary")));
    }
    return e.toString("binary");
  }
  if (typeof TextDecoder < "u") try {
    if (a) {
      if (e[0] == 255 && e[1] == 254) return Xa(new TextDecoder("utf-16le").decode(e.slice(2)));
      if (e[0] == 254 && e[1] == 255) return Xa(new TextDecoder("utf-16be").decode(e.slice(2)));
    }
    var r = {
      "€": "",
      "‚": "",
      ƒ: "",
      "„": "",
      "…": "",
      "†": "",
      "‡": "",
      "ˆ": "",
      "‰": "",
      Š: "",
      "‹": "",
      Œ: "",
      Ž: "",
      "‘": "",
      "’": "",
      "“": "",
      "”": "",
      "•": "",
      "–": "",
      "—": "",
      "˜": "",
      "™": "",
      š: "",
      "›": "",
      œ: "",
      ž: "",
      Ÿ: ""
    };
    return Array.isArray(e) && (e = new Uint8Array(e)), new TextDecoder("latin1").decode(e).replace(/[€‚ƒ„…†‡ˆ‰Š‹ŒŽ‘’“”•–—˜™š›œžŸ]/g, function(i) {
      return r[i] || i;
    });
  } catch {
  }
  var t = [], n = 0;
  try {
    for (n = 0; n < e.length - 65536; n += 65536) t.push(String.fromCharCode.apply(0, e.slice(n, n + 65536)));
    t.push(String.fromCharCode.apply(0, e.slice(n)));
  } catch {
    try {
      for (; n < e.length - 16384; n += 16384) t.push(String.fromCharCode.apply(0, e.slice(n, n + 16384)));
      t.push(String.fromCharCode.apply(0, e.slice(n)));
    } catch {
      for (; n != e.length; ++n) t.push(String.fromCharCode(e[n]));
    }
  }
  return t.join("");
}
function er(e) {
  if (typeof JSON < "u" && !Array.isArray(e)) return JSON.parse(JSON.stringify(e));
  if (typeof e != "object" || e == null) return e;
  if (e instanceof Date) return new Date(e.getTime());
  var a = {};
  for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (a[r] = er(e[r]));
  return a;
}
function Ie(e, a) {
  for (var r = ""; r.length < a; ) r += e;
  return r;
}
function Or(e) {
  var a = Number(e);
  if (!isNaN(a)) return isFinite(a) ? a : NaN;
  if (!/\d/.test(e)) return a;
  var r = 1, t = e.replace(/([\d]),([\d])/g, "$1$2").replace(/[$]/g, "").replace(/[%]/g, function() {
    return r *= 100, "";
  });
  return !isNaN(a = Number(t)) || (t = t.replace(/[(]([^()]*)[)]/, function(n, i) {
    return r = -r, i;
  }), !isNaN(a = Number(t))) ? a / r : a;
}
var Uc = /^(0?\d|1[0-2])(?:|:([0-5]?\d)(?:|(\.\d+)(?:|:([0-5]?\d))|:([0-5]?\d)(|\.\d+)))\s+([ap])m?$/, Hc = /^([01]?\d|2[0-3])(?:|:([0-5]?\d)(?:|(\.\d+)(?:|:([0-5]?\d))|:([0-5]?\d)(|\.\d+)))$/, Wc = /^(\d+)-(\d+)-(\d+)[T ](\d+):(\d+)(:\d+)(\.\d+)?[Z]?$/, Vc = (/* @__PURE__ */ new Date("6/9/69 00:00 UTC")).valueOf() == -177984e5;
function Gc(e) {
  return e[2] ? e[3] ? e[4] ? new Date(Date.UTC(1899, 11, 31, +e[1] % 12 + (e[7] == "p" ? 12 : 0), +e[2], +e[4], parseFloat(e[3]) * 1e3)) : new Date(Date.UTC(1899, 11, 31, e[7] == "p" ? 12 : 0, +e[1], +e[2], parseFloat(e[3]) * 1e3)) : e[5] ? new Date(Date.UTC(1899, 11, 31, +e[1] % 12 + (e[7] == "p" ? 12 : 0), +e[2], +e[5], e[6] ? parseFloat(e[6]) * 1e3 : 0)) : new Date(Date.UTC(1899, 11, 31, +e[1] % 12 + (e[7] == "p" ? 12 : 0), +e[2], 0, 0)) : new Date(Date.UTC(1899, 11, 31, +e[1] % 12 + (e[7] == "p" ? 12 : 0), 0, 0, 0));
}
function $c(e) {
  return e[2] ? e[3] ? e[4] ? new Date(Date.UTC(1899, 11, 31, +e[1], +e[2], +e[4], parseFloat(e[3]) * 1e3)) : new Date(Date.UTC(1899, 11, 31, 0, +e[1], +e[2], parseFloat(e[3]) * 1e3)) : e[5] ? new Date(Date.UTC(1899, 11, 31, +e[1], +e[2], +e[5], e[6] ? parseFloat(e[6]) * 1e3 : 0)) : new Date(Date.UTC(1899, 11, 31, +e[1], +e[2], 0, 0)) : new Date(Date.UTC(1899, 11, 31, +e[1], 0, 0, 0));
}
var Xc = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
function it(e) {
  if (Wc.test(e)) return e.indexOf("Z") == -1 ? Yt(new Date(e)) : new Date(e);
  var a = e.toLowerCase(), r = a.replace(/\s+/g, " ").trim(), t = r.match(Uc);
  if (t) return Gc(t);
  if (t = r.match(Hc), t) return $c(t);
  if (t = r.match(gi), t) return new Date(Date.UTC(+t[1], +t[2] - 1, +t[3], +t[4], +t[5], t[6] && parseInt(t[6].slice(1), 10) || 0, t[7] && parseInt((t[7] + "0000").slice(1, 4), 10) || 0));
  var n = new Date(Vc && e.indexOf("UTC") == -1 ? e + " UTC" : e), i = /* @__PURE__ */ new Date(NaN), c = n.getYear();
  n.getMonth();
  var s = n.getDate();
  if (isNaN(s)) return i;
  if (a.match(/jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec/)) {
    if (a = a.replace(/[^a-z]/g, "").replace(/([^a-z]|^)[ap]m?([^a-z]|$)/, ""), a.length > 3 && Xc.indexOf(a) == -1) return i;
  } else if (a.replace(/[ap]m?/, "").match(/[a-z]/)) return i;
  return c < 0 || c > 8099 || e.match(/[^-0-9:,\/\\\ ]/) ? i : n;
}
var zc = /* @__PURE__ */ (function() {
  var e = "abacaba".split(/(:?b)/i).length == 5;
  return function(r, t, n) {
    if (e || typeof t == "string") return r.split(t);
    for (var i = r.split(t), c = [i[0]], s = 1; s < i.length; ++s)
      c.push(n), c.push(i[s]);
    return c;
  };
})();
function wa(e) {
  return new Date(e.getUTCFullYear(), e.getUTCMonth(), e.getUTCDate(), e.getUTCHours(), e.getUTCMinutes(), e.getUTCSeconds(), e.getUTCMilliseconds());
}
function Yt(e) {
  return new Date(Date.UTC(e.getFullYear(), e.getMonth(), e.getDate(), e.getHours(), e.getMinutes(), e.getSeconds(), e.getMilliseconds()));
}
function I0(e) {
  var a = e.slice(0, 1024), r = a.indexOf("<!DOCTYPE");
  if (r == -1) return e;
  var t = e.match(/<[\w]/);
  return t ? e.slice(0, r) + e.slice(t.index) : e;
}
function O0(e, a, r) {
  for (var t = [], n = e.indexOf(a); n > -1; ) {
    var i = e.indexOf(r, n + a.length);
    if (i == -1) break;
    t.push(e.slice(n, i + r.length)), n = e.indexOf(a, i + r.length);
  }
  return t.length > 0 ? t : null;
}
function ut(e, a, r) {
  var t = [], n = 0, i = e.indexOf(a);
  if (i == -1) return e;
  for (; i > -1; ) {
    t.push(e.slice(n, i));
    var c = e.indexOf(r, i + a.length);
    if (c == -1) break;
    (i = e.indexOf(a, n = c + r.length)) == -1 && t.push(e.slice(n));
  }
  return t.join("");
}
var Kc = { " ": 1, "	": 1, "\r": 1, "\n": 1, ">": 1 };
function ma(e, a) {
  for (var r = e.indexOf("<" + a), t = a.length + 1, n = e.length; r >= 0 && r <= n - t && !Kc[e.charAt(r + t)]; ) r = e.indexOf("<" + a, r + 1);
  if (r === -1) return null;
  var i = e.indexOf(">", r + a.length);
  if (i === -1) return null;
  var c = "</" + a + ">", s = e.indexOf(c, i);
  return s == -1 ? null : [e.slice(r, s + c.length), e.slice(i + 1, s)];
}
var ir = /* @__PURE__ */ (function() {
  var e = {};
  return function(r, t) {
    var n = e[t];
    n || (e[t] = n = [
      new RegExp("<(?:\\w+:)?" + t + "\\b[^<>]*>", "g"),
      new RegExp("</(?:\\w+:)?" + t + ">", "g")
    ]), n[0].lastIndex = n[1].lastIndex = 0;
    var i = n[0].exec(r);
    if (!i) return null;
    var c = i.index, s = n[0].lastIndex;
    if (n[1].lastIndex = n[0].lastIndex, i = n[1].exec(r), !i) return null;
    var f = i.index, o = n[1].lastIndex;
    return [r.slice(c, o), r.slice(s, f)];
  };
})(), mi = /* @__PURE__ */ (function() {
  var e = {};
  return function(r, t) {
    var n = [], i = e[t];
    i || (e[t] = i = [
      new RegExp("<(?:\\w+:)?" + t + "\\b[^<>]*>", "g"),
      new RegExp("</(?:\\w+:)?" + t + ">", "g")
    ]), i[0].lastIndex = i[1].lastIndex = 0;
    for (var c; c = i[0].exec(r); ) {
      var s = c.index;
      if (i[1].lastIndex = i[0].lastIndex, c = i[1].exec(r), !c) return null;
      var f = i[1].lastIndex;
      n.push(r.slice(s, f)), i[0].lastIndex = i[1].lastIndex;
    }
    return n.length == 0 ? null : n;
  };
})(), Yc = /* @__PURE__ */ (function() {
  var e = {};
  return function(r, t) {
    var n = [], i = e[t];
    i || (e[t] = i = [
      new RegExp("<(?:\\w+:)?" + t + "\\b[^<>]*>", "g"),
      new RegExp("</(?:\\w+:)?" + t + ">", "g")
    ]), i[0].lastIndex = i[1].lastIndex = 0;
    for (var c, s = 0, f = 0; c = i[0].exec(r); ) {
      if (s = c.index, n.push(r.slice(f, s)), f = s, i[1].lastIndex = i[0].lastIndex, c = i[1].exec(r), !c) return null;
      f = i[1].lastIndex, i[0].lastIndex = i[1].lastIndex;
    }
    return n.push(r.slice(f)), n.length == 0 ? "" : n.join("");
  };
})(), jc = /* @__PURE__ */ (function() {
  var e = {};
  return function(r, t) {
    var n = [], i = e[t];
    i || (e[t] = i = [
      new RegExp("<" + t + "\\b[^<>]*>", "ig"),
      new RegExp("</" + t + ">", "ig")
    ]), i[0].lastIndex = i[1].lastIndex = 0;
    for (var c; c = i[0].exec(r); ) {
      var s = c.index;
      if (i[1].lastIndex = i[0].lastIndex, c = i[1].exec(r), !c) return null;
      var f = i[1].lastIndex;
      n.push(r.slice(s, f)), i[0].lastIndex = i[1].lastIndex;
    }
    return n.length == 0 ? null : n;
  };
})();
function _i(e) {
  return e ? e.content && e.type ? ka(e.content, !0) : e.data ? Ga(e.data) : e.asNodeBuffer && ye ? Ga(e.asNodeBuffer().toString("binary")) : e.asBinary ? Ga(e.asBinary()) : e._data && e._data.getContent ? Ga(ka(Array.prototype.slice.call(e._data.getContent(), 0))) : null : null;
}
function Ti(e) {
  if (!e) return null;
  if (e.data) return Z0(e.data);
  if (e.asNodeBuffer && ye) return e.asNodeBuffer();
  if (e._data && e._data.getContent) {
    var a = e._data.getContent();
    return typeof a == "string" ? Z0(a) : Array.prototype.slice.call(a);
  }
  return e.content && e.type ? e.content : null;
}
function Jc(e) {
  return e && e.name.slice(-4) === ".bin" ? Ti(e) : _i(e);
}
function br(e, a) {
  for (var r = e.FullPaths || Br(e.files), t = a.toLowerCase().replace(/[\/]/g, "\\"), n = t.replace(/\\/g, "/"), i = 0; i < r.length; ++i) {
    var c = r[i].replace(/^Root Entry[\/]/, "").toLowerCase();
    if (t == c || n == c) return e.files ? e.files[r[i]] : e.FileIndex[i];
  }
  return null;
}
function R0(e, a) {
  var r = br(e, a);
  if (r == null) throw new Error("Cannot find file " + a + " in zip");
  return r;
}
function Ze(e, a, r) {
  if (!r) return Jc(R0(e, a));
  if (!a) return null;
  try {
    return Ze(e, a);
  } catch {
    return null;
  }
}
function Tr(e, a, r) {
  if (!r) return _i(R0(e, a));
  if (!a) return null;
  try {
    return Tr(e, a);
  } catch {
    return null;
  }
}
function Zc(e, a, r) {
  return Ti(R0(e, a));
}
function ln(e) {
  for (var a = e.FullPaths || Br(e.files), r = [], t = 0; t < a.length; ++t) a[t].slice(-1) != "/" && r.push(a[t].replace(/^Root Entry[\/]/, ""));
  return r.sort();
}
function qc(e, a, r) {
  if (e.FullPaths) {
    if (Array.isArray(r) && typeof r[0] == "string" && (r = r.join("")), typeof r == "string") {
      var t;
      return ye ? t = ua(r) : t = ic(r), Oe.utils.cfb_add(e, a, t);
    }
    Oe.utils.cfb_add(e, a, r);
  } else e.file(a, r);
}
function Ei(e, a) {
  switch (a.type) {
    case "base64":
      return Oe.read(e, { type: "base64" });
    case "binary":
      return Oe.read(e, { type: "binary" });
    case "buffer":
    case "array":
      return Oe.read(e, { type: "buffer" });
  }
  throw new Error("Unrecognized type " + a.type);
}
function Oa(e, a) {
  if (e.charAt(0) == "/") return e.slice(1);
  var r = a.split("/");
  a.slice(-1) != "/" && r.pop();
  for (var t = e.split("/"); t.length !== 0; ) {
    var n = t.shift();
    n === ".." ? r.pop() : n !== "." && r.push(n);
  }
  return r.join("/");
}
var ki = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r
`, wi = /\s([^"\s?>\/]+)\s*=\s*((?:")([^"]*)(?:")|(?:')([^']*)(?:')|([^'">\s]+))/g, un = /<[\/\?]?[a-zA-Z0-9:_-]+(?:\s+[^"\s?<>\/]+\s*=\s*(?:"[^"]*"|'[^']*'|[^'"<>\s=]+))*\s*[\/\?]?>/mg, Qc = /<[^<>]*>/g, or = /* @__PURE__ */ ki.match(un) ? un : Qc, ef = /<\w*:/, rf = /<(\/?)\w+:/;
function le(e, a, r) {
  for (var t = {}, n = 0, i = 0; n !== e.length && !((i = e.charCodeAt(n)) === 32 || i === 10 || i === 13); ++n) ;
  if (a || (t[0] = e.slice(0, n)), n === e.length) return t;
  var c = e.match(wi), s = 0, f = "", o = 0, l = "", v = "", x = 1;
  if (c) for (o = 0; o != c.length; ++o) {
    for (v = c[o].slice(1), i = 0; i != v.length && v.charCodeAt(i) !== 61; ++i) ;
    for (l = v.slice(0, i).trim(); v.charCodeAt(i + 1) == 32; ) ++i;
    for (x = (n = v.charCodeAt(i + 1)) == 34 || n == 39 ? 1 : 0, f = v.slice(i + 1 + x, v.length - x), s = 0; s != l.length && l.charCodeAt(s) !== 58; ++s) ;
    if (s === l.length)
      l.indexOf("_") > 0 && (l = l.slice(0, l.indexOf("_"))), t[l] = f, t[l.toLowerCase()] = f;
    else {
      var u = (s === 5 && l.slice(0, 5) === "xmlns" ? "xmlns" : "") + l.slice(s + 1);
      if (t[u] && l.slice(s - 3, s) == "ext") continue;
      t[u] = f, t[u.toLowerCase()] = f;
    }
  }
  return t;
}
function af(e, a, r) {
  for (var t = {}, n = 0, i = 0; n !== e.length && !((i = e.charCodeAt(n)) === 32 || i === 10 || i === 13); ++n) ;
  if (n === e.length) return t;
  var c = e.match(wi), s = "", f = 0, o = "", l = "", v = 1;
  if (c) for (f = 0; f != c.length; ++f) {
    for (l = c[f].slice(1), i = 0; i != l.length && l.charCodeAt(i) !== 61; ++i) ;
    for (o = l.slice(0, i).trim(); l.charCodeAt(i + 1) == 32; ) ++i;
    v = (n = l.charCodeAt(i + 1)) == 34 || n == 39 ? 1 : 0, s = l.slice(i + 1 + v, l.length - v), o.indexOf("_") > 0 && (o = o.slice(0, o.indexOf("_"))), t[o] = s, t[o.toLowerCase()] = s;
  }
  return t;
}
function Hr(e) {
  return e.replace(rf, "<$1");
}
var Fi = {
  "&quot;": '"',
  "&apos;": "'",
  "&gt;": ">",
  "&lt;": "<",
  "&amp;": "&"
}, tf = /* @__PURE__ */ D0(Fi), Se = /* @__PURE__ */ (function() {
  var e = /&(?:quot|apos|gt|lt|amp|#x?([\da-fA-F]+));/ig, a = /_x([\da-fA-F]{4})_/ig;
  function r(t) {
    var n = t + "", i = n.indexOf("<![CDATA[");
    if (i == -1) return n.replace(e, function(s, f) {
      return Fi[s] || String.fromCharCode(parseInt(f, s.indexOf("x") > -1 ? 16 : 10)) || s;
    }).replace(a, function(s, f) {
      return String.fromCharCode(parseInt(f, 16));
    });
    var c = n.indexOf("]]>");
    return r(n.slice(0, i)) + n.slice(i + 9, c) + r(n.slice(c + 3));
  }
  return function(n, i) {
    var c = r(n);
    return i ? c.replace(/\r\n/g, `
`) : c;
  };
})(), nf = /[&<>'"]/g, sf = /[\u0000-\u001f]/g;
function za(e) {
  var a = e + "";
  return a.replace(nf, function(r) {
    return tf[r];
  }).replace(/\n/g, "<br/>").replace(sf, function(r) {
    return "&#x" + ("000" + r.charCodeAt(0).toString(16)).slice(-4) + ";";
  });
}
var hn = /* @__PURE__ */ (function() {
  var e = /&#(\d+);/g;
  function a(r, t) {
    return String.fromCharCode(parseInt(t, 10));
  }
  return function(t) {
    return t.replace(e, a);
  };
})();
function Be(e) {
  switch (e) {
    case 1:
    case !0:
    case "1":
    case "true":
      return !0;
    case 0:
    case !1:
    case "0":
    case "false":
      return !1;
  }
  return !1;
}
function s0(e) {
  for (var a = "", r = 0, t = 0, n = 0, i = 0, c = 0, s = 0; r < e.length; ) {
    if (t = e.charCodeAt(r++), t < 128) {
      a += String.fromCharCode(t);
      continue;
    }
    if (n = e.charCodeAt(r++), t > 191 && t < 224) {
      c = (t & 31) << 6, c |= n & 63, a += String.fromCharCode(c);
      continue;
    }
    if (i = e.charCodeAt(r++), t < 240) {
      a += String.fromCharCode((t & 15) << 12 | (n & 63) << 6 | i & 63);
      continue;
    }
    c = e.charCodeAt(r++), s = ((t & 7) << 18 | (n & 63) << 12 | (i & 63) << 6 | c & 63) - 65536, a += String.fromCharCode(55296 + (s >>> 10 & 1023)), a += String.fromCharCode(56320 + (s & 1023));
  }
  return a;
}
function xn(e) {
  var a = fa(2 * e.length), r, t, n = 1, i = 0, c = 0, s;
  for (t = 0; t < e.length; t += n)
    n = 1, (s = e.charCodeAt(t)) < 128 ? r = s : s < 224 ? (r = (s & 31) * 64 + (e.charCodeAt(t + 1) & 63), n = 2) : s < 240 ? (r = (s & 15) * 4096 + (e.charCodeAt(t + 1) & 63) * 64 + (e.charCodeAt(t + 2) & 63), n = 3) : (n = 4, r = (s & 7) * 262144 + (e.charCodeAt(t + 1) & 63) * 4096 + (e.charCodeAt(t + 2) & 63) * 64 + (e.charCodeAt(t + 3) & 63), r -= 65536, c = 55296 + (r >>> 10 & 1023), r = 56320 + (r & 1023)), c !== 0 && (a[i++] = c & 255, a[i++] = c >>> 8, c = 0), a[i++] = r % 256, a[i++] = r >>> 8;
  return a.slice(0, i).toString("ucs2");
}
function dn(e) {
  return ua(e, "binary").toString("utf8");
}
var Et = "foo bar bazâð£", Ue = ye && (/* @__PURE__ */ dn(Et) == /* @__PURE__ */ s0(Et) && dn || /* @__PURE__ */ xn(Et) == /* @__PURE__ */ s0(Et) && xn) || s0, Xa = ye ? function(e) {
  return ua(e, "utf8").toString("binary");
} : function(e) {
  for (var a = [], r = 0, t = 0, n = 0; r < e.length; )
    switch (t = e.charCodeAt(r++), !0) {
      case t < 128:
        a.push(String.fromCharCode(t));
        break;
      case t < 2048:
        a.push(String.fromCharCode(192 + (t >> 6))), a.push(String.fromCharCode(128 + (t & 63)));
        break;
      case (t >= 55296 && t < 57344):
        t -= 55296, n = e.charCodeAt(r++) - 56320 + (t << 10), a.push(String.fromCharCode(240 + (n >> 18 & 7))), a.push(String.fromCharCode(144 + (n >> 12 & 63))), a.push(String.fromCharCode(128 + (n >> 6 & 63))), a.push(String.fromCharCode(128 + (n & 63)));
        break;
      default:
        a.push(String.fromCharCode(224 + (t >> 12))), a.push(String.fromCharCode(128 + (t >> 6 & 63))), a.push(String.fromCharCode(128 + (t & 63)));
    }
  return a.join("");
}, Ai = /* @__PURE__ */ (function() {
  var e = [
    ["nbsp", " "],
    ["middot", "·"],
    ["quot", '"'],
    ["apos", "'"],
    ["gt", ">"],
    ["lt", "<"],
    ["amp", "&"]
  ].map(function(a) {
    return [new RegExp("&" + a[0] + ";", "ig"), a[1]];
  });
  return function(r) {
    for (var t = r.replace(/^[\t\n\r ]+/, "").replace(/(^|[^\t\n\r ])[\t\n\r ]+$/, "$1").replace(/>\s+/g, ">").replace(/\b\s+</g, "<").replace(/[\t\n\r ]+/g, " ").replace(/<\s*[bB][rR]\s*\/?>/g, `
`).replace(/<[^<>]*>/g, ""), n = 0; n < e.length; ++n) t = t.replace(e[n][0], e[n][1]);
    return t;
  };
})(), cf = /<\/?(?:vt:)?variant>/g, ff = /<(?:vt:)([^<"'>]*)>([\s\S]*)</;
function vn(e, a) {
  var r = le(e), t = mi(e, r.baseType) || [], n = [];
  if (t.length != r.size) {
    if (a.WTF) throw new Error("unexpected vector length " + t.length + " != " + r.size);
    return n;
  }
  return t.forEach(function(i) {
    var c = i.replace(cf, "").match(ff);
    c && n.push({ v: Ue(c[2]), t: c[1] });
  }), n;
}
var of = /(^\s|\s$|\n)/;
function lf(e) {
  return Br(e).map(function(a) {
    return " " + a + '="' + e[a] + '"';
  }).join("");
}
function uf(e, a, r) {
  return "<" + e + (r != null ? lf(r) : "") + (a != null ? (a.match(of) ? ' xml:space="preserve"' : "") + ">" + a + "</" + e : "/") + ">";
}
function jt(e) {
  if (ye && /*::typeof Buffer !== "undefined" && d != null && d instanceof Buffer &&*/
  Buffer.isBuffer(e)) return e.toString("utf8");
  if (typeof e == "string") return e;
  if (typeof Uint8Array < "u" && e instanceof Uint8Array) return Ue(aa(A0(e)));
  throw new Error("Bad input format: expected Buffer or string");
}
var qe = /<([\/]?)([^\s?><!\/:"]*:|)([^\s?<>:\/"]+)(?:\s+[^<>=?"'\s]+="[^"]*?")*\s*[\/]?>/mg, hf = {
  CT: "http://schemas.openxmlformats.org/package/2006/content-types"
}, xf = [
  "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
  "http://purl.oclc.org/ooxml/spreadsheetml/main",
  "http://schemas.microsoft.com/office/excel/2006/main",
  "http://schemas.microsoft.com/office/excel/2006/2"
];
function df(e, a) {
  for (var r = 1 - 2 * (e[a + 7] >>> 7), t = ((e[a + 7] & 127) << 4) + (e[a + 6] >>> 4 & 15), n = e[a + 6] & 15, i = 5; i >= 0; --i) n = n * 256 + e[a + i];
  return t == 2047 ? n == 0 ? r * (1 / 0) : NaN : (t == 0 ? t = -1022 : (t -= 1023, n += Math.pow(2, 52)), r * Math.pow(2, t - 52) * n);
}
function vf(e, a, r) {
  var t = (a < 0 || 1 / a == -1 / 0 ? 1 : 0) << 7, n = 0, i = 0, c = t ? -a : a;
  isFinite(c) ? c == 0 ? n = i = 0 : (n = Math.floor(Math.log(c) / Math.LN2), i = c * Math.pow(2, 52 - n), n <= -1023 && (!isFinite(i) || i < Math.pow(2, 52)) ? n = -1022 : (i -= Math.pow(2, 52), n += 1023)) : (n = 2047, i = isNaN(a) ? 26985 : 0);
  for (var s = 0; s <= 5; ++s, i /= 256) e[r + s] = i & 255;
  e[r + 6] = (n & 15) << 4 | i & 15, e[r + 7] = n >> 4 | t;
}
var pn = function(e) {
  for (var a = [], r = 10240, t = 0; t < e[0].length; ++t) if (e[0][t]) for (var n = 0, i = e[0][t].length; n < i; n += r) a.push.apply(a, e[0][t].slice(n, n + r));
  return a;
}, gn = ye ? function(e) {
  return e[0].length > 0 && Buffer.isBuffer(e[0][0]) ? Buffer.concat(e[0].map(function(a) {
    return Buffer.isBuffer(a) ? a : ua(a);
  })) : pn(e);
} : pn, mn = function(e, a, r) {
  for (var t = [], n = a; n < r; n += 2) t.push(String.fromCharCode(Qr(e, n)));
  return t.join("").replace(wr, "");
}, N0 = ye ? function(e, a, r) {
  return !Buffer.isBuffer(e) || !tt ? mn(e, a, r) : e.toString("utf16le", a, r).replace(wr, "");
} : mn, _n = function(e, a, r) {
  for (var t = [], n = a; n < a + r; ++n) t.push(("0" + e[n].toString(16)).slice(-2));
  return t.join("");
}, yi = ye ? function(e, a, r) {
  return Buffer.isBuffer(e) ? e.toString("hex", a, a + r) : _n(e, a, r);
} : _n, Tn = function(e, a, r) {
  for (var t = [], n = a; n < r; n++) t.push(String.fromCharCode(Ia(e, n)));
  return t.join("");
}, ht = ye ? function(a, r, t) {
  return Buffer.isBuffer(a) ? a.toString("utf8", r, t) : Tn(a, r, t);
} : Tn, Si = function(e, a) {
  var r = Ir(e, a);
  return r > 0 ? ht(e, a + 4, a + 4 + r - 1) : "";
}, Ci = Si, Di = function(e, a) {
  var r = Ir(e, a);
  return r > 0 ? ht(e, a + 4, a + 4 + r - 1) : "";
}, Ii = Di, Oi = function(e, a) {
  var r = 2 * Ir(e, a);
  return r > 0 ? ht(e, a + 4, a + 4 + r - 1) : "";
}, Ri = Oi, Ni = function(a, r) {
  var t = Ir(a, r);
  return t > 0 ? N0(a, r + 4, r + 4 + t) : "";
}, Pi = Ni, bi = function(e, a) {
  var r = Ir(e, a);
  return r > 0 ? ht(e, a + 4, a + 4 + r) : "";
}, Li = bi, Bi = function(e, a) {
  return df(e, a);
}, Bt = Bi, Mi = function(a) {
  return Array.isArray(a) || typeof Uint8Array < "u" && a instanceof Uint8Array;
};
ye && (Ci = function(a, r) {
  if (!Buffer.isBuffer(a)) return Si(a, r);
  var t = a.readUInt32LE(r);
  return t > 0 ? a.toString("utf8", r + 4, r + 4 + t - 1) : "";
}, Ii = function(a, r) {
  if (!Buffer.isBuffer(a)) return Di(a, r);
  var t = a.readUInt32LE(r);
  return t > 0 ? a.toString("utf8", r + 4, r + 4 + t - 1) : "";
}, Ri = function(a, r) {
  if (!Buffer.isBuffer(a) || !tt) return Oi(a, r);
  var t = 2 * a.readUInt32LE(r);
  return a.toString("utf16le", r + 4, r + 4 + t - 1);
}, Pi = function(a, r) {
  if (!Buffer.isBuffer(a) || !tt) return Ni(a, r);
  var t = a.readUInt32LE(r);
  return a.toString("utf16le", r + 4, r + 4 + t);
}, Li = function(a, r) {
  if (!Buffer.isBuffer(a)) return bi(a, r);
  var t = a.readUInt32LE(r);
  return a.toString("utf8", r + 4, r + 4 + t);
}, Bt = function(a, r) {
  return Buffer.isBuffer(a) ? a.readDoubleLE(r) : Bi(a, r);
}, Mi = function(a) {
  return Buffer.isBuffer(a) || Array.isArray(a) || typeof Uint8Array < "u" && a instanceof Uint8Array;
});
var Ia = function(e, a) {
  return e[a];
}, Qr = function(e, a) {
  return e[a + 1] * 256 + e[a];
}, pf = function(e, a) {
  var r = e[a + 1] * 256 + e[a];
  return r < 32768 ? r : (65535 - r + 1) * -1;
}, Ir = function(e, a) {
  return e[a + 3] * (1 << 24) + (e[a + 2] << 16) + (e[a + 1] << 8) + e[a];
}, pa = function(e, a) {
  return e[a + 3] << 24 | e[a + 2] << 16 | e[a + 1] << 8 | e[a];
}, gf = function(e, a) {
  return e[a] << 24 | e[a + 1] << 16 | e[a + 2] << 8 | e[a + 3];
};
function Ka(e, a) {
  var r = "", t, n, i = [], c, s, f, o;
  switch (a) {
    case "dbcs":
      if (o = this.l, ye && Buffer.isBuffer(this) && tt) r = this.slice(this.l, this.l + 2 * e).toString("utf16le");
      else for (f = 0; f < e; ++f)
        r += String.fromCharCode(Qr(this, o)), o += 2;
      e *= 2;
      break;
    case "utf8":
      r = ht(this, this.l, this.l + e);
      break;
    case "utf16le":
      e *= 2, r = N0(this, this.l, this.l + e);
      break;
    case "wstr":
      return Ka.call(this, e, "dbcs");
    /* [MS-OLEDS] 2.1.4 LengthPrefixedAnsiString */
    case "lpstr-ansi":
      r = Ci(this, this.l), e = 4 + Ir(this, this.l);
      break;
    case "lpstr-cp":
      r = Ii(this, this.l), e = 4 + Ir(this, this.l);
      break;
    /* [MS-OLEDS] 2.1.5 LengthPrefixedUnicodeString */
    case "lpwstr":
      r = Ri(this, this.l), e = 4 + 2 * Ir(this, this.l);
      break;
    /* [MS-OFFCRYPTO] 2.1.2 Length-Prefixed Padded Unicode String (UNICODE-LP-P4) */
    case "lpp4":
      e = 4 + Ir(this, this.l), r = Pi(this, this.l), e & 2 && (e += 2);
      break;
    /* [MS-OFFCRYPTO] 2.1.3 Length-Prefixed UTF-8 String (UTF-8-LP-P4) */
    case "8lpp4":
      e = 4 + Ir(this, this.l), r = Li(this, this.l), e & 3 && (e += 4 - (e & 3));
      break;
    case "cstr":
      for (e = 0, r = ""; (c = Ia(this, this.l + e++)) !== 0; ) i.push(Tt(c));
      r = i.join("");
      break;
    case "_wstr":
      for (e = 0, r = ""; (c = Qr(this, this.l + e)) !== 0; )
        i.push(Tt(c)), e += 2;
      e += 2, r = i.join("");
      break;
    /* sbcs and dbcs support continue records in the SST way TODO codepages */
    case "dbcs-cont":
      for (r = "", o = this.l, f = 0; f < e; ++f) {
        if (this.lens && this.lens.indexOf(o) !== -1)
          return c = Ia(this, o), this.l = o + 1, s = Ka.call(this, e - f, c ? "dbcs-cont" : "sbcs-cont"), i.join("") + s;
        i.push(Tt(Qr(this, o))), o += 2;
      }
      r = i.join(""), e *= 2;
      break;
    case "cpstr":
    /* falls through */
    case "sbcs-cont":
      for (r = "", o = this.l, f = 0; f != e; ++f) {
        if (this.lens && this.lens.indexOf(o) !== -1)
          return c = Ia(this, o), this.l = o + 1, s = Ka.call(this, e - f, c ? "dbcs-cont" : "sbcs-cont"), i.join("") + s;
        i.push(Tt(Ia(this, o))), o += 1;
      }
      r = i.join("");
      break;
    default:
      switch (e) {
        case 1:
          return t = Ia(this, this.l), this.l++, t;
        case 2:
          return t = (a === "i" ? pf : Qr)(this, this.l), this.l += 2, t;
        case 4:
        case -4:
          return a === "i" || (this[this.l + 3] & 128) === 0 ? (t = (e > 0 ? pa : gf)(this, this.l), this.l += 4, t) : (n = Ir(this, this.l), this.l += 4, n);
        case 8:
        case -8:
          if (a === "f")
            return e == 8 ? n = Bt(this, this.l) : n = Bt([this[this.l + 7], this[this.l + 6], this[this.l + 5], this[this.l + 4], this[this.l + 3], this[this.l + 2], this[this.l + 1], this[this.l + 0]], 0), this.l += 8, n;
          e = 8;
        /* falls through */
        case 16:
          r = yi(this, this.l, e);
          break;
      }
  }
  return this.l += e, r;
}
var mf = function(e, a, r) {
  e[r] = a & 255, e[r + 1] = a >>> 8 & 255, e[r + 2] = a >>> 16 & 255, e[r + 3] = a >>> 24 & 255;
}, _f = function(e, a, r) {
  e[r] = a & 255, e[r + 1] = a >> 8 & 255, e[r + 2] = a >> 16 & 255, e[r + 3] = a >> 24 & 255;
}, Tf = function(e, a, r) {
  e[r] = a & 255, e[r + 1] = a >>> 8 & 255;
};
function Ef(e, a, r) {
  var t = 0, n = 0;
  if (r === "dbcs") {
    for (n = 0; n != a.length; ++n) Tf(this, a.charCodeAt(n), this.l + 2 * n);
    t = 2 * a.length;
  } else if (r === "sbcs" || r == "cpstr") {
    for (a = a.replace(/[^\x00-\x7F]/g, "_"), n = 0; n != a.length; ++n) this[this.l + n] = a.charCodeAt(n) & 255;
    t = a.length;
  } else if (r === "hex") {
    for (; n < e; ++n)
      this[this.l++] = parseInt(a.slice(2 * n, 2 * n + 2), 16) || 0;
    return this;
  } else if (r === "utf16le") {
    var i = Math.min(this.l + e, this.length);
    for (n = 0; n < Math.min(a.length, e); ++n) {
      var c = a.charCodeAt(n);
      this[this.l++] = c & 255, this[this.l++] = c >> 8;
    }
    for (; this.l < i; ) this[this.l++] = 0;
    return this;
  } else switch (e) {
    case 1:
      t = 1, this[this.l] = a & 255;
      break;
    case 2:
      t = 2, this[this.l] = a & 255, a >>>= 8, this[this.l + 1] = a & 255;
      break;
    case 3:
      t = 3, this[this.l] = a & 255, a >>>= 8, this[this.l + 1] = a & 255, a >>>= 8, this[this.l + 2] = a & 255;
      break;
    case 4:
      t = 4, mf(this, a, this.l);
      break;
    case 8:
      if (t = 8, r === "f") {
        vf(this, a, this.l);
        break;
      }
    /* falls through */
    case 16:
      break;
    case -4:
      t = 4, _f(this, a, this.l);
      break;
  }
  return this.l += t, this;
}
function Ui(e, a) {
  var r = yi(this, this.l, e.length >> 1);
  if (r !== e) throw new Error(a + "Expected " + e + " saw " + r);
  this.l += e.length >> 1;
}
function rr(e, a) {
  e.l = a, e.read_shift = /*::(*/
  Ka, e.chk = Ui, e.write_shift = Ef;
}
function pr(e, a) {
  e.l += a;
}
function Qe(e) {
  var a = fa(e);
  return rr(a, 0), a;
}
function ta(e, a, r) {
  if (e) {
    var t, n, i;
    rr(e, e.l || 0);
    for (var c = e.length, s = 0, f = 0; e.l < c; ) {
      s = e.read_shift(1), s & 128 && (s = (s & 127) + ((e.read_shift(1) & 127) << 7));
      var o = Gt[s] || Gt[65535];
      for (t = e.read_shift(1), i = t & 127, n = 1; n < 4 && t & 128; ++n) i += ((t = e.read_shift(1)) & 127) << 7 * n;
      f = e.l + i;
      var l = o.f && o.f(e, i, r);
      if (e.l = f, a(l, o, s)) return;
    }
  }
}
function p0() {
  var e = [], a = ye ? 16384 : 2048;
  ye && Qe(a).copy;
  var r = function(l) {
    var v = Qe(l);
    return rr(v, 0), v;
  }, t = r(a), n = function() {
    t && (t.l && (t.length > t.l && (t = t.slice(0, t.l), t.l = t.length), t.length > 0 && e.push(t)), t = null);
  }, i = function(l) {
    return t && l < t.length - t.l ? t : (n(), t = r(Math.max(l + 1, a)));
  }, c = function() {
    return n(), ia(e);
  }, s = function() {
    return n(), e;
  }, f = function(l) {
    n(), t = l, t.l == null && (t.l = t.length), i(a);
  };
  return { next: i, push: f, end: c, _bufs: e, end2: s };
}
function Ya(e, a, r) {
  var t = er(e);
  if (a.s ? (t.cRel && (t.c += a.s.c), t.rRel && (t.r += a.s.r)) : (t.cRel && (t.c += a.c), t.rRel && (t.r += a.r)), !r || r.biff < 12) {
    for (; t.c >= 256; ) t.c -= 256;
    for (; t.r >= 65536; ) t.r -= 65536;
  }
  return t;
}
function En(e, a, r) {
  var t = er(e);
  return t.s = Ya(t.s, a.s, r), t.e = Ya(t.e, a.s, r), t;
}
function ja(e, a) {
  if (e.cRel && e.c < 0)
    for (e = er(e); e.c < 0; ) e.c += a > 8 ? 16384 : 256;
  if (e.rRel && e.r < 0)
    for (e = er(e); e.r < 0; ) e.r += a > 8 ? 1048576 : a > 5 ? 65536 : 16384;
  var r = Ne(e);
  return !e.cRel && e.cRel != null && (r = Ff(r)), !e.rRel && e.rRel != null && (r = kf(r)), r;
}
function c0(e, a) {
  return e.s.r == 0 && !e.s.rRel && e.e.r == (a.biff >= 12 ? 1048575 : a.biff >= 8 ? 65536 : 16384) && !e.e.rRel ? (e.s.cRel ? "" : "$") + Pe(e.s.c) + ":" + (e.e.cRel ? "" : "$") + Pe(e.e.c) : e.s.c == 0 && !e.s.cRel && e.e.c == (a.biff >= 12 ? 16383 : 255) && !e.e.cRel ? (e.s.rRel ? "" : "$") + Me(e.s.r) + ":" + (e.e.rRel ? "" : "$") + Me(e.e.r) : ja(e.s, a.biff) + ":" + ja(e.e, a.biff);
}
function P0(e) {
  return parseInt(wf(e), 10) - 1;
}
function Me(e) {
  return "" + (e + 1);
}
function kf(e) {
  return e.replace(/([A-Z]|^)(\d+)$/, "$1$$$2");
}
function wf(e) {
  return e.replace(/\$(\d+)$/, "$1");
}
function b0(e) {
  for (var a = Af(e), r = 0, t = 0; t !== a.length; ++t) r = 26 * r + a.charCodeAt(t) - 64;
  return r - 1;
}
function Pe(e) {
  if (e < 0) throw new Error("invalid column " + e);
  var a = "";
  for (++e; e; e = Math.floor((e - 1) / 26)) a = String.fromCharCode((e - 1) % 26 + 65) + a;
  return a;
}
function Ff(e) {
  return e.replace(/^([A-Z])/, "$$$1");
}
function Af(e) {
  return e.replace(/^\$([A-Z])/, "$1");
}
function yf(e) {
  return e.replace(/(\$?[A-Z]*)(\$?\d*)/, "$1,$2").split(",");
}
function dr(e) {
  for (var a = 0, r = 0, t = 0; t < e.length; ++t) {
    var n = e.charCodeAt(t);
    n >= 48 && n <= 57 ? a = 10 * a + (n - 48) : n >= 65 && n <= 90 && (r = 26 * r + (n - 64));
  }
  return { c: r - 1, r: a - 1 };
}
function Ne(e) {
  for (var a = e.c + 1, r = ""; a; a = (a - 1) / 26 | 0) r = String.fromCharCode((a - 1) % 26 + 65) + r;
  return r + (e.r + 1);
}
function Aa(e) {
  var a = e.indexOf(":");
  return a == -1 ? { s: dr(e), e: dr(e) } : { s: dr(e.slice(0, a)), e: dr(e.slice(a + 1)) };
}
function Ce(e, a) {
  return typeof a > "u" || typeof a == "number" ? Ce(e.s, e.e) : (typeof e != "string" && (e = Ne(e)), typeof a != "string" && (a = Ne(a)), e == a ? e : e + ":" + a);
}
function Sf(e, a) {
  if (!e && !(a && a.biff <= 5 && a.biff >= 2)) throw new Error("empty sheet name");
  return /[^\w\u4E00-\u9FFF\u3040-\u30FF]/.test(e) ? "'" + e.replace(/'/g, "''") + "'" : e;
}
function Ke(e) {
  var a = { s: { c: 0, r: 0 }, e: { c: 0, r: 0 } }, r = 0, t = 0, n = 0, i = e.length;
  for (r = 0; t < i && !((n = e.charCodeAt(t) - 64) < 1 || n > 26); ++t)
    r = 26 * r + n;
  for (a.s.c = --r, r = 0; t < i && !((n = e.charCodeAt(t) - 48) < 0 || n > 9); ++t)
    r = 10 * r + n;
  if (a.s.r = --r, t === i || n != 10)
    return a.e.c = a.s.c, a.e.r = a.s.r, a;
  for (++t, r = 0; t != i && !((n = e.charCodeAt(t) - 64) < 1 || n > 26); ++t)
    r = 26 * r + n;
  for (a.e.c = --r, r = 0; t != i && !((n = e.charCodeAt(t) - 48) < 0 || n > 9); ++t)
    r = 10 * r + n;
  return a.e.r = --r, a;
}
function kn(e, a) {
  var r = e.t == "d" && a instanceof Date;
  if (e.z != null) try {
    return e.w = Fr(e.z, r ? ar(a) : a);
  } catch {
  }
  try {
    return e.w = Fr((e.XF || {}).numFmtId || (r ? 14 : 0), r ? ar(a) : a);
  } catch {
    return "" + a;
  }
}
function oa(e, a, r) {
  return e == null || e.t == null || e.t == "z" ? "" : e.w !== void 0 ? e.w : (e.t == "d" && !e.z && r && r.dateNF && (e.z = r.dateNF), e.t == "e" ? Ar[e.v] || e.v : a == null ? kn(e, e.v) : kn(e, a));
}
function ha(e, a) {
  var r = a && a.sheet ? a.sheet : "Sheet1", t = {};
  return t[r] = e, { SheetNames: [r], Sheets: t };
}
function Cf(e) {
  var a = {}, r = e || {};
  return r.dense && (a["!data"] = []), a;
}
function Hi(e, a, r) {
  var t = r || {}, n = e ? e["!data"] != null : t.dense, i = e || (n ? { "!data": [] } : {});
  n && !i["!data"] && (i["!data"] = []);
  var c = 0, s = 0;
  if (i && t.origin != null)
    if (typeof t.origin == "number") c = t.origin;
    else {
      var f = typeof t.origin == "string" ? dr(t.origin) : t.origin;
      c = f.r, s = f.c;
    }
  var o = { s: { c: 1e7, r: 1e7 }, e: { c: 0, r: 0 } };
  if (i["!ref"]) {
    var l = Ke(i["!ref"]);
    o.s.c = l.s.c, o.s.r = l.s.r, o.e.c = Math.max(o.e.c, l.e.c), o.e.r = Math.max(o.e.r, l.e.r), c == -1 && (o.e.r = c = i["!ref"] ? l.e.r + 1 : 0);
  } else
    o.s.c = o.e.c = o.s.r = o.e.r = 0;
  for (var v = [], x = !1, u = 0; u != a.length; ++u)
    if (a[u]) {
      if (!Array.isArray(a[u])) throw new Error("aoa_to_sheet expects an array of arrays");
      var p = c + u;
      n && (i["!data"][p] || (i["!data"][p] = []), v = i["!data"][p]);
      for (var _ = a[u], d = 0; d != _.length; ++d)
        if (!(typeof _[d] > "u")) {
          var h = { v: _[d], t: "" }, E = s + d;
          if (o.s.r > p && (o.s.r = p), o.s.c > E && (o.s.c = E), o.e.r < p && (o.e.r = p), o.e.c < E && (o.e.c = E), x = !0, _[d] && typeof _[d] == "object" && !Array.isArray(_[d]) && !(_[d] instanceof Date)) h = _[d];
          else if (Array.isArray(h.v) && (h.f = _[d][1], h.v = h.v[0]), h.v === null)
            if (h.f) h.t = "n";
            else if (t.nullError)
              h.t = "e", h.v = 0;
            else if (t.sheetStubs) h.t = "z";
            else continue;
          else typeof h.v == "number" ? isFinite(h.v) ? h.t = "n" : isNaN(h.v) ? (h.t = "e", h.v = 15) : (h.t = "e", h.v = 7) : typeof h.v == "boolean" ? h.t = "b" : h.v instanceof Date ? (h.z = t.dateNF || ge[14], t.UTC || (h.v = Yt(h.v)), t.cellDates ? (h.t = "d", h.w = Fr(h.z, ar(h.v, t.date1904))) : (h.t = "n", h.v = ar(h.v, t.date1904), h.w = Fr(h.z, h.v))) : h.t = "s";
          if (n)
            v[E] && v[E].z && (h.z = v[E].z), v[E] = h;
          else {
            var g = Pe(E) + (p + 1);
            i[g] && i[g].z && (h.z = i[g].z), i[g] = h;
          }
        }
    }
  return x && o.s.c < 104e5 && (i["!ref"] = Ce(o)), i;
}
function Ua(e, a) {
  return Hi(null, e, a);
}
function Df(e) {
  return e.read_shift(4, "i");
}
function vr(e) {
  var a = e.read_shift(4);
  return a === 0 ? "" : e.read_shift(a, "dbcs");
}
function If(e) {
  return { ich: e.read_shift(2), ifnt: e.read_shift(2) };
}
function L0(e, a) {
  var r = e.l, t = e.read_shift(1), n = vr(e), i = [], c = { t: n, h: n };
  if ((t & 1) !== 0) {
    for (var s = e.read_shift(4), f = 0; f != s; ++f) i.push(If(e));
    c.r = i;
  } else c.r = [{ ich: 0, ifnt: 0 }];
  return e.l = r + a, c;
}
var Of = L0;
function Wr(e) {
  var a = e.read_shift(4), r = e.read_shift(2);
  return r += e.read_shift(1) << 16, e.l++, { c: a, iStyleRef: r };
}
function ya(e) {
  var a = e.read_shift(2);
  return a += e.read_shift(1) << 16, e.l++, { c: -1, iStyleRef: a };
}
var Rf = vr;
function Jt(e) {
  var a = e.read_shift(4);
  return a === 0 || a === 4294967295 ? "" : e.read_shift(a, "dbcs");
}
var Nf = vr, g0 = Jt;
function Zt(e) {
  var a = e.slice(e.l, e.l + 4), r = a[0] & 1, t = a[0] & 2;
  e.l += 4;
  var n = t === 0 ? Bt([0, 0, 0, 0, a[0] & 252, a[1], a[2], a[3]], 0) : pa(a, 0) >> 2;
  return r ? n / 100 : n;
}
function Wi(e) {
  var a = { s: {}, e: {} };
  return a.s.r = e.read_shift(4), a.e.r = e.read_shift(4), a.s.c = e.read_shift(4), a.e.c = e.read_shift(4), a;
}
var Sa = Wi;
function xr(e) {
  if (e.length - e.l < 8) throw "XLS Xnum Buffer underflow";
  return e.read_shift(8, "f");
}
function Pf(e) {
  var a = {}, r = e.read_shift(1), t = r >>> 1, n = e.read_shift(1), i = e.read_shift(2, "i"), c = e.read_shift(1), s = e.read_shift(1), f = e.read_shift(1);
  switch (e.l++, t) {
    case 0:
      a.auto = 1;
      break;
    case 1:
      a.index = n;
      var o = _a[n];
      o && (a.rgb = ct(o));
      break;
    case 2:
      a.rgb = ct([c, s, f]);
      break;
    case 3:
      a.theme = n;
      break;
  }
  return i != 0 && (a.tint = i > 0 ? i / 32767 : i / 32768), a;
}
function bf(e) {
  var a = e.read_shift(1);
  e.l++;
  var r = {
    fBold: a & 1,
    fItalic: a & 2,
    fUnderline: a & 4,
    fStrikeout: a & 8,
    fOutline: a & 16,
    fShadow: a & 32,
    fCondense: a & 64,
    fExtend: a & 128
  };
  return r;
}
function Vi(e, a) {
  var r = { 2: "BITMAP", 3: "METAFILEPICT", 8: "DIB", 14: "ENHMETAFILE" }, t = e.read_shift(4);
  switch (t) {
    case 0:
      return "";
    case 4294967295:
    case 4294967294:
      return r[e.read_shift(4)] || "";
  }
  if (t > 400) throw new Error("Unsupported Clipboard: " + t.toString(16));
  return e.l -= 4, e.read_shift(0, a == 1 ? "lpstr" : "lpwstr");
}
function Lf(e) {
  return Vi(e, 1);
}
function Bf(e) {
  return Vi(e, 2);
}
var B0 = 2, kr = 3, kt = 11, wn = 12, Mt = 19, wt = 64, Mf = 65, Uf = 71, Hf = 4108, Wf = 4126, tr = 80, Gi = 81, Vf = [tr, Gi], Gf = {
  1: { n: "CodePage", t: B0 },
  2: { n: "Category", t: tr },
  3: { n: "PresentationFormat", t: tr },
  4: { n: "ByteCount", t: kr },
  5: { n: "LineCount", t: kr },
  6: { n: "ParagraphCount", t: kr },
  7: { n: "SlideCount", t: kr },
  8: { n: "NoteCount", t: kr },
  9: { n: "HiddenCount", t: kr },
  10: { n: "MultimediaClipCount", t: kr },
  11: { n: "ScaleCrop", t: kt },
  12: {
    n: "HeadingPairs",
    t: Hf
    /* VT_VECTOR | VT_VARIANT */
  },
  13: {
    n: "TitlesOfParts",
    t: Wf
    /* VT_VECTOR | VT_LPSTR */
  },
  14: { n: "Manager", t: tr },
  15: { n: "Company", t: tr },
  16: { n: "LinksUpToDate", t: kt },
  17: { n: "CharacterCount", t: kr },
  19: { n: "SharedDoc", t: kt },
  22: { n: "HyperlinksChanged", t: kt },
  23: { n: "AppVersion", t: kr, p: "version" },
  24: { n: "DigSig", t: Mf },
  26: { n: "ContentType", t: tr },
  27: { n: "ContentStatus", t: tr },
  28: { n: "Language", t: tr },
  29: { n: "Version", t: tr },
  255: {},
  /* [MS-OLEPS] 2.18 */
  2147483648: { n: "Locale", t: Mt },
  2147483651: { n: "Behavior", t: Mt },
  1919054434: {}
}, $f = {
  1: { n: "CodePage", t: B0 },
  2: { n: "Title", t: tr },
  3: { n: "Subject", t: tr },
  4: { n: "Author", t: tr },
  5: { n: "Keywords", t: tr },
  6: { n: "Comments", t: tr },
  7: { n: "Template", t: tr },
  8: { n: "LastAuthor", t: tr },
  9: { n: "RevNumber", t: tr },
  10: { n: "EditTime", t: wt },
  11: { n: "LastPrinted", t: wt },
  12: { n: "CreatedDate", t: wt },
  13: { n: "ModifiedDate", t: wt },
  14: { n: "PageCount", t: kr },
  15: { n: "WordCount", t: kr },
  16: { n: "CharCount", t: kr },
  17: { n: "Thumbnail", t: Uf },
  18: { n: "Application", t: tr },
  19: { n: "DocSecurity", t: kr },
  255: {},
  /* [MS-OLEPS] 2.18 */
  2147483648: { n: "Locale", t: Mt },
  2147483651: { n: "Behavior", t: Mt },
  1919054434: {}
}, Fn = {
  1: "US",
  // United States
  2: "CA",
  // Canada
  3: "",
  // Latin America (except Brazil)
  7: "RU",
  // Russia
  20: "EG",
  // Egypt
  30: "GR",
  // Greece
  31: "NL",
  // Netherlands
  32: "BE",
  // Belgium
  33: "FR",
  // France
  34: "ES",
  // Spain
  36: "HU",
  // Hungary
  39: "IT",
  // Italy
  41: "CH",
  // Switzerland
  43: "AT",
  // Austria
  44: "GB",
  // United Kingdom
  45: "DK",
  // Denmark
  46: "SE",
  // Sweden
  47: "NO",
  // Norway
  48: "PL",
  // Poland
  49: "DE",
  // Germany
  52: "MX",
  // Mexico
  55: "BR",
  // Brazil
  61: "AU",
  // Australia
  64: "NZ",
  // New Zealand
  66: "TH",
  // Thailand
  81: "JP",
  // Japan
  82: "KR",
  // Korea
  84: "VN",
  // Viet Nam
  86: "CN",
  // China
  90: "TR",
  // Turkey
  105: "JS",
  // Ramastan
  213: "DZ",
  // Algeria
  216: "MA",
  // Morocco
  218: "LY",
  // Libya
  351: "PT",
  // Portugal
  354: "IS",
  // Iceland
  358: "FI",
  // Finland
  420: "CZ",
  // Czech Republic
  886: "TW",
  // Taiwan
  961: "LB",
  // Lebanon
  962: "JO",
  // Jordan
  963: "SY",
  // Syria
  964: "IQ",
  // Iraq
  965: "KW",
  // Kuwait
  966: "SA",
  // Saudi Arabia
  971: "AE",
  // United Arab Emirates
  972: "IL",
  // Israel
  974: "QA",
  // Qatar
  981: "IR",
  // Iran
  65535: "US"
  // United States
}, Xf = [
  null,
  "solid",
  "mediumGray",
  "darkGray",
  "lightGray",
  "darkHorizontal",
  "darkVertical",
  "darkDown",
  "darkUp",
  "darkGrid",
  "darkTrellis",
  "lightHorizontal",
  "lightVertical",
  "lightDown",
  "lightUp",
  "lightGrid",
  "lightTrellis",
  "gray125",
  "gray0625"
];
function zf(e) {
  return e.map(function(a) {
    return [a >> 16 & 255, a >> 8 & 255, a & 255];
  });
}
var Kf = /* @__PURE__ */ zf([
  /* Color Constants */
  0,
  16777215,
  16711680,
  65280,
  255,
  16776960,
  16711935,
  65535,
  /* Overridable Defaults */
  0,
  16777215,
  16711680,
  65280,
  255,
  16776960,
  16711935,
  65535,
  8388608,
  32768,
  128,
  8421376,
  8388736,
  32896,
  12632256,
  8421504,
  10066431,
  10040166,
  16777164,
  13434879,
  6684774,
  16744576,
  26316,
  13421823,
  128,
  16711935,
  16776960,
  65535,
  8388736,
  8388608,
  32896,
  255,
  52479,
  13434879,
  13434828,
  16777113,
  10079487,
  16751052,
  13408767,
  16764057,
  3368703,
  3394764,
  10079232,
  16763904,
  16750848,
  16737792,
  6710937,
  9868950,
  13158,
  3381606,
  13056,
  3355392,
  10040064,
  10040166,
  3355545,
  3355443,
  /* Other entries to appease BIFF8/12 */
  0,
  /* 0x40 icvForeground ?? */
  16777215,
  /* 0x41 icvBackground ?? */
  0,
  /* 0x42 icvFrame ?? */
  0,
  /* 0x43 icv3D ?? */
  0,
  /* 0x44 icv3DText ?? */
  0,
  /* 0x45 icv3DHilite ?? */
  0,
  /* 0x46 icv3DShadow ?? */
  0,
  /* 0x47 icvHilite ?? */
  0,
  /* 0x48 icvCtlText ?? */
  0,
  /* 0x49 icvCtlScrl ?? */
  0,
  /* 0x4A icvCtlInv ?? */
  0,
  /* 0x4B icvCtlBody ?? */
  0,
  /* 0x4C icvCtlFrame ?? */
  0,
  /* 0x4D icvCtlFore ?? */
  0,
  /* 0x4E icvCtlBack ?? */
  0,
  /* 0x4F icvCtlNeutral */
  0,
  /* 0x50 icvInfoBk ?? */
  0
  /* 0x51 icvInfoText ?? */
]), _a = /* @__PURE__ */ er(Kf), Ar = {
  0: "#NULL!",
  7: "#DIV/0!",
  15: "#VALUE!",
  23: "#REF!",
  29: "#NAME?",
  36: "#NUM!",
  42: "#N/A",
  43: "#GETTING_DATA",
  255: "#WTF?"
}, sr = {
  "#NULL!": 0,
  "#DIV/0!": 7,
  "#VALUE!": 15,
  "#REF!": 23,
  "#NAME?": 29,
  "#NUM!": 36,
  "#N/A": 42,
  "#GETTING_DATA": 43,
  "#WTF?": 255
}, $i = [
  "_xlnm.Consolidate_Area",
  "_xlnm.Auto_Open",
  "_xlnm.Auto_Close",
  "_xlnm.Extract",
  "_xlnm.Database",
  "_xlnm.Criteria",
  "_xlnm.Print_Area",
  "_xlnm.Print_Titles",
  "_xlnm.Recorder",
  "_xlnm.Data_Form",
  "_xlnm.Auto_Activate",
  "_xlnm.Auto_Deactivate",
  "_xlnm.Sheet_Title",
  "_xlnm._FilterDatabase"
], An = {
  /* Workbook */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml": "workbooks",
  "application/vnd.ms-excel.sheet.macroEnabled.main+xml": "workbooks",
  "application/vnd.ms-excel.sheet.binary.macroEnabled.main": "workbooks",
  "application/vnd.ms-excel.addin.macroEnabled.main+xml": "workbooks",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.template.main+xml": "workbooks",
  /* Worksheet */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml": "sheets",
  "application/vnd.ms-excel.worksheet": "sheets",
  "application/vnd.ms-excel.binIndexWs": "TODO",
  /* Binary Index */
  /* Chartsheet */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.chartsheet+xml": "charts",
  "application/vnd.ms-excel.chartsheet": "charts",
  /* Macrosheet */
  "application/vnd.ms-excel.macrosheet+xml": "macros",
  "application/vnd.ms-excel.macrosheet": "macros",
  "application/vnd.ms-excel.intlmacrosheet": "TODO",
  "application/vnd.ms-excel.binIndexMs": "TODO",
  /* Binary Index */
  /* Dialogsheet */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.dialogsheet+xml": "dialogs",
  "application/vnd.ms-excel.dialogsheet": "dialogs",
  /* Shared Strings */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml": "strs",
  "application/vnd.ms-excel.sharedStrings": "strs",
  /* Styles */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml": "styles",
  "application/vnd.ms-excel.styles": "styles",
  /* File Properties */
  "application/vnd.openxmlformats-package.core-properties+xml": "coreprops",
  "application/vnd.openxmlformats-officedocument.custom-properties+xml": "custprops",
  "application/vnd.openxmlformats-officedocument.extended-properties+xml": "extprops",
  /* Custom Data Properties */
  "application/vnd.openxmlformats-officedocument.customXmlProperties+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.customProperty": "TODO",
  /* Comments */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml": "comments",
  "application/vnd.ms-excel.comments": "comments",
  "application/vnd.ms-excel.threadedcomments+xml": "threadedcomments",
  "application/vnd.ms-excel.person+xml": "people",
  /* Metadata (Stock/Geography and Dynamic Array) */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheetMetadata+xml": "metadata",
  "application/vnd.ms-excel.sheetMetadata": "metadata",
  /* PivotTable */
  "application/vnd.ms-excel.pivotTable": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotTable+xml": "TODO",
  /* Chart Objects */
  "application/vnd.openxmlformats-officedocument.drawingml.chart+xml": "TODO",
  /* Chart Colors */
  "application/vnd.ms-office.chartcolorstyle+xml": "TODO",
  /* Chart Style */
  "application/vnd.ms-office.chartstyle+xml": "TODO",
  /* Chart Advanced */
  "application/vnd.ms-office.chartex+xml": "TODO",
  /* Calculation Chain */
  "application/vnd.ms-excel.calcChain": "calcchains",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.calcChain+xml": "calcchains",
  /* Printer Settings */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.printerSettings": "TODO",
  /* ActiveX */
  "application/vnd.ms-office.activeX": "TODO",
  "application/vnd.ms-office.activeX+xml": "TODO",
  /* Custom Toolbars */
  "application/vnd.ms-excel.attachedToolbars": "TODO",
  /* External Data Connections */
  "application/vnd.ms-excel.connections": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.connections+xml": "TODO",
  /* External Links */
  "application/vnd.ms-excel.externalLink": "links",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.externalLink+xml": "links",
  /* PivotCache */
  "application/vnd.ms-excel.pivotCacheDefinition": "TODO",
  "application/vnd.ms-excel.pivotCacheRecords": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotCacheDefinition+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotCacheRecords+xml": "TODO",
  /* Query Table */
  "application/vnd.ms-excel.queryTable": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.queryTable+xml": "TODO",
  /* Shared Workbook */
  "application/vnd.ms-excel.userNames": "TODO",
  "application/vnd.ms-excel.revisionHeaders": "TODO",
  "application/vnd.ms-excel.revisionLog": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionHeaders+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionLog+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.userNames+xml": "TODO",
  /* Single Cell Table */
  "application/vnd.ms-excel.tableSingleCells": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.tableSingleCells+xml": "TODO",
  /* Slicer */
  "application/vnd.ms-excel.slicer": "TODO",
  "application/vnd.ms-excel.slicerCache": "TODO",
  "application/vnd.ms-excel.slicer+xml": "TODO",
  "application/vnd.ms-excel.slicerCache+xml": "TODO",
  /* Sort Map */
  "application/vnd.ms-excel.wsSortMap": "TODO",
  /* Table */
  "application/vnd.ms-excel.table": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml": "TODO",
  /* Themes */
  "application/vnd.openxmlformats-officedocument.theme+xml": "themes",
  /* Theme Override */
  "application/vnd.openxmlformats-officedocument.themeOverride+xml": "TODO",
  /* Timeline */
  "application/vnd.ms-excel.Timeline+xml": "TODO",
  /* verify */
  "application/vnd.ms-excel.TimelineCache+xml": "TODO",
  /* verify */
  /* VBA */
  "application/vnd.ms-office.vbaProject": "vba",
  "application/vnd.ms-office.vbaProjectSignature": "TODO",
  /* Volatile Dependencies */
  "application/vnd.ms-office.volatileDependencies": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.volatileDependencies+xml": "TODO",
  /* Control Properties */
  "application/vnd.ms-excel.controlproperties+xml": "TODO",
  /* Data Model */
  "application/vnd.openxmlformats-officedocument.model+data": "TODO",
  /* Survey */
  "application/vnd.ms-excel.Survey+xml": "TODO",
  /* Drawing */
  "application/vnd.openxmlformats-officedocument.drawing+xml": "drawings",
  "application/vnd.openxmlformats-officedocument.drawingml.chartshapes+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.drawingml.diagramColors+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.drawingml.diagramData+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.drawingml.diagramLayout+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.drawingml.diagramStyle+xml": "TODO",
  /* VML */
  "application/vnd.openxmlformats-officedocument.vmlDrawing": "TODO",
  "application/vnd.openxmlformats-package.relationships+xml": "rels",
  "application/vnd.openxmlformats-officedocument.oleObject": "TODO",
  /* Image */
  "image/png": "TODO",
  sheet: "js"
};
function Yf() {
  return {
    workbooks: [],
    sheets: [],
    charts: [],
    dialogs: [],
    macros: [],
    rels: [],
    strs: [],
    comments: [],
    threadedcomments: [],
    links: [],
    coreprops: [],
    extprops: [],
    custprops: [],
    themes: [],
    styles: [],
    calcchains: [],
    vba: [],
    drawings: [],
    metadata: [],
    people: [],
    TODO: [],
    xmlns: ""
  };
}
function jf(e) {
  var a = Yf();
  if (!e || !e.match) return a;
  var r = {};
  if ((e.match(or) || []).forEach(function(t) {
    var n = le(t);
    switch (n[0].replace(ef, "<")) {
      case "<?xml":
        break;
      case "<Types":
        a.xmlns = n["xmlns" + (n[0].match(/<(\w+):/) || ["", ""])[1]];
        break;
      case "<Default":
        r[n.Extension.toLowerCase()] = n.ContentType;
        break;
      case "<Override":
        a[An[n.ContentType]] !== void 0 && a[An[n.ContentType]].push(n.PartName);
        break;
    }
  }), a.xmlns !== hf.CT) throw new Error("Unknown Namespace: " + a.xmlns);
  return a.calcchain = a.calcchains.length > 0 ? a.calcchains[0] : "", a.sst = a.strs.length > 0 ? a.strs[0] : "", a.style = a.styles.length > 0 ? a.styles[0] : "", a.defaults = r, delete a.calcchains, a;
}
var Ra = {
  WB: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument",
  SHEET: "http://sheetjs.openxmlformats.org/officeDocument/2006/relationships/officeDocument",
  HLINK: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
  VML: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/vmlDrawing",
  XPATH: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/externalLinkPath",
  XMISS: "http://schemas.microsoft.com/office/2006/relationships/xlExternalLinkPath/xlPathMissing",
  XLINK: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/externalLink",
  CXML: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml",
  CXMLP: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXmlProps",
  CMNT: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments",
  CORE_PROPS: "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties",
  EXT_PROPS: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties",
  CUST_PROPS: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties",
  SST: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings",
  STY: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles",
  THEME: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme",
  CHART: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart",
  CHARTEX: "http://schemas.microsoft.com/office/2014/relationships/chartEx",
  CS: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/chartsheet",
  WS: [
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet",
    "http://purl.oclc.org/ooxml/officeDocument/relationships/worksheet"
  ],
  DS: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/dialogsheet",
  MS: "http://schemas.microsoft.com/office/2006/relationships/xlMacrosheet",
  IMG: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
  DRAW: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing",
  XLMETA: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sheetMetadata",
  TCMNT: "http://schemas.microsoft.com/office/2017/10/relationships/threadedComment",
  PEOPLE: "http://schemas.microsoft.com/office/2017/10/relationships/person",
  CONN: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/connections",
  VBA: "http://schemas.microsoft.com/office/2006/relationships/vbaProject"
};
function m0(e) {
  var a = e.lastIndexOf("/");
  return e.slice(0, a + 1) + "_rels/" + e.slice(a + 1) + ".rels";
}
function Ja(e, a) {
  var r = { "!id": {} };
  if (!e) return r;
  a.charAt(0) !== "/" && (a = "/" + a);
  var t = {};
  return (e.match(or) || []).forEach(function(n) {
    var i = le(n);
    if (i[0] === "<Relationship") {
      var c = {};
      c.Type = i.Type, c.Target = Se(i.Target), c.Id = i.Id, i.TargetMode && (c.TargetMode = i.TargetMode);
      var s = i.TargetMode === "External" ? i.Target : Oa(i.Target, a);
      r[s] = c, t[i.Id] = c;
    }
  }), r["!id"] = t, r;
}
var Jf = "application/vnd.oasis.opendocument.spreadsheet";
function Zf(e, a) {
  for (var r = jt(e), t, n; t = qe.exec(r); )
    switch (t[3]) {
      case "manifest":
        break;
      case "file-entry":
        if (n = le(t[0], !1), n.path == "/" && n.type !== Jf)
          throw new Error("This OpenDocument is not a spreadsheet");
        break;
      case "encryption-data":
      case "algorithm":
      case "start-key-generation":
      case "key-derivation":
        throw new Error("Unsupported ODS Encryption");
      default:
        if (a && a.WTF)
          throw t;
    }
}
var yn = [
  ["cp:category", "Category"],
  ["cp:contentStatus", "ContentStatus"],
  ["cp:keywords", "Keywords"],
  ["cp:lastModifiedBy", "LastAuthor"],
  ["cp:lastPrinted", "LastPrinted"],
  ["cp:revision", "RevNumber"],
  ["cp:version", "Version"],
  ["dc:creator", "Author"],
  ["dc:description", "Comments"],
  ["dc:identifier", "Identifier"],
  ["dc:language", "Language"],
  ["dc:subject", "Subject"],
  ["dc:title", "Title"],
  ["dcterms:created", "CreatedDate", "date"],
  ["dcterms:modified", "ModifiedDate", "date"]
];
function Xi(e) {
  var a = {};
  e = Ue(e);
  for (var r = 0; r < yn.length; ++r) {
    var t = yn[r], n = ma(e, t[0]);
    n != null && n.length > 0 && (a[t[1]] = Se(n[1])), t[2] === "date" && a[t[1]] && (a[t[1]] = fr(a[t[1]]));
  }
  return a;
}
var qf = [
  ["Application", "Application", "string"],
  ["AppVersion", "AppVersion", "string"],
  ["Company", "Company", "string"],
  ["DocSecurity", "DocSecurity", "string"],
  ["Manager", "Manager", "string"],
  ["HyperlinksChanged", "HyperlinksChanged", "bool"],
  ["SharedDoc", "SharedDoc", "bool"],
  ["LinksUpToDate", "LinksUpToDate", "bool"],
  ["ScaleCrop", "ScaleCrop", "bool"],
  ["HeadingPairs", "HeadingPairs", "raw"],
  ["TitlesOfParts", "TitlesOfParts", "raw"]
];
function zi(e, a, r, t) {
  var n = [];
  if (typeof e == "string") n = vn(e, t);
  else for (var i = 0; i < e.length; ++i) n = n.concat(e[i].map(function(l) {
    return { v: l };
  }));
  var c = typeof a == "string" ? vn(a, t).map(function(l) {
    return l.v;
  }) : a, s = 0, f = 0;
  if (c.length > 0) for (var o = 0; o !== n.length; o += 2) {
    switch (f = +n[o + 1].v, n[o].v) {
      case "Worksheets":
      case "工作表":
      case "Листы":
      case "أوراق العمل":
      case "ワークシート":
      case "גליונות עבודה":
      case "Arbeitsblätter":
      case "Çalışma Sayfaları":
      case "Feuilles de calcul":
      case "Fogli di lavoro":
      case "Folhas de cálculo":
      case "Planilhas":
      case "Regneark":
      case "Hojas de cálculo":
      case "Werkbladen":
        r.Worksheets = f, r.SheetNames = c.slice(s, s + f);
        break;
      case "Named Ranges":
      case "Rangos con nombre":
      case "名前付き一覧":
      case "Benannte Bereiche":
      case "Navngivne områder":
        r.NamedRanges = f, r.DefinedNames = c.slice(s, s + f);
        break;
      case "Charts":
      case "Diagramme":
        r.Chartsheets = f, r.ChartNames = c.slice(s, s + f);
        break;
    }
    s += f;
  }
}
function Qf(e, a, r) {
  var t = {};
  return a || (a = {}), e = Ue(e), qf.forEach(function(n) {
    var i = (ir(e, n[0]) || [])[1];
    switch (n[2]) {
      case "string":
        i && (a[n[1]] = Se(i));
        break;
      case "bool":
        a[n[1]] = i === "true";
        break;
      case "raw":
        var c = ma(e, n[0]);
        c && c.length > 0 && (t[n[1]] = c[1]);
        break;
    }
  }), t.HeadingPairs && t.TitlesOfParts && zi(t.HeadingPairs, t.TitlesOfParts, a, r), a;
}
var eo = /<[^<>]+>[^<]*/g;
function ro(e, a) {
  var r = {}, t = "", n = e.match(eo);
  if (n) for (var i = 0; i != n.length; ++i) {
    var c = n[i], s = le(c);
    switch (Hr(s[0])) {
      case "<?xml":
        break;
      case "<Properties":
        break;
      case "<property":
        t = Se(s.name);
        break;
      case "</property>":
        t = null;
        break;
      default:
        if (c.indexOf("<vt:") === 0) {
          var f = c.split(">"), o = f[0].slice(4), l = f[1];
          switch (o) {
            case "lpstr":
            case "bstr":
            case "lpwstr":
              r[t] = Se(l);
              break;
            case "bool":
              r[t] = Be(l);
              break;
            case "i1":
            case "i2":
            case "i4":
            case "i8":
            case "int":
            case "uint":
              r[t] = parseInt(l, 10);
              break;
            case "r4":
            case "r8":
            case "decimal":
              r[t] = parseFloat(l);
              break;
            case "filetime":
            case "date":
              r[t] = fr(l);
              break;
            case "cy":
            case "error":
              r[t] = Se(l);
              break;
            default:
              if (o.slice(-1) == "/") break;
              a.WTF && typeof console < "u" && console.warn("Unexpected", c, o, f);
          }
        } else if (c.slice(0, 2) !== "</") {
          if (a.WTF) throw new Error(c);
        }
    }
  }
  return r;
}
var ao = {
  Title: "Title",
  Subject: "Subject",
  Author: "Author",
  Keywords: "Keywords",
  Comments: "Description",
  LastAuthor: "LastAuthor",
  RevNumber: "Revision",
  Application: "AppName",
  /* TotalTime: 'TotalTime', */
  LastPrinted: "LastPrinted",
  CreatedDate: "Created",
  ModifiedDate: "LastSaved",
  /* Pages */
  /* Words */
  /* Characters */
  Category: "Category",
  /* PresentationFormat */
  Manager: "Manager",
  Company: "Company",
  /* Guid */
  /* HyperlinkBase */
  /* Bytes */
  /* Lines */
  /* Paragraphs */
  /* CharactersWithSpaces */
  AppVersion: "Version",
  ContentStatus: "ContentStatus",
  /* NOTE: missing from schema */
  Identifier: "Identifier",
  /* NOTE: missing from schema */
  Language: "Language"
  /* NOTE: missing from schema */
}, f0;
function to(e, a, r) {
  f0 || (f0 = D0(ao)), a = f0[a] || a, e[a] = r;
}
function M0(e) {
  var a = e.read_shift(4), r = e.read_shift(4);
  return new Date((r / 1e7 * Math.pow(2, 32) + a / 1e7 - 11644473600) * 1e3).toISOString().replace(/\.000/, "");
}
function no(e, a, r) {
  var t = e.l, n = e.read_shift(0, "lpstr-cp");
  if (r) for (; e.l - t & 3; ) ++e.l;
  return n;
}
function io(e, a, r) {
  var t = e.read_shift(0, "lpwstr");
  return t;
}
function Ki(e, a, r) {
  return a === 31 ? io(e) : no(e, a, r);
}
function Za(e, a, r) {
  return Ki(e, a, r === !1 ? 0 : 4);
}
function so(e, a) {
  if (!a) throw new Error("VtUnalignedString must have positive length");
  return Ki(e, a, 0);
}
function co(e) {
  for (var a = e.read_shift(4), r = [], t = 0; t != a; ++t) {
    var n = e.l;
    r[t] = e.read_shift(0, "lpwstr").replace(wr, ""), e.l - n & 2 && (e.l += 2);
  }
  return r;
}
function fo(e) {
  for (var a = e.read_shift(4), r = [], t = 0; t != a; ++t) r[t] = e.read_shift(0, "lpstr-cp").replace(wr, "");
  return r;
}
function oo(e) {
  var a = e.l, r = Ut(e, Gi);
  e[e.l] == 0 && e[e.l + 1] == 0 && e.l - a & 2 && (e.l += 2);
  var t = Ut(e, kr);
  return [r, t];
}
function lo(e) {
  for (var a = e.read_shift(4), r = [], t = 0; t < a / 2; ++t) r.push(oo(e));
  return r;
}
function Sn(e, a) {
  for (var r = e.read_shift(4), t = {}, n = 0; n != r; ++n) {
    var i = e.read_shift(4), c = e.read_shift(4);
    t[i] = e.read_shift(c, a === 1200 ? "utf16le" : "utf8").replace(wr, "").replace($a, "!"), a === 1200 && c % 2 && (e.l += 2);
  }
  return e.l & 3 && (e.l = e.l >> 3 << 2), t;
}
function Yi(e) {
  var a = e.read_shift(4), r = e.slice(e.l, e.l + a);
  return e.l += a, (a & 3) > 0 && (e.l += 4 - (a & 3) & 3), r;
}
function uo(e) {
  var a = {};
  return a.Size = e.read_shift(4), e.l += a.Size + 3 - (a.Size - 1) % 4, a;
}
function Ut(e, a, r) {
  var t = e.read_shift(2), n, i = r || {};
  if (e.l += 2, a !== wn && t !== a && Vf.indexOf(a) === -1 && !((a & 65534) == 4126 && (t & 65534) == 4126))
    throw new Error("Expected type " + a + " saw " + t);
  switch (a === wn ? t : a) {
    case 2:
      return n = e.read_shift(2, "i"), i.raw || (e.l += 2), n;
    case 3:
      return n = e.read_shift(4, "i"), n;
    case 11:
      return e.read_shift(4) !== 0;
    case 19:
      return n = e.read_shift(4), n;
    case 30:
      e.l += 4, val = Za(e, e[e.l - 4]).replace(/(^|[^\u0000])\u0000+$/, "$1");
      break;
    case 31:
      e.l += 4, val = Za(e, e[e.l - 4]).replace(/(^|[^\u0000])\u0000+$/, "$1");
      break;
    case 64:
      return M0(e);
    case 65:
      return Yi(e);
    case 71:
      return uo(e);
    case 80:
      return Za(e, t, !i.raw).replace(wr, "");
    case 81:
      return so(
        e,
        t
        /*, 4*/
      ).replace(wr, "");
    case 4108:
      return lo(e);
    case 4126:
    case 4127:
      return t == 4127 ? co(e) : fo(e);
    default:
      throw new Error("TypedPropertyValue unrecognized type " + a + " " + t);
  }
}
function Cn(e, a) {
  var r = e.l, t = e.read_shift(4), n = e.read_shift(4), i = [], c = 0, s = 0, f = -1, o = {};
  for (c = 0; c != n; ++c) {
    var l = e.read_shift(4), v = e.read_shift(4);
    i[c] = [l, v + r];
  }
  i.sort(function(E, g) {
    return E[1] - g[1];
  });
  var x = {};
  for (c = 0; c != n; ++c) {
    if (e.l !== i[c][1]) {
      var u = !0;
      if (c > 0 && a) switch (a[i[c - 1][0]].t) {
        case 2:
          e.l + 2 === i[c][1] && (e.l += 2, u = !1);
          break;
        case 80:
          e.l <= i[c][1] && (e.l = i[c][1], u = !1);
          break;
        case 4108:
          e.l <= i[c][1] && (e.l = i[c][1], u = !1);
          break;
      }
      if ((!a || c == 0) && e.l <= i[c][1] && (u = !1, e.l = i[c][1]), u) throw new Error("Read Error: Expected address " + i[c][1] + " at " + e.l + " :" + c);
    }
    if (a) {
      if (i[c][0] == 0 && i.length > c + 1 && i[c][1] == i[c + 1][1]) continue;
      var p = a[i[c][0]];
      if (x[p.n] = Ut(e, p.t, { raw: !0 }), p.p === "version" && (x[p.n] = String(x[p.n] >> 16) + "." + ("0000" + String(x[p.n] & 65535)).slice(-4)), p.n == "CodePage") switch (x[p.n]) {
        case 0:
          x[p.n] = 1252;
        /* falls through */
        case 874:
        case 932:
        case 936:
        case 949:
        case 950:
        case 1250:
        case 1251:
        case 1253:
        case 1254:
        case 1255:
        case 1256:
        case 1257:
        case 1258:
        case 1e4:
        case 1200:
        case 1201:
        case 1252:
        case 65e3:
        case -536:
        case 65001:
        case -535:
          $r(s = x[p.n] >>> 0 & 65535);
          break;
        default:
          throw new Error("Unsupported CodePage: " + x[p.n]);
      }
    } else if (i[c][0] === 1) {
      if (s = x.CodePage = Ut(e, B0), $r(s), f !== -1) {
        var _ = e.l;
        e.l = i[f][1], o = Sn(e, s), e.l = _;
      }
    } else if (i[c][0] === 0) {
      if (s === 0) {
        f = c, e.l = i[c + 1][1];
        continue;
      }
      o = Sn(e, s);
    } else {
      var d = o[i[c][0]], h;
      switch (e[e.l]) {
        case 65:
          e.l += 4, h = Yi(e);
          break;
        case 30:
          e.l += 4, h = Za(e, e[e.l - 4]).replace(/(^|[^\u0000])\u0000+$/, "$1");
          break;
        case 31:
          e.l += 4, h = Za(e, e[e.l - 4]).replace(/(^|[^\u0000])\u0000+$/, "$1");
          break;
        case 3:
          e.l += 4, h = e.read_shift(4, "i");
          break;
        case 19:
          e.l += 4, h = e.read_shift(4);
          break;
        case 5:
          e.l += 4, h = e.read_shift(8, "f");
          break;
        case 11:
          e.l += 4, h = ze(e, 4);
          break;
        case 64:
          e.l += 4, h = fr(M0(e));
          break;
        default:
          throw new Error("unparsed value: " + e[e.l]);
      }
      x[d] = h;
    }
  }
  return e.l = r + t, x;
}
function Dn(e, a, r) {
  var t = e.content;
  if (!t) return {};
  rr(t, 0);
  var n, i, c, s, f = 0;
  t.chk("feff", "Byte Order: "), t.read_shift(2);
  var o = t.read_shift(4), l = t.read_shift(16);
  if (l !== Oe.utils.consts.HEADER_CLSID && l !== r) throw new Error("Bad PropertySet CLSID " + l);
  if (n = t.read_shift(4), n !== 1 && n !== 2) throw new Error("Unrecognized #Sets: " + n);
  if (i = t.read_shift(16), s = t.read_shift(4), n === 1 && s !== t.l) throw new Error("Length mismatch: " + s + " !== " + t.l);
  n === 2 && (c = t.read_shift(16), f = t.read_shift(4));
  var v = Cn(t, a), x = { SystemIdentifier: o };
  for (var u in v) x[u] = v[u];
  if (x.FMTID = i, n === 1) return x;
  if (f - t.l == 2 && (t.l += 2), t.l !== f) throw new Error("Length mismatch 2: " + t.l + " !== " + f);
  var p;
  try {
    p = Cn(t, null);
  } catch {
  }
  for (u in p) x[u] = p[u];
  return x.FMTID = [i, c], x;
}
function na(e, a) {
  return e.read_shift(a), null;
}
function ho(e, a, r) {
  for (var t = [], n = e.l + a; e.l < n; ) t.push(r(e, n - e.l));
  if (n !== e.l) throw new Error("Slurp error");
  return t;
}
function ze(e, a) {
  return e.read_shift(a) === 1;
}
function Xe(e) {
  return e.read_shift(2, "u");
}
function ji(e, a) {
  return ho(e, a, Xe);
}
function Ji(e) {
  var a = e.read_shift(1), r = e.read_shift(1);
  return r === 1 ? a : a === 1;
}
function Ba(e, a, r) {
  var t = e.read_shift(r && r.biff >= 12 ? 2 : 1), n = "sbcs-cont", i = Lr;
  if (r && r.biff >= 8 && (Lr = 1200), !r || r.biff == 8) {
    var c = e.read_shift(1);
    c && (n = "dbcs-cont");
  } else r.biff == 12 && (n = "wstr");
  r.biff >= 2 && r.biff <= 5 && (n = "cpstr");
  var s = t ? e.read_shift(t, n) : "";
  return Lr = i, s;
}
function xo(e) {
  var a = Lr;
  Lr = 1200;
  var r = e.read_shift(2), t = e.read_shift(1), n = t & 4, i = t & 8, c = 1 + (t & 1), s = 0, f, o = {};
  i && (s = e.read_shift(2)), n && (f = e.read_shift(4));
  var l = c == 2 ? "dbcs-cont" : "sbcs-cont", v = r === 0 ? "" : e.read_shift(r, l);
  return i && (e.l += 4 * s), n && (e.l += f), o.t = v, i || (o.raw = "<t>" + o.t + "</t>", o.r = o.t), Lr = a, o;
}
function Fa(e, a, r) {
  var t;
  if (r) {
    if (r.biff >= 2 && r.biff <= 5) return e.read_shift(a, "cpstr");
    if (r.biff >= 12) return e.read_shift(a, "dbcs-cont");
  }
  var n = e.read_shift(1);
  return n === 0 ? t = e.read_shift(a, "sbcs-cont") : t = e.read_shift(a, "dbcs-cont"), t;
}
function xt(e, a, r) {
  var t = e.read_shift(r && r.biff == 2 ? 1 : 2);
  return t === 0 ? (e.l++, "") : Fa(e, t, r);
}
function Ca(e, a, r) {
  if (r.biff > 5) return xt(e, a, r);
  var t = e.read_shift(1);
  return t === 0 ? (e.l++, "") : e.read_shift(t, r.biff <= 4 || !e.lens ? "cpstr" : "sbcs-cont");
}
function vo(e) {
  var a = e.read_shift(1);
  e.l++;
  var r = e.read_shift(2);
  return e.l += 2, [a, r];
}
function po(e) {
  var a = e.read_shift(4), r = e.l, t = !1;
  a > 24 && (e.l += a - 24, e.read_shift(16) === "795881f43b1d7f48af2c825dc4852763" && (t = !0), e.l = r);
  var n = e.read_shift((t ? a - 24 : a) >> 1, "utf16le").replace(wr, "");
  return t && (e.l += 24), n;
}
function go(e) {
  for (var a = e.read_shift(2), r = ""; a-- > 0; ) r += "../";
  var t = e.read_shift(0, "lpstr-ansi");
  if (e.l += 2, e.read_shift(2) != 57005) throw new Error("Bad FileMoniker");
  var n = e.read_shift(4);
  if (n === 0) return r + t.replace(/\\/g, "/");
  var i = e.read_shift(4);
  if (e.read_shift(2) != 3) throw new Error("Bad FileMoniker");
  var c = e.read_shift(i >> 1, "utf16le").replace(wr, "");
  return r + c;
}
function mo(e, a) {
  var r = e.read_shift(16);
  switch (r) {
    case "e0c9ea79f9bace118c8200aa004ba90b":
      return po(e);
    case "0303000000000000c000000000000046":
      return go(e);
    default:
      throw new Error("Unsupported Moniker " + r);
  }
}
function Ft(e) {
  var a = e.read_shift(4), r = a > 0 ? e.read_shift(a, "utf16le").replace(wr, "") : "";
  return r;
}
function _o(e, a) {
  var r = e.l + a, t = e.read_shift(4);
  if (t !== 2) throw new Error("Unrecognized streamVersion: " + t);
  var n = e.read_shift(2);
  e.l += 2;
  var i, c, s, f, o = "", l, v;
  n & 16 && (i = Ft(e, r - e.l)), n & 128 && (c = Ft(e, r - e.l)), (n & 257) === 257 && (s = Ft(e, r - e.l)), (n & 257) === 1 && (f = mo(e, r - e.l)), n & 8 && (o = Ft(e, r - e.l)), n & 32 && (l = e.read_shift(16)), n & 64 && (v = M0(
    e
    /*, 8*/
  )), e.l = r;
  var x = c || s || f || "";
  x && o && (x += "#" + o), x || (x = "#" + o), n & 2 && x.charAt(0) == "/" && x.charAt(1) != "/" && (x = "file://" + x);
  var u = { Target: x };
  return l && (u.guid = l), v && (u.time = v), i && (u.Tooltip = i), u;
}
function Zi(e) {
  var a = e.read_shift(1), r = e.read_shift(1), t = e.read_shift(1), n = e.read_shift(1);
  return [a, r, t, n];
}
function qi(e, a) {
  var r = Zi(e);
  return r[3] = 0, r;
}
function zr(e, a, r) {
  var t = e.read_shift(2), n = e.read_shift(2), i = { r: t, c: n, ixfe: 0 };
  if (r && r.biff == 2 || a == 7) {
    var c = e.read_shift(1);
    i.ixfe = c & 63, e.l += 2;
  } else i.ixfe = e.read_shift(2);
  return i;
}
function To(e) {
  var a = e.read_shift(2), r = e.read_shift(2);
  return e.l += 8, { type: a, flags: r };
}
function Eo(e, a, r) {
  return a === 0 ? "" : Ca(e, a, r);
}
function ko(e, a, r) {
  var t = r.biff > 8 ? 4 : 2, n = e.read_shift(t), i = e.read_shift(t, "i"), c = e.read_shift(t, "i");
  return [n, i, c];
}
function Qi(e) {
  var a = e.read_shift(2), r = Zt(e);
  return [a, r];
}
function wo(e, a, r) {
  e.l += 4, a -= 4;
  var t = e.l + a, n = Ba(e, a, r), i = e.read_shift(2);
  if (t -= e.l, i !== t) throw new Error("Malformed AddinUdf: padding = " + t + " != " + i);
  return e.l += i, n;
}
function qt(e) {
  var a = e.read_shift(2), r = e.read_shift(2), t = e.read_shift(2), n = e.read_shift(2);
  return { s: { c: t, r: a }, e: { c: n, r } };
}
function es(e) {
  var a = e.read_shift(2), r = e.read_shift(2), t = e.read_shift(1), n = e.read_shift(1);
  return { s: { c: t, r: a }, e: { c: n, r } };
}
var Fo = es;
function rs(e) {
  e.l += 4;
  var a = e.read_shift(2), r = e.read_shift(2), t = e.read_shift(2);
  return e.l += 12, [r, a, t];
}
function Ao(e) {
  var a = {};
  return e.l += 4, e.l += 16, a.fSharedNote = e.read_shift(2), e.l += 4, a;
}
function yo(e) {
  var a = {};
  return e.l += 4, e.cf = e.read_shift(2), a;
}
function ur(e) {
  e.l += 2, e.l += e.read_shift(2);
}
var So = {
  0: ur,
  /* FtEnd */
  4: ur,
  /* FtMacro */
  5: ur,
  /* FtButton */
  6: ur,
  /* FtGmo */
  7: yo,
  /* FtCf */
  8: ur,
  /* FtPioGrbit */
  9: ur,
  /* FtPictFmla */
  10: ur,
  /* FtCbls */
  11: ur,
  /* FtRbo */
  12: ur,
  /* FtSbs */
  13: Ao,
  /* FtNts */
  14: ur,
  /* FtSbsFmla */
  15: ur,
  /* FtGboData */
  16: ur,
  /* FtEdoData */
  17: ur,
  /* FtRboData */
  18: ur,
  /* FtCblsData */
  19: ur,
  /* FtLbsData */
  20: ur,
  /* FtCblsFmla */
  21: rs
};
function Co(e, a) {
  for (var r = e.l + a, t = []; e.l < r; ) {
    var n = e.read_shift(2);
    e.l -= 2;
    try {
      t[n] = So[n](e, r - e.l);
    } catch {
      return e.l = r, t;
    }
  }
  return e.l != r && (e.l = r), t;
}
function At(e, a) {
  var r = { BIFFVer: 0, dt: 0 };
  switch (r.BIFFVer = e.read_shift(2), a -= 2, a >= 2 && (r.dt = e.read_shift(2), e.l -= 2), r.BIFFVer) {
    case 1536:
    /* BIFF8 */
    case 1280:
    /* BIFF5 */
    case 1024:
    /* BIFF4 */
    case 768:
    /* BIFF3 */
    case 512:
    /* BIFF2 */
    case 2:
    case 7:
      break;
    default:
      if (a > 6) throw new Error("Unexpected BIFF Ver " + r.BIFFVer);
  }
  return e.read_shift(a), r;
}
function Do(e, a) {
  return a === 0 || e.read_shift(2), 1200;
}
function Io(e, a, r) {
  if (r.enc)
    return e.l += a, "";
  var t = e.l, n = Ca(e, 0, r);
  return e.read_shift(a + t - e.l), n;
}
function Oo(e, a, r) {
  var t = r && r.biff == 8 || a == 2 ? e.read_shift(2) : (e.l += a, 0);
  return { fDialog: t & 16, fBelow: t & 64, fRight: t & 128 };
}
function Ro(e, a, r) {
  var t = "";
  if (r.biff == 4)
    return t = Ba(e, 0, r), t.length === 0 && (t = "Sheet1"), { name: t };
  var n = e.read_shift(4), i = e.read_shift(1) & 3, c = e.read_shift(1);
  switch (c) {
    case 0:
      c = "Worksheet";
      break;
    case 1:
      c = "Macrosheet";
      break;
    case 2:
      c = "Chartsheet";
      break;
    case 6:
      c = "VBAModule";
      break;
  }
  return t = Ba(e, 0, r), t.length === 0 && (t = "Sheet1"), { pos: n, hs: i, dt: c, name: t };
}
function No(e, a) {
  for (var r = e.l + a, t = e.read_shift(4), n = e.read_shift(4), i = [], c = 0; c != n && e.l < r; ++c)
    i.push(xo(e));
  return i.Count = t, i.Unique = n, i;
}
function Po(e, a) {
  var r = {};
  return r.dsst = e.read_shift(2), e.l += a - 2, r;
}
function bo(e) {
  var a = {};
  a.r = e.read_shift(2), a.c = e.read_shift(2), a.cnt = e.read_shift(2) - a.c;
  var r = e.read_shift(2);
  e.l += 4;
  var t = e.read_shift(1);
  return e.l += 3, t & 7 && (a.level = t & 7), t & 32 && (a.hidden = !0), t & 64 && (a.hpt = r / 20), a;
}
function Lo(e) {
  var a = To(e);
  if (a.type != 2211) throw new Error("Invalid Future Record " + a.type);
  var r = e.read_shift(4);
  return r !== 0;
}
function Bo(e) {
  return e.read_shift(2), e.read_shift(4);
}
function In(e, a, r) {
  var t = 0;
  r && r.biff == 2 || (t = e.read_shift(2));
  var n = e.read_shift(2);
  r && r.biff == 2 && (t = 1 - (n >> 15), n &= 32767);
  var i = { Unsynced: t & 1, DyZero: (t & 2) >> 1, ExAsc: (t & 4) >> 2, ExDsc: (t & 8) >> 3 };
  return [i, n];
}
function Mo(e) {
  var a = e.read_shift(2), r = e.read_shift(2), t = e.read_shift(2), n = e.read_shift(2), i = e.read_shift(2), c = e.read_shift(2), s = e.read_shift(2), f = e.read_shift(2), o = e.read_shift(2);
  return {
    Pos: [a, r],
    Dim: [t, n],
    Flags: i,
    CurTab: c,
    FirstTab: s,
    Selected: f,
    TabRatio: o
  };
}
function Uo(e, a, r) {
  if (r && r.biff >= 2 && r.biff < 5) return {};
  var t = e.read_shift(2);
  return { RTL: t & 64 };
}
function Ho() {
}
function Wo(e, a, r) {
  var t = {
    dyHeight: e.read_shift(2),
    fl: e.read_shift(2)
  };
  switch (r && r.biff || 8) {
    case 2:
      break;
    case 3:
    case 4:
      e.l += 2;
      break;
    default:
      e.l += 10;
      break;
  }
  return t.name = Ba(e, 0, r), t;
}
function Vo(e, a, r) {
  var t = zr(e, a, r);
  return t.isst = e.read_shift(4), t;
}
function Go(e, a, r) {
  r.biffguess && r.biff == 2 && (r.biff = 5);
  var t = e.l + a, n = zr(e, a, r), i = xt(e, t - e.l, r);
  return n.val = i, n;
}
function $o(e, a, r) {
  var t = e.read_shift(2), n = Ca(e, 0, r);
  return [t, n];
}
var Xo = Ca;
function On(e, a, r) {
  var t = e.l + a, n = r.biff == 8 || !r.biff ? 4 : 2, i = e.read_shift(n), c = e.read_shift(n), s = e.read_shift(2), f = e.read_shift(2);
  return e.l = t, { s: { r: i, c: s }, e: { r: c, c: f } };
}
function zo(e) {
  var a = e.read_shift(2), r = e.read_shift(2), t = Qi(e);
  return { r: a, c: r, ixfe: t[0], rknum: t[1] };
}
function Ko(e, a) {
  for (var r = e.l + a - 2, t = e.read_shift(2), n = e.read_shift(2), i = []; e.l < r; ) i.push(Qi(e));
  if (e.l !== r) throw new Error("MulRK read error");
  var c = e.read_shift(2);
  if (i.length != c - n + 1) throw new Error("MulRK length mismatch");
  return { r: t, c: n, C: c, rkrec: i };
}
function Yo(e, a) {
  for (var r = e.l + a - 2, t = e.read_shift(2), n = e.read_shift(2), i = []; e.l < r; ) i.push(e.read_shift(2));
  if (e.l !== r) throw new Error("MulBlank read error");
  var c = e.read_shift(2);
  if (i.length != c - n + 1) throw new Error("MulBlank length mismatch");
  return { r: t, c: n, C: c, ixfe: i };
}
function jo(e, a, r, t) {
  var n = {}, i = e.read_shift(4), c = e.read_shift(4), s = e.read_shift(4), f = e.read_shift(2);
  return n.patternType = Xf[s >> 26], t.cellStyles && (n.alc = i & 7, n.fWrap = i >> 3 & 1, n.alcV = i >> 4 & 7, n.fJustLast = i >> 7 & 1, n.trot = i >> 8 & 255, n.cIndent = i >> 16 & 15, n.fShrinkToFit = i >> 20 & 1, n.iReadOrder = i >> 22 & 2, n.fAtrNum = i >> 26 & 1, n.fAtrFnt = i >> 27 & 1, n.fAtrAlc = i >> 28 & 1, n.fAtrBdr = i >> 29 & 1, n.fAtrPat = i >> 30 & 1, n.fAtrProt = i >> 31 & 1, n.dgLeft = c & 15, n.dgRight = c >> 4 & 15, n.dgTop = c >> 8 & 15, n.dgBottom = c >> 12 & 15, n.icvLeft = c >> 16 & 127, n.icvRight = c >> 23 & 127, n.grbitDiag = c >> 30 & 3, n.icvTop = s & 127, n.icvBottom = s >> 7 & 127, n.icvDiag = s >> 14 & 127, n.dgDiag = s >> 21 & 15, n.icvFore = f & 127, n.icvBack = f >> 7 & 127, n.fsxButton = f >> 14 & 1), n;
}
function Jo(e, a, r) {
  var t = {};
  return t.ifnt = e.read_shift(2), t.numFmtId = e.read_shift(2), t.flags = e.read_shift(2), t.fStyle = t.flags >> 2 & 1, a -= 6, t.data = jo(e, a, t.fStyle, r), t;
}
function Zo(e) {
  var a = {};
  return a.ifnt = e.read_shift(1), e.l++, a.flags = e.read_shift(1), a.numFmtId = a.flags & 63, a.flags >>= 6, a.fStyle = 0, a.data = {}, a;
}
function qo(e) {
  var a = {};
  return a.ifnt = e.read_shift(1), a.numFmtId = e.read_shift(1), a.flags = e.read_shift(2), a.fStyle = a.flags >> 2 & 1, a.data = {}, a;
}
function Qo(e) {
  var a = {};
  return a.ifnt = e.read_shift(1), a.numFmtId = e.read_shift(1), a.flags = e.read_shift(2), a.fStyle = a.flags >> 2 & 1, a.data = {}, a;
}
function el(e) {
  e.l += 4;
  var a = [e.read_shift(2), e.read_shift(2)];
  if (a[0] !== 0 && a[0]--, a[1] !== 0 && a[1]--, a[0] > 7 || a[1] > 7) throw new Error("Bad Gutters: " + a.join("|"));
  return a;
}
function rl(e, a, r) {
  var t = zr(e, 6, r), n = Ji(e);
  return t.val = n, t.t = n === !0 || n === !1 ? "b" : "e", t;
}
function al(e, a, r) {
  r.biffguess && r.biff == 2 && (r.biff = 5);
  var t = zr(e, 6, r), n = xr(e);
  return t.val = n, t;
}
var Rn = Eo;
function tl(e, a, r) {
  var t = e.l + a, n = e.read_shift(2), i = e.read_shift(2);
  if (r.sbcch = i, i == 1025 || i == 14849) return [i, n];
  if (i < 1 || i > 255) throw new Error("Unexpected SupBook type: " + i);
  for (var c = Fa(e, i), s = []; t > e.l; ) s.push(xt(e));
  return [i, n, c, s];
}
function Nn(e, a, r) {
  var t = e.read_shift(2), n, i = {
    fBuiltIn: t & 1,
    fWantAdvise: t >>> 1 & 1,
    fWantPict: t >>> 2 & 1,
    fOle: t >>> 3 & 1,
    fOleLink: t >>> 4 & 1,
    cf: t >>> 5 & 1023,
    fIcon: t >>> 15 & 1
  };
  return r.sbcch === 14849 && (n = wo(e, a - 2, r)), i.body = n || e.read_shift(a - 2), typeof n == "string" && (i.Name = n), i;
}
function Pn(e, a, r) {
  var t = e.l + a, n = e.read_shift(2), i = e.read_shift(1), c = e.read_shift(1), s = e.read_shift(r && r.biff == 2 ? 1 : 2), f = 0;
  (!r || r.biff >= 5) && (r.biff != 5 && (e.l += 2), f = e.read_shift(2), r.biff == 5 && (e.l += 2), e.l += 4);
  var o = Fa(e, c, r);
  n & 32 && (o = $i[o.charCodeAt(0)]);
  var l = t - e.l;
  r && r.biff == 2 && --l;
  var v = t == e.l || s === 0 || !(l > 0) ? [] : Rh(e, l, r, s);
  return {
    chKey: i,
    Name: o,
    itab: f,
    rgce: v
  };
}
function as(e, a, r) {
  if (r.biff < 8 || !(r.biff > 8) && a == e[e.l] + (e[e.l + 1] == 3 ? 1 : 0) + 1) return bn(e, a, r);
  for (var t = [], n = e.l + a, i = e.read_shift(r.biff > 8 ? 4 : 2); i-- !== 0; ) t.push(ko(e, r.biff > 8 ? 12 : 6, r));
  if (e.l != n) throw new Error("Bad ExternSheet: " + e.l + " != " + n);
  return t;
}
function bn(e, a, r) {
  e[e.l + 1] == 3 && e[e.l]++;
  var t = Ba(e, a, r);
  return t.charCodeAt(0) == 3 ? t.slice(1) : t;
}
function nl(e, a, r) {
  if (r.biff < 8) {
    e.l += a;
    return;
  }
  var t = e.read_shift(2), n = e.read_shift(2), i = Fa(e, t, r), c = Fa(e, n, r);
  return [i, c];
}
function il(e, a, r) {
  var t = es(e);
  e.l++;
  var n = e.read_shift(1);
  return a -= 8, [Nh(e, a, r), n, t];
}
function Ln(e, a, r) {
  var t = Fo(e);
  switch (r.biff) {
    case 2:
      e.l++, a -= 7;
      break;
    case 3:
    case 4:
      e.l += 2, a -= 8;
      break;
    default:
      e.l += 6, a -= 12;
  }
  return [t, Ih(e, a, r)];
}
function sl(e) {
  var a = e.read_shift(4) !== 0, r = e.read_shift(4) !== 0, t = e.read_shift(4);
  return [a, r, t];
}
function cl(e, a, r) {
  var t = e.read_shift(2), n = e.read_shift(2), i = e.read_shift(2), c = e.read_shift(2), s = Ca(e, 0, r);
  return [{ r: t, c: n }, s, c, i];
}
function fl(e, a, r) {
  if (r && r.biff < 8) {
    var t = e.read_shift(2), n = e.read_shift(2);
    if (t == 65535 || t == -1) return;
    var i = e.read_shift(2), c = e.read_shift(Math.min(i, 2048), "cpstr");
    return [{ r: t, c: n }, c];
  }
  return cl(e, a, r);
}
function ol(e, a) {
  for (var r = [], t = e.read_shift(2); t--; ) r.push(qt(e));
  return r;
}
function ll(e, a, r) {
  if (r && r.biff < 8) return hl(e, a, r);
  var t = rs(e), n = Co(e, a - 22, t[1]);
  return { cmo: t, ft: n };
}
var ul = {
  8: function(e, a) {
    var r = e.l + a;
    e.l += 10;
    var t = e.read_shift(2);
    e.l += 4, e.l += 2, e.l += 2, e.l += 2, e.l += 4;
    var n = e.read_shift(1);
    return e.l += n, e.l = r, { fmt: t };
  }
};
function hl(e, a, r) {
  e.l += 4;
  var t = e.read_shift(2), n = e.read_shift(2), i = e.read_shift(2);
  e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 6, a -= 36;
  var c = [];
  return c.push((ul[t] || pr)(e, a, r)), { cmo: [n, t, i], ft: c };
}
function xl(e, a, r) {
  var t = e.l, n = "";
  try {
    e.l += 4;
    var i = (r.lastobj || { cmo: [0, 0] }).cmo[1], c;
    [0, 5, 7, 11, 12, 14].indexOf(i) == -1 ? e.l += 6 : c = vo(e, 6, r);
    var s = e.read_shift(2);
    e.read_shift(2), Xe(e, 2);
    var f = e.read_shift(2);
    e.l += f;
    for (var o = 1; o < e.lens.length - 1; ++o) {
      if (e.l - t != e.lens[o]) throw new Error("TxO: bad continue record");
      var l = e[e.l], v = Fa(e, e.lens[o + 1] - e.lens[o] - 1);
      if (n += v, n.length >= (l ? s : 2 * s)) break;
    }
    if (n.length !== s && n.length !== s * 2)
      throw new Error("cchText: " + s + " != " + n.length);
    return e.l = t + a, { t: n };
  } catch {
    return e.l = t + a, { t: n };
  }
}
function dl(e, a) {
  var r = qt(e);
  e.l += 16;
  var t = _o(e, a - 24);
  return [r, t];
}
function vl(e, a) {
  e.read_shift(2);
  var r = qt(e), t = e.read_shift((a - 10) / 2, "dbcs-cont");
  return t = t.replace(wr, ""), [r, t];
}
function pl(e) {
  var a = [0, 0], r;
  return r = e.read_shift(2), a[0] = Fn[r] || r, r = e.read_shift(2), a[1] = Fn[r] || r, a;
}
function gl(e) {
  for (var a = e.read_shift(2), r = []; a-- > 0; ) r.push(qi(e));
  return r;
}
function ml(e) {
  for (var a = e.read_shift(2), r = []; a-- > 0; ) r.push(qi(e));
  return r;
}
function _l(e) {
  e.l += 2;
  var a = { cxfs: 0, crc: 0 };
  return a.cxfs = e.read_shift(2), a.crc = e.read_shift(4), a;
}
function ts(e, a, r) {
  if (!r.cellStyles) return pr(e, a);
  var t = r && r.biff >= 12 ? 4 : 2, n = e.read_shift(t), i = e.read_shift(t), c = e.read_shift(t), s = e.read_shift(t), f = e.read_shift(2);
  t == 2 && (e.l += 2);
  var o = { s: n, e: i, w: c, ixfe: s, flags: f };
  return (r.biff >= 5 || !r.biff) && (o.level = f >> 8 & 7), o;
}
function Tl(e, a) {
  var r = {};
  return a < 32 || (e.l += 16, r.header = xr(e), r.footer = xr(e), e.l += 2), r;
}
function El(e, a, r) {
  var t = { area: !1 };
  if (r.biff != 5)
    return e.l += a, t;
  var n = e.read_shift(1);
  return e.l += 3, n & 16 && (t.area = !0), t;
}
var kl = zr, wl = ji, Fl = xt;
function Al(e) {
  var a = e.read_shift(2), r = e.read_shift(2), t = e.read_shift(4), n = { fmt: a, env: r, len: t, data: e.slice(e.l, e.l + t) };
  return e.l += t, n;
}
function yl(e, a, r) {
  r.biffguess && r.biff == 5 && (r.biff = 2);
  var t = zr(e, 7, r), n = Ca(e, a - 7, r);
  return t.t = "str", t.val = n, t;
}
function Sl(e, a, r) {
  var t = zr(e, 7, r), n = xr(e);
  return t.t = "n", t.val = n, t;
}
function Cl(e, a, r) {
  var t = zr(e, 7, r), n = e.read_shift(2);
  return t.t = "n", t.val = n, t;
}
function Dl(e) {
  var a = e.read_shift(1);
  return a === 0 ? (e.l++, "") : e.read_shift(a, "sbcs-cont");
}
function Il(e, a, r) {
  var t = e.l + 7, n = zr(e, 6, r);
  e.l = t;
  var i = Ji(e);
  return n.val = i, n.t = i === !0 || i === !1 ? "b" : "e", n;
}
function Ol(e, a) {
  e.l += 6, e.l += 2, e.l += 1, e.l += 3, e.l += 1, e.l += a - 13;
}
function Rl(e, a, r) {
  var t = e.l + a, n = zr(e, 6, r), i = e.read_shift(2), c = Fa(e, i, r);
  return e.l = t, n.t = "str", n.val = c, n;
}
function Nl(e) {
  var a = e.read_shift(4), r = e.read_shift(1), t = e.read_shift(r, "sbcs");
  return t.length === 0 && (t = "Sheet1"), { flags: a, name: t };
}
var Pl = [2, 3, 48, 49, 131, 139, 140, 245], Bn = /* @__PURE__ */ (function() {
  var e = {
    /* Code Pages Supported by Visual FoxPro */
    1: 437,
    2: 850,
    3: 1252,
    4: 1e4,
    100: 852,
    101: 866,
    102: 865,
    103: 861,
    104: 895,
    105: 620,
    106: 737,
    107: 857,
    120: 950,
    121: 949,
    122: 936,
    123: 932,
    124: 874,
    125: 1255,
    126: 1256,
    150: 10007,
    151: 10029,
    152: 10006,
    200: 1250,
    201: 1251,
    202: 1254,
    203: 1253,
    /* shapefile DBF extension */
    0: 20127,
    8: 865,
    9: 437,
    10: 850,
    11: 437,
    13: 437,
    14: 850,
    15: 437,
    16: 850,
    17: 437,
    18: 850,
    19: 932,
    20: 850,
    21: 437,
    22: 850,
    23: 865,
    24: 437,
    25: 437,
    26: 850,
    27: 437,
    28: 863,
    29: 850,
    31: 852,
    34: 852,
    35: 852,
    36: 860,
    37: 850,
    38: 866,
    55: 850,
    64: 852,
    77: 936,
    78: 949,
    79: 950,
    80: 874,
    87: 1252,
    88: 1252,
    89: 1252,
    108: 863,
    134: 737,
    135: 852,
    136: 857,
    204: 1257,
    255: 16969
  }, a = D0({
    1: 437,
    2: 850,
    3: 1252,
    4: 1e4,
    100: 852,
    101: 866,
    102: 865,
    103: 861,
    104: 895,
    105: 620,
    106: 737,
    107: 857,
    120: 950,
    121: 949,
    122: 936,
    123: 932,
    124: 874,
    125: 1255,
    126: 1256,
    150: 10007,
    151: 10029,
    152: 10006,
    200: 1250,
    201: 1251,
    202: 1254,
    203: 1253,
    0: 20127
  });
  function r(s, f) {
    var o = [], l = fa(1);
    switch (f.type) {
      case "base64":
        l = Dr(Rr(s));
        break;
      case "binary":
        l = Dr(s);
        break;
      case "buffer":
      case "array":
        l = s;
        break;
    }
    rr(l, 0);
    var v = l.read_shift(1), x = !!(v & 136), u = !1, p = !1;
    switch (v) {
      case 2:
        break;
      // dBASE II
      case 3:
        break;
      // dBASE III
      case 48:
        u = !0, x = !0;
        break;
      // VFP
      case 49:
        u = !0, x = !0;
        break;
      // VFP with autoincrement
      // 0x43 dBASE IV SQL table files
      // 0x63 dBASE IV SQL system files
      case 131:
        break;
      // dBASE III with memo
      case 139:
        break;
      // dBASE IV with memo
      case 140:
        p = !0;
        break;
      // dBASE Level 7 with memo
      // case 0xCB dBASE IV SQL table files with memo
      case 245:
        break;
      // FoxPro 2.x with memo
      // case 0xFB FoxBASE
      default:
        throw new Error("DBF Unsupported Version: " + v.toString(16));
    }
    var _ = 0, d = 521;
    v == 2 && (_ = l.read_shift(2)), l.l += 3, v != 2 && (_ = l.read_shift(4)), _ > 1048576 && (_ = 1e6), v != 2 && (d = l.read_shift(2));
    var h = l.read_shift(2);
    f.codepage, v != 2 && (l.l += 16, l.read_shift(1), l[l.l] !== 0 && e[l[l.l]], l.l += 1, l.l += 2), p && (l.l += 36);
    for (var E = [], g = {}, C = Math.min(l.length, v == 2 ? 521 : d - 10 - (u ? 264 : 0)), P = p ? 32 : 11; l.l < C && l[l.l] != 13; )
      switch (g = {}, g.name = aa(l.slice(l.l, l.l + P)).replace(/[\u0000\r\n][\S\s]*$/g, ""), l.l += P, g.type = String.fromCharCode(l.read_shift(1)), v != 2 && !p && (g.offset = l.read_shift(4)), g.len = l.read_shift(1), v == 2 && (g.offset = l.read_shift(2)), g.dec = l.read_shift(1), g.name.length && E.push(g), v != 2 && (l.l += p ? 13 : 14), g.type) {
        case "B":
          (!u || g.len != 8) && f.WTF && console.log("Skipping " + g.name + ":" + g.type);
          break;
        case "G":
        // General (FoxPro and dBASE L7)
        case "P":
          f.WTF && console.log("Skipping " + g.name + ":" + g.type);
          break;
        case "+":
        // Autoincrement (dBASE L7 only)
        case "0":
        // _NullFlags (VFP only)
        case "@":
        // Timestamp (dBASE L7 only)
        case "C":
        // Character (dBASE II)
        case "D":
        // Date (dBASE III)
        case "F":
        // Float (dBASE IV)
        case "I":
        // Long (VFP and dBASE L7)
        case "L":
        // Logical (dBASE II)
        case "M":
        // Memo (dBASE III)
        case "N":
        // Number (dBASE II)
        case "O":
        // Double (dBASE L7 only)
        case "T":
        // Datetime (VFP only)
        case "Y":
          break;
        default:
          throw new Error("Unknown Field Type: " + g.type);
      }
    if (l[l.l] !== 13 && (l.l = d - 1), l.read_shift(1) !== 13) throw new Error("DBF Terminator not found " + l.l + " " + l[l.l]);
    l.l = d;
    var M = 0, I = 0;
    for (o[0] = [], I = 0; I != E.length; ++I) o[0][I] = E[I].name;
    for (; _-- > 0; ) {
      if (l[l.l] === 42) {
        l.l += h;
        continue;
      }
      for (++l.l, o[++M] = [], I = 0, I = 0; I != E.length; ++I) {
        var N = l.slice(l.l, l.l + E[I].len);
        l.l += E[I].len, rr(N, 0);
        var O = aa(N);
        switch (E[I].type) {
          case "C":
            O.trim().length && (o[M][I] = O.replace(/([^\s])\s+$/, "$1"));
            break;
          case "D":
            O.length === 8 ? (o[M][I] = new Date(Date.UTC(+O.slice(0, 4), +O.slice(4, 6) - 1, +O.slice(6, 8), 0, 0, 0, 0)), f && f.UTC || (o[M][I] = wa(o[M][I]))) : o[M][I] = O;
            break;
          case "F":
            o[M][I] = parseFloat(O.trim());
            break;
          case "+":
          case "I":
            o[M][I] = p ? N.read_shift(-4, "i") ^ 2147483648 : N.read_shift(4, "i");
            break;
          case "L":
            switch (O.trim().toUpperCase()) {
              case "Y":
              case "T":
                o[M][I] = !0;
                break;
              case "N":
              case "F":
                o[M][I] = !1;
                break;
              case "":
              case "\0":
              case "?":
                break;
              default:
                throw new Error("DBF Unrecognized L:|" + O + "|");
            }
            break;
          case "M":
            if (!x) throw new Error("DBF Unexpected MEMO for type " + v.toString(16));
            o[M][I] = "##MEMO##" + (p ? parseInt(O.trim(), 10) : N.read_shift(4));
            break;
          case "N":
            O = O.replace(/\u0000/g, "").trim(), O && O != "." && (o[M][I] = +O || 0);
            break;
          case "@":
            o[M][I] = new Date(N.read_shift(-8, "f") - 621356832e5);
            break;
          case "T":
            {
              var B = N.read_shift(4), b = N.read_shift(4);
              if (B == 0 && b == 0) break;
              o[M][I] = new Date((B - 2440588) * 864e5 + b), f && f.UTC || (o[M][I] = wa(o[M][I]));
            }
            break;
          case "Y":
            o[M][I] = N.read_shift(4, "i") / 1e4 + N.read_shift(4, "i") / 1e4 * Math.pow(2, 32);
            break;
          case "O":
            o[M][I] = -N.read_shift(-8, "f");
            break;
          case "B":
            if (u && E[I].len == 8) {
              o[M][I] = N.read_shift(8, "f");
              break;
            }
          /* falls through */
          case "G":
          case "P":
            N.l += E[I].len;
            break;
          case "0":
            if (E[I].name === "_NullFlags") break;
          /* falls through */
          default:
            throw new Error("DBF Unsupported data type " + E[I].type);
        }
      }
    }
    if (v != 2 && l.l < l.length && l[l.l++] != 26) throw new Error("DBF EOF Marker missing " + (l.l - 1) + " of " + l.length + " " + l[l.l - 1].toString(16));
    return f && f.sheetRows && (o = o.slice(0, f.sheetRows)), f.DBF = E, o;
  }
  function t(s, f) {
    var o = f || {};
    o.dateNF || (o.dateNF = "yyyymmdd");
    var l = Ua(r(s, o), o);
    return l["!cols"] = o.DBF.map(function(v) {
      return {
        wch: v.len,
        DBF: v
      };
    }), delete o.DBF, l;
  }
  function n(s, f) {
    try {
      var o = ha(t(s, f), f);
      return o.bookType = "dbf", o;
    } catch (l) {
      if (f && f.WTF) throw l;
    }
    return { SheetNames: [], Sheets: {} };
  }
  var i = { B: 8, C: 250, L: 1, D: 8, "?": 0, "": 0 };
  function c(s, f) {
    if (!s["!ref"]) throw new Error("Cannot export empty sheet to DBF");
    var o = f || {}, l = Lr;
    if (+o.codepage >= 0 && $r(+o.codepage), o.type == "string") throw new Error("Cannot write DBF to JS string");
    var v = p0(), x = k0(s, { header: 1, raw: !0, cellDates: !0 }), u = x[0], p = x.slice(1), _ = s["!cols"] || [], d = 0, h = 0, E = 0, g = 1;
    for (d = 0; d < u.length; ++d) {
      if (((_[d] || {}).DBF || {}).name) {
        u[d] = _[d].DBF.name, ++E;
        continue;
      }
      if (u[d] != null) {
        if (++E, typeof u[d] == "number" && (u[d] = u[d].toString(10)), typeof u[d] != "string") throw new Error("DBF Invalid column name " + u[d] + " |" + typeof u[d] + "|");
        if (u.indexOf(u[d]) !== d) {
          for (h = 0; h < 1024; ++h)
            if (u.indexOf(u[d] + "_" + h) == -1) {
              u[d] += "_" + h;
              break;
            }
        }
      }
    }
    var C = Ke(s["!ref"]), P = [], M = [], I = [];
    for (d = 0; d <= C.e.c - C.s.c; ++d) {
      var N = "", O = "", B = 0, b = [];
      for (h = 0; h < p.length; ++h)
        p[h][d] != null && b.push(p[h][d]);
      if (b.length == 0 || u[d] == null) {
        P[d] = "?";
        continue;
      }
      for (h = 0; h < b.length; ++h) {
        switch (typeof b[h]) {
          /* TODO: check if L2 compat is desired */
          case "number":
            O = "B";
            break;
          case "string":
            O = "C";
            break;
          case "boolean":
            O = "L";
            break;
          case "object":
            O = b[h] instanceof Date ? "D" : "C";
            break;
          default:
            O = "C";
        }
        B = Math.max(B, String(b[h]).length), N = N && N != O ? "C" : O;
      }
      B > 250 && (B = 250), O = ((_[d] || {}).DBF || {}).type, O == "C" && _[d].DBF.len > B && (B = _[d].DBF.len), N == "B" && O == "N" && (N = "N", I[d] = _[d].DBF.dec, B = _[d].DBF.len), M[d] = N == "C" || O == "N" ? B : i[N] || 0, g += M[d], P[d] = N;
    }
    var G = v.next(32);
    for (G.write_shift(4, 318902576), G.write_shift(4, p.length), G.write_shift(2, 296 + 32 * E), G.write_shift(2, g), d = 0; d < 4; ++d) G.write_shift(4, 0);
    var z = +a[
      /*::String(*/
      Lr
      /*::)*/
    ] || 3;
    for (G.write_shift(4, 0 | z << 8), e[z] != +o.codepage && (o.codepage && console.error("DBF Unsupported codepage " + Lr + ", using 1252"), Lr = 1252), d = 0, h = 0; d < u.length; ++d)
      if (u[d] != null) {
        var ce = v.next(32), j = (u[d].slice(-10) + "\0\0\0\0\0\0\0\0\0\0\0").slice(0, 11);
        ce.write_shift(1, j, "sbcs"), ce.write_shift(1, P[d] == "?" ? "C" : P[d], "sbcs"), ce.write_shift(4, h), ce.write_shift(1, M[d] || i[P[d]] || 0), ce.write_shift(1, I[d] || 0), ce.write_shift(1, 2), ce.write_shift(4, 0), ce.write_shift(1, 0), ce.write_shift(4, 0), ce.write_shift(4, 0), h += M[d] || i[P[d]] || 0;
      }
    var he = v.next(264);
    for (he.write_shift(4, 13), d = 0; d < 65; ++d) he.write_shift(4, 0);
    for (d = 0; d < p.length; ++d) {
      var J = v.next(g);
      for (J.write_shift(1, 0), h = 0; h < u.length; ++h)
        if (u[h] != null)
          switch (P[h]) {
            case "L":
              J.write_shift(1, p[d][h] == null ? 63 : p[d][h] ? 84 : 70);
              break;
            case "B":
              J.write_shift(8, p[d][h] || 0, "f");
              break;
            case "N":
              var ne = "0";
              for (typeof p[d][h] == "number" && (ne = p[d][h].toFixed(I[h] || 0)), ne.length > M[h] && (ne = ne.slice(0, M[h])), E = 0; E < M[h] - ne.length; ++E) J.write_shift(1, 32);
              J.write_shift(1, ne, "sbcs");
              break;
            case "D":
              p[d][h] ? (J.write_shift(4, ("0000" + p[d][h].getFullYear()).slice(-4), "sbcs"), J.write_shift(2, ("00" + (p[d][h].getMonth() + 1)).slice(-2), "sbcs"), J.write_shift(2, ("00" + p[d][h].getDate()).slice(-2), "sbcs")) : J.write_shift(8, "00000000", "sbcs");
              break;
            case "C":
              var pe = J.l, X = String(p[d][h] != null ? p[d][h] : "").slice(0, M[h]);
              for (J.write_shift(1, X, "cpstr"), pe += M[h] - J.l, E = 0; E < pe; ++E) J.write_shift(1, 32);
              break;
          }
    }
    return Lr = l, v.next(1).write_shift(1, 26), v.end();
  }
  return {
    to_workbook: n,
    to_sheet: t,
    from_sheet: c
  };
})(), bl = /* @__PURE__ */ (function() {
  var e = {
    AA: "À",
    BA: "Á",
    CA: "Â",
    DA: 195,
    HA: "Ä",
    JA: 197,
    AE: "È",
    BE: "É",
    CE: "Ê",
    HE: "Ë",
    AI: "Ì",
    BI: "Í",
    CI: "Î",
    HI: "Ï",
    AO: "Ò",
    BO: "Ó",
    CO: "Ô",
    DO: 213,
    HO: "Ö",
    AU: "Ù",
    BU: "Ú",
    CU: "Û",
    HU: "Ü",
    Aa: "à",
    Ba: "á",
    Ca: "â",
    Da: 227,
    Ha: "ä",
    Ja: 229,
    Ae: "è",
    Be: "é",
    Ce: "ê",
    He: "ë",
    Ai: "ì",
    Bi: "í",
    Ci: "î",
    Hi: "ï",
    Ao: "ò",
    Bo: "ó",
    Co: "ô",
    Do: 245,
    Ho: "ö",
    Au: "ù",
    Bu: "ú",
    Cu: "û",
    Hu: "ü",
    KC: "Ç",
    Kc: "ç",
    q: "æ",
    z: "œ",
    a: "Æ",
    j: "Œ",
    DN: 209,
    Dn: 241,
    Hy: 255,
    S: 169,
    c: 170,
    R: 174,
    "B ": 180,
    0: 176,
    1: 177,
    2: 178,
    3: 179,
    5: 181,
    6: 182,
    7: 183,
    Q: 185,
    k: 186,
    b: 208,
    i: 216,
    l: 222,
    s: 240,
    y: 248,
    "!": 161,
    '"': 162,
    "#": 163,
    "(": 164,
    "%": 165,
    "'": 167,
    "H ": 168,
    "+": 171,
    ";": 187,
    "<": 188,
    "=": 189,
    ">": 190,
    "?": 191,
    "{": 223
  }, a = new RegExp("\x1BN(" + Br(e).join("|").replace(/\|\|\|/, "|\\||").replace(/([?()+])/g, "\\$1").replace("{", "\\{") + "|\\|)", "gm");
  try {
    a = new RegExp("\x1BN(" + Br(e).join("|").replace(/\|\|\|/, "|\\||").replace(/([?()+])/g, "\\$1") + "|\\|)", "gm");
  } catch {
  }
  var r = function(u, p) {
    var _ = e[p];
    return typeof _ == "number" ? q0(_) : _;
  }, t = function(u, p, _) {
    var d = p.charCodeAt(0) - 32 << 4 | _.charCodeAt(0) - 48;
    return d == 59 ? u : q0(d);
  };
  e["|"] = 254;
  var n = function(u) {
    return u.replace(/\n/g, "\x1B :").replace(/\r/g, "\x1B =");
  };
  function i(u, p) {
    switch (p.type) {
      case "base64":
        return c(Rr(u), p);
      case "binary":
        return c(u, p);
      case "buffer":
        return c(ye && Buffer.isBuffer(u) ? u.toString("binary") : aa(u), p);
      case "array":
        return c(ka(u), p);
    }
    throw new Error("Unrecognized type " + p.type);
  }
  function c(u, p) {
    var _ = u.split(/[\n\r]+/), d = -1, h = -1, E = 0, g = 0, C = [], P = [], M = null, I = {}, N = [], O = [], B = [], b = 0, G, z = { Workbook: { WBProps: {}, Names: [] } };
    for (+p.codepage >= 0 && $r(+p.codepage); E !== _.length; ++E) {
      b = 0;
      var ce = _[E].trim().replace(/\x1B([\x20-\x2F])([\x30-\x3F])/g, t).replace(a, r), j = ce.replace(/;;/g, "\0").split(";").map(function(D) {
        return D.replace(/\u0000/g, ";");
      }), he = j[0], J;
      if (ce.length > 0) switch (he) {
        case "ID":
          break;
        /* header */
        case "E":
          break;
        /* EOF */
        case "B":
          break;
        /* dimensions */
        case "O":
          for (g = 1; g < j.length; ++g) switch (j[g].charAt(0)) {
            case "V":
              {
                var ne = parseInt(j[g].slice(1), 10);
                ne >= 1 && ne <= 4 && (z.Workbook.WBProps.date1904 = !0);
              }
              break;
          }
          break;
        case "W":
          break;
        /* window */
        case "P":
          switch (j[1].charAt(0)) {
            case "P":
              P.push(ce.slice(3).replace(/;;/g, ";"));
              break;
          }
          break;
        case "NN":
          {
            var pe = { Sheet: 0 };
            for (g = 1; g < j.length; ++g) switch (j[g].charAt(0)) {
              case "N":
                pe.Name = j[g].slice(1);
                break;
              case "E":
                pe.Ref = (p && p.sheet || "Sheet1") + "!" + Ta(j[g].slice(1));
                break;
            }
            z.Workbook.Names.push(pe);
          }
          break;
        // case 'NE': // ??
        // case 'NU': // ??
        case "C":
          var X = !1, Te = !1, _e = !1, de = !1, fe = -1, ke = -1, me = "", Fe = "z", y = "";
          for (g = 1; g < j.length; ++g) switch (j[g].charAt(0)) {
            case "A":
              y = j[g].slice(1);
              break;
            // TODO: comment
            case "X":
              h = parseInt(j[g].slice(1), 10) - 1, Te = !0;
              break;
            case "Y":
              for (d = parseInt(j[g].slice(1), 10) - 1, Te || (h = 0), G = C.length; G <= d; ++G) C[G] = [];
              break;
            case "K":
              J = j[g].slice(1), J.charAt(0) === '"' ? (J = J.slice(1, J.length - 1), Fe = "s") : J === "TRUE" || J === "FALSE" ? (J = J === "TRUE", Fe = "b") : J.charAt(0) == "#" && sr[J] != null ? (Fe = "e", J = sr[J]) : isNaN(Or(J)) || (J = Or(J), Fe = "n", M !== null && Ur(M) && p.cellDates && (J = ca(z.Workbook.WBProps.date1904 ? J + 1462 : J), Fe = typeof J == "number" ? "n" : "d")), X = !0;
              break;
            case "E":
              de = !0, me = Ta(j[g].slice(1), { r: d, c: h });
              break;
            case "S":
              _e = !0;
              break;
            case "G":
              break;
            // unknown
            case "R":
              fe = parseInt(j[g].slice(1), 10) - 1;
              break;
            case "C":
              ke = parseInt(j[g].slice(1), 10) - 1;
              break;
            // case 'P': // ??
            // case 'D': // ??
            default:
              if (p && p.WTF) throw new Error("SYLK bad record " + ce);
          }
          if (X && (C[d][h] ? (C[d][h].t = Fe, C[d][h].v = J) : C[d][h] = { t: Fe, v: J }, M && (C[d][h].z = M), p.cellText !== !1 && M && (C[d][h].w = Fr(C[d][h].z, C[d][h].v, { date1904: z.Workbook.WBProps.date1904 })), M = null), _e) {
            if (de) throw new Error("SYLK shared formula cannot have own formula");
            var L = fe > -1 && C[fe][ke];
            if (!L || !L[1]) throw new Error("SYLK shared formula cannot find base");
            me = hs(L[1], { r: d - fe, c: h - ke });
          }
          me && (C[d][h] ? C[d][h].f = me : C[d][h] = { t: "n", f: me }), y && (C[d][h] || (C[d][h] = { t: "z" }), C[d][h].c = [{ a: "SheetJSYLK", t: y }]);
          break;
        case "F":
          var R = 0;
          for (g = 1; g < j.length; ++g) switch (j[g].charAt(0)) {
            case "X":
              h = parseInt(j[g].slice(1), 10) - 1, ++R;
              break;
            case "Y":
              for (d = parseInt(j[g].slice(1), 10) - 1, G = C.length; G <= d; ++G) C[G] = [];
              break;
            case "M":
              b = parseInt(j[g].slice(1), 10) / 20;
              break;
            case "F":
              break;
            /* ??? */
            case "G":
              break;
            /* hide grid */
            case "P":
              M = P[parseInt(j[g].slice(1), 10)];
              break;
            case "S":
              break;
            /* cell style */
            case "D":
              break;
            /* column */
            case "N":
              break;
            /* font */
            case "W":
              for (B = j[g].slice(1).split(" "), G = parseInt(B[0], 10); G <= parseInt(B[1], 10); ++G)
                b = parseInt(B[2], 10), O[G - 1] = b === 0 ? { hidden: !0 } : { wch: b };
              break;
            case "C":
              h = parseInt(j[g].slice(1), 10) - 1, O[h] || (O[h] = {});
              break;
            case "R":
              d = parseInt(j[g].slice(1), 10) - 1, N[d] || (N[d] = {}), b > 0 ? (N[d].hpt = b, N[d].hpx = ft(b)) : b === 0 && (N[d].hidden = !0);
              break;
            // case 'K': // ??
            // case 'E': // ??
            default:
              if (p && p.WTF) throw new Error("SYLK bad record " + ce);
          }
          R < 1 && (M = null);
          break;
        default:
          if (p && p.WTF) throw new Error("SYLK bad record " + ce);
      }
    }
    return N.length > 0 && (I["!rows"] = N), O.length > 0 && (I["!cols"] = O), O.forEach(function(D) {
      Ma(D);
    }), p && p.sheetRows && (C = C.slice(0, p.sheetRows)), [C, I, z];
  }
  function s(u, p) {
    var _ = i(u, p), d = _[0], h = _[1], E = _[2], g = er(p);
    g.date1904 = (((E || {}).Workbook || {}).WBProps || {}).date1904;
    var C = Ua(d, g);
    Br(h).forEach(function(M) {
      C[M] = h[M];
    });
    var P = ha(C, p);
    return Br(E).forEach(function(M) {
      P[M] = E[M];
    }), P.bookType = "sylk", P;
  }
  function f(u, p, _, d, h, E) {
    var g = "C;Y" + (_ + 1) + ";X" + (d + 1) + ";K";
    switch (u.t) {
      case "n":
        g += isFinite(u.v) ? u.v || 0 : Ar[isNaN(u.v) ? 36 : 7], u.f && !u.F && (g += ";E" + vu(u.f, { r: _, c: d }));
        break;
      case "b":
        g += u.v ? "TRUE" : "FALSE";
        break;
      case "e":
        g += u.w || Ar[u.v] || u.v;
        break;
      case "d":
        g += ar(fr(u.v, E), E);
        break;
      case "s":
        g += '"' + (u.v == null ? "" : String(u.v)).replace(/"/g, "").replace(/;/g, ";;") + '"';
        break;
    }
    return g;
  }
  function o(u, p, _) {
    var d = "C;Y" + (p + 1) + ";X" + (_ + 1) + ";A";
    return d += n(u.map(function(h) {
      return h.t;
    }).join("")), d;
  }
  function l(u, p) {
    p.forEach(function(_, d) {
      var h = "F;W" + (d + 1) + " " + (d + 1) + " ";
      _.hidden ? h += "0" : (typeof _.width == "number" && !_.wpx && (_.wpx = Wt(_.width)), typeof _.wpx == "number" && !_.wch && (_.wch = Vt(_.wpx)), typeof _.wch == "number" && (h += Math.round(_.wch))), h.charAt(h.length - 1) != " " && u.push(h);
    });
  }
  function v(u, p) {
    p.forEach(function(_, d) {
      var h = "F;";
      _.hidden ? h += "M0;" : _.hpt ? h += "M" + 20 * _.hpt + ";" : _.hpx && (h += "M" + 20 * ls(_.hpx) + ";"), h.length > 2 && u.push(h + "R" + (d + 1));
    });
  }
  function x(u, p, _) {
    p || (p = {}), p._formats = ["General"];
    var d = ["ID;PSheetJS;N;E"], h = [], E = Ke(u["!ref"] || "A1"), g, C = u["!data"] != null, P = `\r
`, M = (((_ || {}).Workbook || {}).WBProps || {}).date1904, I = "General";
    d.push("P;PGeneral");
    var N = E.s.r, O = E.s.c, B = [];
    if (u["!ref"]) {
      for (N = E.s.r; N <= E.e.r; ++N)
        if (!(C && !u["!data"][N])) {
          for (B = [], O = E.s.c; O <= E.e.c; ++O)
            g = C ? u["!data"][N][O] : u[Pe(O) + Me(N)], !(!g || !g.c) && B.push(o(g.c, N, O));
          B.length && h.push(B.join(P));
        }
    }
    if (u["!ref"]) {
      for (N = E.s.r; N <= E.e.r; ++N)
        if (!(C && !u["!data"][N])) {
          for (B = [], O = E.s.c; O <= E.e.c; ++O)
            if (g = C ? u["!data"][N][O] : u[Pe(O) + Me(N)], !(!g || g.v == null && (!g.f || g.F))) {
              if ((g.z || (g.t == "d" ? ge[14] : "General")) != I) {
                var b = p._formats.indexOf(g.z);
                b == -1 && (p._formats.push(g.z), b = p._formats.length - 1, d.push("P;P" + g.z.replace(/;/g, ";;"))), B.push("F;P" + b + ";Y" + (N + 1) + ";X" + (O + 1));
              }
              B.push(f(g, u, N, O, p, M));
            }
          h.push(B.join(P));
        }
    }
    return d.push("F;P0;DG0G8;M255"), u["!cols"] && l(d, u["!cols"]), u["!rows"] && v(d, u["!rows"]), u["!ref"] && d.push("B;Y" + (E.e.r - E.s.r + 1) + ";X" + (E.e.c - E.s.c + 1) + ";D" + [E.s.c, E.s.r, E.e.c, E.e.r].join(" ")), d.push("O;L;D;B" + (M ? ";V4" : "") + ";K47;G100 0.001"), delete p._formats, d.join(P) + P + h.join(P) + P + "E" + P;
  }
  return {
    to_workbook: s,
    from_sheet: x
  };
})(), Ll = /* @__PURE__ */ (function() {
  function e(s, f) {
    switch (f.type) {
      case "base64":
        return a(Rr(s), f);
      case "binary":
        return a(s, f);
      case "buffer":
        return a(ye && Buffer.isBuffer(s) ? s.toString("binary") : aa(s), f);
      case "array":
        return a(ka(s), f);
    }
    throw new Error("Unrecognized type " + f.type);
  }
  function a(s, f) {
    for (var o = s.split(`
`), l = -1, v = -1, x = 0, u = []; x !== o.length; ++x) {
      if (o[x].trim() === "BOT") {
        u[++l] = [], v = 0;
        continue;
      }
      if (!(l < 0)) {
        var p = o[x].trim().split(","), _ = p[0], d = p[1];
        ++x;
        for (var h = o[x] || ""; (h.match(/["]/g) || []).length & 1 && x < o.length - 1; ) h += `
` + o[++x];
        switch (h = h.trim(), +_) {
          case -1:
            if (h === "BOT") {
              u[++l] = [], v = 0;
              continue;
            } else if (h !== "EOD") throw new Error("Unrecognized DIF special command " + h);
            break;
          case 0:
            h === "TRUE" ? u[l][v] = !0 : h === "FALSE" ? u[l][v] = !1 : isNaN(Or(d)) ? isNaN(it(d).getDate()) ? u[l][v] = d : (u[l][v] = fr(d), f && f.UTC || (u[l][v] = wa(u[l][v]))) : u[l][v] = Or(d), ++v;
            break;
          case 1:
            h = h.slice(1, h.length - 1), h = h.replace(/""/g, '"'), h && h.match(/^=".*"$/) && (h = h.slice(2, -1)), u[l][v++] = h !== "" ? h : null;
            break;
        }
        if (h === "EOD") break;
      }
    }
    return f && f.sheetRows && (u = u.slice(0, f.sheetRows)), u;
  }
  function r(s, f) {
    return Ua(e(s, f), f);
  }
  function t(s, f) {
    var o = ha(r(s, f), f);
    return o.bookType = "dif", o;
  }
  function n(s, f) {
    return "0," + String(s) + `\r
` + f;
  }
  function i(s) {
    return `1,0\r
"` + s.replace(/"/g, '""') + '"';
  }
  function c(s) {
    if (!s["!ref"]) throw new Error("Cannot export empty sheet to DIF");
    for (var f = Ke(s["!ref"]), o = s["!data"] != null, l = [
      `TABLE\r
0,1\r
"sheetjs"\r
`,
      `VECTORS\r
0,` + (f.e.r - f.s.r + 1) + `\r
""\r
`,
      `TUPLES\r
0,` + (f.e.c - f.s.c + 1) + `\r
""\r
`,
      `DATA\r
0,0\r
""\r
`
    ], v = f.s.r; v <= f.e.r; ++v) {
      for (var x = o ? s["!data"][v] : [], u = `-1,0\r
BOT\r
`, p = f.s.c; p <= f.e.c; ++p) {
        var _ = o ? x && x[p] : s[Ne({ r: v, c: p })];
        if (_ == null) {
          u += `1,0\r
""\r
`;
          continue;
        }
        switch (_.t) {
          case "n":
            _.w != null ? u += "0," + _.w + `\r
V` : _.v != null ? u += n(_.v, "V") : _.f != null && !_.F ? u += i("=" + _.f) : u += `1,0\r
""`;
            break;
          case "b":
            u += _.v ? n(1, "TRUE") : n(0, "FALSE");
            break;
          case "s":
            u += i(isNaN(+_.v) ? _.v : '="' + _.v + '"');
            break;
          case "d":
            _.w || (_.w = Fr(_.z || ge[14], ar(fr(_.v)))), u += n(_.w, "V");
            break;
          default:
            u += `1,0\r
""`;
        }
        u += `\r
`;
      }
      l.push(u);
    }
    return l.join("") + `-1,0\r
EOD`;
  }
  return {
    to_workbook: t,
    to_sheet: r,
    from_sheet: c
  };
})(), Bl = /* @__PURE__ */ (function() {
  function e(v) {
    return v.replace(/\\b/g, "\\").replace(/\\c/g, ":").replace(/\\n/g, `
`);
  }
  function a(v) {
    return v.replace(/\\/g, "\\b").replace(/:/g, "\\c").replace(/\n/g, "\\n");
  }
  function r(v, x) {
    for (var u = v.split(`
`), p = -1, _ = -1, d = 0, h = []; d !== u.length; ++d) {
      var E = u[d].trim().split(":");
      if (E[0] === "cell") {
        var g = dr(E[1]);
        if (h.length <= g.r) for (p = h.length; p <= g.r; ++p) h[p] || (h[p] = []);
        switch (p = g.r, _ = g.c, E[2]) {
          case "t":
            h[p][_] = e(E[3]);
            break;
          case "v":
            h[p][_] = +E[3];
            break;
          case "vtf":
            var C = E[E.length - 1];
          /* falls through */
          case "vtc":
            switch (E[3]) {
              case "nl":
                h[p][_] = !!+E[4];
                break;
              default:
                h[p][_] = E[E.length - 1].charAt(0) == "#" ? { t: "e", v: sr[E[E.length - 1]] } : +E[4];
                break;
            }
            E[2] == "vtf" && (h[p][_] = [h[p][_], C]);
        }
      }
    }
    return x && x.sheetRows && (h = h.slice(0, x.sheetRows)), h;
  }
  function t(v, x) {
    return Ua(r(v, x), x);
  }
  function n(v, x) {
    return ha(t(v, x), x);
  }
  var i = [
    "socialcalc:version:1.5",
    "MIME-Version: 1.0",
    "Content-Type: multipart/mixed; boundary=SocialCalcSpreadsheetControlSave"
  ].join(`
`), c = [
    "--SocialCalcSpreadsheetControlSave",
    "Content-type: text/plain; charset=UTF-8"
  ].join(`
`) + `
`, s = [
    "# SocialCalc Spreadsheet Control Save",
    "part:sheet"
  ].join(`
`), f = "--SocialCalcSpreadsheetControlSave--";
  function o(v) {
    if (!v || !v["!ref"]) return "";
    for (var x = [], u = [], p, _ = "", d = Aa(v["!ref"]), h = v["!data"] != null, E = d.s.r; E <= d.e.r; ++E)
      for (var g = d.s.c; g <= d.e.c; ++g)
        if (_ = Ne({ r: E, c: g }), p = h ? (v["!data"][E] || [])[g] : v[_], !(!p || p.v == null || p.t === "z")) {
          switch (u = ["cell", _, "t"], p.t) {
            case "s":
              u.push(a(p.v));
              break;
            case "b":
              u[2] = "vt" + (p.f ? "f" : "c"), u[3] = "nl", u[4] = p.v ? "1" : "0", u[5] = a(p.f || (p.v ? "TRUE" : "FALSE"));
              break;
            case "d":
              var C = ar(fr(p.v));
              u[2] = "vtc", u[3] = "nd", u[4] = "" + C, u[5] = p.w || Fr(p.z || ge[14], C);
              break;
            case "n":
              isFinite(p.v) ? p.f ? (u[2] = "vtf", u[3] = "n", u[4] = p.v, u[5] = a(p.f)) : (u[2] = "v", u[3] = p.v) : (u[2] = "vt" + (p.f ? "f" : "c"), u[3] = "e" + Ar[isNaN(p.v) ? 36 : 7], u[4] = "0", u[5] = p.f || u[3].slice(1), u[6] = "e", u[7] = u[3].slice(1));
              break;
            case "e":
              continue;
          }
          x.push(u.join(":"));
        }
    return x.push("sheet:c:" + (d.e.c - d.s.c + 1) + ":r:" + (d.e.r - d.s.r + 1) + ":tvf:1"), x.push("valueformat:1:text-wiki"), x.join(`
`);
  }
  function l(v) {
    return [i, c, s, c, o(v), f].join(`
`);
  }
  return {
    to_workbook: n,
    to_sheet: t,
    from_sheet: l
  };
})(), st = /* @__PURE__ */ (function() {
  function e(l, v, x, u, p) {
    p.raw ? v[x][u] = l : l === "" || (l === "TRUE" ? v[x][u] = !0 : l === "FALSE" ? v[x][u] = !1 : isNaN(Or(l)) ? isNaN(it(l).getDate()) ? l.charCodeAt(0) == 35 && sr[l] != null ? v[x][u] = { t: "e", v: sr[l], w: l } : v[x][u] = l : v[x][u] = fr(l) : v[x][u] = Or(l));
  }
  function a(l, v) {
    var x = v || {}, u = [];
    if (!l || l.length === 0) return u;
    for (var p = l.split(/[\r\n]/), _ = p.length - 1; _ >= 0 && p[_].length === 0; ) --_;
    for (var d = 10, h = 0, E = 0; E <= _; ++E)
      h = p[E].indexOf(" "), h == -1 ? h = p[E].length : h++, d = Math.max(d, h);
    for (E = 0; E <= _; ++E) {
      u[E] = [];
      var g = 0;
      for (e(p[E].slice(0, d).trim(), u, E, g, x), g = 1; g <= (p[E].length - d) / 10 + 1; ++g)
        e(p[E].slice(d + (g - 1) * 10, d + g * 10).trim(), u, E, g, x);
    }
    return x.sheetRows && (u = u.slice(0, x.sheetRows)), u;
  }
  var r = {
    44: ",",
    9: "	",
    59: ";",
    124: "|"
  }, t = {
    44: 3,
    9: 2,
    59: 1,
    124: 0
  };
  function n(l) {
    for (var v = {}, x = !1, u = 0, p = 0; u < l.length; ++u)
      (p = l.charCodeAt(u)) == 34 ? x = !x : !x && p in r && (v[p] = (v[p] || 0) + 1);
    p = [];
    for (u in v) Object.prototype.hasOwnProperty.call(v, u) && p.push([v[u], u]);
    if (!p.length) {
      v = t;
      for (u in v) Object.prototype.hasOwnProperty.call(v, u) && p.push([v[u], u]);
    }
    return p.sort(function(_, d) {
      return _[0] - d[0] || t[_[1]] - t[d[1]];
    }), r[p.pop()[1]] || 44;
  }
  function i(l, v) {
    var x = v || {}, u = "", p = {};
    x.dense && (p["!data"] = []);
    var _ = { s: { c: 0, r: 0 }, e: { c: 0, r: 0 } };
    l.slice(0, 4) == "sep=" ? l.charCodeAt(5) == 13 && l.charCodeAt(6) == 10 ? (u = l.charAt(4), l = l.slice(7)) : l.charCodeAt(5) == 13 || l.charCodeAt(5) == 10 ? (u = l.charAt(4), l = l.slice(6)) : u = n(l.slice(0, 1024)) : x && x.FS ? u = x.FS : u = n(l.slice(0, 1024));
    var d = 0, h = 0, E = 0, g = 0, C = 0, P = u.charCodeAt(0), M = !1, I = 0, N = l.charCodeAt(0), O = x.dateNF != null ? Dc(x.dateNF) : null;
    function B() {
      var b = l.slice(g, C);
      b.slice(-1) == "\r" && (b = b.slice(0, -1));
      var G = {};
      if (b.charAt(0) == '"' && b.charAt(b.length - 1) == '"' && (b = b.slice(1, -1).replace(/""/g, '"')), x.cellText !== !1 && (G.w = b), b.length === 0) G.t = "z";
      else if (x.raw)
        G.t = "s", G.v = b;
      else if (b.trim().length === 0)
        G.t = "s", G.v = b;
      else if (b.charCodeAt(0) == 61)
        b.charCodeAt(1) == 34 && b.charCodeAt(b.length - 1) == 34 ? (G.t = "s", G.v = b.slice(2, -1).replace(/""/g, '"')) : pu(b) ? (G.t = "s", G.f = b.slice(1), G.v = b) : (G.t = "s", G.v = b);
      else if (b == "TRUE")
        G.t = "b", G.v = !0;
      else if (b == "FALSE")
        G.t = "b", G.v = !1;
      else if (!isNaN(E = Or(b)))
        G.t = "n", G.v = E;
      else if (!isNaN((E = it(b)).getDate()) || O && b.match(O)) {
        if (G.z = x.dateNF || ge[14], O && b.match(O)) {
          var z = Ic(b, x.dateNF, b.match(O) || []);
          E = fr(z), x && x.UTC === !1 && (E = wa(E));
        } else x && x.UTC === !1 ? E = wa(E) : x.cellText !== !1 && x.dateNF && (G.w = Fr(G.z, E));
        x.cellDates ? (G.t = "d", G.v = E) : (G.t = "n", G.v = ar(E)), x.cellNF || delete G.z;
      } else b.charCodeAt(0) == 35 && sr[b] != null ? (G.t = "e", G.w = b, G.v = sr[b]) : (G.t = "s", G.v = b);
      if (G.t == "z" || (x.dense ? (p["!data"][d] || (p["!data"][d] = []), p["!data"][d][h] = G) : p[Ne({ c: h, r: d })] = G), g = C + 1, N = l.charCodeAt(g), _.e.c < h && (_.e.c = h), _.e.r < d && (_.e.r = d), I == P) ++h;
      else if (h = 0, ++d, x.sheetRows && x.sheetRows <= d) return !0;
    }
    e: for (; C < l.length; ++C) switch (I = l.charCodeAt(C)) {
      case 34:
        N === 34 && (M = !M);
        break;
      case 13:
        if (M) break;
        l.charCodeAt(C + 1) == 10 && ++C;
      /* falls through */
      case P:
      case 10:
        if (!M && B()) break e;
        break;
    }
    return C - g > 0 && B(), p["!ref"] = Ce(_), p;
  }
  function c(l, v) {
    return !(v && v.PRN) || v.FS || l.slice(0, 4) == "sep=" || l.indexOf("	") >= 0 || l.indexOf(",") >= 0 || l.indexOf(";") >= 0 ? i(l, v) : Ua(a(l, v), v);
  }
  function s(l, v) {
    var x = "", u = v.type == "string" ? [0, 0, 0, 0] : X0(l, v);
    switch (v.type) {
      case "base64":
        x = Rr(l);
        break;
      case "binary":
        x = l;
        break;
      case "buffer":
        v.codepage == 65001 ? x = l.toString("utf8") : (v.codepage, x = ye && Buffer.isBuffer(l) ? l.toString("binary") : aa(l));
        break;
      case "array":
        x = ka(l);
        break;
      case "string":
        x = l;
        break;
      default:
        throw new Error("Unrecognized type " + v.type);
    }
    return u[0] == 239 && u[1] == 187 && u[2] == 191 ? x = Ue(x.slice(3)) : v.type != "string" && v.type != "buffer" && v.codepage == 65001 ? x = Ue(x) : v.type == "binary", x.slice(0, 19) == "socialcalc:version:" ? Bl.to_sheet(v.type == "string" ? x : Ue(x), v) : c(x, v);
  }
  function f(l, v) {
    return ha(s(l, v), v);
  }
  function o(l) {
    var v = [];
    if (!l["!ref"]) return "";
    for (var x = Ke(l["!ref"]), u, p = l["!data"] != null, _ = x.s.r; _ <= x.e.r; ++_) {
      for (var d = [], h = x.s.c; h <= x.e.c; ++h) {
        var E = Ne({ r: _, c: h });
        if (u = p ? (l["!data"][_] || [])[h] : l[E], !u || u.v == null) {
          d.push("          ");
          continue;
        }
        for (var g = (u.w || (oa(u), u.w) || "").slice(0, 10); g.length < 10; ) g += " ";
        d.push(g + (h === 0 ? " " : ""));
      }
      v.push(d.join(""));
    }
    return v.join(`
`);
  }
  return {
    to_workbook: f,
    to_sheet: s,
    from_sheet: o
  };
})();
function Ml(e, a) {
  var r = a || {}, t = !!r.WTF;
  r.WTF = !0;
  try {
    var n = bl.to_workbook(e, r);
    return r.WTF = t, n;
  } catch (i) {
    if (r.WTF = t, i.message.indexOf("SYLK bad record ID") == -1 && t) throw i;
    return st.to_workbook(e, a);
  }
}
var qa = /* @__PURE__ */ (function() {
  function e(y, L, R) {
    if (y) {
      rr(y, y.l || 0);
      for (var D = R.Enum || de; y.l < y.length; ) {
        var Y = y.read_shift(2), w = D[Y] || D[65535], te = y.read_shift(2), ie = y.l + te, Q = w.f && w.f(y, te, R);
        if (y.l = ie, L(Q, w, Y)) return;
      }
    }
  }
  function a(y, L) {
    switch (L.type) {
      case "base64":
        return t(Dr(Rr(y)), L);
      case "binary":
        return t(Dr(y), L);
      case "buffer":
      case "array":
        return t(y, L);
    }
    throw "Unsupported type " + L.type;
  }
  var r = [
    "mmmm",
    "dd-mmm-yyyy",
    "dd-mmm",
    "mmm-yyyy",
    "@",
    // "text"?
    "mm/dd",
    "hh:mm:ss AM/PM",
    // 7
    "hh:mm AM/PM",
    "mm/dd/yyyy",
    "mm/dd",
    "hh:mm:ss",
    "hh:mm"
    // 12
  ];
  function t(y, L) {
    if (!y) return y;
    var R = L || {}, D = {}, Y = "Sheet1", w = "", te = 0, ie = {}, Q = [], ve = [], xe = [];
    R.dense && (xe = D["!data"] = []);
    var Ee = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }, Le = R.sheetRows || 0, He = {};
    if (y[4] == 81 && y[5] == 80 && y[6] == 87) return Fe(y, L);
    if (y[2] == 0 && (y[3] == 8 || y[3] == 9) && y.length >= 16 && y[14] == 5 && y[15] === 108)
      throw new Error("Unsupported Works 3 for Mac file");
    if (y[2] == 2)
      R.Enum = de, e(y, function(re, yr, gr) {
        switch (gr) {
          case 0:
            R.vers = re, re >= 4096 && (R.qpro = !0);
            break;
          case 255:
            R.vers = re, R.works = !0;
            break;
          case 6:
            Ee = re;
            break;
          /* RANGE */
          case 204:
            re && (w = re);
            break;
          /* SHEETNAMECS */
          case 222:
            w = re;
            break;
          /* SHEETNAMELP */
          case 15:
          /* LABEL */
          case 51:
            (!R.qpro && !R.works || gr == 51) && re[1].v.charCodeAt(0) < 48 && (re[1].v = re[1].v.slice(1)), (R.works || R.works2) && (re[1].v = re[1].v.replace(/\r\n/g, `
`));
          /* falls through */
          case 13:
          /* INTEGER */
          case 14:
          /* NUMBER */
          case 16:
            (re[2] & 112) == 112 && (re[2] & 15) > 1 && (re[2] & 15) < 15 && (re[1].z = R.dateNF || r[(re[2] & 15) - 1] || ge[14], R.cellDates && (re[1].v = ca(re[1].v), re[1].t = typeof re[1].v == "number" ? "n" : "d")), R.qpro && re[3] > te && (D["!ref"] = Ce(Ee), ie[Y] = D, Q.push(Y), D = {}, R.dense && (xe = D["!data"] = []), Ee = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }, te = re[3], Y = w || "Sheet" + (te + 1), w = "");
            var We = R.dense ? (xe[re[0].r] || [])[re[0].c] : D[Ne(re[0])];
            if (We) {
              We.t = re[1].t, We.v = re[1].v, re[1].z != null && (We.z = re[1].z), re[1].f != null && (We.f = re[1].f), He = We;
              break;
            }
            R.dense ? (xe[re[0].r] || (xe[re[0].r] = []), xe[re[0].r][re[0].c] = re[1]) : D[Ne(re[0])] = re[1], He = re[1];
            break;
          case 21509:
            R.works2 = !0;
            break;
          case 21506:
            re == 5281 && (He.z = "hh:mm:ss", R.cellDates && He.t == "n" && (He.v = ca(He.v), He.t = typeof He.v == "number" ? "n" : "d"));
            break;
        }
      }, R);
    else if (y[2] == 26 || y[2] == 14)
      R.Enum = fe, y[2] == 14 && (R.qpro = !0, y.l = 0), e(y, function(re, yr, gr) {
        switch (gr) {
          case 204:
            Y = re;
            break;
          /* SHEETNAMECS */
          case 22:
            re[1].v.charCodeAt(0) < 48 && (re[1].v = re[1].v.slice(1)), re[1].v = re[1].v.replace(/\x0F./g, function(We) {
              return String.fromCharCode(We.charCodeAt(1) - 32);
            }).replace(/\r\n/g, `
`);
          /* falls through */
          case 23:
          /* NUMBER17 */
          case 24:
          /* NUMBER18 */
          case 25:
          /* FORMULA19 */
          case 37:
          /* NUMBER25 */
          case 39:
          /* NUMBER27 */
          case 40:
            if (re[3] > te && (D["!ref"] = Ce(Ee), ie[Y] = D, Q.push(Y), D = {}, R.dense && (xe = D["!data"] = []), Ee = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }, te = re[3], Y = "Sheet" + (te + 1)), Le > 0 && re[0].r >= Le) break;
            R.dense ? (xe[re[0].r] || (xe[re[0].r] = []), xe[re[0].r][re[0].c] = re[1]) : D[Ne(re[0])] = re[1], Ee.e.c < re[0].c && (Ee.e.c = re[0].c), Ee.e.r < re[0].r && (Ee.e.r = re[0].r);
            break;
          case 27:
            re[14e3] && (ve[re[14e3][0]] = re[14e3][1]);
            break;
          case 1537:
            ve[re[0]] = re[1], re[0] == te && (Y = re[1]);
            break;
        }
      }, R);
    else throw new Error("Unrecognized LOTUS BOF " + y[2]);
    if (D["!ref"] = Ce(Ee), ie[w || Y] = D, Q.push(w || Y), !ve.length) return { SheetNames: Q, Sheets: ie };
    for (var $e = {}, ue = [], De = 0; De < ve.length; ++De) ie[Q[De]] ? (ue.push(ve[De] || Q[De]), $e[ve[De]] = ie[ve[De]] || ie[Q[De]]) : (ue.push(ve[De]), $e[ve[De]] = { "!ref": "A1" });
    return { SheetNames: ue, Sheets: $e };
  }
  function n(y, L) {
    var R = L || {};
    if (+R.codepage >= 0 && $r(+R.codepage), R.type == "string") throw new Error("Cannot write WK1 to JS string");
    var D = p0();
    if (!y["!ref"]) throw new Error("Cannot export empty sheet to WK1");
    var Y = Ke(y["!ref"]), w = y["!data"] != null, te = [];
    Sr(D, 0, c(1030)), Sr(D, 6, o(Y));
    for (var ie = Math.min(Y.e.r, 8191), Q = Y.s.c; Q <= Y.e.c; ++Q) te[Q] = Pe(Q);
    for (var ve = Y.s.r; ve <= ie; ++ve) {
      var xe = Me(ve);
      for (Q = Y.s.c; Q <= Y.e.c; ++Q) {
        var Ee = w ? (y["!data"][ve] || [])[Q] : y[te[Q] + xe];
        if (!(!Ee || Ee.t == "z"))
          switch (Ee.t) {
            case "n":
              (Ee.v | 0) == Ee.v && Ee.v >= -32768 && Ee.v <= 32767 ? Sr(D, 13, d(ve, Q, Ee)) : Sr(D, 14, E(ve, Q, Ee));
              break;
            case "d":
              var Le = ar(Ee.v);
              (Le | 0) == Le && Le >= -32768 && Le <= 32767 ? Sr(D, 13, d(ve, Q, { v: Le, z: Ee.z || ge[14] })) : Sr(D, 14, E(ve, Q, { v: Le, z: Ee.z || ge[14] }));
              break;
            default:
              var He = oa(Ee);
              Sr(D, 15, u(ve, Q, He.slice(0, 239)));
          }
      }
    }
    return Sr(D, 1), D.end();
  }
  function i(y, L) {
    var R = L || {};
    if (+R.codepage >= 0 && $r(+R.codepage), R.type == "string") throw new Error("Cannot write WK3 to JS string");
    var D = p0();
    Sr(D, 0, s(y));
    for (var Y = 0, w = 0; Y < y.SheetNames.length; ++Y) (y.Sheets[y.SheetNames[Y]] || {})["!ref"] && Sr(D, 27, _e(y.SheetNames[Y], w++));
    var te = 0;
    for (Y = 0; Y < y.SheetNames.length; ++Y) {
      var ie = y.Sheets[y.SheetNames[Y]];
      if (!(!ie || !ie["!ref"])) {
        for (var Q = Ke(ie["!ref"]), ve = ie["!data"] != null, xe = [], Ee = Math.min(Q.e.r, 8191), Le = Q.s.r; Le <= Ee; ++Le)
          for (var He = Me(Le), $e = Q.s.c; $e <= Q.e.c; ++$e) {
            Le === Q.s.r && (xe[$e] = Pe($e));
            var ue = xe[$e] + He, De = ve ? (ie["!data"][Le] || [])[$e] : ie[ue];
            if (!(!De || De.t == "z"))
              if (De.t == "n")
                Sr(D, 23, z(Le, $e, te, De.v));
              else {
                var re = oa(De);
                Sr(D, 22, B(Le, $e, te, re.slice(0, 239)));
              }
          }
        ++te;
      }
    }
    return Sr(D, 1), D.end();
  }
  function c(y) {
    var L = Qe(2);
    return L.write_shift(2, y), L;
  }
  function s(y) {
    var L = Qe(26);
    L.write_shift(2, 4096), L.write_shift(2, 4), L.write_shift(4, 0);
    for (var R = 0, D = 0, Y = 0, w = 0; w < y.SheetNames.length; ++w) {
      var te = y.SheetNames[w], ie = y.Sheets[te];
      if (!(!ie || !ie["!ref"])) {
        ++Y;
        var Q = Aa(ie["!ref"]);
        R < Q.e.r && (R = Q.e.r), D < Q.e.c && (D = Q.e.c);
      }
    }
    return R > 8191 && (R = 8191), L.write_shift(2, R), L.write_shift(1, Y), L.write_shift(1, D), L.write_shift(2, 0), L.write_shift(2, 0), L.write_shift(1, 1), L.write_shift(1, 2), L.write_shift(4, 0), L.write_shift(4, 0), L;
  }
  function f(y, L, R) {
    var D = { s: { c: 0, r: 0 }, e: { c: 0, r: 0 } };
    return L == 8 && R.qpro ? (D.s.c = y.read_shift(1), y.l++, D.s.r = y.read_shift(2), D.e.c = y.read_shift(1), y.l++, D.e.r = y.read_shift(2), D) : (D.s.c = y.read_shift(2), D.s.r = y.read_shift(2), L == 12 && R.qpro && (y.l += 2), D.e.c = y.read_shift(2), D.e.r = y.read_shift(2), L == 12 && R.qpro && (y.l += 2), D.s.c == 65535 && (D.s.c = D.e.c = D.s.r = D.e.r = 0), D);
  }
  function o(y) {
    var L = Qe(8);
    return L.write_shift(2, y.s.c), L.write_shift(2, y.s.r), L.write_shift(2, y.e.c), L.write_shift(2, y.e.r), L;
  }
  function l(y, L, R) {
    var D = [{ c: 0, r: 0 }, { t: "n", v: 0 }, 0, 0];
    return R.qpro && R.vers != 20768 ? (D[0].c = y.read_shift(1), D[3] = y.read_shift(1), D[0].r = y.read_shift(2), y.l += 2) : R.works ? (D[0].c = y.read_shift(2), D[0].r = y.read_shift(2), D[2] = y.read_shift(2)) : (D[2] = y.read_shift(1), D[0].c = y.read_shift(2), D[0].r = y.read_shift(2)), D;
  }
  function v(y) {
    return y.z && Ur(y.z) ? 240 | (r.indexOf(y.z) + 1 || 2) : 255;
  }
  function x(y, L, R) {
    var D = y.l + L, Y = l(y, L, R);
    if (Y[1].t = "s", (R.vers & 65534) == 20768) {
      y.l++;
      var w = y.read_shift(1);
      return Y[1].v = y.read_shift(w, "utf8"), Y;
    }
    return R.qpro && y.l++, Y[1].v = y.read_shift(D - y.l, "cstr"), Y;
  }
  function u(y, L, R) {
    var D = Qe(7 + R.length);
    D.write_shift(1, 255), D.write_shift(2, L), D.write_shift(2, y), D.write_shift(1, 39);
    for (var Y = 0; Y < D.length; ++Y) {
      var w = R.charCodeAt(Y);
      D.write_shift(1, w >= 128 ? 95 : w);
    }
    return D.write_shift(1, 0), D;
  }
  function p(y, L, R) {
    var D = y.l + L, Y = l(y, L, R);
    if (Y[1].t = "s", R.vers == 20768) {
      var w = y.read_shift(1);
      return Y[1].v = y.read_shift(w, "utf8"), Y;
    }
    return Y[1].v = y.read_shift(D - y.l, "cstr"), Y;
  }
  function _(y, L, R) {
    var D = l(y, L, R);
    return D[1].v = y.read_shift(2, "i"), D;
  }
  function d(y, L, R) {
    var D = Qe(7);
    return D.write_shift(1, v(R)), D.write_shift(2, L), D.write_shift(2, y), D.write_shift(2, R.v, "i"), D;
  }
  function h(y, L, R) {
    var D = l(y, L, R);
    return D[1].v = y.read_shift(8, "f"), D;
  }
  function E(y, L, R) {
    var D = Qe(13);
    return D.write_shift(1, v(R)), D.write_shift(2, L), D.write_shift(2, y), D.write_shift(8, R.v, "f"), D;
  }
  function g(y, L, R) {
    var D = y.l + L, Y = l(y, L, R);
    if (Y[1].v = y.read_shift(8, "f"), R.qpro) y.l = D;
    else {
      var w = y.read_shift(2);
      I(y.slice(y.l, y.l + w), Y), y.l += w;
    }
    return Y;
  }
  function C(y, L, R) {
    var D = L & 32768;
    return L &= -32769, L = (D ? y : 0) + (L >= 8192 ? L - 16384 : L), (D ? "" : "$") + (R ? Pe(L) : Me(L));
  }
  var P = {
    31: ["NA", 0],
    // 0x20: ["ERR", 0],
    33: ["ABS", 1],
    34: ["TRUNC", 1],
    35: ["SQRT", 1],
    36: ["LOG", 1],
    37: ["LN", 1],
    38: ["PI", 0],
    39: ["SIN", 1],
    40: ["COS", 1],
    41: ["TAN", 1],
    42: ["ATAN2", 2],
    43: ["ATAN", 1],
    44: ["ASIN", 1],
    45: ["ACOS", 1],
    46: ["EXP", 1],
    47: ["MOD", 2],
    // 0x30
    49: ["ISNA", 1],
    50: ["ISERR", 1],
    51: ["FALSE", 0],
    52: ["TRUE", 0],
    53: ["RAND", 0],
    54: ["DATE", 3],
    // 0x37 NOW
    // 0x38 PMT
    // 0x39 PV
    // 0x3A FV
    // 0x3B IF
    // 0x3C DAY
    // 0x3D MONTH
    // 0x3E YEAR
    63: ["ROUND", 2],
    64: ["TIME", 3],
    // 0x41 HOUR
    // 0x42 MINUTE
    // 0x43 SECOND
    68: ["ISNUMBER", 1],
    69: ["ISTEXT", 1],
    70: ["LEN", 1],
    71: ["VALUE", 1],
    // 0x48: ["FIXED", ?? 1],
    73: ["MID", 3],
    74: ["CHAR", 1],
    // 0x4B
    // 0x4C FIND
    // 0x4D DATEVALUE
    // 0x4E TIMEVALUE
    // 0x4F CELL
    80: ["SUM", 69],
    81: ["AVERAGEA", 69],
    82: ["COUNTA", 69],
    83: ["MINA", 69],
    84: ["MAXA", 69],
    // 0x55 VLOOKUP
    // 0x56 NPV
    // 0x57 VAR
    // 0x58 STD
    // 0x59 IRR
    // 0x5A HLOOKUP
    // 0x5B DSUM
    // 0x5C DAVERAGE
    // 0x5D DCOUNTA
    // 0x5E DMIN
    // 0x5F DMAX
    // 0x60 DVARP
    // 0x61 DSTDEVP
    // 0x62 INDEX
    // 0x63 COLS
    // 0x64 ROWS
    // 0x65 REPEAT
    102: ["UPPER", 1],
    103: ["LOWER", 1],
    // 0x68 LEFT
    // 0x69 RIGHT
    // 0x6A REPLACE
    107: ["PROPER", 1],
    // 0x6C CELL
    109: ["TRIM", 1],
    // 0x6E CLEAN
    111: ["T", 1]
    // 0x70 V
  }, M = [
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    // eslint-disable-line no-mixed-spaces-and-tabs
    "",
    "+",
    "-",
    "*",
    "/",
    "^",
    "=",
    "<>",
    // eslint-disable-line no-mixed-spaces-and-tabs
    "<=",
    ">=",
    "<",
    ">",
    "",
    "",
    "",
    "",
    // eslint-disable-line no-mixed-spaces-and-tabs
    "&",
    "",
    "",
    "",
    "",
    "",
    "",
    ""
    // eslint-disable-line no-mixed-spaces-and-tabs
  ];
  function I(y, L) {
    rr(y, 0);
    for (var R = [], D = 0, Y = "", w = "", te = "", ie = ""; y.l < y.length; ) {
      var Q = y[y.l++];
      switch (Q) {
        case 0:
          R.push(y.read_shift(8, "f"));
          break;
        case 1:
          w = C(L[0].c, y.read_shift(2), !0), Y = C(L[0].r, y.read_shift(2), !1), R.push(w + Y);
          break;
        case 2:
          {
            var ve = C(L[0].c, y.read_shift(2), !0), xe = C(L[0].r, y.read_shift(2), !1);
            w = C(L[0].c, y.read_shift(2), !0), Y = C(L[0].r, y.read_shift(2), !1), R.push(ve + xe + ":" + w + Y);
          }
          break;
        case 3:
          if (y.l < y.length) {
            console.error("WK1 premature formula end");
            return;
          }
          break;
        case 4:
          R.push("(" + R.pop() + ")");
          break;
        case 5:
          R.push(y.read_shift(2));
          break;
        case 6:
          {
            for (var Ee = ""; Q = y[y.l++]; ) Ee += String.fromCharCode(Q);
            R.push('"' + Ee.replace(/"/g, '""') + '"');
          }
          break;
        case 8:
          R.push("-" + R.pop());
          break;
        case 23:
          R.push("+" + R.pop());
          break;
        case 22:
          R.push("NOT(" + R.pop() + ")");
          break;
        case 20:
        case 21:
          ie = R.pop(), te = R.pop(), R.push(["AND", "OR"][Q - 20] + "(" + te + "," + ie + ")");
          break;
        default:
          if (Q < 32 && M[Q])
            ie = R.pop(), te = R.pop(), R.push(te + M[Q] + ie);
          else if (P[Q]) {
            if (D = P[Q][1], D == 69 && (D = y[y.l++]), D > R.length) {
              console.error("WK1 bad formula parse 0x" + Q.toString(16) + ":|" + R.join("|") + "|");
              return;
            }
            var Le = R.slice(-D);
            R.length -= D, R.push(P[Q][0] + "(" + Le.join(",") + ")");
          } else return Q <= 7 ? console.error("WK1 invalid opcode " + Q.toString(16)) : Q <= 24 ? console.error("WK1 unsupported op " + Q.toString(16)) : Q <= 30 ? console.error("WK1 invalid opcode " + Q.toString(16)) : Q <= 115 ? console.error("WK1 unsupported function opcode " + Q.toString(16)) : console.error("WK1 unrecognized opcode " + Q.toString(16));
      }
    }
    R.length == 1 ? L[1].f = "" + R[0] : console.error("WK1 bad formula parse |" + R.join("|") + "|");
  }
  function N(y) {
    var L = [{ c: 0, r: 0 }, { t: "n", v: 0 }, 0];
    return L[0].r = y.read_shift(2), L[3] = y[y.l++], L[0].c = y[y.l++], L;
  }
  function O(y, L) {
    var R = N(y);
    return R[1].t = "s", R[1].v = y.read_shift(L - 4, "cstr"), R;
  }
  function B(y, L, R, D) {
    var Y = Qe(6 + D.length);
    Y.write_shift(2, y), Y.write_shift(1, R), Y.write_shift(1, L), Y.write_shift(1, 39);
    for (var w = 0; w < D.length; ++w) {
      var te = D.charCodeAt(w);
      Y.write_shift(1, te >= 128 ? 95 : te);
    }
    return Y.write_shift(1, 0), Y;
  }
  function b(y, L) {
    var R = N(y);
    R[1].v = y.read_shift(2);
    var D = R[1].v >> 1;
    if (R[1].v & 1)
      switch (D & 7) {
        case 0:
          D = (D >> 3) * 5e3;
          break;
        case 1:
          D = (D >> 3) * 500;
          break;
        case 2:
          D = (D >> 3) / 20;
          break;
        case 3:
          D = (D >> 3) / 200;
          break;
        case 4:
          D = (D >> 3) / 2e3;
          break;
        case 5:
          D = (D >> 3) / 2e4;
          break;
        case 6:
          D = (D >> 3) / 16;
          break;
        case 7:
          D = (D >> 3) / 64;
          break;
      }
    return R[1].v = D, R;
  }
  function G(y, L) {
    var R = N(y), D = y.read_shift(4), Y = y.read_shift(4), w = y.read_shift(2);
    if (w == 65535)
      return D === 0 && Y === 3221225472 ? (R[1].t = "e", R[1].v = 15) : D === 0 && Y === 3489660928 ? (R[1].t = "e", R[1].v = 42) : R[1].v = 0, R;
    var te = w & 32768;
    return w = (w & 32767) - 16446, R[1].v = (1 - te * 2) * (Y * Math.pow(2, w + 32) + D * Math.pow(2, w)), R;
  }
  function z(y, L, R, D) {
    var Y = Qe(14);
    if (Y.write_shift(2, y), Y.write_shift(1, R), Y.write_shift(1, L), D == 0)
      return Y.write_shift(4, 0), Y.write_shift(4, 0), Y.write_shift(2, 65535), Y;
    var w = 0, te = 0, ie = 0, Q = 0;
    return D < 0 && (w = 1, D = -D), te = Math.log2(D) | 0, D /= Math.pow(2, te - 31), Q = D >>> 0, (Q & 2147483648) == 0 && (D /= 2, ++te, Q = D >>> 0), D -= Q, Q |= 2147483648, Q >>>= 0, D *= Math.pow(2, 32), ie = D >>> 0, Y.write_shift(4, ie), Y.write_shift(4, Q), te += 16383 + (w ? 32768 : 0), Y.write_shift(2, te), Y;
  }
  function ce(y, L) {
    var R = G(y);
    return y.l += L - 14, R;
  }
  function j(y, L) {
    var R = N(y), D = y.read_shift(4);
    return R[1].v = D >> 6, R;
  }
  function he(y, L) {
    var R = N(y), D = y.read_shift(8, "f");
    return R[1].v = D, R;
  }
  function J(y, L) {
    var R = he(y);
    return y.l += L - 12, R;
  }
  function ne(y, L) {
    return y[y.l + L - 1] == 0 ? y.read_shift(L, "cstr") : "";
  }
  function pe(y, L) {
    var R = y[y.l++];
    R > L - 1 && (R = L - 1);
    for (var D = ""; D.length < R; ) D += String.fromCharCode(y[y.l++]);
    return D;
  }
  function X(y, L, R) {
    if (!(!R.qpro || L < 21)) {
      var D = y.read_shift(1);
      y.l += 17, y.l += 1, y.l += 2;
      var Y = y.read_shift(L - 21, "cstr");
      return [D, Y];
    }
  }
  function Te(y, L) {
    for (var R = {}, D = y.l + L; y.l < D; ) {
      var Y = y.read_shift(2);
      if (Y == 14e3) {
        for (R[Y] = [0, ""], R[Y][0] = y.read_shift(2); y[y.l]; )
          R[Y][1] += String.fromCharCode(y[y.l]), y.l++;
        y.l++;
      }
    }
    return R;
  }
  function _e(y, L) {
    var R = Qe(5 + y.length);
    R.write_shift(2, 14e3), R.write_shift(2, L);
    for (var D = 0; D < y.length; ++D) {
      var Y = y.charCodeAt(D);
      R[R.l++] = Y > 127 ? 95 : Y;
    }
    return R[R.l++] = 0, R;
  }
  var de = {
    0: { n: "BOF", f: Xe },
    1: { n: "EOF" },
    2: { n: "CALCMODE" },
    3: { n: "CALCORDER" },
    4: { n: "SPLIT" },
    5: { n: "SYNC" },
    6: { n: "RANGE", f },
    7: { n: "WINDOW1" },
    8: { n: "COLW1" },
    9: { n: "WINTWO" },
    10: { n: "COLW2" },
    11: { n: "NAME" },
    12: { n: "BLANK" },
    13: { n: "INTEGER", f: _ },
    14: { n: "NUMBER", f: h },
    15: { n: "LABEL", f: x },
    16: { n: "FORMULA", f: g },
    24: { n: "TABLE" },
    25: { n: "ORANGE" },
    26: { n: "PRANGE" },
    27: { n: "SRANGE" },
    28: { n: "FRANGE" },
    29: { n: "KRANGE1" },
    32: { n: "HRANGE" },
    35: { n: "KRANGE2" },
    36: { n: "PROTEC" },
    37: { n: "FOOTER" },
    38: { n: "HEADER" },
    39: { n: "SETUP" },
    40: { n: "MARGINS" },
    41: { n: "LABELFMT" },
    42: { n: "TITLES" },
    43: { n: "SHEETJS" },
    45: { n: "GRAPH" },
    46: { n: "NGRAPH" },
    47: { n: "CALCCOUNT" },
    48: { n: "UNFORMATTED" },
    49: { n: "CURSORW12" },
    50: { n: "WINDOW" },
    51: { n: "STRING", f: p },
    55: { n: "PASSWORD" },
    56: { n: "LOCKED" },
    60: { n: "QUERY" },
    61: { n: "QUERYNAME" },
    62: { n: "PRINT" },
    63: { n: "PRINTNAME" },
    64: { n: "GRAPH2" },
    65: { n: "GRAPHNAME" },
    66: { n: "ZOOM" },
    67: { n: "SYMSPLIT" },
    68: { n: "NSROWS" },
    69: { n: "NSCOLS" },
    70: { n: "RULER" },
    71: { n: "NNAME" },
    72: { n: "ACOMM" },
    73: { n: "AMACRO" },
    74: { n: "PARSE" },
    // 0x0064
    102: { n: "PRANGES??" },
    103: { n: "RRANGES??" },
    104: { n: "FNAME??" },
    105: { n: "MRANGES??" },
    // 0x0096
    // 0x0099
    // 0x009A
    // 0x009B
    // 0x009C
    // 0x00C0
    // 0x00C7
    // 0x00C9
    204: { n: "SHEETNAMECS", f: ne },
    // 0x00CD
    222: { n: "SHEETNAMELP", f: pe },
    255: { n: "BOF", f: Xe },
    21506: { n: "WKSNF", f: Xe },
    65535: { n: "" }
  }, fe = {
    0: { n: "BOF" },
    1: { n: "EOF" },
    2: { n: "PASSWORD" },
    3: { n: "CALCSET" },
    4: { n: "WINDOWSET" },
    5: { n: "SHEETCELLPTR" },
    6: { n: "SHEETLAYOUT" },
    7: { n: "COLUMNWIDTH" },
    8: { n: "HIDDENCOLUMN" },
    9: { n: "USERRANGE" },
    10: { n: "SYSTEMRANGE" },
    11: { n: "ZEROFORCE" },
    12: { n: "SORTKEYDIR" },
    13: { n: "FILESEAL" },
    14: { n: "DATAFILLNUMS" },
    15: { n: "PRINTMAIN" },
    16: { n: "PRINTSTRING" },
    17: { n: "GRAPHMAIN" },
    18: { n: "GRAPHSTRING" },
    19: { n: "??" },
    20: { n: "ERRCELL" },
    21: { n: "NACELL" },
    22: { n: "LABEL16", f: O },
    23: { n: "NUMBER17", f: G },
    24: { n: "NUMBER18", f: b },
    25: { n: "FORMULA19", f: ce },
    26: { n: "FORMULA1A" },
    27: { n: "XFORMAT", f: Te },
    28: { n: "DTLABELMISC" },
    29: { n: "DTLABELCELL" },
    30: { n: "GRAPHWINDOW" },
    31: { n: "CPA" },
    32: { n: "LPLAUTO" },
    33: { n: "QUERY" },
    34: { n: "HIDDENSHEET" },
    35: { n: "??" },
    37: { n: "NUMBER25", f: j },
    38: { n: "??" },
    39: { n: "NUMBER27", f: he },
    40: { n: "FORMULA28", f: J },
    142: { n: "??" },
    147: { n: "??" },
    150: { n: "??" },
    151: { n: "??" },
    152: { n: "??" },
    153: { n: "??" },
    154: { n: "??" },
    155: { n: "??" },
    156: { n: "??" },
    163: { n: "??" },
    174: { n: "??" },
    175: { n: "??" },
    176: { n: "??" },
    177: { n: "??" },
    184: { n: "??" },
    185: { n: "??" },
    186: { n: "??" },
    187: { n: "??" },
    188: { n: "??" },
    195: { n: "??" },
    201: { n: "??" },
    204: { n: "SHEETNAMECS", f: ne },
    205: { n: "??" },
    206: { n: "??" },
    207: { n: "??" },
    208: { n: "??" },
    256: { n: "??" },
    259: { n: "??" },
    260: { n: "??" },
    261: { n: "??" },
    262: { n: "??" },
    263: { n: "??" },
    265: { n: "??" },
    266: { n: "??" },
    267: { n: "??" },
    268: { n: "??" },
    270: { n: "??" },
    271: { n: "??" },
    384: { n: "??" },
    389: { n: "??" },
    390: { n: "??" },
    393: { n: "??" },
    396: { n: "??" },
    512: { n: "??" },
    514: { n: "??" },
    513: { n: "??" },
    516: { n: "??" },
    517: { n: "??" },
    640: { n: "??" },
    641: { n: "??" },
    642: { n: "??" },
    643: { n: "??" },
    644: { n: "??" },
    645: { n: "??" },
    646: { n: "??" },
    647: { n: "??" },
    648: { n: "??" },
    658: { n: "??" },
    659: { n: "??" },
    660: { n: "??" },
    661: { n: "??" },
    662: { n: "??" },
    665: { n: "??" },
    666: { n: "??" },
    768: { n: "??" },
    772: { n: "??" },
    1537: { n: "SHEETINFOQP", f: X },
    1600: { n: "??" },
    1602: { n: "??" },
    1793: { n: "??" },
    1794: { n: "??" },
    1795: { n: "??" },
    1796: { n: "??" },
    1920: { n: "??" },
    2048: { n: "??" },
    2049: { n: "??" },
    2052: { n: "??" },
    2688: { n: "??" },
    10998: { n: "??" },
    12849: { n: "??" },
    28233: { n: "??" },
    28484: { n: "??" },
    65535: { n: "" }
  }, ke = {
    5: "dd-mmm-yy",
    6: "dd-mmm",
    7: "mmm-yy",
    8: "mm/dd/yy",
    // Long Date Intl
    10: "hh:mm:ss AM/PM",
    11: "hh:mm AM/PM",
    14: "dd-mmm-yyyy",
    15: "mmm-yyyy",
    /* It is suspected that the the low nybble specifies decimal places */
    34: "0.00",
    50: "0.00;[Red]0.00",
    66: "0.00;(0.00)",
    82: "0.00;[Red](0.00)",
    162: '"$"#,##0.00;\\("$"#,##0.00\\)',
    288: "0%",
    304: "0E+00",
    320: "# ?/?"
  };
  function me(y) {
    var L = y.read_shift(2), R = y.read_shift(1);
    if (R != 0) throw "unsupported QPW string type " + R.toString(16);
    return y.read_shift(L, "sbcs-cont");
  }
  function Fe(y, L) {
    rr(y, 0);
    var R = L || {}, D = {};
    R.dense && (D["!data"] = []);
    var Y = [], w = "", te = { s: { r: -1, c: -1 }, e: { r: -1, c: -1 } }, ie = 0, Q = 0, ve = 0, xe = 0, Ee = { SheetNames: [], Sheets: {} }, Le = [];
    e: for (; y.l < y.length; ) {
      var He = y.read_shift(2), $e = y.read_shift(2), ue = y.slice(y.l, y.l + $e);
      switch (rr(ue, 0), He) {
        case 1:
          if (ue.read_shift(4) != 962023505) throw "Bad QPW9 BOF!";
          break;
        case 2:
          break e;
        case 8:
          break;
        // TODO: this is tied to custom number formats
        case 10:
          for (var De = ue.read_shift(4), re = (ue.length - ue.l) / De | 0, yr = 0; yr < De; ++yr) {
            var gr = ue.l + re, We = {};
            ue.l += 2, We.numFmtId = ue.read_shift(2), ke[We.numFmtId] && (We.z = ke[We.numFmtId]), ue.l = gr, Le.push(We);
          }
          break;
        /* TODO: The behavior here should be consistent with Numbers: QP Notebook ~ .TN.SheetArchive, QP Sheet ~ .TST.TableModelArchive */
        case 1025:
          break;
        case 1026:
          break;
        case 1031:
          for (ue.l += 12; ue.l < ue.length; )
            ie = ue.read_shift(2), Q = ue.read_shift(1), Y.push(ue.read_shift(ie, "cstr"));
          break;
        case 1032:
          break;
        case 1537:
          {
            var Vr = ue.read_shift(2);
            D = {}, R.dense && (D["!data"] = []), te.s.c = ue.read_shift(2), te.e.c = ue.read_shift(2), te.s.r = ue.read_shift(4), te.e.r = ue.read_shift(4), ue.l += 4, ue.l + 2 < ue.length && (ie = ue.read_shift(2), Q = ue.read_shift(1), w = ie == 0 ? "" : ue.read_shift(ie, "cstr")), w || (w = Pe(Vr));
          }
          break;
        case 1538:
          {
            if (te.s.c > 255 || te.s.r > 999999) break;
            te.e.c < te.s.c && (te.e.c = te.s.c), te.e.r < te.s.r && (te.e.r = te.s.r), D["!ref"] = Ce(te), gt(Ee, D, w);
          }
          break;
        case 2561:
          ve = ue.read_shift(2), te.e.c < ve && (te.e.c = ve), te.s.c > ve && (te.s.c = ve), xe = ue.read_shift(4), te.s.r > xe && (te.s.r = xe), xe = ue.read_shift(4), te.e.r < xe && (te.e.r = xe);
          break;
        case 3073:
          {
            xe = ue.read_shift(4), ie = ue.read_shift(4), te.s.r > xe && (te.s.r = xe), te.e.r < xe + ie - 1 && (te.e.r = xe + ie - 1);
            for (var Er = Pe(ve); ue.l < ue.length; ) {
              var se = { t: "z" }, be = ue.read_shift(1), Ye = -1;
              be & 128 && (Ye = ue.read_shift(2));
              var je = be & 64 ? ue.read_shift(2) - 1 : 0;
              switch (be & 31) {
                case 0:
                  break;
                case 1:
                  break;
                case 2:
                  se = { t: "n", v: ue.read_shift(2) };
                  break;
                case 3:
                  se = { t: "n", v: ue.read_shift(2, "i") };
                  break;
                case 4:
                  se = { t: "n", v: Zt(ue) };
                  break;
                case 5:
                  se = { t: "n", v: ue.read_shift(8, "f") };
                  break;
                case 7:
                  se = { t: "s", v: Y[Q = ue.read_shift(4) - 1] };
                  break;
                case 8:
                  se = { t: "n", v: ue.read_shift(8, "f") }, ue.l += 2, ue.l += 4, isNaN(se.v) && (se = { t: "e", v: 15 });
                  break;
                default:
                  throw "Unrecognized QPW cell type " + (be & 31);
              }
              Ye != -1 && (Le[Ye - 1] || {}).z && (se.z = Le[Ye - 1].z);
              var Jr = 0;
              if (be & 32) switch (be & 31) {
                case 2:
                  Jr = ue.read_shift(2);
                  break;
                case 3:
                  Jr = ue.read_shift(2, "i");
                  break;
                case 7:
                  Jr = ue.read_shift(2);
                  break;
                default:
                  throw "Unsupported delta for QPW cell type " + (be & 31);
              }
              if (!(!R.sheetStubs && se.t == "z")) {
                var xa = er(se);
                se.t == "n" && se.z && Ur(se.z) && R.cellDates && (xa.v = ca(se.v), xa.t = typeof xa.v == "number" ? "n" : "d"), D["!data"] != null ? (D["!data"][xe] || (D["!data"][xe] = []), D["!data"][xe][ve] = xa) : D[Er + Me(xe)] = xa;
              }
              for (++xe, --ie; je-- > 0 && ie >= 0; ) {
                if (be & 32) switch (be & 31) {
                  case 2:
                    se = { t: "n", v: se.v + Jr & 65535 };
                    break;
                  case 3:
                    se = { t: "n", v: se.v + Jr & 65535 }, se.v > 32767 && (se.v -= 65536);
                    break;
                  case 7:
                    se = { t: "s", v: Y[Q = Q + Jr >>> 0] };
                    break;
                  default:
                    throw "Cannot apply delta for QPW cell type " + (be & 31);
                }
                else switch (be & 31) {
                  case 1:
                    se = { t: "z" };
                    break;
                  case 2:
                    se = { t: "n", v: ue.read_shift(2) };
                    break;
                  case 7:
                    se = { t: "s", v: Y[Q = ue.read_shift(4) - 1] };
                    break;
                  default:
                    throw "Cannot apply repeat for QPW cell type " + (be & 31);
                }
                !R.sheetStubs && se.t == "z" || (D["!data"] != null ? (D["!data"][xe] || (D["!data"][xe] = []), D["!data"][xe][ve] = se) : D[Er + Me(xe)] = se), ++xe, --ie;
              }
            }
          }
          break;
        case 3074:
          {
            ve = ue.read_shift(2), xe = ue.read_shift(4);
            var mt = me(ue);
            D["!data"] != null ? (D["!data"][xe] || (D["!data"][xe] = []), D["!data"][xe][ve] = { t: "s", v: mt }) : D[Pe(ve) + Me(xe)] = { t: "s", v: mt };
          }
          break;
      }
      y.l += $e;
    }
    return Ee;
  }
  return {
    sheet_to_wk1: n,
    book_to_wk3: i,
    to_workbook: a
  };
})();
function Ul(e) {
  var a = {}, r = e.match(or), t = 0, n = !1;
  if (r) for (; t != r.length; ++t) {
    var i = le(r[t]);
    switch (i[0].replace(/<\w*:/g, "<")) {
      /* 18.8.12 condense CT_BooleanProperty */
      /* ** not required . */
      case "<condense":
        break;
      /* 18.8.17 extend CT_BooleanProperty */
      /* ** not required . */
      case "<extend":
        break;
      /* 18.8.36 shadow CT_BooleanProperty */
      /* ** not required . */
      case "<shadow":
        if (!i.val) break;
      /* falls through */
      case "<shadow>":
      case "<shadow/>":
        a.shadow = 1;
        break;
      case "</shadow>":
        break;
      /* 18.4.1 charset CT_IntProperty TODO */
      case "<charset":
        if (i.val == "1") break;
        a.cp = w0[parseInt(i.val, 10)];
        break;
      /* 18.4.2 outline CT_BooleanProperty TODO */
      case "<outline":
        if (!i.val) break;
      /* falls through */
      case "<outline>":
      case "<outline/>":
        a.outline = 1;
        break;
      case "</outline>":
        break;
      /* 18.4.5 rFont CT_FontName */
      case "<rFont":
        a.name = i.val;
        break;
      /* 18.4.11 sz CT_FontSize */
      case "<sz":
        a.sz = i.val;
        break;
      /* 18.4.10 strike CT_BooleanProperty */
      case "<strike":
        if (!i.val) break;
      /* falls through */
      case "<strike>":
      case "<strike/>":
        a.strike = 1;
        break;
      case "</strike>":
        break;
      /* 18.4.13 u CT_UnderlineProperty */
      case "<u":
        if (!i.val) break;
        switch (i.val) {
          case "double":
            a.uval = "double";
            break;
          case "singleAccounting":
            a.uval = "single-accounting";
            break;
          case "doubleAccounting":
            a.uval = "double-accounting";
            break;
        }
      /* falls through */
      case "<u>":
      case "<u/>":
        a.u = 1;
        break;
      case "</u>":
        break;
      /* 18.8.2 b */
      case "<b":
        if (i.val == "0") break;
      /* falls through */
      case "<b>":
      case "<b/>":
        a.b = 1;
        break;
      case "</b>":
        break;
      /* 18.8.26 i */
      case "<i":
        if (i.val == "0") break;
      /* falls through */
      case "<i>":
      case "<i/>":
        a.i = 1;
        break;
      case "</i>":
        break;
      /* 18.3.1.15 color CT_Color TODO: tint, theme, auto, indexed */
      case "<color":
        i.rgb && (a.color = i.rgb.slice(2, 8));
        break;
      case "<color>":
      case "<color/>":
      case "</color>":
        break;
      /* 18.8.18 family ST_FontFamily */
      case "<family":
        a.family = i.val;
        break;
      case "<family>":
      case "<family/>":
      case "</family>":
        break;
      /* 18.4.14 vertAlign CT_VerticalAlignFontProperty TODO */
      case "<vertAlign":
        a.valign = i.val;
        break;
      case "<vertAlign>":
      case "<vertAlign/>":
      case "</vertAlign>":
        break;
      /* 18.8.35 scheme CT_FontScheme TODO */
      case "<scheme":
        break;
      case "<scheme>":
      case "<scheme/>":
      case "</scheme>":
        break;
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
        break;
      case "<ext":
        n = !0;
        break;
      case "</ext>":
        n = !1;
        break;
      default:
        if (i[0].charCodeAt(1) !== 47 && !n) throw new Error("Unrecognized rich format " + i[0]);
    }
  }
  return a;
}
var Hl = /* @__PURE__ */ (function() {
  function e(t) {
    var n = ir(t, "t");
    if (!n) return { t: "s", v: "" };
    var i = { t: "s", v: Se(n[1]) }, c = ir(t, "rPr");
    return c && (i.s = Ul(c[1])), i;
  }
  var a = /<(?:\w+:)?r>/g, r = /<\/(?:\w+:)?r>/;
  return function(n) {
    return n.replace(a, "").split(r).map(e).filter(function(i) {
      return i.v;
    });
  };
})(), Wl = /* @__PURE__ */ (function() {
  var a = /(\r\n|\n)/g;
  function r(n, i, c) {
    var s = [];
    n.u && s.push("text-decoration: underline;"), n.uval && s.push("text-underline-style:" + n.uval + ";"), n.sz && s.push("font-size:" + n.sz + "pt;"), n.outline && s.push("text-effect: outline;"), n.shadow && s.push("text-shadow: auto;"), i.push('<span style="' + s.join("") + '">'), n.b && (i.push("<b>"), c.push("</b>")), n.i && (i.push("<i>"), c.push("</i>")), n.strike && (i.push("<s>"), c.push("</s>"));
    var f = n.valign || "";
    return f == "superscript" || f == "super" ? f = "sup" : f == "subscript" && (f = "sub"), f != "" && (i.push("<" + f + ">"), c.push("</" + f + ">")), c.push("</span>"), n;
  }
  function t(n) {
    var i = [[], n.v, []];
    return n.v ? (n.s && r(n.s, i[0], i[2]), i[0].join("") + i[1].replace(a, "<br/>") + i[2].join("")) : "";
  }
  return function(i) {
    return i.map(t).join("");
  };
})(), Vl = /<(?:\w+:)?t\b[^<>]*>([^<]*)<\/(?:\w+:)?t>/g, Gl = /<(?:\w+:)?r\b[^<>]*>/;
function U0(e, a) {
  var r = a ? a.cellHTML : !0, t = {};
  return e ? (e.match(/^\s*<(?:\w+:)?t[^>]*>/) ? (t.t = Se(Ue(e.slice(e.indexOf(">") + 1).split(/<\/(?:\w+:)?t>/)[0] || ""), !0), t.r = Ue(e), r && (t.h = za(t.t))) : (
    /*y = */
    e.match(Gl) && (t.r = Ue(e), t.t = Se(Ue((Yc(e, "rPh").match(Vl) || []).join("").replace(or, "")), !0), r && (t.h = Wl(Hl(t.r))))
  ), t) : { t: "" };
}
var $l = /<(?:\w+:)?(?:si|sstItem)>/g, Xl = /<\/(?:\w+:)?(?:si|sstItem)>/;
function zl(e, a) {
  var r = [], t = "";
  if (!e) return r;
  var n = ir(e, "sst");
  if (n) {
    t = n[1].replace($l, "").split(Xl);
    for (var i = 0; i != t.length; ++i) {
      var c = U0(t[i].trim(), a);
      c != null && (r[r.length] = c);
    }
    n = le(n[0].slice(0, n[0].indexOf(">"))), r.Count = n.count, r.Unique = n.uniqueCount;
  }
  return r;
}
function Kl(e) {
  return [e.read_shift(4), e.read_shift(4)];
}
function Yl(e, a) {
  var r = [], t = !1;
  return ta(e, function(i, c, s) {
    switch (s) {
      case 159:
        r.Count = i[0], r.Unique = i[1];
        break;
      case 19:
        r.push(i);
        break;
      case 160:
        return !0;
      case 35:
        t = !0;
        break;
      case 36:
        t = !1;
        break;
      default:
        if (c.T, !t || a.WTF) throw new Error("Unexpected record 0x" + s.toString(16));
    }
  }), r;
}
function ns(e) {
  for (var a = [], r = e.split(""), t = 0; t < r.length; ++t) a[t] = r[t].charCodeAt(0);
  return a;
}
function ra(e, a) {
  var r = {};
  return r.Major = e.read_shift(2), r.Minor = e.read_shift(2), a >= 4 && (e.l += a - 4), r;
}
function jl(e) {
  var a = {};
  return a.id = e.read_shift(0, "lpp4"), a.R = ra(e, 4), a.U = ra(e, 4), a.W = ra(e, 4), a;
}
function Jl(e) {
  for (var a = e.read_shift(4), r = e.l + a - 4, t = {}, n = e.read_shift(4), i = []; n-- > 0; ) i.push({ t: e.read_shift(4), v: e.read_shift(0, "lpp4") });
  if (t.name = e.read_shift(0, "lpp4"), t.comps = i, e.l != r) throw new Error("Bad DataSpaceMapEntry: " + e.l + " != " + r);
  return t;
}
function Zl(e) {
  var a = [];
  e.l += 4;
  for (var r = e.read_shift(4); r-- > 0; ) a.push(Jl(e));
  return a;
}
function ql(e) {
  var a = [];
  e.l += 4;
  for (var r = e.read_shift(4); r-- > 0; ) a.push(e.read_shift(0, "lpp4"));
  return a;
}
function Ql(e) {
  var a = {};
  return e.read_shift(4), e.l += 4, a.id = e.read_shift(0, "lpp4"), a.name = e.read_shift(0, "lpp4"), a.R = ra(e, 4), a.U = ra(e, 4), a.W = ra(e, 4), a;
}
function e1(e) {
  var a = Ql(e);
  if (a.ename = e.read_shift(0, "8lpp4"), a.blksz = e.read_shift(4), a.cmode = e.read_shift(4), e.read_shift(4) != 4) throw new Error("Bad !Primary record");
  return a;
}
function is(e, a) {
  var r = e.l + a, t = {};
  t.Flags = e.read_shift(4) & 63, e.l += 4, t.AlgID = e.read_shift(4);
  var n = !1;
  switch (t.AlgID) {
    case 26126:
    case 26127:
    case 26128:
      n = t.Flags == 36;
      break;
    case 26625:
      n = t.Flags == 4;
      break;
    case 0:
      n = t.Flags == 16 || t.Flags == 4 || t.Flags == 36;
      break;
    default:
      throw "Unrecognized encryption algorithm: " + t.AlgID;
  }
  if (!n) throw new Error("Encryption Flags/AlgID mismatch");
  return t.AlgIDHash = e.read_shift(4), t.KeySize = e.read_shift(4), t.ProviderType = e.read_shift(4), e.l += 8, t.CSPName = e.read_shift(r - e.l >> 1, "utf16le"), e.l = r, t;
}
function ss(e, a) {
  var r = {}, t = e.l + a;
  return e.l += 4, r.Salt = e.slice(e.l, e.l + 16), e.l += 16, r.Verifier = e.slice(e.l, e.l + 16), e.l += 16, e.read_shift(4), r.VerifierHash = e.slice(e.l, t), e.l = t, r;
}
function r1(e) {
  var a = ra(e);
  switch (a.Minor) {
    case 2:
      return [a.Minor, a1(e)];
    case 3:
      return [a.Minor, t1()];
    case 4:
      return [a.Minor, n1(e)];
  }
  throw new Error("ECMA-376 Encrypted file unrecognized Version: " + a.Minor);
}
function a1(e) {
  var a = e.read_shift(4);
  if ((a & 63) != 36) throw new Error("EncryptionInfo mismatch");
  var r = e.read_shift(4), t = is(e, r), n = ss(e, e.length - e.l);
  return { t: "Std", h: t, v: n };
}
function t1() {
  throw new Error("File is password-protected: ECMA-376 Extensible");
}
function n1(e) {
  var a = ["saltSize", "blockSize", "keyBits", "hashSize", "cipherAlgorithm", "cipherChaining", "hashAlgorithm", "saltValue"];
  e.l += 4;
  var r = e.read_shift(e.length - e.l, "utf8"), t = {};
  return r.replace(or, function(i) {
    var c = le(i);
    switch (Hr(c[0])) {
      case "<?xml":
        break;
      case "<encryption":
      case "</encryption>":
        break;
      case "<keyData":
        a.forEach(function(s) {
          t[s] = c[s];
        });
        break;
      case "<dataIntegrity":
        t.encryptedHmacKey = c.encryptedHmacKey, t.encryptedHmacValue = c.encryptedHmacValue;
        break;
      case "<keyEncryptors>":
      case "<keyEncryptors":
        t.encs = [];
        break;
      case "</keyEncryptors>":
        break;
      case "<keyEncryptor":
        t.uri = c.uri;
        break;
      case "</keyEncryptor>":
        break;
      case "<encryptedKey":
        t.encs.push(c);
        break;
      default:
        throw c[0];
    }
  }), t;
}
function i1(e, a) {
  var r = {}, t = r.EncryptionVersionInfo = ra(e, 4);
  if (a -= 4, t.Minor != 2) throw new Error("unrecognized minor version code: " + t.Minor);
  if (t.Major > 4 || t.Major < 2) throw new Error("unrecognized major version code: " + t.Major);
  r.Flags = e.read_shift(4), a -= 4;
  var n = e.read_shift(4);
  return a -= 4, r.EncryptionHeader = is(e, n), a -= n, r.EncryptionVerifier = ss(e, a), r;
}
function s1(e) {
  var a = {}, r = a.EncryptionVersionInfo = ra(e, 4);
  if (r.Major != 1 || r.Minor != 1) throw "unrecognized version code " + r.Major + " : " + r.Minor;
  return a.Salt = e.read_shift(16), a.EncryptedVerifier = e.read_shift(16), a.EncryptedVerifierHash = e.read_shift(16), a;
}
function c1(e) {
  var a = 0, r, t = ns(e), n = t.length + 1, i, c, s, f, o;
  for (r = fa(n), r[0] = t.length, i = 1; i != n; ++i) r[i] = t[i - 1];
  for (i = n - 1; i >= 0; --i)
    c = r[i], s = (a & 16384) === 0 ? 0 : 1, f = a << 1 & 32767, o = s | f, a = o ^ c;
  return a ^ 52811;
}
var cs = /* @__PURE__ */ (function() {
  var e = [187, 255, 255, 186, 255, 255, 185, 128, 0, 190, 15, 0, 191, 15, 0], a = [57840, 7439, 52380, 33984, 4364, 3600, 61902, 12606, 6258, 57657, 54287, 34041, 10252, 43370, 20163], r = [44796, 19929, 39858, 10053, 20106, 40212, 10761, 31585, 63170, 64933, 60267, 50935, 40399, 11199, 17763, 35526, 1453, 2906, 5812, 11624, 23248, 885, 1770, 3540, 7080, 14160, 28320, 56640, 55369, 41139, 20807, 41614, 21821, 43642, 17621, 28485, 56970, 44341, 19019, 38038, 14605, 29210, 60195, 50791, 40175, 10751, 21502, 43004, 24537, 18387, 36774, 3949, 7898, 15796, 31592, 63184, 47201, 24803, 49606, 37805, 14203, 28406, 56812, 17824, 35648, 1697, 3394, 6788, 13576, 27152, 43601, 17539, 35078, 557, 1114, 2228, 4456, 30388, 60776, 51953, 34243, 7079, 14158, 28316, 14128, 28256, 56512, 43425, 17251, 34502, 7597, 13105, 26210, 52420, 35241, 883, 1766, 3532, 4129, 8258, 16516, 33032, 4657, 9314, 18628], t = function(c) {
    return (c / 2 | c * 128) & 255;
  }, n = function(c, s) {
    return t(c ^ s);
  }, i = function(c) {
    for (var s = a[c.length - 1], f = 104, o = c.length - 1; o >= 0; --o)
      for (var l = c[o], v = 0; v != 7; ++v)
        l & 64 && (s ^= r[f]), l *= 2, --f;
    return s;
  };
  return function(c) {
    for (var s = ns(c), f = i(s), o = s.length, l = fa(16), v = 0; v != 16; ++v) l[v] = 0;
    var x, u, p;
    for ((o & 1) === 1 && (x = f >> 8, l[o] = n(e[0], x), --o, x = f & 255, u = s[s.length - 1], l[o] = n(u, x)); o > 0; )
      --o, x = f >> 8, l[o] = n(s[o], x), --o, x = f & 255, l[o] = n(s[o], x);
    for (o = 15, p = 15 - s.length; p > 0; )
      x = f >> 8, l[o] = n(e[p], x), --o, --p, x = f & 255, l[o] = n(s[o], x), --o, --p;
    return l;
  };
})(), f1 = function(e, a, r, t, n) {
  n || (n = a), t || (t = cs(e));
  var i, c;
  for (i = 0; i != a.length; ++i)
    c = a[i], c ^= t[r], c = (c >> 5 | c << 3) & 255, n[i] = c, ++r;
  return [n, r, t];
}, o1 = function(e) {
  var a = 0, r = cs(e);
  return function(t) {
    var n = f1("", t, a, r);
    return a = n[1], n[0];
  };
};
function l1(e, a, r, t) {
  var n = { key: Xe(e), verificationBytes: Xe(e) };
  return r.password && (n.verifier = c1(r.password)), t.valid = n.verificationBytes === n.verifier, t.valid && (t.insitu = o1(r.password)), n;
}
function u1(e, a, r) {
  var t = r || {};
  return t.Info = e.read_shift(2), e.l -= 2, t.Info === 1 ? t.Data = s1(e) : t.Data = i1(e, a), t;
}
function h1(e, a, r) {
  var t = { Type: r.biff >= 8 ? e.read_shift(2) : 0 };
  return t.Type ? u1(e, a - 2, t) : l1(e, r.biff >= 8 ? a : a - 2, r, t), t;
}
function x1(e, a) {
  switch (a.type) {
    case "base64":
      return yt(Rr(e), a);
    case "binary":
      return yt(e, a);
    case "buffer":
      return yt(ye && Buffer.isBuffer(e) ? e.toString("binary") : aa(e), a);
    case "array":
      return yt(ka(e), a);
  }
  throw new Error("Unrecognized type " + a.type);
}
function yt(e, a) {
  var r = a || {}, t = {}, n = r.dense;
  n && (t["!data"] = []);
  var i = O0(e, "\\trowd", "\\row");
  if (!i)
    throw new Error("RTF missing table");
  var c = { s: { c: 0, r: 0 }, e: { c: 0, r: i.length - 1 } }, s = [];
  return i.forEach(function(f, o) {
    n && (s = t["!data"][o] = []);
    for (var l = /\\[\w\-]+\b/g, v = 0, x, u = -1, p = []; (x = l.exec(f)) != null; ) {
      var _ = f.slice(v, l.lastIndex - x[0].length);
      switch (_.charCodeAt(0) == 32 && (_ = _.slice(1)), _.length && p.push(_), x[0]) {
        case "\\cell":
          if (++u, p.length) {
            var d = { v: p.join(""), t: "s" };
            d.v == "TRUE" || d.v == "FALSE" ? (d.v = d.v == "TRUE", d.t = "b") : isNaN(Or(d.v)) ? sr[d.v] != null && (d.t = "e", d.w = d.v, d.v = sr[d.v]) : (d.t = "n", r.cellText !== !1 && (d.w = d.v), d.v = Or(d.v)), n ? s[u] = d : t[Ne({ r: o, c: u })] = d;
          }
          p = [];
          break;
        case "\\par":
          p.push(`
`);
          break;
      }
      v = l.lastIndex;
    }
    u > c.e.c && (c.e.c = u);
  }), t["!ref"] = Ce(c), t;
}
function d1(e, a) {
  var r = ha(x1(e, a), a);
  return r.bookType = "rtf", r;
}
function v1(e) {
  var a = e.slice(e[0] === "#" ? 1 : 0).slice(0, 6);
  return [parseInt(a.slice(0, 2), 16), parseInt(a.slice(2, 4), 16), parseInt(a.slice(4, 6), 16)];
}
function ct(e) {
  for (var a = 0, r = 1; a != 3; ++a) r = r * 256 + (e[a] > 255 ? 255 : e[a] < 0 ? 0 : e[a]);
  return r.toString(16).toUpperCase().slice(1);
}
function p1(e) {
  var a = e[0] / 255, r = e[1] / 255, t = e[2] / 255, n = Math.max(a, r, t), i = Math.min(a, r, t), c = n - i;
  if (c === 0) return [0, 0, a];
  var s = 0, f = 0, o = n + i;
  switch (f = c / (o > 1 ? 2 - o : o), n) {
    case a:
      s = ((r - t) / c + 6) % 6;
      break;
    case r:
      s = (t - a) / c + 2;
      break;
    case t:
      s = (a - r) / c + 4;
      break;
  }
  return [s / 6, f, o / 2];
}
function g1(e) {
  var a = e[0], r = e[1], t = e[2], n = r * 2 * (t < 0.5 ? t : 1 - t), i = t - n / 2, c = [i, i, i], s = 6 * a, f;
  if (r !== 0) switch (s | 0) {
    case 0:
    case 6:
      f = n * s, c[0] += n, c[1] += f;
      break;
    case 1:
      f = n * (2 - s), c[0] += f, c[1] += n;
      break;
    case 2:
      f = n * (s - 2), c[1] += n, c[2] += f;
      break;
    case 3:
      f = n * (4 - s), c[1] += f, c[2] += n;
      break;
    case 4:
      f = n * (s - 4), c[2] += n, c[0] += f;
      break;
    case 5:
      f = n * (6 - s), c[2] += f, c[0] += n;
      break;
  }
  for (var o = 0; o != 3; ++o) c[o] = Math.round(c[o] * 255);
  return c;
}
function Ht(e, a) {
  if (a === 0) return e;
  var r = p1(v1(e));
  return a < 0 ? r[2] = r[2] * (1 + a) : r[2] = 1 - (1 - r[2]) * (1 - a), ct(g1(r));
}
var fs = 6, m1 = 15, _1 = 1, _r = fs;
function Wt(e) {
  return Math.floor((e + Math.round(128 / _r) / 256) * _r);
}
function Vt(e) {
  return Math.floor((e - 5) / _r * 100 + 0.5) / 100;
}
function _0(e) {
  return Math.round((e * _r + 5) / _r * 256) / 256;
}
function o0(e) {
  return _0(Vt(Wt(e)));
}
function H0(e) {
  var a = Math.abs(e - o0(e)), r = _r;
  if (a > 5e-3) for (_r = _1; _r < m1; ++_r) Math.abs(e - o0(e)) <= a && (a = Math.abs(e - o0(e)), r = _r);
  _r = r;
}
function Ma(e) {
  e.width ? (e.wpx = Wt(e.width), e.wch = Vt(e.wpx), e.MDW = _r) : e.wpx ? (e.wch = Vt(e.wpx), e.width = _0(e.wch), e.MDW = _r) : typeof e.wch == "number" && (e.width = _0(e.wch), e.wpx = Wt(e.width), e.MDW = _r), e.customWidth && delete e.customWidth;
}
var T1 = 96, os = T1;
function ls(e) {
  return e * 96 / os;
}
function ft(e) {
  return e * os / 96;
}
var E1 = {
  None: "none",
  Solid: "solid",
  Gray50: "mediumGray",
  Gray75: "darkGray",
  Gray25: "lightGray",
  HorzStripe: "darkHorizontal",
  VertStripe: "darkVertical",
  ReverseDiagStripe: "darkDown",
  DiagStripe: "darkUp",
  DiagCross: "darkGrid",
  ThickDiagCross: "darkTrellis",
  ThinHorzStripe: "lightHorizontal",
  ThinVertStripe: "lightVertical",
  ThinReverseDiagStripe: "lightDown",
  ThinHorzCross: "lightGrid"
};
function k1(e, a, r, t) {
  a.Borders = [];
  var n = {}, i = !1;
  (e.match(or) || []).forEach(function(c) {
    var s = le(c);
    switch (Hr(s[0])) {
      case "<borders":
      case "<borders>":
      case "</borders>":
        break;
      /* 18.8.4 border CT_Border */
      case "<border":
      case "<border>":
      case "<border/>":
        n = /*::(*/
        {}, s.diagonalUp && (n.diagonalUp = Be(s.diagonalUp)), s.diagonalDown && (n.diagonalDown = Be(s.diagonalDown)), a.Borders.push(n);
        break;
      case "</border>":
        break;
      /* note: not in spec, appears to be CT_BorderPr */
      case "<left/>":
        break;
      case "<left":
      case "<left>":
        break;
      case "</left>":
        break;
      /* note: not in spec, appears to be CT_BorderPr */
      case "<right/>":
        break;
      case "<right":
      case "<right>":
        break;
      case "</right>":
        break;
      /* 18.8.43 top CT_BorderPr */
      case "<top/>":
        break;
      case "<top":
      case "<top>":
        break;
      case "</top>":
        break;
      /* 18.8.6 bottom CT_BorderPr */
      case "<bottom/>":
        break;
      case "<bottom":
      case "<bottom>":
        break;
      case "</bottom>":
        break;
      /* 18.8.13 diagonal CT_BorderPr */
      case "<diagonal":
      case "<diagonal>":
      case "<diagonal/>":
        break;
      case "</diagonal>":
        break;
      /* 18.8.25 horizontal CT_BorderPr */
      case "<horizontal":
      case "<horizontal>":
      case "<horizontal/>":
        break;
      case "</horizontal>":
        break;
      /* 18.8.44 vertical CT_BorderPr */
      case "<vertical":
      case "<vertical>":
      case "<vertical/>":
        break;
      case "</vertical>":
        break;
      /* 18.8.37 start CT_BorderPr */
      case "<start":
      case "<start>":
      case "<start/>":
        break;
      case "</start>":
        break;
      /* 18.8.16 end CT_BorderPr */
      case "<end":
      case "<end>":
      case "<end/>":
        break;
      case "</end>":
        break;
      /* 18.8.? color CT_Color */
      case "<color":
      case "<color>":
        break;
      case "<color/>":
      case "</color>":
        break;
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
        break;
      case "<ext":
        i = !0;
        break;
      case "</ext>":
        i = !1;
        break;
      default:
        if (t && t.WTF && !i)
          throw new Error("unrecognized " + s[0] + " in borders");
    }
  });
}
function w1(e, a, r, t) {
  a.Fills = [];
  var n = {}, i = !1;
  (e.match(or) || []).forEach(function(c) {
    var s = le(c);
    switch (Hr(s[0])) {
      case "<fills":
      case "<fills>":
      case "</fills>":
        break;
      /* 18.8.20 fill CT_Fill */
      case "<fill>":
      case "<fill":
      case "<fill/>":
        n = {}, a.Fills.push(n);
        break;
      case "</fill>":
        break;
      /* 18.8.24 gradientFill CT_GradientFill */
      case "<gradientFill>":
        break;
      case "<gradientFill":
      case "</gradientFill>":
        a.Fills.push(n), n = {};
        break;
      /* 18.8.32 patternFill CT_PatternFill */
      case "<patternFill":
      case "<patternFill>":
        s.patternType && (n.patternType = s.patternType);
        break;
      case "<patternFill/>":
      case "</patternFill>":
        break;
      /* 18.8.3 bgColor CT_Color */
      case "<bgColor":
        n.bgColor || (n.bgColor = {}), s.indexed && (n.bgColor.indexed = parseInt(s.indexed, 10)), s.theme && (n.bgColor.theme = parseInt(s.theme, 10)), s.tint && (n.bgColor.tint = parseFloat(s.tint)), s.rgb && (n.bgColor.rgb = s.rgb.slice(-6));
        break;
      case "<bgColor/>":
      case "</bgColor>":
        break;
      /* 18.8.19 fgColor CT_Color */
      case "<fgColor":
        n.fgColor || (n.fgColor = {}), s.theme && (n.fgColor.theme = parseInt(s.theme, 10)), s.tint && (n.fgColor.tint = parseFloat(s.tint)), s.rgb != null && (n.fgColor.rgb = s.rgb.slice(-6));
        break;
      case "<fgColor/>":
      case "</fgColor>":
        break;
      /* 18.8.38 stop CT_GradientStop */
      case "<stop":
      case "<stop/>":
        break;
      case "</stop>":
        break;
      /* 18.8.? color CT_Color */
      case "<color":
      case "<color/>":
        break;
      case "</color>":
        break;
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
        break;
      case "<ext":
        i = !0;
        break;
      case "</ext>":
        i = !1;
        break;
      default:
        if (t && t.WTF && !i)
          throw new Error("unrecognized " + s[0] + " in fills");
    }
  });
}
function F1(e, a, r, t) {
  a.Fonts = [];
  var n = {}, i = !1;
  (e.match(or) || []).forEach(function(c) {
    var s = le(c);
    switch (Hr(s[0])) {
      case "<fonts":
      case "<fonts>":
      case "</fonts>":
        break;
      /* 18.8.22 font CT_Font */
      case "<font":
      case "<font>":
        break;
      case "</font>":
      case "<font/>":
        a.Fonts.push(n), n = {};
        break;
      /* 18.8.29 name CT_FontName */
      case "<name":
        s.val && (n.name = Ue(s.val));
        break;
      case "<name/>":
      case "</name>":
        break;
      /* 18.8.2  b CT_BooleanProperty */
      case "<b":
        n.bold = s.val ? Be(s.val) : 1;
        break;
      case "<b/>":
        n.bold = 1;
        break;
      case "</b>":
      case "</b":
        break;
      /* 18.8.26 i CT_BooleanProperty */
      case "<i":
        n.italic = s.val ? Be(s.val) : 1;
        break;
      case "<i/>":
        n.italic = 1;
        break;
      case "</i>":
      case "</i":
        break;
      /* 18.4.13 u CT_UnderlineProperty */
      case "<u":
        switch (s.val) {
          case "none":
            n.underline = 0;
            break;
          case "single":
            n.underline = 1;
            break;
          case "double":
            n.underline = 2;
            break;
          case "singleAccounting":
            n.underline = 33;
            break;
          case "doubleAccounting":
            n.underline = 34;
            break;
        }
        break;
      case "<u/>":
        n.underline = 1;
        break;
      case "</u>":
      case "</u":
        break;
      /* 18.4.10 strike CT_BooleanProperty */
      case "<strike":
        n.strike = s.val ? Be(s.val) : 1;
        break;
      case "<strike/>":
        n.strike = 1;
        break;
      case "</strike>":
      case "</strike":
        break;
      /* 18.4.2  outline CT_BooleanProperty */
      case "<outline":
        n.outline = s.val ? Be(s.val) : 1;
        break;
      case "<outline/>":
        n.outline = 1;
        break;
      case "</outline>":
      case "</outline":
        break;
      /* 18.8.36 shadow CT_BooleanProperty */
      case "<shadow":
        n.shadow = s.val ? Be(s.val) : 1;
        break;
      case "<shadow/>":
        n.shadow = 1;
        break;
      case "</shadow>":
      case "</shadow":
        break;
      /* 18.8.12 condense CT_BooleanProperty */
      case "<condense":
        n.condense = s.val ? Be(s.val) : 1;
        break;
      case "<condense/>":
        n.condense = 1;
        break;
      case "</condense>":
      case "</condense":
        break;
      /* 18.8.17 extend CT_BooleanProperty */
      case "<extend":
        n.extend = s.val ? Be(s.val) : 1;
        break;
      case "<extend/>":
        n.extend = 1;
        break;
      case "</extend>":
      case "</extend":
        break;
      /* 18.4.11 sz CT_FontSize */
      case "<sz":
        s.val && (n.sz = +s.val);
        break;
      case "<sz/>":
      case "</sz>":
      case "</sz":
        break;
      /* 18.4.14 vertAlign CT_VerticalAlignFontProperty */
      case "<vertAlign":
        s.val && (n.vertAlign = s.val);
        break;
      case "<vertAlign/>":
      case "</vertAlign>":
      case "</vertAlign":
        break;
      /* 18.8.18 family CT_FontFamily */
      case "<family":
        s.val && (n.family = parseInt(s.val, 10));
        break;
      case "<family/>":
      case "</family>":
      case "</family":
        break;
      /* 18.8.35 scheme CT_FontScheme */
      case "<scheme":
        s.val && (n.scheme = s.val);
        break;
      case "<scheme/>":
      case "</scheme>":
      case "</scheme":
        break;
      /* 18.4.1 charset CT_IntProperty */
      case "<charset":
        if (s.val == "1") break;
        s.codepage = w0[parseInt(s.val, 10)];
        break;
      case "<charset/>":
      case "</charset>":
      case "</charset":
        break;
      /* 18.?.? color CT_Color */
      case "<color":
        if (n.color || (n.color = {}), s.auto && (n.color.auto = Be(s.auto)), s.rgb) n.color.rgb = s.rgb.slice(-6);
        else if (s.indexed) {
          n.color.index = parseInt(s.indexed, 10);
          var f = _a[n.color.index];
          n.color.index == 81 && (f = _a[1]), f || (f = _a[1]), n.color.rgb = f[0].toString(16) + f[1].toString(16) + f[2].toString(16);
        } else s.theme && (n.color.theme = parseInt(s.theme, 10), s.tint && (n.color.tint = parseFloat(s.tint)), s.theme && r.themeElements && r.themeElements.clrScheme && (n.color.rgb = Ht(r.themeElements.clrScheme[n.color.theme].rgb, n.color.tint || 0)));
        break;
      case "<color/>":
      case "</color>":
      case "</color":
        break;
      /* note: sometimes mc:AlternateContent appears bare */
      case "<AlternateContent":
        i = !0;
        break;
      case "</AlternateContent>":
      case "</AlternateContent":
        i = !1;
        break;
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
        break;
      case "<ext":
        i = !0;
        break;
      case "</ext>":
        i = !1;
        break;
      default:
        if (t && t.WTF && !i)
          throw new Error("unrecognized " + s[0] + " in fonts");
    }
  });
}
function A1(e, a, r) {
  a.NumberFmt = [];
  for (var t = Br(ge), n = 0; n < t.length; ++n) a.NumberFmt[t[n]] = ge[t[n]];
  var i = e.match(or);
  if (i)
    for (n = 0; n < i.length; ++n) {
      var c = le(i[n]);
      switch (Hr(c[0])) {
        case "<numFmts":
        case "</numFmts>":
        case "<numFmts/>":
        case "<numFmts>":
          break;
        case "<numFmt":
          {
            var s = Se(Ue(c.formatCode)), f = parseInt(c.numFmtId, 10);
            if (a.NumberFmt[f] = s, f > 0) {
              if (f > 392) {
                for (f = 392; f > 60 && a.NumberFmt[f] != null; --f) ;
                a.NumberFmt[f] = s;
              }
              ga(s, f);
            }
          }
          break;
        case "</numFmt>":
          break;
        default:
          if (r.WTF) throw new Error("unrecognized " + c[0] + " in numFmts");
      }
    }
}
var St = ["numFmtId", "fillId", "fontId", "borderId", "xfId"], Ct = ["applyAlignment", "applyBorder", "applyFill", "applyFont", "applyNumberFormat", "applyProtection", "pivotButton", "quotePrefix"];
function y1(e, a, r) {
  a.CellXf = [];
  var t, n = !1;
  (e.match(or) || []).forEach(function(i) {
    var c = le(i), s = 0;
    switch (Hr(c[0])) {
      case "<cellXfs":
      case "<cellXfs>":
      case "<cellXfs/>":
      case "</cellXfs>":
        break;
      /* 18.8.45 xf CT_Xf */
      case "<xf":
      case "<xf/>":
      case "<xf>":
        for (t = c, delete t[0], s = 0; s < St.length; ++s) t[St[s]] && (t[St[s]] = parseInt(t[St[s]], 10));
        for (s = 0; s < Ct.length; ++s) t[Ct[s]] && (t[Ct[s]] = Be(t[Ct[s]]));
        if (a.NumberFmt && t.numFmtId > 392) {
          for (s = 392; s > 60; --s) if (a.NumberFmt[t.numFmtId] == a.NumberFmt[s]) {
            t.numFmtId = s;
            break;
          }
        }
        a.CellXf.push(t);
        break;
      case "</xf>":
        break;
      /* 18.8.1 alignment CT_CellAlignment */
      case "<alignment":
      case "<alignment/>":
      case "<alignment>":
        var f = {};
        c.vertical && (f.vertical = c.vertical), c.horizontal && (f.horizontal = c.horizontal), c.textRotation != null && (f.textRotation = c.textRotation), c.indent && (f.indent = c.indent), c.wrapText && (f.wrapText = Be(c.wrapText)), t.alignment = f;
        break;
      case "</alignment>":
        break;
      /* 18.8.33 protection CT_CellProtection */
      case "<protection":
      case "<protection>":
        break;
      case "</protection>":
      case "<protection/>":
        break;
      /* note: sometimes mc:AlternateContent appears bare */
      case "<AlternateContent":
      case "<AlternateContent>":
        n = !0;
        break;
      case "</AlternateContent>":
        n = !1;
        break;
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
        break;
      case "<ext":
        n = !0;
        break;
      case "</ext>":
        n = !1;
        break;
      default:
        if (r && r.WTF && !n)
          throw new Error("unrecognized " + c[0] + " in cellXfs");
    }
  });
}
var S1 = /* @__PURE__ */ (function() {
  return function(r, t, n) {
    var i = {};
    if (!r) return i;
    r = I0(ut(r, "<!--", "-->"));
    var c;
    return (c = ir(r, "numFmts")) && A1(c[0], i, n), (c = ir(r, "fonts")) && F1(c[0], i, t, n), (c = ir(r, "fills")) && w1(c[0], i, t, n), (c = ir(r, "borders")) && k1(c[0], i, t, n), (c = ir(r, "cellXfs")) && y1(c[0], i, n), i;
  };
})();
function C1(e, a) {
  var r = e.read_shift(2), t = vr(e);
  return [r, t];
}
function D1(e, a, r) {
  var t = {};
  t.sz = e.read_shift(2) / 20;
  var n = bf(e);
  n.fItalic && (t.italic = 1), n.fCondense && (t.condense = 1), n.fExtend && (t.extend = 1), n.fShadow && (t.shadow = 1), n.fOutline && (t.outline = 1), n.fStrikeout && (t.strike = 1);
  var i = e.read_shift(2);
  switch (i === 700 && (t.bold = 1), e.read_shift(2)) {
    /* case 0: out.vertAlign = "baseline"; break; */
    case 1:
      t.vertAlign = "superscript";
      break;
    case 2:
      t.vertAlign = "subscript";
      break;
  }
  var c = e.read_shift(1);
  c != 0 && (t.underline = c);
  var s = e.read_shift(1);
  s > 0 && (t.family = s);
  var f = e.read_shift(1);
  switch (f > 0 && (t.charset = f), e.l++, t.color = Pf(e), e.read_shift(1)) {
    /* case 0: out.scheme = "none": break; */
    case 1:
      t.scheme = "major";
      break;
    case 2:
      t.scheme = "minor";
      break;
  }
  return t.name = vr(e), t;
}
var I1 = pr;
function O1(e, a) {
  var r = e.l + a, t = e.read_shift(2), n = e.read_shift(2);
  return e.l = r, { ixfe: t, numFmtId: n };
}
var R1 = pr;
function N1(e, a, r) {
  var t = {};
  t.NumberFmt = [];
  for (var n in ge) t.NumberFmt[n] = ge[n];
  t.CellXf = [], t.Fonts = [];
  var i = [], c = !1;
  return ta(e, function(f, o, l) {
    switch (l) {
      case 44:
        t.NumberFmt[f[0]] = f[1], ga(f[1], f[0]);
        break;
      case 43:
        t.Fonts.push(f), f.color.theme != null && a && a.themeElements && a.themeElements.clrScheme && (f.color.rgb = Ht(a.themeElements.clrScheme[f.color.theme].rgb, f.color.tint || 0));
        break;
      case 1025:
        break;
      case 45:
        break;
      case 46:
        break;
      case 47:
        i[i.length - 1] == 617 && t.CellXf.push(f);
        break;
      case 48:
      /* BrtStyle */
      case 507:
      /* BrtDXF */
      case 572:
      /* BrtMRUColor */
      case 475:
        break;
      case 1171:
      /* BrtDXF14 */
      case 2102:
      /* BrtDXF15 */
      case 1130:
      /* BrtSlicerStyleElement */
      case 512:
      /* BrtTableStyleElement */
      case 2095:
      /* BrtTimelineStyleElement */
      case 3072:
        break;
      case 35:
        c = !0;
        break;
      case 36:
        c = !1;
        break;
      case 37:
        i.push(l), c = !0;
        break;
      case 38:
        i.pop(), c = !1;
        break;
      default:
        if (o.T > 0) i.push(l);
        else if (o.T < 0) i.pop();
        else if (!c || r.WTF && i[i.length - 1] != 37) throw new Error("Unexpected record 0x" + l.toString(16));
    }
  }), t;
}
var P1 = [
  "</a:lt1>",
  "</a:dk1>",
  "</a:lt2>",
  "</a:dk2>",
  "</a:accent1>",
  "</a:accent2>",
  "</a:accent3>",
  "</a:accent4>",
  "</a:accent5>",
  "</a:accent6>",
  "</a:hlink>",
  "</a:folHlink>"
];
function b1(e, a, r) {
  a.themeElements.clrScheme = [];
  var t = {};
  (e[0].match(or) || []).forEach(function(n) {
    var i = le(n);
    switch (i[0]) {
      /* 20.1.6.2 clrScheme (Color Scheme) CT_ColorScheme */
      case "<a:clrScheme":
      case "</a:clrScheme>":
        break;
      /* 20.1.2.3.32 srgbClr CT_SRgbColor */
      case "<a:srgbClr":
        t.rgb = i.val;
        break;
      case "</a:srgbClr>":
        break;
      /* 20.1.2.3.33 sysClr CT_SystemColor */
      case "<a:sysClr":
        t.rgb = i.lastClr;
        break;
      case "</a:sysClr>":
        break;
      /* 20.1.4.1.1 accent1 (Accent 1) */
      /* 20.1.4.1.2 accent2 (Accent 2) */
      /* 20.1.4.1.3 accent3 (Accent 3) */
      /* 20.1.4.1.4 accent4 (Accent 4) */
      /* 20.1.4.1.5 accent5 (Accent 5) */
      /* 20.1.4.1.6 accent6 (Accent 6) */
      /* 20.1.4.1.9 dk1 (Dark 1) */
      /* 20.1.4.1.10 dk2 (Dark 2) */
      /* 20.1.4.1.15 folHlink (Followed Hyperlink) */
      /* 20.1.4.1.19 hlink (Hyperlink) */
      /* 20.1.4.1.22 lt1 (Light 1) */
      /* 20.1.4.1.23 lt2 (Light 2) */
      case "</a:dk1>":
      case "</a:lt1>":
      case "<a:dk1>":
      case "<a:lt1>":
      case "<a:dk2>":
      case "</a:dk2>":
      case "<a:lt2>":
      case "</a:lt2>":
      case "<a:accent1>":
      case "</a:accent1>":
      case "<a:accent2>":
      case "</a:accent2>":
      case "<a:accent3>":
      case "</a:accent3>":
      case "<a:accent4>":
      case "</a:accent4>":
      case "<a:accent5>":
      case "</a:accent5>":
      case "<a:accent6>":
      case "</a:accent6>":
      case "<a:hlink>":
      case "</a:hlink>":
      case "<a:folHlink>":
      case "</a:folHlink>":
        i[0].charAt(1) === "/" ? (a.themeElements.clrScheme[P1.indexOf(i[0])] = t, t = {}) : t.name = i[0].slice(3, i[0].length - 1);
        break;
      default:
        if (r && r.WTF) throw new Error("Unrecognized " + i[0] + " in clrScheme");
    }
  });
}
function L1(e, a, r) {
  a.themeElements = {};
  var t;
  if (!(t = ma(e, "a:clrScheme"))) throw new Error("clrScheme not found in themeElements");
  if (b1(t, a, r), !(t = ma(e, "a:fontScheme"))) throw new Error("fontScheme not found in themeElements");
  if (!(t = ma(e, "a:fmtScheme"))) throw new Error("fmtScheme not found in themeElements");
}
function us(e, a) {
  (!e || e.length === 0) && (e = B1());
  var r, t = {};
  if (!(r = ma(e, "a:themeElements"))) throw new Error("themeElements not found in theme");
  return L1(r[0], t, a), t.raw = e, t;
}
function B1(e, a) {
  var r = [ki];
  return r[r.length] = '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Office Theme">', r[r.length] = "<a:themeElements>", r[r.length] = '<a:clrScheme name="Office">', r[r.length] = '<a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1>', r[r.length] = '<a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1>', r[r.length] = '<a:dk2><a:srgbClr val="1F497D"/></a:dk2>', r[r.length] = '<a:lt2><a:srgbClr val="EEECE1"/></a:lt2>', r[r.length] = '<a:accent1><a:srgbClr val="4F81BD"/></a:accent1>', r[r.length] = '<a:accent2><a:srgbClr val="C0504D"/></a:accent2>', r[r.length] = '<a:accent3><a:srgbClr val="9BBB59"/></a:accent3>', r[r.length] = '<a:accent4><a:srgbClr val="8064A2"/></a:accent4>', r[r.length] = '<a:accent5><a:srgbClr val="4BACC6"/></a:accent5>', r[r.length] = '<a:accent6><a:srgbClr val="F79646"/></a:accent6>', r[r.length] = '<a:hlink><a:srgbClr val="0000FF"/></a:hlink>', r[r.length] = '<a:folHlink><a:srgbClr val="800080"/></a:folHlink>', r[r.length] = "</a:clrScheme>", r[r.length] = '<a:fontScheme name="Office">', r[r.length] = "<a:majorFont>", r[r.length] = '<a:latin typeface="Cambria"/>', r[r.length] = '<a:ea typeface=""/>', r[r.length] = '<a:cs typeface=""/>', r[r.length] = '<a:font script="Jpan" typeface="ＭＳ Ｐゴシック"/>', r[r.length] = '<a:font script="Hang" typeface="맑은 고딕"/>', r[r.length] = '<a:font script="Hans" typeface="宋体"/>', r[r.length] = '<a:font script="Hant" typeface="新細明體"/>', r[r.length] = '<a:font script="Arab" typeface="Times New Roman"/>', r[r.length] = '<a:font script="Hebr" typeface="Times New Roman"/>', r[r.length] = '<a:font script="Thai" typeface="Tahoma"/>', r[r.length] = '<a:font script="Ethi" typeface="Nyala"/>', r[r.length] = '<a:font script="Beng" typeface="Vrinda"/>', r[r.length] = '<a:font script="Gujr" typeface="Shruti"/>', r[r.length] = '<a:font script="Khmr" typeface="MoolBoran"/>', r[r.length] = '<a:font script="Knda" typeface="Tunga"/>', r[r.length] = '<a:font script="Guru" typeface="Raavi"/>', r[r.length] = '<a:font script="Cans" typeface="Euphemia"/>', r[r.length] = '<a:font script="Cher" typeface="Plantagenet Cherokee"/>', r[r.length] = '<a:font script="Yiii" typeface="Microsoft Yi Baiti"/>', r[r.length] = '<a:font script="Tibt" typeface="Microsoft Himalaya"/>', r[r.length] = '<a:font script="Thaa" typeface="MV Boli"/>', r[r.length] = '<a:font script="Deva" typeface="Mangal"/>', r[r.length] = '<a:font script="Telu" typeface="Gautami"/>', r[r.length] = '<a:font script="Taml" typeface="Latha"/>', r[r.length] = '<a:font script="Syrc" typeface="Estrangelo Edessa"/>', r[r.length] = '<a:font script="Orya" typeface="Kalinga"/>', r[r.length] = '<a:font script="Mlym" typeface="Kartika"/>', r[r.length] = '<a:font script="Laoo" typeface="DokChampa"/>', r[r.length] = '<a:font script="Sinh" typeface="Iskoola Pota"/>', r[r.length] = '<a:font script="Mong" typeface="Mongolian Baiti"/>', r[r.length] = '<a:font script="Viet" typeface="Times New Roman"/>', r[r.length] = '<a:font script="Uigh" typeface="Microsoft Uighur"/>', r[r.length] = '<a:font script="Geor" typeface="Sylfaen"/>', r[r.length] = "</a:majorFont>", r[r.length] = "<a:minorFont>", r[r.length] = '<a:latin typeface="Calibri"/>', r[r.length] = '<a:ea typeface=""/>', r[r.length] = '<a:cs typeface=""/>', r[r.length] = '<a:font script="Jpan" typeface="ＭＳ Ｐゴシック"/>', r[r.length] = '<a:font script="Hang" typeface="맑은 고딕"/>', r[r.length] = '<a:font script="Hans" typeface="宋体"/>', r[r.length] = '<a:font script="Hant" typeface="新細明體"/>', r[r.length] = '<a:font script="Arab" typeface="Arial"/>', r[r.length] = '<a:font script="Hebr" typeface="Arial"/>', r[r.length] = '<a:font script="Thai" typeface="Tahoma"/>', r[r.length] = '<a:font script="Ethi" typeface="Nyala"/>', r[r.length] = '<a:font script="Beng" typeface="Vrinda"/>', r[r.length] = '<a:font script="Gujr" typeface="Shruti"/>', r[r.length] = '<a:font script="Khmr" typeface="DaunPenh"/>', r[r.length] = '<a:font script="Knda" typeface="Tunga"/>', r[r.length] = '<a:font script="Guru" typeface="Raavi"/>', r[r.length] = '<a:font script="Cans" typeface="Euphemia"/>', r[r.length] = '<a:font script="Cher" typeface="Plantagenet Cherokee"/>', r[r.length] = '<a:font script="Yiii" typeface="Microsoft Yi Baiti"/>', r[r.length] = '<a:font script="Tibt" typeface="Microsoft Himalaya"/>', r[r.length] = '<a:font script="Thaa" typeface="MV Boli"/>', r[r.length] = '<a:font script="Deva" typeface="Mangal"/>', r[r.length] = '<a:font script="Telu" typeface="Gautami"/>', r[r.length] = '<a:font script="Taml" typeface="Latha"/>', r[r.length] = '<a:font script="Syrc" typeface="Estrangelo Edessa"/>', r[r.length] = '<a:font script="Orya" typeface="Kalinga"/>', r[r.length] = '<a:font script="Mlym" typeface="Kartika"/>', r[r.length] = '<a:font script="Laoo" typeface="DokChampa"/>', r[r.length] = '<a:font script="Sinh" typeface="Iskoola Pota"/>', r[r.length] = '<a:font script="Mong" typeface="Mongolian Baiti"/>', r[r.length] = '<a:font script="Viet" typeface="Arial"/>', r[r.length] = '<a:font script="Uigh" typeface="Microsoft Uighur"/>', r[r.length] = '<a:font script="Geor" typeface="Sylfaen"/>', r[r.length] = "</a:minorFont>", r[r.length] = "</a:fontScheme>", r[r.length] = '<a:fmtScheme name="Office">', r[r.length] = "<a:fillStyleLst>", r[r.length] = '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>', r[r.length] = '<a:gradFill rotWithShape="1">', r[r.length] = "<a:gsLst>", r[r.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="50000"/><a:satMod val="300000"/></a:schemeClr></a:gs>', r[r.length] = '<a:gs pos="35000"><a:schemeClr val="phClr"><a:tint val="37000"/><a:satMod val="300000"/></a:schemeClr></a:gs>', r[r.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:tint val="15000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', r[r.length] = "</a:gsLst>", r[r.length] = '<a:lin ang="16200000" scaled="1"/>', r[r.length] = "</a:gradFill>", r[r.length] = '<a:gradFill rotWithShape="1">', r[r.length] = "<a:gsLst>", r[r.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="100000"/><a:shade val="100000"/><a:satMod val="130000"/></a:schemeClr></a:gs>', r[r.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:tint val="50000"/><a:shade val="100000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', r[r.length] = "</a:gsLst>", r[r.length] = '<a:lin ang="16200000" scaled="0"/>', r[r.length] = "</a:gradFill>", r[r.length] = "</a:fillStyleLst>", r[r.length] = "<a:lnStyleLst>", r[r.length] = '<a:ln w="9525" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"><a:shade val="95000"/><a:satMod val="105000"/></a:schemeClr></a:solidFill><a:prstDash val="solid"/></a:ln>', r[r.length] = '<a:ln w="25400" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>', r[r.length] = '<a:ln w="38100" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>', r[r.length] = "</a:lnStyleLst>", r[r.length] = "<a:effectStyleLst>", r[r.length] = "<a:effectStyle>", r[r.length] = "<a:effectLst>", r[r.length] = '<a:outerShdw blurRad="40000" dist="20000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="38000"/></a:srgbClr></a:outerShdw>', r[r.length] = "</a:effectLst>", r[r.length] = "</a:effectStyle>", r[r.length] = "<a:effectStyle>", r[r.length] = "<a:effectLst>", r[r.length] = '<a:outerShdw blurRad="40000" dist="23000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="35000"/></a:srgbClr></a:outerShdw>', r[r.length] = "</a:effectLst>", r[r.length] = "</a:effectStyle>", r[r.length] = "<a:effectStyle>", r[r.length] = "<a:effectLst>", r[r.length] = '<a:outerShdw blurRad="40000" dist="23000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="35000"/></a:srgbClr></a:outerShdw>', r[r.length] = "</a:effectLst>", r[r.length] = '<a:scene3d><a:camera prst="orthographicFront"><a:rot lat="0" lon="0" rev="0"/></a:camera><a:lightRig rig="threePt" dir="t"><a:rot lat="0" lon="0" rev="1200000"/></a:lightRig></a:scene3d>', r[r.length] = '<a:sp3d><a:bevelT w="63500" h="25400"/></a:sp3d>', r[r.length] = "</a:effectStyle>", r[r.length] = "</a:effectStyleLst>", r[r.length] = "<a:bgFillStyleLst>", r[r.length] = '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>', r[r.length] = '<a:gradFill rotWithShape="1">', r[r.length] = "<a:gsLst>", r[r.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="40000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', r[r.length] = '<a:gs pos="40000"><a:schemeClr val="phClr"><a:tint val="45000"/><a:shade val="99000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', r[r.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="20000"/><a:satMod val="255000"/></a:schemeClr></a:gs>', r[r.length] = "</a:gsLst>", r[r.length] = '<a:path path="circle"><a:fillToRect l="50000" t="-80000" r="50000" b="180000"/></a:path>', r[r.length] = "</a:gradFill>", r[r.length] = '<a:gradFill rotWithShape="1">', r[r.length] = "<a:gsLst>", r[r.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="80000"/><a:satMod val="300000"/></a:schemeClr></a:gs>', r[r.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="30000"/><a:satMod val="200000"/></a:schemeClr></a:gs>', r[r.length] = "</a:gsLst>", r[r.length] = '<a:path path="circle"><a:fillToRect l="50000" t="50000" r="50000" b="50000"/></a:path>', r[r.length] = "</a:gradFill>", r[r.length] = "</a:bgFillStyleLst>", r[r.length] = "</a:fmtScheme>", r[r.length] = "</a:themeElements>", r[r.length] = "<a:objectDefaults>", r[r.length] = "<a:spDef>", r[r.length] = '<a:spPr/><a:bodyPr/><a:lstStyle/><a:style><a:lnRef idx="1"><a:schemeClr val="accent1"/></a:lnRef><a:fillRef idx="3"><a:schemeClr val="accent1"/></a:fillRef><a:effectRef idx="2"><a:schemeClr val="accent1"/></a:effectRef><a:fontRef idx="minor"><a:schemeClr val="lt1"/></a:fontRef></a:style>', r[r.length] = "</a:spDef>", r[r.length] = "<a:lnDef>", r[r.length] = '<a:spPr/><a:bodyPr/><a:lstStyle/><a:style><a:lnRef idx="2"><a:schemeClr val="accent1"/></a:lnRef><a:fillRef idx="0"><a:schemeClr val="accent1"/></a:fillRef><a:effectRef idx="1"><a:schemeClr val="accent1"/></a:effectRef><a:fontRef idx="minor"><a:schemeClr val="tx1"/></a:fontRef></a:style>', r[r.length] = "</a:lnDef>", r[r.length] = "</a:objectDefaults>", r[r.length] = "<a:extraClrSchemeLst/>", r[r.length] = "</a:theme>", r.join("");
}
function M1(e, a, r) {
  var t = e.l + a, n = e.read_shift(4);
  if (n !== 124226) {
    if (!r.cellStyles) {
      e.l = t;
      return;
    }
    var i = e.slice(e.l);
    e.l = t;
    var c;
    try {
      c = Ei(i, { type: "array" });
    } catch {
      return;
    }
    var s = Tr(c, "theme/theme/theme1.xml", !0);
    if (s)
      return us(s, r);
  }
}
function U1(e) {
  return e.read_shift(4);
}
function H1(e) {
  var a = {};
  switch (a.xclrType = e.read_shift(2), a.nTintShade = e.read_shift(2), a.xclrType) {
    case 0:
      e.l += 4;
      break;
    case 1:
      a.xclrValue = W1(e, 4);
      break;
    case 2:
      a.xclrValue = Zi(e);
      break;
    case 3:
      a.xclrValue = U1(e);
      break;
    case 4:
      e.l += 4;
      break;
  }
  return e.l += 8, a;
}
function W1(e, a) {
  return pr(e, a);
}
function V1(e, a) {
  return pr(e, a);
}
function G1(e) {
  var a = e.read_shift(2), r = e.read_shift(2) - 4, t = [a];
  switch (a) {
    case 4:
    case 5:
    case 7:
    case 8:
    case 9:
    case 10:
    case 11:
    case 13:
      t[1] = H1(e);
      break;
    case 6:
      t[1] = V1(e, r);
      break;
    case 14:
    case 15:
      t[1] = e.read_shift(r === 1 ? 1 : 2);
      break;
    default:
      throw new Error("Unrecognized ExtProp type: " + a + " " + r);
  }
  return t;
}
function $1(e, a) {
  var r = e.l + a;
  e.l += 2;
  var t = e.read_shift(2);
  e.l += 2;
  for (var n = e.read_shift(2), i = []; n-- > 0; ) i.push(G1(e, r - e.l));
  return { ixfe: t, ext: i };
}
function X1(e, a) {
  a.forEach(function(r) {
    r[0];
  });
}
function z1(e, a) {
  return {
    flags: e.read_shift(4),
    version: e.read_shift(4),
    name: vr(e)
  };
}
function K1(e) {
  for (var a = [], r = e.read_shift(4); r-- > 0; )
    a.push([e.read_shift(4), e.read_shift(4)]);
  return a;
}
function Y1(e) {
  return e.l += 4, e.read_shift(4) != 0;
}
function j1(e, a, r) {
  var t = { Types: [], Cell: [], Value: [] }, n = r || {}, i = [], c = !1, s = 2;
  return ta(e, function(f, o, l) {
    switch (l) {
      case 335:
        t.Types.push({ name: f.name });
        break;
      case 51:
        f.forEach(function(v) {
          s == 1 ? t.Cell.push({ type: t.Types[v[0] - 1].name, index: v[1] }) : s == 0 && t.Value.push({ type: t.Types[v[0] - 1].name, index: v[1] });
        });
        break;
      case 337:
        s = f ? 1 : 0;
        break;
      case 338:
        s = 2;
        break;
      case 35:
        i.push(l), c = !0;
        break;
      case 36:
        i.pop(), c = !1;
        break;
      default:
        if (!o.T) {
          if (!c || n.WTF && i[i.length - 1] != 35)
            throw new Error("Unexpected record 0x" + l.toString(16));
        }
    }
  }), t;
}
function J1(e, a, r) {
  var t = { Types: [], Cell: [], Value: [] };
  if (!e)
    return t;
  var n = !1, i = 2, c;
  return e.replace(or, function(s) {
    var f = le(s);
    switch (Hr(f[0])) {
      case "<?xml":
        break;
      case "<metadata":
      case "</metadata>":
        break;
      case "<metadataTypes":
      case "</metadataTypes>":
        break;
      case "<metadataType":
        t.Types.push({ name: f.name });
        break;
      case "</metadataType>":
        break;
      case "<futureMetadata":
        for (var o = 0; o < t.Types.length; ++o)
          t.Types[o].name == f.name && (c = t.Types[o]);
        break;
      case "</futureMetadata>":
        break;
      case "<bk>":
        break;
      case "</bk>":
        break;
      case "<rc":
        i == 1 ? t.Cell.push({ type: t.Types[f.t - 1].name, index: +f.v }) : i == 0 && t.Value.push({ type: t.Types[f.t - 1].name, index: +f.v });
        break;
      case "</rc>":
        break;
      case "<cellMetadata":
        i = 1;
        break;
      case "</cellMetadata>":
        i = 2;
        break;
      case "<valueMetadata":
        i = 0;
        break;
      case "</valueMetadata>":
        i = 2;
        break;
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
      case "<extLst/>":
        break;
      case "<ext":
        n = !0;
        break;
      case "</ext>":
        n = !1;
        break;
      case "<rvb":
        if (!c)
          break;
        c.offsets || (c.offsets = []), c.offsets.push(+f.i);
        break;
      default:
        if (!n && r?.WTF)
          throw new Error("unrecognized " + f[0] + " in metadata");
    }
    return s;
  }), t;
}
function Z1(e) {
  var a = [];
  if (!e) return a;
  var r = 1;
  return (e.match(or) || []).forEach(function(t) {
    var n = le(t);
    switch (n[0]) {
      case "<?xml":
        break;
      /* 18.6.2  calcChain CT_CalcChain 1 */
      case "<calcChain":
      case "<calcChain>":
      case "</calcChain>":
        break;
      /* 18.6.1  c CT_CalcCell 1 */
      case "<c":
        delete n[0], n.i ? r = n.i : n.i = r, a.push(n);
        break;
    }
  }), a;
}
function q1(e) {
  var a = {};
  a.i = e.read_shift(4);
  var r = {};
  r.r = e.read_shift(4), r.c = e.read_shift(4), a.r = Ne(r);
  var t = e.read_shift(1);
  return t & 2 && (a.l = "1"), t & 8 && (a.a = "1"), a;
}
function Q1(e, a, r) {
  var t = [];
  return ta(e, function(i, c, s) {
    switch (s) {
      case 63:
        t.push(i);
        break;
      default:
        if (!c.T) throw new Error("Unexpected record 0x" + s.toString(16));
    }
  }), t;
}
function eu(e, a, r, t) {
  if (!e) return e;
  var n = t || {}, i = !1;
  ta(e, function(s, f, o) {
    switch (o) {
      case 359:
      /* 'BrtSupTabs' */
      case 363:
      /* 'BrtExternTableStart' */
      case 364:
      /* 'BrtExternTableEnd' */
      case 366:
      /* 'BrtExternRowHdr' */
      case 367:
      /* 'BrtExternCellBlank' */
      case 368:
      /* 'BrtExternCellReal' */
      case 369:
      /* 'BrtExternCellBool' */
      case 370:
      /* 'BrtExternCellError' */
      case 371:
      /* 'BrtExternCellString' */
      case 472:
      /* 'BrtExternValueMeta' */
      case 577:
      /* 'BrtSupNameStart' */
      case 578:
      /* 'BrtSupNameValueStart' */
      case 579:
      /* 'BrtSupNameValueEnd' */
      case 580:
      /* 'BrtSupNameNum' */
      case 581:
      /* 'BrtSupNameErr' */
      case 582:
      /* 'BrtSupNameSt' */
      case 583:
      /* 'BrtSupNameNil' */
      case 584:
      /* 'BrtSupNameBool' */
      case 585:
      /* 'BrtSupNameFmla' */
      case 586:
      /* 'BrtSupNameBits' */
      case 587:
        break;
      case 35:
        i = !0;
        break;
      case 36:
        i = !1;
        break;
      default:
        if (!f.T) {
          if (!i || n.WTF) throw new Error("Unexpected record 0x" + o.toString(16));
        }
    }
  }, n);
}
function ru(e, a) {
  if (!e) return "??";
  var r = (e.match(/<c:chart [^<>]*r:id="([^<>"]*)"/) || ["", ""])[1];
  return a["!id"][r].Target;
}
function au(e, a, r) {
  var t = 0;
  (mi(e, "shape") || []).forEach(function(n) {
    var i = "", c = !0, s = -1, f = -1, o = -1;
    switch (n.replace(or, function(v, x) {
      var u = le(v);
      switch (Hr(u[0])) {
        case "<ClientData":
          u.ObjectType && (i = u.ObjectType);
          break;
        case "<Visible":
        case "<Visible/>":
          c = !1;
          break;
        case "<Row":
        case "<Row>":
          s = x + v.length;
          break;
        case "</Row>":
          f = +n.slice(s, x).trim();
          break;
        case "<Column":
        case "<Column>":
          s = x + v.length;
          break;
        case "</Column>":
          o = +n.slice(s, x).trim();
          break;
      }
      return "";
    }), i) {
      case "Note":
        var l = lt(a, f >= 0 && o >= 0 ? Ne({ r: f, c: o }) : r[t].ref);
        l.c && (l.c.hidden = c), ++t;
        break;
    }
  });
}
function Mn(e, a, r, t) {
  var n = e["!data"] != null, i;
  a.forEach(function(c) {
    var s = dr(c.ref);
    if (!(s.r < 0 || s.c < 0)) {
      if (n ? (e["!data"][s.r] || (e["!data"][s.r] = []), i = e["!data"][s.r][s.c]) : i = e[c.ref], !i) {
        i = { t: "z" }, n ? e["!data"][s.r][s.c] = i : e[c.ref] = i;
        var f = Ke(e["!ref"] || "BDWGO1000001:A1");
        f.s.r > s.r && (f.s.r = s.r), f.e.r < s.r && (f.e.r = s.r), f.s.c > s.c && (f.s.c = s.c), f.e.c < s.c && (f.e.c = s.c);
        var o = Ce(f);
        e["!ref"] = o;
      }
      i.c || (i.c = []);
      var l = { a: c.author, t: c.t, r: c.r, T: r };
      c.h && (l.h = c.h);
      for (var v = i.c.length - 1; v >= 0; --v) {
        if (!r && i.c[v].T) return;
        r && !i.c[v].T && i.c.splice(v, 1);
      }
      if (r && t) {
        for (v = 0; v < t.length; ++v)
          if (l.a == t[v].id) {
            l.a = t[v].name || l.a;
            break;
          }
      }
      i.c.push(l);
    }
  });
}
function tu(e, a) {
  if (e.match(/<(?:\w+:)?comments *\/>/)) return [];
  var r = [], t = [], n = ir(e, "authors");
  n && n[1] && n[1].split(/<\/\w*:?author>/).forEach(function(c) {
    if (!(c === "" || c.trim() === "")) {
      var s = c.match(/<(?:\w+:)?author[^<>]*>(.*)/);
      s && r.push(s[1]);
    }
  });
  var i = ir(e, "commentList");
  return i && i[1] && i[1].split(/<\/\w*:?comment>/).forEach(function(c) {
    if (!(c === "" || c.trim() === "")) {
      var s = c.match(/<(?:\w+:)?comment[^<>]*>/);
      if (s) {
        var f = le(s[0]), o = { author: f.authorId && r[f.authorId] || "sheetjsghost", ref: f.ref, guid: f.guid }, l = dr(f.ref);
        if (!(a.sheetRows && a.sheetRows <= l.r)) {
          var v = ir(c, "text"), x = !!v && !!v[1] && U0(v[1]) || { r: "", t: "", h: "" };
          o.r = x.r, x.r == "<t></t>" && (x.t = x.h = ""), o.t = (x.t || "").replace(/\r\n/g, `
`).replace(/\r/g, `
`), a.cellHTML && (o.h = x.h), t.push(o);
        }
      }
    }
  }), t;
}
function nu(e, a) {
  var r = [], t = !1, n = {}, i = 0;
  return e.replace(or, function(s, f) {
    var o = le(s);
    switch (Hr(o[0])) {
      case "<?xml":
        break;
      /* 2.6.207 ThreadedComments CT_ThreadedComments */
      case "<ThreadedComments":
        break;
      case "</ThreadedComments>":
        break;
      /* 2.6.205 threadedComment CT_ThreadedComment */
      case "<threadedComment":
        n = { author: o.personId, guid: o.id, ref: o.ref, T: 1 };
        break;
      case "</threadedComment>":
        n.t != null && r.push(n);
        break;
      case "<text>":
      case "<text":
        i = f + s.length;
        break;
      case "</text>":
        n.t = e.slice(i, f).replace(/\r\n/g, `
`).replace(/\r/g, `
`);
        break;
      /* 2.6.206 mentions CT_ThreadedCommentMentions TODO */
      case "<mentions":
      case "<mentions>":
        t = !0;
        break;
      case "</mentions>":
        t = !1;
        break;
      /* 2.6.202 mention CT_Mention TODO */
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
      case "<extLst/>":
        break;
      /* 18.2.7  ext CT_Extension + */
      case "<ext":
        t = !0;
        break;
      case "</ext>":
        t = !1;
        break;
      default:
        if (!t && a.WTF) throw new Error("unrecognized " + o[0] + " in threaded comments");
    }
    return s;
  }), r;
}
function iu(e, a) {
  var r = [], t = !1;
  return e.replace(or, function(i) {
    var c = le(i);
    switch (Hr(c[0])) {
      case "<?xml":
        break;
      /* 2.4.85 personList CT_PersonList */
      case "<personList":
        break;
      case "</personList>":
        break;
      /* 2.6.203 person CT_Person TODO: providers */
      case "<person":
        r.push({ name: c.displayname, id: c.id });
        break;
      case "</person>":
        break;
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
      case "<extLst/>":
        break;
      /* 18.2.7  ext CT_Extension + */
      case "<ext":
        t = !0;
        break;
      case "</ext>":
        t = !1;
        break;
      default:
        if (!t && a.WTF) throw new Error("unrecognized " + c[0] + " in threaded comments");
    }
    return i;
  }), r;
}
function su(e) {
  var a = {};
  a.iauthor = e.read_shift(4);
  var r = Sa(e);
  return a.rfx = r.s, a.ref = Ne(r.s), e.l += 16, a;
}
var cu = vr;
function fu(e, a) {
  var r = [], t = [], n = {}, i = !1;
  return ta(e, function(s, f, o) {
    switch (o) {
      case 632:
        t.push(s);
        break;
      case 635:
        n = s;
        break;
      case 637:
        n.t = s.t, n.h = s.h, n.r = s.r;
        break;
      case 636:
        if (n.author = t[n.iauthor], delete n.iauthor, a.sheetRows && n.rfx && a.sheetRows <= n.rfx.r) break;
        n.t || (n.t = ""), delete n.rfx, r.push(n);
        break;
      case 3072:
        break;
      case 35:
        i = !0;
        break;
      case 36:
        i = !1;
        break;
      case 37:
        break;
      case 38:
        break;
      default:
        if (!f.T) {
          if (!i || a.WTF) throw new Error("Unexpected record 0x" + o.toString(16));
        }
    }
  }), r;
}
var ou = "application/vnd.ms-office.vbaProject";
function lu(e) {
  var a = Oe.utils.cfb_new({ root: "R" });
  return e.FullPaths.forEach(function(r, t) {
    if (!(r.slice(-1) === "/" || !r.match(/_VBA_PROJECT_CUR/))) {
      var n = r.replace(/^[^\/]*/, "R").replace(/\/_VBA_PROJECT_CUR\u0000*/, "");
      Oe.utils.cfb_add(a, n, e.FileIndex[t].content);
    }
  }), Oe.write(a);
}
function uu() {
  return { "!type": "dialog" };
}
function hu() {
  return { "!type": "dialog" };
}
function xu() {
  return { "!type": "macro" };
}
function du() {
  return { "!type": "macro" };
}
var Ta = /* @__PURE__ */ (function() {
  var e = /(^|[^A-Za-z_])R(\[?-?\d+\]|[1-9]\d*|)C(\[?-?\d+\]|[1-9]\d*|)(?![A-Za-z0-9_])/g, a = { r: 0, c: 0 };
  function r(t, n, i, c) {
    var s = !1, f = !1;
    i.length == 0 ? f = !0 : i.charAt(0) == "[" && (f = !0, i = i.slice(1, -1)), c.length == 0 ? s = !0 : c.charAt(0) == "[" && (s = !0, c = c.slice(1, -1));
    var o = i.length > 0 ? parseInt(i, 10) | 0 : 0, l = c.length > 0 ? parseInt(c, 10) | 0 : 0;
    return s ? l += a.c : --l, f ? o += a.r : --o, n + (s ? "" : "$") + Pe(l) + (f ? "" : "$") + Me(o);
  }
  return function(n, i) {
    return a = i, n.replace(e, r);
  };
})(), W0 = /(^|[^._A-Z0-9])(\$?)([A-Z]{1,2}|[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D])(\$?)(\d{1,7})(?![_.\(A-Za-z0-9])/g;
try {
  W0 = /(^|[^._A-Z0-9])([$]?)([A-Z]{1,2}|[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D])([$]?)(10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5})(?![_.\(A-Za-z0-9])/g;
} catch {
}
var vu = /* @__PURE__ */ (function() {
  return function(a, r) {
    return a.replace(W0, function(t, n, i, c, s, f) {
      var o = b0(c) - (i ? 0 : r.c), l = P0(f) - (s ? 0 : r.r), v = s == "$" ? l + 1 : l == 0 ? "" : "[" + l + "]", x = i == "$" ? o + 1 : o == 0 ? "" : "[" + o + "]";
      return n + "R" + v + "C" + x;
    });
  };
})();
function hs(e, a) {
  return e.replace(W0, function(r, t, n, i, c, s) {
    return t + (n == "$" ? n + i : Pe(b0(i) + a.c)) + (c == "$" ? c + s : Me(P0(s) + a.r));
  });
}
function Un(e, a, r) {
  var t = Aa(a), n = t.s, i = dr(r), c = { r: i.r - n.r, c: i.c - n.c };
  return hs(e, c);
}
function pu(e) {
  return e.length != 1;
}
function Hn(e) {
  return e.replace(/_xlfn\./g, "");
}
function Je(e) {
  e.l += 1;
}
function la(e, a) {
  var r = e.read_shift(2);
  return [r & 16383, r >> 14 & 1, r >> 15 & 1];
}
function xs(e, a, r) {
  var t = 2;
  if (r) {
    if (r.biff >= 2 && r.biff <= 5) return ds(e);
    r.biff == 12 && (t = 4);
  }
  var n = e.read_shift(t), i = e.read_shift(t), c = la(e), s = la(e);
  return { s: { r: n, c: c[0], cRel: c[1], rRel: c[2] }, e: { r: i, c: s[0], cRel: s[1], rRel: s[2] } };
}
function ds(e) {
  var a = la(e), r = la(e), t = e.read_shift(1), n = e.read_shift(1);
  return { s: { r: a[0], c: t, cRel: a[1], rRel: a[2] }, e: { r: r[0], c: n, cRel: r[1], rRel: r[2] } };
}
function gu(e, a, r) {
  if (r.biff < 8) return ds(e);
  var t = e.read_shift(r.biff == 12 ? 4 : 2), n = e.read_shift(r.biff == 12 ? 4 : 2), i = la(e), c = la(e);
  return { s: { r: t, c: i[0], cRel: i[1], rRel: i[2] }, e: { r: n, c: c[0], cRel: c[1], rRel: c[2] } };
}
function vs(e, a, r) {
  if (r && r.biff >= 2 && r.biff <= 5) return mu(e);
  var t = e.read_shift(r && r.biff == 12 ? 4 : 2), n = la(e);
  return { r: t, c: n[0], cRel: n[1], rRel: n[2] };
}
function mu(e) {
  var a = la(e), r = e.read_shift(1);
  return { r: a[0], c: r, cRel: a[1], rRel: a[2] };
}
function _u(e) {
  var a = e.read_shift(2), r = e.read_shift(2);
  return { r: a, c: r & 255, fQuoted: !!(r & 16384), cRel: r >> 15, rRel: r >> 15 };
}
function Tu(e, a, r) {
  var t = r && r.biff ? r.biff : 8;
  if (t >= 2 && t <= 5) return Eu(e);
  var n = e.read_shift(t >= 12 ? 4 : 2), i = e.read_shift(2), c = (i & 16384) >> 14, s = (i & 32768) >> 15;
  if (i &= 16383, s == 1) for (; n > 524287; ) n -= 1048576;
  if (c == 1) for (; i > 8191; ) i = i - 16384;
  return { r: n, c: i, cRel: c, rRel: s };
}
function Eu(e) {
  var a = e.read_shift(2), r = e.read_shift(1), t = (a & 32768) >> 15, n = (a & 16384) >> 14;
  return a &= 16383, t == 1 && a >= 8192 && (a = a - 16384), n == 1 && r >= 128 && (r = r - 256), { r: a, c: r, cRel: n, rRel: t };
}
function ku(e, a, r) {
  var t = (e[e.l++] & 96) >> 5, n = xs(e, r.biff >= 2 && r.biff <= 5 ? 6 : 8, r);
  return [t, n];
}
function wu(e, a, r) {
  var t = (e[e.l++] & 96) >> 5, n = e.read_shift(2, "i"), i = 8;
  if (r) switch (r.biff) {
    case 5:
      e.l += 12, i = 6;
      break;
    case 12:
      i = 12;
      break;
  }
  var c = xs(e, i, r);
  return [t, n, c];
}
function Fu(e, a, r) {
  var t = (e[e.l++] & 96) >> 5;
  return e.l += r && r.biff > 8 ? 12 : r.biff < 8 ? 6 : 8, [t];
}
function Au(e, a, r) {
  var t = (e[e.l++] & 96) >> 5, n = e.read_shift(2), i = 8;
  if (r) switch (r.biff) {
    case 5:
      e.l += 12, i = 6;
      break;
    case 12:
      i = 12;
      break;
  }
  return e.l += i, [t, n];
}
function yu(e, a, r) {
  var t = (e[e.l++] & 96) >> 5, n = gu(e, a - 1, r);
  return [t, n];
}
function Su(e, a, r) {
  var t = (e[e.l++] & 96) >> 5;
  return e.l += r.biff == 2 ? 6 : r.biff == 12 ? 14 : 7, [t];
}
function Wn(e) {
  var a = e[e.l + 1] & 1, r = 1;
  return e.l += 4, [a, r];
}
function Cu(e, a, r) {
  e.l += 2;
  for (var t = e.read_shift(r && r.biff == 2 ? 1 : 2), n = [], i = 0; i <= t; ++i) n.push(e.read_shift(r && r.biff == 2 ? 1 : 2));
  return n;
}
function Du(e, a, r) {
  var t = e[e.l + 1] & 255 ? 1 : 0;
  return e.l += 2, [t, e.read_shift(r && r.biff == 2 ? 1 : 2)];
}
function Iu(e, a, r) {
  var t = e[e.l + 1] & 255 ? 1 : 0;
  return e.l += 2, [t, e.read_shift(r && r.biff == 2 ? 1 : 2)];
}
function Ou(e) {
  var a = e[e.l + 1] & 255 ? 1 : 0;
  return e.l += 2, [a, e.read_shift(2)];
}
function Ru(e, a, r) {
  var t = e[e.l + 1] & 255 ? 1 : 0;
  return e.l += r && r.biff == 2 ? 3 : 4, [t];
}
function ps(e) {
  var a = e.read_shift(1), r = e.read_shift(1);
  return [a, r];
}
function Nu(e) {
  return e.read_shift(2), ps(e);
}
function Pu(e) {
  return e.read_shift(2), ps(e);
}
function bu(e, a, r) {
  var t = (e[e.l] & 96) >> 5;
  e.l += 1;
  var n = vs(e, 0, r);
  return [t, n];
}
function Lu(e, a, r) {
  var t = (e[e.l] & 96) >> 5;
  e.l += 1;
  var n = Tu(e, 0, r);
  return [t, n];
}
function Bu(e, a, r) {
  var t = (e[e.l] & 96) >> 5;
  e.l += 1;
  var n = e.read_shift(2);
  r && r.biff == 5 && (e.l += 12);
  var i = vs(e, 0, r);
  return [t, n, i];
}
function Mu(e, a, r) {
  var t = (e[e.l] & 96) >> 5;
  e.l += 1;
  var n = e.read_shift(r && r.biff <= 3 ? 1 : 2);
  return [Uh[n], _s[n], t];
}
function Uu(e, a, r) {
  var t = e[e.l++], n = e.read_shift(1), i = r && r.biff <= 3 ? [t == 88 ? -1 : 0, e.read_shift(1)] : Hu(e);
  return [n, (i[0] === 0 ? _s : Mh)[i[1]]];
}
function Hu(e) {
  return [e[e.l + 1] >> 7, e.read_shift(2) & 32767];
}
function Wu(e, a, r) {
  e.l += r && r.biff == 2 ? 3 : 4;
}
function Vu(e, a, r) {
  if (e.l++, r && r.biff == 12) return [e.read_shift(4, "i"), 0];
  var t = e.read_shift(2), n = e.read_shift(r && r.biff == 2 ? 1 : 2);
  return [t, n];
}
function Gu(e) {
  return e.l++, Ar[e.read_shift(1)];
}
function $u(e) {
  return e.l++, e.read_shift(2);
}
function Xu(e) {
  return e.l++, e.read_shift(1) !== 0;
}
function zu(e) {
  return e.l++, xr(e);
}
function Ku(e, a, r) {
  return e.l++, Ba(e, a - 1, r);
}
function Yu(e, a) {
  var r = [e.read_shift(1)];
  if (a == 12) switch (r[0]) {
    case 2:
      r[0] = 4;
      break;
    /* SerBool */
    case 4:
      r[0] = 16;
      break;
    /* SerErr */
    case 0:
      r[0] = 1;
      break;
    /* SerNum */
    case 1:
      r[0] = 2;
      break;
  }
  switch (r[0]) {
    case 4:
      r[1] = ze(e, 1) ? "TRUE" : "FALSE", a != 12 && (e.l += 7);
      break;
    case 37:
    /* appears to be an alias */
    case 16:
      r[1] = Ar[e[e.l]], e.l += a == 12 ? 4 : 8;
      break;
    case 0:
      e.l += 8;
      break;
    case 1:
      r[1] = xr(e);
      break;
    case 2:
      r[1] = Ca(e, 0, { biff: a > 0 && a < 8 ? 2 : a });
      break;
    default:
      throw new Error("Bad SerAr: " + r[0]);
  }
  return r;
}
function ju(e, a, r) {
  for (var t = e.read_shift(r.biff == 12 ? 4 : 2), n = [], i = 0; i != t; ++i) n.push((r.biff == 12 ? Sa : qt)(e));
  return n;
}
function Ju(e, a, r) {
  var t = 0, n = 0;
  r.biff == 12 ? (t = e.read_shift(4), n = e.read_shift(4)) : (n = 1 + e.read_shift(1), t = 1 + e.read_shift(2)), r.biff >= 2 && r.biff < 8 && (--t, --n == 0 && (n = 256));
  for (var i = 0, c = []; i != t && (c[i] = []); ++i)
    for (var s = 0; s != n; ++s) c[i][s] = Yu(e, r.biff);
  return c;
}
function Zu(e, a, r) {
  var t = e.read_shift(1) >>> 5 & 3, n = !r || r.biff >= 8 ? 4 : 2, i = e.read_shift(n);
  switch (r.biff) {
    case 2:
      e.l += 5;
      break;
    case 3:
    case 4:
      e.l += 8;
      break;
    case 5:
      e.l += 12;
      break;
  }
  return [t, 0, i];
}
function qu(e, a, r) {
  if (r.biff == 5) return Qu(e);
  var t = e.read_shift(1) >>> 5 & 3, n = e.read_shift(2), i = e.read_shift(4);
  return [t, n, i];
}
function Qu(e) {
  var a = e.read_shift(1) >>> 5 & 3, r = e.read_shift(2, "i");
  e.l += 8;
  var t = e.read_shift(2);
  return e.l += 12, [a, r, t];
}
function eh(e, a, r) {
  var t = e.read_shift(1) >>> 5 & 3;
  e.l += r && r.biff == 2 ? 3 : 4;
  var n = e.read_shift(r && r.biff == 2 ? 1 : 2);
  return [t, n];
}
function rh(e, a, r) {
  var t = e.read_shift(1) >>> 5 & 3, n = e.read_shift(r && r.biff == 2 ? 1 : 2);
  return [t, n];
}
function ah(e, a, r) {
  var t = e.read_shift(1) >>> 5 & 3;
  return e.l += 4, r.biff < 8 && e.l--, r.biff == 12 && (e.l += 2), [t];
}
function th(e, a, r) {
  var t = (e[e.l++] & 96) >> 5, n = e.read_shift(2), i = 4;
  if (r) switch (r.biff) {
    case 5:
      i = 15;
      break;
    case 12:
      i = 6;
      break;
  }
  return e.l += i, [t, n];
}
var nh = pr, ih = pr, sh = pr;
function dt(e, a, r) {
  return e.l += 2, [_u(e)];
}
function V0(e) {
  return e.l += 6, [];
}
var ch = dt, fh = V0, oh = V0, lh = dt;
function gs(e) {
  return e.l += 2, [Xe(e), e.read_shift(2) & 1];
}
var uh = dt, hh = gs, xh = V0, dh = dt, vh = dt, ph = [
  "Data",
  "All",
  "Headers",
  "??",
  "?Data2",
  "??",
  "?DataHeaders",
  "??",
  "Totals",
  "??",
  "??",
  "??",
  "?DataTotals",
  "??",
  "??",
  "??",
  "?Current"
];
function gh(e) {
  e.l += 2;
  var a = e.read_shift(2), r = e.read_shift(2), t = e.read_shift(4), n = e.read_shift(2), i = e.read_shift(2), c = ph[r >> 2 & 31];
  return { ixti: a, coltype: r & 3, rt: c, idx: t, c: n, C: i };
}
function mh(e) {
  return e.l += 2, [e.read_shift(4)];
}
function _h(e, a, r) {
  return e.l += 5, e.l += 2, e.l += r.biff == 2 ? 1 : 4, ["PTGSHEET"];
}
function Th(e, a, r) {
  return e.l += r.biff == 2 ? 4 : 5, ["PTGENDSHEET"];
}
function Eh(e) {
  var a = e.read_shift(1) >>> 5 & 3, r = e.read_shift(2);
  return [a, r];
}
function kh(e) {
  var a = e.read_shift(1) >>> 5 & 3, r = e.read_shift(2);
  return [a, r];
}
function wh(e) {
  return e.l += 4, [0, 0];
}
var Vn = {
  1: { n: "PtgExp", f: Vu },
  2: { n: "PtgTbl", f: sh },
  3: { n: "PtgAdd", f: Je },
  4: { n: "PtgSub", f: Je },
  5: { n: "PtgMul", f: Je },
  6: { n: "PtgDiv", f: Je },
  7: { n: "PtgPower", f: Je },
  8: { n: "PtgConcat", f: Je },
  9: { n: "PtgLt", f: Je },
  10: { n: "PtgLe", f: Je },
  11: { n: "PtgEq", f: Je },
  12: { n: "PtgGe", f: Je },
  13: { n: "PtgGt", f: Je },
  14: { n: "PtgNe", f: Je },
  15: { n: "PtgIsect", f: Je },
  16: { n: "PtgUnion", f: Je },
  17: { n: "PtgRange", f: Je },
  18: { n: "PtgUplus", f: Je },
  19: { n: "PtgUminus", f: Je },
  20: { n: "PtgPercent", f: Je },
  21: { n: "PtgParen", f: Je },
  22: { n: "PtgMissArg", f: Je },
  23: { n: "PtgStr", f: Ku },
  26: { n: "PtgSheet", f: _h },
  27: { n: "PtgEndSheet", f: Th },
  28: { n: "PtgErr", f: Gu },
  29: { n: "PtgBool", f: Xu },
  30: { n: "PtgInt", f: $u },
  31: { n: "PtgNum", f: zu },
  32: { n: "PtgArray", f: Su },
  33: { n: "PtgFunc", f: Mu },
  34: { n: "PtgFuncVar", f: Uu },
  35: { n: "PtgName", f: Zu },
  36: { n: "PtgRef", f: bu },
  37: { n: "PtgArea", f: ku },
  38: { n: "PtgMemArea", f: eh },
  39: { n: "PtgMemErr", f: nh },
  40: { n: "PtgMemNoMem", f: ih },
  41: { n: "PtgMemFunc", f: rh },
  42: { n: "PtgRefErr", f: ah },
  43: { n: "PtgAreaErr", f: Fu },
  44: { n: "PtgRefN", f: Lu },
  45: { n: "PtgAreaN", f: yu },
  46: { n: "PtgMemAreaN", f: Eh },
  47: { n: "PtgMemNoMemN", f: kh },
  57: { n: "PtgNameX", f: qu },
  58: { n: "PtgRef3d", f: Bu },
  59: { n: "PtgArea3d", f: wu },
  60: { n: "PtgRefErr3d", f: th },
  61: { n: "PtgAreaErr3d", f: Au },
  255: {}
}, Fh = {
  64: 32,
  96: 32,
  65: 33,
  97: 33,
  66: 34,
  98: 34,
  67: 35,
  99: 35,
  68: 36,
  100: 36,
  69: 37,
  101: 37,
  70: 38,
  102: 38,
  71: 39,
  103: 39,
  72: 40,
  104: 40,
  73: 41,
  105: 41,
  74: 42,
  106: 42,
  75: 43,
  107: 43,
  76: 44,
  108: 44,
  77: 45,
  109: 45,
  78: 46,
  110: 46,
  79: 47,
  111: 47,
  88: 34,
  120: 34,
  89: 57,
  121: 57,
  90: 58,
  122: 58,
  91: 59,
  123: 59,
  92: 60,
  124: 60,
  93: 61,
  125: 61
}, Ah = {
  1: { n: "PtgElfLel", f: gs },
  2: { n: "PtgElfRw", f: dh },
  3: { n: "PtgElfCol", f: ch },
  6: { n: "PtgElfRwV", f: vh },
  7: { n: "PtgElfColV", f: lh },
  10: { n: "PtgElfRadical", f: uh },
  11: { n: "PtgElfRadicalS", f: xh },
  13: { n: "PtgElfColS", f: fh },
  15: { n: "PtgElfColSV", f: oh },
  16: { n: "PtgElfRadicalLel", f: hh },
  25: { n: "PtgList", f: gh },
  29: { n: "PtgSxName", f: mh },
  255: {}
}, yh = {
  0: { n: "PtgAttrNoop", f: wh },
  1: { n: "PtgAttrSemi", f: Ru },
  2: { n: "PtgAttrIf", f: Iu },
  4: { n: "PtgAttrChoose", f: Cu },
  8: { n: "PtgAttrGoto", f: Du },
  16: { n: "PtgAttrSum", f: Wu },
  32: { n: "PtgAttrBaxcel", f: Wn },
  33: { n: "PtgAttrBaxcel", f: Wn },
  64: { n: "PtgAttrSpace", f: Nu },
  65: { n: "PtgAttrSpaceSemi", f: Pu },
  128: { n: "PtgAttrIfError", f: Ou },
  255: {}
};
function vt(e, a, r, t) {
  if (t.biff < 8) return pr(e, a);
  for (var n = e.l + a, i = [], c = 0; c !== r.length; ++c)
    switch (r[c][0]) {
      case "PtgArray":
        r[c][1] = Ju(e, 0, t), i.push(r[c][1]);
        break;
      case "PtgMemArea":
        r[c][2] = ju(e, r[c][1], t), i.push(r[c][2]);
        break;
      case "PtgExp":
        t && t.biff == 12 && (r[c][1][1] = e.read_shift(4), i.push(r[c][1]));
        break;
      case "PtgList":
      /* TODO: PtgList -> PtgExtraList */
      case "PtgElfRadicalS":
      /* TODO: PtgElfRadicalS -> PtgExtraElf */
      case "PtgElfColS":
      /* TODO: PtgElfColS -> PtgExtraElf */
      case "PtgElfColSV":
        throw "Unsupported " + r[c][0];
    }
  return a = n - e.l, a !== 0 && i.push(pr(e, a)), i;
}
function pt(e, a, r) {
  for (var t = e.l + a, n, i, c = []; t != e.l; )
    a = t - e.l, i = e[e.l], n = Vn[i] || Vn[Fh[i]], (i === 24 || i === 25) && (n = (i === 24 ? Ah : yh)[e[e.l + 1]]), !n || !n.f ? pr(e, a) : c.push([n.n, n.f(e, a, r)]);
  return c;
}
function Sh(e) {
  for (var a = [], r = 0; r < e.length; ++r) {
    for (var t = e[r], n = [], i = 0; i < t.length; ++i) {
      var c = t[i];
      if (c) switch (c[0]) {
        // TODO: handle embedded quotes
        case 2:
          n.push('"' + c[1].replace(/"/g, '""') + '"');
          break;
        default:
          n.push(c[1]);
      }
      else n.push("");
    }
    a.push(n.join(","));
  }
  return a.join(";");
}
var Ch = {
  PtgAdd: "+",
  PtgConcat: "&",
  PtgDiv: "/",
  PtgEq: "=",
  PtgGe: ">=",
  PtgGt: ">",
  PtgLe: "<=",
  PtgLt: "<",
  PtgMul: "*",
  PtgNe: "<>",
  PtgPower: "^",
  PtgSub: "-"
};
function Dh(e, a) {
  var r = e.lastIndexOf("!"), t = a.lastIndexOf("!");
  return r == -1 && t == -1 ? e + ":" + a : r > 0 && t > 0 && e.slice(0, r).toLowerCase() == a.slice(0, t).toLowerCase() ? e + ":" + a.slice(t + 1) : (console.error("Cannot hydrate range", e, a), e + ":" + a);
}
function ms(e, a, r) {
  if (!e) return "SH33TJSERR0";
  if (r.biff > 8 && (!e.XTI || !e.XTI[a])) return e.SheetNames[a];
  if (!e.XTI) return "SH33TJSERR6";
  var t = e.XTI[a];
  if (r.biff < 8)
    return a > 1e4 && (a -= 65536), a < 0 && (a = -a), a == 0 ? "" : e.XTI[a - 1];
  if (!t) return "SH33TJSERR1";
  var n = "";
  if (r.biff > 8) switch (e[t[0]][0]) {
    case 357:
      return n = t[1] == -1 ? "#REF" : e.SheetNames[t[1]], t[1] == t[2] ? n : n + ":" + e.SheetNames[t[2]];
    case 358:
      return r.SID != null ? e.SheetNames[r.SID] : "SH33TJSSAME" + e[t[0]][0];
    case 355:
    /* 'BrtSupBookSrc' */
    /* falls through */
    default:
      return "SH33TJSSRC" + e[t[0]][0];
  }
  switch (e[t[0]][0][0]) {
    case 1025:
      return n = t[1] == -1 ? "#REF" : e.SheetNames[t[1]] || "SH33TJSERR3", t[1] == t[2] ? n : n + ":" + e.SheetNames[t[2]];
    case 14849:
      return e[t[0]].slice(1).map(function(i) {
        return i.Name;
      }).join(";;");
    //return "SH33TJSERR8";
    default:
      return e[t[0]][0][3] ? (n = t[1] == -1 ? "#REF" : e[t[0]][0][3][t[1]] || "SH33TJSERR4", t[1] == t[2] ? n : n + ":" + e[t[0]][0][3][t[2]]) : "SH33TJSERR2";
  }
}
function Gn(e, a, r) {
  var t = ms(e, a, r);
  return t == "#REF" ? t : Sf(t, r);
}
function hr(e, a, r, t, n) {
  var i = n && n.biff || 8, c = (
    /*range != null ? range :*/
    { s: { c: 0, r: 0 } }
  ), s = [], f, o, l, v = 0, x = 0, u, p = "";
  if (!e[0] || !e[0][0]) return "";
  for (var _ = -1, d = "", h = 0, E = e[0].length; h < E; ++h) {
    var g = e[0][h];
    switch (g[0]) {
      case "PtgUminus":
        s.push("-" + s.pop());
        break;
      case "PtgUplus":
        s.push("+" + s.pop());
        break;
      case "PtgPercent":
        s.push(s.pop() + "%");
        break;
      case "PtgAdd":
      /* [MS-XLS] 2.5.198.26 */
      case "PtgConcat":
      /* [MS-XLS] 2.5.198.43 */
      case "PtgDiv":
      /* [MS-XLS] 2.5.198.45 */
      case "PtgEq":
      /* [MS-XLS] 2.5.198.56 */
      case "PtgGe":
      /* [MS-XLS] 2.5.198.64 */
      case "PtgGt":
      /* [MS-XLS] 2.5.198.65 */
      case "PtgLe":
      /* [MS-XLS] 2.5.198.68 */
      case "PtgLt":
      /* [MS-XLS] 2.5.198.69 */
      case "PtgMul":
      /* [MS-XLS] 2.5.198.75 */
      case "PtgNe":
      /* [MS-XLS] 2.5.198.78 */
      case "PtgPower":
      /* [MS-XLS] 2.5.198.82 */
      case "PtgSub":
        if (f = s.pop(), o = s.pop(), _ >= 0) {
          switch (e[0][_][1][0]) {
            case 0:
              d = Ie(" ", e[0][_][1][1]);
              break;
            case 1:
              d = Ie("\r", e[0][_][1][1]);
              break;
            default:
              if (d = "", n.WTF) throw new Error("Unexpected PtgAttrSpaceType " + e[0][_][1][0]);
          }
          o = o + d, _ = -1;
        }
        s.push(o + Ch[g[0]] + f);
        break;
      case "PtgIsect":
        f = s.pop(), o = s.pop(), s.push(o + " " + f);
        break;
      case "PtgUnion":
        f = s.pop(), o = s.pop(), s.push(o + "," + f);
        break;
      case "PtgRange":
        f = s.pop(), o = s.pop(), s.push(Dh(o, f));
        break;
      case "PtgAttrChoose":
        break;
      case "PtgAttrGoto":
        break;
      case "PtgAttrIf":
        break;
      case "PtgAttrIfError":
        break;
      case "PtgRef":
        l = Ya(g[1][1], c, n), s.push(ja(l, i));
        break;
      case "PtgRefN":
        l = r ? Ya(g[1][1], r, n) : g[1][1], s.push(ja(l, i));
        break;
      case "PtgRef3d":
        v = /*::Number(*/
        g[1][1], l = Ya(g[1][2], c, n), p = Gn(t, v, n), s.push(p + "!" + ja(l, i));
        break;
      case "PtgFunc":
      /* [MS-XLS] 2.5.198.62 */
      case "PtgFuncVar":
        var C = g[1][0], P = g[1][1];
        C || (C = 0), C &= 127;
        var M = C == 0 ? [] : s.slice(-C);
        s.length -= C, P === "User" && (P = M.shift()), s.push(P + "(" + M.join(",") + ")");
        break;
      case "PtgBool":
        s.push(g[1] ? "TRUE" : "FALSE");
        break;
      case "PtgInt":
        s.push(
          /*::String(*/
          g[1]
          /*::)*/
        );
        break;
      case "PtgNum":
        s.push(String(g[1]));
        break;
      case "PtgStr":
        s.push('"' + g[1].replace(/"/g, '""') + '"');
        break;
      case "PtgErr":
        s.push(
          /*::String(*/
          g[1]
          /*::)*/
        );
        break;
      case "PtgAreaN":
        u = En(g[1][1], r ? { s: r } : c, n), s.push(c0(u, n));
        break;
      case "PtgArea":
        u = En(g[1][1], c, n), s.push(c0(u, n));
        break;
      case "PtgArea3d":
        v = /*::Number(*/
        g[1][1], u = g[1][2], p = Gn(t, v, n), s.push(p + "!" + c0(u, n));
        break;
      case "PtgAttrSum":
        s.push("SUM(" + s.pop() + ")");
        break;
      case "PtgAttrBaxcel":
      /* [MS-XLS] 2.5.198.33 */
      case "PtgAttrSemi":
        break;
      case "PtgName":
        x = g[1][2];
        var I = (t.names || [])[x - 1] || (t[0] || [])[x], N = I ? I.Name : "SH33TJSNAME" + String(x);
        N && N.slice(0, 6) == "_xlfn." && !n.xlfn && (N = N.slice(6)), s.push(N);
        break;
      case "PtgNameX":
        var O = g[1][1];
        x = g[1][2];
        var B;
        if (n.biff <= 5)
          O < 0 && (O = -O), t[O] && (B = t[O][x]);
        else {
          var b = "";
          if (((t[O] || [])[0] || [])[0] == 14849 || (((t[O] || [])[0] || [])[0] == 1025 ? t[O][x] && t[O][x].itab > 0 && (b = t.SheetNames[t[O][x].itab - 1] + "!") : b = t.SheetNames[x - 1] + "!"), t[O] && t[O][x]) b += t[O][x].Name;
          else if (t[0] && t[0][x]) b += t[0][x].Name;
          else {
            var G = (ms(t, O, n) || "").split(";;");
            G[x - 1] ? b = G[x - 1] : b += "SH33TJSERRX";
          }
          s.push(b);
          break;
        }
        B || (B = { Name: "SH33TJSERRY" }), s.push(B.Name);
        break;
      case "PtgParen":
        var z = "(", ce = ")";
        if (_ >= 0) {
          switch (d = "", e[0][_][1][0]) {
            // $FlowIgnore
            case 2:
              z = Ie(" ", e[0][_][1][1]) + z;
              break;
            // $FlowIgnore
            case 3:
              z = Ie("\r", e[0][_][1][1]) + z;
              break;
            // $FlowIgnore
            case 4:
              ce = Ie(" ", e[0][_][1][1]) + ce;
              break;
            // $FlowIgnore
            case 5:
              ce = Ie("\r", e[0][_][1][1]) + ce;
              break;
            default:
              if (n.WTF) throw new Error("Unexpected PtgAttrSpaceType " + e[0][_][1][0]);
          }
          _ = -1;
        }
        s.push(z + s.pop() + ce);
        break;
      case "PtgRefErr":
        s.push("#REF!");
        break;
      case "PtgRefErr3d":
        s.push("#REF!");
        break;
      case "PtgExp":
        l = { c: g[1][1], r: g[1][0] };
        var j = { c: r.c, r: r.r };
        if (t.sharedf[Ne(l)]) {
          var he = t.sharedf[Ne(l)];
          s.push(hr(he, c, j, t, n));
        } else {
          var J = !1;
          for (f = 0; f != t.arrayf.length; ++f)
            if (o = t.arrayf[f], !(l.c < o[0].s.c || l.c > o[0].e.c) && !(l.r < o[0].s.r || l.r > o[0].e.r)) {
              s.push(hr(o[1], c, j, t, n)), J = !0;
              break;
            }
          J || s.push(
            /*::String(*/
            g[1]
            /*::)*/
          );
        }
        break;
      case "PtgArray":
        s.push("{" + Sh(
          /*::(*/
          g[1]
          /*:: :any)*/
        ) + "}");
        break;
      case "PtgMemArea":
        break;
      case "PtgAttrSpace":
      /* [MS-XLS] 2.5.198.38 */
      case "PtgAttrSpaceSemi":
        _ = h;
        break;
      case "PtgTbl":
        break;
      case "PtgMemErr":
        break;
      case "PtgMissArg":
        s.push("");
        break;
      case "PtgAreaErr":
        s.push("#REF!");
        break;
      case "PtgAreaErr3d":
        s.push("#REF!");
        break;
      case "PtgList":
        s.push("Table" + g[1].idx + "[#" + g[1].rt + "]");
        break;
      case "PtgMemAreaN":
      case "PtgMemNoMemN":
      case "PtgAttrNoop":
      case "PtgSheet":
      case "PtgEndSheet":
        break;
      case "PtgMemFunc":
        break;
      case "PtgMemNoMem":
        break;
      case "PtgElfCol":
      /* [MS-XLS] 2.5.198.46 */
      case "PtgElfColS":
      /* [MS-XLS] 2.5.198.47 */
      case "PtgElfColSV":
      /* [MS-XLS] 2.5.198.48 */
      case "PtgElfColV":
      /* [MS-XLS] 2.5.198.49 */
      case "PtgElfLel":
      /* [MS-XLS] 2.5.198.50 */
      case "PtgElfRadical":
      /* [MS-XLS] 2.5.198.51 */
      case "PtgElfRadicalLel":
      /* [MS-XLS] 2.5.198.52 */
      case "PtgElfRadicalS":
      /* [MS-XLS] 2.5.198.53 */
      case "PtgElfRw":
      /* [MS-XLS] 2.5.198.54 */
      case "PtgElfRwV":
        throw new Error("Unsupported ELFs");
      case "PtgSxName":
        throw new Error("Unrecognized Formula Token: " + String(g));
      default:
        throw new Error("Unrecognized Formula Token: " + String(g));
    }
    var ne = ["PtgAttrSpace", "PtgAttrSpaceSemi", "PtgAttrGoto"];
    if (n.biff != 3 && _ >= 0 && ne.indexOf(e[0][h][0]) == -1) {
      g = e[0][_];
      var pe = !0;
      switch (g[1][0]) {
        /* note: some bad XLSB files omit the PtgParen */
        case 4:
          pe = !1;
        /* falls through */
        case 0:
          d = Ie(" ", g[1][1]);
          break;
        case 5:
          pe = !1;
        /* falls through */
        case 1:
          d = Ie("\r", g[1][1]);
          break;
        default:
          if (d = "", n.WTF) throw new Error("Unexpected PtgAttrSpaceType " + g[1][0]);
      }
      s.push((pe ? d : "") + s.pop() + (pe ? "" : d)), _ = -1;
    }
  }
  if (s.length > 1 && n.WTF) throw new Error("bad formula stack");
  return s[0] == "TRUE" ? !0 : s[0] == "FALSE" ? !1 : s[0];
}
function Ih(e, a, r) {
  var t = e.l + a, n = r.biff == 2 ? 1 : 2, i, c = e.read_shift(n);
  if (c == 65535) return [[], pr(e, a - 2)];
  var s = pt(e, c, r);
  return a !== c + n && (i = vt(e, a - c - n, s, r)), e.l = t, [s, i];
}
function Oh(e, a, r) {
  var t = e.l + a, n = r.biff == 2 ? 1 : 2, i, c = e.read_shift(n);
  if (c == 65535) return [[], pr(e, a - 2)];
  var s = pt(e, c, r);
  return a !== c + n && (i = vt(e, a - c - n, s, r)), e.l = t, [s, i];
}
function Rh(e, a, r, t) {
  var n = e.l + a, i = pt(e, t, r), c;
  return n !== e.l && (c = vt(e, n - e.l, i, r)), [i, c];
}
function Nh(e, a, r) {
  var t = e.l + a, n, i = e.read_shift(2), c = pt(e, i, r);
  return i == 65535 ? [[], pr(e, a - 2)] : (a !== i + 2 && (n = vt(e, t - i - 2, c, r)), [c, n]);
}
function Ph(e) {
  var a;
  if (Qr(e, e.l + 6) !== 65535) return [xr(e), "n"];
  switch (e[e.l]) {
    case 0:
      return e.l += 8, ["String", "s"];
    case 1:
      return a = e[e.l + 2] === 1, e.l += 8, [a, "b"];
    case 2:
      return a = e[e.l + 2], e.l += 8, [a, "e"];
    case 3:
      return e.l += 8, ["", "s"];
  }
  return [];
}
function l0(e, a, r) {
  var t = e.l + a, n = zr(e, 6, r), i = Ph(e), c = e.read_shift(1);
  r.biff != 2 && (e.read_shift(1), r.biff >= 5 && e.read_shift(4));
  var s = Oh(e, t - e.l, r);
  return { cell: n, val: i[0], formula: s, shared: c >> 3 & 1, tt: i[1] };
}
function Qt(e, a, r) {
  var t = e.read_shift(4), n = pt(e, t, r), i = e.read_shift(4), c = i > 0 ? vt(e, i, n, r) : null;
  return [n, c];
}
var bh = Qt, e0 = Qt, Lh = Qt, Bh = Qt, Mh = {
  0: "BEEP",
  1: "OPEN",
  2: "OPEN.LINKS",
  3: "CLOSE.ALL",
  4: "SAVE",
  5: "SAVE.AS",
  6: "FILE.DELETE",
  7: "PAGE.SETUP",
  8: "PRINT",
  9: "PRINTER.SETUP",
  10: "QUIT",
  11: "NEW.WINDOW",
  12: "ARRANGE.ALL",
  13: "WINDOW.SIZE",
  14: "WINDOW.MOVE",
  15: "FULL",
  16: "CLOSE",
  17: "RUN",
  22: "SET.PRINT.AREA",
  23: "SET.PRINT.TITLES",
  24: "SET.PAGE.BREAK",
  25: "REMOVE.PAGE.BREAK",
  26: "FONT",
  27: "DISPLAY",
  28: "PROTECT.DOCUMENT",
  29: "PRECISION",
  30: "A1.R1C1",
  31: "CALCULATE.NOW",
  32: "CALCULATION",
  34: "DATA.FIND",
  35: "EXTRACT",
  36: "DATA.DELETE",
  37: "SET.DATABASE",
  38: "SET.CRITERIA",
  39: "SORT",
  40: "DATA.SERIES",
  41: "TABLE",
  42: "FORMAT.NUMBER",
  43: "ALIGNMENT",
  44: "STYLE",
  45: "BORDER",
  46: "CELL.PROTECTION",
  47: "COLUMN.WIDTH",
  48: "UNDO",
  49: "CUT",
  50: "COPY",
  51: "PASTE",
  52: "CLEAR",
  53: "PASTE.SPECIAL",
  54: "EDIT.DELETE",
  55: "INSERT",
  56: "FILL.RIGHT",
  57: "FILL.DOWN",
  61: "DEFINE.NAME",
  62: "CREATE.NAMES",
  63: "FORMULA.GOTO",
  64: "FORMULA.FIND",
  65: "SELECT.LAST.CELL",
  66: "SHOW.ACTIVE.CELL",
  67: "GALLERY.AREA",
  68: "GALLERY.BAR",
  69: "GALLERY.COLUMN",
  70: "GALLERY.LINE",
  71: "GALLERY.PIE",
  72: "GALLERY.SCATTER",
  73: "COMBINATION",
  74: "PREFERRED",
  75: "ADD.OVERLAY",
  76: "GRIDLINES",
  77: "SET.PREFERRED",
  78: "AXES",
  79: "LEGEND",
  80: "ATTACH.TEXT",
  81: "ADD.ARROW",
  82: "SELECT.CHART",
  83: "SELECT.PLOT.AREA",
  84: "PATTERNS",
  85: "MAIN.CHART",
  86: "OVERLAY",
  87: "SCALE",
  88: "FORMAT.LEGEND",
  89: "FORMAT.TEXT",
  90: "EDIT.REPEAT",
  91: "PARSE",
  92: "JUSTIFY",
  93: "HIDE",
  94: "UNHIDE",
  95: "WORKSPACE",
  96: "FORMULA",
  97: "FORMULA.FILL",
  98: "FORMULA.ARRAY",
  99: "DATA.FIND.NEXT",
  100: "DATA.FIND.PREV",
  101: "FORMULA.FIND.NEXT",
  102: "FORMULA.FIND.PREV",
  103: "ACTIVATE",
  104: "ACTIVATE.NEXT",
  105: "ACTIVATE.PREV",
  106: "UNLOCKED.NEXT",
  107: "UNLOCKED.PREV",
  108: "COPY.PICTURE",
  109: "SELECT",
  110: "DELETE.NAME",
  111: "DELETE.FORMAT",
  112: "VLINE",
  113: "HLINE",
  114: "VPAGE",
  115: "HPAGE",
  116: "VSCROLL",
  117: "HSCROLL",
  118: "ALERT",
  119: "NEW",
  120: "CANCEL.COPY",
  121: "SHOW.CLIPBOARD",
  122: "MESSAGE",
  124: "PASTE.LINK",
  125: "APP.ACTIVATE",
  126: "DELETE.ARROW",
  127: "ROW.HEIGHT",
  128: "FORMAT.MOVE",
  129: "FORMAT.SIZE",
  130: "FORMULA.REPLACE",
  131: "SEND.KEYS",
  132: "SELECT.SPECIAL",
  133: "APPLY.NAMES",
  134: "REPLACE.FONT",
  135: "FREEZE.PANES",
  136: "SHOW.INFO",
  137: "SPLIT",
  138: "ON.WINDOW",
  139: "ON.DATA",
  140: "DISABLE.INPUT",
  142: "OUTLINE",
  143: "LIST.NAMES",
  144: "FILE.CLOSE",
  145: "SAVE.WORKBOOK",
  146: "DATA.FORM",
  147: "COPY.CHART",
  148: "ON.TIME",
  149: "WAIT",
  150: "FORMAT.FONT",
  151: "FILL.UP",
  152: "FILL.LEFT",
  153: "DELETE.OVERLAY",
  155: "SHORT.MENUS",
  159: "SET.UPDATE.STATUS",
  161: "COLOR.PALETTE",
  162: "DELETE.STYLE",
  163: "WINDOW.RESTORE",
  164: "WINDOW.MAXIMIZE",
  166: "CHANGE.LINK",
  167: "CALCULATE.DOCUMENT",
  168: "ON.KEY",
  169: "APP.RESTORE",
  170: "APP.MOVE",
  171: "APP.SIZE",
  172: "APP.MINIMIZE",
  173: "APP.MAXIMIZE",
  174: "BRING.TO.FRONT",
  175: "SEND.TO.BACK",
  185: "MAIN.CHART.TYPE",
  186: "OVERLAY.CHART.TYPE",
  187: "SELECT.END",
  188: "OPEN.MAIL",
  189: "SEND.MAIL",
  190: "STANDARD.FONT",
  191: "CONSOLIDATE",
  192: "SORT.SPECIAL",
  193: "GALLERY.3D.AREA",
  194: "GALLERY.3D.COLUMN",
  195: "GALLERY.3D.LINE",
  196: "GALLERY.3D.PIE",
  197: "VIEW.3D",
  198: "GOAL.SEEK",
  199: "WORKGROUP",
  200: "FILL.GROUP",
  201: "UPDATE.LINK",
  202: "PROMOTE",
  203: "DEMOTE",
  204: "SHOW.DETAIL",
  206: "UNGROUP",
  207: "OBJECT.PROPERTIES",
  208: "SAVE.NEW.OBJECT",
  209: "SHARE",
  210: "SHARE.NAME",
  211: "DUPLICATE",
  212: "APPLY.STYLE",
  213: "ASSIGN.TO.OBJECT",
  214: "OBJECT.PROTECTION",
  215: "HIDE.OBJECT",
  216: "SET.EXTRACT",
  217: "CREATE.PUBLISHER",
  218: "SUBSCRIBE.TO",
  219: "ATTRIBUTES",
  220: "SHOW.TOOLBAR",
  222: "PRINT.PREVIEW",
  223: "EDIT.COLOR",
  224: "SHOW.LEVELS",
  225: "FORMAT.MAIN",
  226: "FORMAT.OVERLAY",
  227: "ON.RECALC",
  228: "EDIT.SERIES",
  229: "DEFINE.STYLE",
  240: "LINE.PRINT",
  243: "ENTER.DATA",
  249: "GALLERY.RADAR",
  250: "MERGE.STYLES",
  251: "EDITION.OPTIONS",
  252: "PASTE.PICTURE",
  253: "PASTE.PICTURE.LINK",
  254: "SPELLING",
  256: "ZOOM",
  259: "INSERT.OBJECT",
  260: "WINDOW.MINIMIZE",
  265: "SOUND.NOTE",
  266: "SOUND.PLAY",
  267: "FORMAT.SHAPE",
  268: "EXTEND.POLYGON",
  269: "FORMAT.AUTO",
  272: "GALLERY.3D.BAR",
  273: "GALLERY.3D.SURFACE",
  274: "FILL.AUTO",
  276: "CUSTOMIZE.TOOLBAR",
  277: "ADD.TOOL",
  278: "EDIT.OBJECT",
  279: "ON.DOUBLECLICK",
  280: "ON.ENTRY",
  281: "WORKBOOK.ADD",
  282: "WORKBOOK.MOVE",
  283: "WORKBOOK.COPY",
  284: "WORKBOOK.OPTIONS",
  285: "SAVE.WORKSPACE",
  288: "CHART.WIZARD",
  289: "DELETE.TOOL",
  290: "MOVE.TOOL",
  291: "WORKBOOK.SELECT",
  292: "WORKBOOK.ACTIVATE",
  293: "ASSIGN.TO.TOOL",
  295: "COPY.TOOL",
  296: "RESET.TOOL",
  297: "CONSTRAIN.NUMERIC",
  298: "PASTE.TOOL",
  302: "WORKBOOK.NEW",
  305: "SCENARIO.CELLS",
  306: "SCENARIO.DELETE",
  307: "SCENARIO.ADD",
  308: "SCENARIO.EDIT",
  309: "SCENARIO.SHOW",
  310: "SCENARIO.SHOW.NEXT",
  311: "SCENARIO.SUMMARY",
  312: "PIVOT.TABLE.WIZARD",
  313: "PIVOT.FIELD.PROPERTIES",
  314: "PIVOT.FIELD",
  315: "PIVOT.ITEM",
  316: "PIVOT.ADD.FIELDS",
  318: "OPTIONS.CALCULATION",
  319: "OPTIONS.EDIT",
  320: "OPTIONS.VIEW",
  321: "ADDIN.MANAGER",
  322: "MENU.EDITOR",
  323: "ATTACH.TOOLBARS",
  324: "VBAActivate",
  325: "OPTIONS.CHART",
  328: "VBA.INSERT.FILE",
  330: "VBA.PROCEDURE.DEFINITION",
  336: "ROUTING.SLIP",
  338: "ROUTE.DOCUMENT",
  339: "MAIL.LOGON",
  342: "INSERT.PICTURE",
  343: "EDIT.TOOL",
  344: "GALLERY.DOUGHNUT",
  350: "CHART.TREND",
  352: "PIVOT.ITEM.PROPERTIES",
  354: "WORKBOOK.INSERT",
  355: "OPTIONS.TRANSITION",
  356: "OPTIONS.GENERAL",
  370: "FILTER.ADVANCED",
  373: "MAIL.ADD.MAILER",
  374: "MAIL.DELETE.MAILER",
  375: "MAIL.REPLY",
  376: "MAIL.REPLY.ALL",
  377: "MAIL.FORWARD",
  378: "MAIL.NEXT.LETTER",
  379: "DATA.LABEL",
  380: "INSERT.TITLE",
  381: "FONT.PROPERTIES",
  382: "MACRO.OPTIONS",
  383: "WORKBOOK.HIDE",
  384: "WORKBOOK.UNHIDE",
  385: "WORKBOOK.DELETE",
  386: "WORKBOOK.NAME",
  388: "GALLERY.CUSTOM",
  390: "ADD.CHART.AUTOFORMAT",
  391: "DELETE.CHART.AUTOFORMAT",
  392: "CHART.ADD.DATA",
  393: "AUTO.OUTLINE",
  394: "TAB.ORDER",
  395: "SHOW.DIALOG",
  396: "SELECT.ALL",
  397: "UNGROUP.SHEETS",
  398: "SUBTOTAL.CREATE",
  399: "SUBTOTAL.REMOVE",
  400: "RENAME.OBJECT",
  412: "WORKBOOK.SCROLL",
  413: "WORKBOOK.NEXT",
  414: "WORKBOOK.PREV",
  415: "WORKBOOK.TAB.SPLIT",
  416: "FULL.SCREEN",
  417: "WORKBOOK.PROTECT",
  420: "SCROLLBAR.PROPERTIES",
  421: "PIVOT.SHOW.PAGES",
  422: "TEXT.TO.COLUMNS",
  423: "FORMAT.CHARTTYPE",
  424: "LINK.FORMAT",
  425: "TRACER.DISPLAY",
  430: "TRACER.NAVIGATE",
  431: "TRACER.CLEAR",
  432: "TRACER.ERROR",
  433: "PIVOT.FIELD.GROUP",
  434: "PIVOT.FIELD.UNGROUP",
  435: "CHECKBOX.PROPERTIES",
  436: "LABEL.PROPERTIES",
  437: "LISTBOX.PROPERTIES",
  438: "EDITBOX.PROPERTIES",
  439: "PIVOT.REFRESH",
  440: "LINK.COMBO",
  441: "OPEN.TEXT",
  442: "HIDE.DIALOG",
  443: "SET.DIALOG.FOCUS",
  444: "ENABLE.OBJECT",
  445: "PUSHBUTTON.PROPERTIES",
  446: "SET.DIALOG.DEFAULT",
  447: "FILTER",
  448: "FILTER.SHOW.ALL",
  449: "CLEAR.OUTLINE",
  450: "FUNCTION.WIZARD",
  451: "ADD.LIST.ITEM",
  452: "SET.LIST.ITEM",
  453: "REMOVE.LIST.ITEM",
  454: "SELECT.LIST.ITEM",
  455: "SET.CONTROL.VALUE",
  456: "SAVE.COPY.AS",
  458: "OPTIONS.LISTS.ADD",
  459: "OPTIONS.LISTS.DELETE",
  460: "SERIES.AXES",
  461: "SERIES.X",
  462: "SERIES.Y",
  463: "ERRORBAR.X",
  464: "ERRORBAR.Y",
  465: "FORMAT.CHART",
  466: "SERIES.ORDER",
  467: "MAIL.LOGOFF",
  468: "CLEAR.ROUTING.SLIP",
  469: "APP.ACTIVATE.MICROSOFT",
  470: "MAIL.EDIT.MAILER",
  471: "ON.SHEET",
  472: "STANDARD.WIDTH",
  473: "SCENARIO.MERGE",
  474: "SUMMARY.INFO",
  475: "FIND.FILE",
  476: "ACTIVE.CELL.FONT",
  477: "ENABLE.TIPWIZARD",
  478: "VBA.MAKE.ADDIN",
  480: "INSERTDATATABLE",
  481: "WORKGROUP.OPTIONS",
  482: "MAIL.SEND.MAILER",
  485: "AUTOCORRECT",
  489: "POST.DOCUMENT",
  491: "PICKLIST",
  493: "VIEW.SHOW",
  494: "VIEW.DEFINE",
  495: "VIEW.DELETE",
  509: "SHEET.BACKGROUND",
  510: "INSERT.MAP.OBJECT",
  511: "OPTIONS.MENONO",
  517: "MSOCHECKS",
  518: "NORMAL",
  519: "LAYOUT",
  520: "RM.PRINT.AREA",
  521: "CLEAR.PRINT.AREA",
  522: "ADD.PRINT.AREA",
  523: "MOVE.BRK",
  545: "HIDECURR.NOTE",
  546: "HIDEALL.NOTES",
  547: "DELETE.NOTE",
  548: "TRAVERSE.NOTES",
  549: "ACTIVATE.NOTES",
  620: "PROTECT.REVISIONS",
  621: "UNPROTECT.REVISIONS",
  647: "OPTIONS.ME",
  653: "WEB.PUBLISH",
  667: "NEWWEBQUERY",
  673: "PIVOT.TABLE.CHART",
  753: "OPTIONS.SAVE",
  755: "OPTIONS.SPELL",
  808: "HIDEALL.INKANNOTS"
}, _s = {
  0: "COUNT",
  1: "IF",
  2: "ISNA",
  3: "ISERROR",
  4: "SUM",
  5: "AVERAGE",
  6: "MIN",
  7: "MAX",
  8: "ROW",
  9: "COLUMN",
  10: "NA",
  11: "NPV",
  12: "STDEV",
  13: "DOLLAR",
  14: "FIXED",
  15: "SIN",
  16: "COS",
  17: "TAN",
  18: "ATAN",
  19: "PI",
  20: "SQRT",
  21: "EXP",
  22: "LN",
  23: "LOG10",
  24: "ABS",
  25: "INT",
  26: "SIGN",
  27: "ROUND",
  28: "LOOKUP",
  29: "INDEX",
  30: "REPT",
  31: "MID",
  32: "LEN",
  33: "VALUE",
  34: "TRUE",
  35: "FALSE",
  36: "AND",
  37: "OR",
  38: "NOT",
  39: "MOD",
  40: "DCOUNT",
  41: "DSUM",
  42: "DAVERAGE",
  43: "DMIN",
  44: "DMAX",
  45: "DSTDEV",
  46: "VAR",
  47: "DVAR",
  48: "TEXT",
  49: "LINEST",
  50: "TREND",
  51: "LOGEST",
  52: "GROWTH",
  53: "GOTO",
  54: "HALT",
  55: "RETURN",
  56: "PV",
  57: "FV",
  58: "NPER",
  59: "PMT",
  60: "RATE",
  61: "MIRR",
  62: "IRR",
  63: "RAND",
  64: "MATCH",
  65: "DATE",
  66: "TIME",
  67: "DAY",
  68: "MONTH",
  69: "YEAR",
  70: "WEEKDAY",
  71: "HOUR",
  72: "MINUTE",
  73: "SECOND",
  74: "NOW",
  75: "AREAS",
  76: "ROWS",
  77: "COLUMNS",
  78: "OFFSET",
  79: "ABSREF",
  80: "RELREF",
  81: "ARGUMENT",
  82: "SEARCH",
  83: "TRANSPOSE",
  84: "ERROR",
  85: "STEP",
  86: "TYPE",
  87: "ECHO",
  88: "SET.NAME",
  89: "CALLER",
  90: "DEREF",
  91: "WINDOWS",
  92: "SERIES",
  93: "DOCUMENTS",
  94: "ACTIVE.CELL",
  95: "SELECTION",
  96: "RESULT",
  97: "ATAN2",
  98: "ASIN",
  99: "ACOS",
  100: "CHOOSE",
  101: "HLOOKUP",
  102: "VLOOKUP",
  103: "LINKS",
  104: "INPUT",
  105: "ISREF",
  106: "GET.FORMULA",
  107: "GET.NAME",
  108: "SET.VALUE",
  109: "LOG",
  110: "EXEC",
  111: "CHAR",
  112: "LOWER",
  113: "UPPER",
  114: "PROPER",
  115: "LEFT",
  116: "RIGHT",
  117: "EXACT",
  118: "TRIM",
  119: "REPLACE",
  120: "SUBSTITUTE",
  121: "CODE",
  122: "NAMES",
  123: "DIRECTORY",
  124: "FIND",
  125: "CELL",
  126: "ISERR",
  127: "ISTEXT",
  128: "ISNUMBER",
  129: "ISBLANK",
  130: "T",
  131: "N",
  132: "FOPEN",
  133: "FCLOSE",
  134: "FSIZE",
  135: "FREADLN",
  136: "FREAD",
  137: "FWRITELN",
  138: "FWRITE",
  139: "FPOS",
  140: "DATEVALUE",
  141: "TIMEVALUE",
  142: "SLN",
  143: "SYD",
  144: "DDB",
  145: "GET.DEF",
  146: "REFTEXT",
  147: "TEXTREF",
  148: "INDIRECT",
  149: "REGISTER",
  150: "CALL",
  151: "ADD.BAR",
  152: "ADD.MENU",
  153: "ADD.COMMAND",
  154: "ENABLE.COMMAND",
  155: "CHECK.COMMAND",
  156: "RENAME.COMMAND",
  157: "SHOW.BAR",
  158: "DELETE.MENU",
  159: "DELETE.COMMAND",
  160: "GET.CHART.ITEM",
  161: "DIALOG.BOX",
  162: "CLEAN",
  163: "MDETERM",
  164: "MINVERSE",
  165: "MMULT",
  166: "FILES",
  167: "IPMT",
  168: "PPMT",
  169: "COUNTA",
  170: "CANCEL.KEY",
  171: "FOR",
  172: "WHILE",
  173: "BREAK",
  174: "NEXT",
  175: "INITIATE",
  176: "REQUEST",
  177: "POKE",
  178: "EXECUTE",
  179: "TERMINATE",
  180: "RESTART",
  181: "HELP",
  182: "GET.BAR",
  183: "PRODUCT",
  184: "FACT",
  185: "GET.CELL",
  186: "GET.WORKSPACE",
  187: "GET.WINDOW",
  188: "GET.DOCUMENT",
  189: "DPRODUCT",
  190: "ISNONTEXT",
  191: "GET.NOTE",
  192: "NOTE",
  193: "STDEVP",
  194: "VARP",
  195: "DSTDEVP",
  196: "DVARP",
  197: "TRUNC",
  198: "ISLOGICAL",
  199: "DCOUNTA",
  200: "DELETE.BAR",
  201: "UNREGISTER",
  204: "USDOLLAR",
  205: "FINDB",
  206: "SEARCHB",
  207: "REPLACEB",
  208: "LEFTB",
  209: "RIGHTB",
  210: "MIDB",
  211: "LENB",
  212: "ROUNDUP",
  213: "ROUNDDOWN",
  214: "ASC",
  215: "DBCS",
  216: "RANK",
  219: "ADDRESS",
  220: "DAYS360",
  221: "TODAY",
  222: "VDB",
  223: "ELSE",
  224: "ELSE.IF",
  225: "END.IF",
  226: "FOR.CELL",
  227: "MEDIAN",
  228: "SUMPRODUCT",
  229: "SINH",
  230: "COSH",
  231: "TANH",
  232: "ASINH",
  233: "ACOSH",
  234: "ATANH",
  235: "DGET",
  236: "CREATE.OBJECT",
  237: "VOLATILE",
  238: "LAST.ERROR",
  239: "CUSTOM.UNDO",
  240: "CUSTOM.REPEAT",
  241: "FORMULA.CONVERT",
  242: "GET.LINK.INFO",
  243: "TEXT.BOX",
  244: "INFO",
  245: "GROUP",
  246: "GET.OBJECT",
  247: "DB",
  248: "PAUSE",
  251: "RESUME",
  252: "FREQUENCY",
  253: "ADD.TOOLBAR",
  254: "DELETE.TOOLBAR",
  255: "User",
  256: "RESET.TOOLBAR",
  257: "EVALUATE",
  258: "GET.TOOLBAR",
  259: "GET.TOOL",
  260: "SPELLING.CHECK",
  261: "ERROR.TYPE",
  262: "APP.TITLE",
  263: "WINDOW.TITLE",
  264: "SAVE.TOOLBAR",
  265: "ENABLE.TOOL",
  266: "PRESS.TOOL",
  267: "REGISTER.ID",
  268: "GET.WORKBOOK",
  269: "AVEDEV",
  270: "BETADIST",
  271: "GAMMALN",
  272: "BETAINV",
  273: "BINOMDIST",
  274: "CHIDIST",
  275: "CHIINV",
  276: "COMBIN",
  277: "CONFIDENCE",
  278: "CRITBINOM",
  279: "EVEN",
  280: "EXPONDIST",
  281: "FDIST",
  282: "FINV",
  283: "FISHER",
  284: "FISHERINV",
  285: "FLOOR",
  286: "GAMMADIST",
  287: "GAMMAINV",
  288: "CEILING",
  289: "HYPGEOMDIST",
  290: "LOGNORMDIST",
  291: "LOGINV",
  292: "NEGBINOMDIST",
  293: "NORMDIST",
  294: "NORMSDIST",
  295: "NORMINV",
  296: "NORMSINV",
  297: "STANDARDIZE",
  298: "ODD",
  299: "PERMUT",
  300: "POISSON",
  301: "TDIST",
  302: "WEIBULL",
  303: "SUMXMY2",
  304: "SUMX2MY2",
  305: "SUMX2PY2",
  306: "CHITEST",
  307: "CORREL",
  308: "COVAR",
  309: "FORECAST",
  310: "FTEST",
  311: "INTERCEPT",
  312: "PEARSON",
  313: "RSQ",
  314: "STEYX",
  315: "SLOPE",
  316: "TTEST",
  317: "PROB",
  318: "DEVSQ",
  319: "GEOMEAN",
  320: "HARMEAN",
  321: "SUMSQ",
  322: "KURT",
  323: "SKEW",
  324: "ZTEST",
  325: "LARGE",
  326: "SMALL",
  327: "QUARTILE",
  328: "PERCENTILE",
  329: "PERCENTRANK",
  330: "MODE",
  331: "TRIMMEAN",
  332: "TINV",
  334: "MOVIE.COMMAND",
  335: "GET.MOVIE",
  336: "CONCATENATE",
  337: "POWER",
  338: "PIVOT.ADD.DATA",
  339: "GET.PIVOT.TABLE",
  340: "GET.PIVOT.FIELD",
  341: "GET.PIVOT.ITEM",
  342: "RADIANS",
  343: "DEGREES",
  344: "SUBTOTAL",
  345: "SUMIF",
  346: "COUNTIF",
  347: "COUNTBLANK",
  348: "SCENARIO.GET",
  349: "OPTIONS.LISTS.GET",
  350: "ISPMT",
  351: "DATEDIF",
  352: "DATESTRING",
  353: "NUMBERSTRING",
  354: "ROMAN",
  355: "OPEN.DIALOG",
  356: "SAVE.DIALOG",
  357: "VIEW.GET",
  358: "GETPIVOTDATA",
  359: "HYPERLINK",
  360: "PHONETIC",
  361: "AVERAGEA",
  362: "MAXA",
  363: "MINA",
  364: "STDEVPA",
  365: "VARPA",
  366: "STDEVA",
  367: "VARA",
  368: "BAHTTEXT",
  369: "THAIDAYOFWEEK",
  370: "THAIDIGIT",
  371: "THAIMONTHOFYEAR",
  372: "THAINUMSOUND",
  373: "THAINUMSTRING",
  374: "THAISTRINGLENGTH",
  375: "ISTHAIDIGIT",
  376: "ROUNDBAHTDOWN",
  377: "ROUNDBAHTUP",
  378: "THAIYEAR",
  379: "RTD",
  380: "CUBEVALUE",
  381: "CUBEMEMBER",
  382: "CUBEMEMBERPROPERTY",
  383: "CUBERANKEDMEMBER",
  384: "HEX2BIN",
  385: "HEX2DEC",
  386: "HEX2OCT",
  387: "DEC2BIN",
  388: "DEC2HEX",
  389: "DEC2OCT",
  390: "OCT2BIN",
  391: "OCT2HEX",
  392: "OCT2DEC",
  393: "BIN2DEC",
  394: "BIN2OCT",
  395: "BIN2HEX",
  396: "IMSUB",
  397: "IMDIV",
  398: "IMPOWER",
  399: "IMABS",
  400: "IMSQRT",
  401: "IMLN",
  402: "IMLOG2",
  403: "IMLOG10",
  404: "IMSIN",
  405: "IMCOS",
  406: "IMEXP",
  407: "IMARGUMENT",
  408: "IMCONJUGATE",
  409: "IMAGINARY",
  410: "IMREAL",
  411: "COMPLEX",
  412: "IMSUM",
  413: "IMPRODUCT",
  414: "SERIESSUM",
  415: "FACTDOUBLE",
  416: "SQRTPI",
  417: "QUOTIENT",
  418: "DELTA",
  419: "GESTEP",
  420: "ISEVEN",
  421: "ISODD",
  422: "MROUND",
  423: "ERF",
  424: "ERFC",
  425: "BESSELJ",
  426: "BESSELK",
  427: "BESSELY",
  428: "BESSELI",
  429: "XIRR",
  430: "XNPV",
  431: "PRICEMAT",
  432: "YIELDMAT",
  433: "INTRATE",
  434: "RECEIVED",
  435: "DISC",
  436: "PRICEDISC",
  437: "YIELDDISC",
  438: "TBILLEQ",
  439: "TBILLPRICE",
  440: "TBILLYIELD",
  441: "PRICE",
  442: "YIELD",
  443: "DOLLARDE",
  444: "DOLLARFR",
  445: "NOMINAL",
  446: "EFFECT",
  447: "CUMPRINC",
  448: "CUMIPMT",
  449: "EDATE",
  450: "EOMONTH",
  451: "YEARFRAC",
  452: "COUPDAYBS",
  453: "COUPDAYS",
  454: "COUPDAYSNC",
  455: "COUPNCD",
  456: "COUPNUM",
  457: "COUPPCD",
  458: "DURATION",
  459: "MDURATION",
  460: "ODDLPRICE",
  461: "ODDLYIELD",
  462: "ODDFPRICE",
  463: "ODDFYIELD",
  464: "RANDBETWEEN",
  465: "WEEKNUM",
  466: "AMORDEGRC",
  467: "AMORLINC",
  468: "CONVERT",
  724: "SHEETJS",
  469: "ACCRINT",
  470: "ACCRINTM",
  471: "WORKDAY",
  472: "NETWORKDAYS",
  473: "GCD",
  474: "MULTINOMIAL",
  475: "LCM",
  476: "FVSCHEDULE",
  477: "CUBEKPIMEMBER",
  478: "CUBESET",
  479: "CUBESETCOUNT",
  480: "IFERROR",
  481: "COUNTIFS",
  482: "SUMIFS",
  483: "AVERAGEIF",
  484: "AVERAGEIFS"
}, Uh = {
  2: 1,
  3: 1,
  10: 0,
  15: 1,
  16: 1,
  17: 1,
  18: 1,
  19: 0,
  20: 1,
  21: 1,
  22: 1,
  23: 1,
  24: 1,
  25: 1,
  26: 1,
  27: 2,
  30: 2,
  31: 3,
  32: 1,
  33: 1,
  34: 0,
  35: 0,
  38: 1,
  39: 2,
  40: 3,
  41: 3,
  42: 3,
  43: 3,
  44: 3,
  45: 3,
  47: 3,
  48: 2,
  53: 1,
  61: 3,
  63: 0,
  65: 3,
  66: 3,
  67: 1,
  68: 1,
  69: 1,
  70: 1,
  71: 1,
  72: 1,
  73: 1,
  74: 0,
  75: 1,
  76: 1,
  77: 1,
  79: 2,
  80: 2,
  83: 1,
  85: 0,
  86: 1,
  89: 0,
  90: 1,
  94: 0,
  95: 0,
  97: 2,
  98: 1,
  99: 1,
  101: 3,
  102: 3,
  105: 1,
  106: 1,
  108: 2,
  111: 1,
  112: 1,
  113: 1,
  114: 1,
  117: 2,
  118: 1,
  119: 4,
  121: 1,
  126: 1,
  127: 1,
  128: 1,
  129: 1,
  130: 1,
  131: 1,
  133: 1,
  134: 1,
  135: 1,
  136: 2,
  137: 2,
  138: 2,
  140: 1,
  141: 1,
  142: 3,
  143: 4,
  144: 4,
  161: 1,
  162: 1,
  163: 1,
  164: 1,
  165: 2,
  172: 1,
  175: 2,
  176: 2,
  177: 3,
  178: 2,
  179: 1,
  184: 1,
  186: 1,
  189: 3,
  190: 1,
  195: 3,
  196: 3,
  197: 1,
  198: 1,
  199: 3,
  201: 1,
  207: 4,
  210: 3,
  211: 1,
  212: 2,
  213: 2,
  214: 1,
  215: 1,
  225: 0,
  229: 1,
  230: 1,
  231: 1,
  232: 1,
  233: 1,
  234: 1,
  235: 3,
  244: 1,
  247: 4,
  252: 2,
  257: 1,
  261: 1,
  271: 1,
  273: 4,
  274: 2,
  275: 2,
  276: 2,
  277: 3,
  278: 3,
  279: 1,
  280: 3,
  281: 3,
  282: 3,
  283: 1,
  284: 1,
  285: 2,
  286: 4,
  287: 3,
  288: 2,
  289: 4,
  290: 3,
  291: 3,
  292: 3,
  293: 4,
  294: 1,
  295: 3,
  296: 1,
  297: 3,
  298: 1,
  299: 2,
  300: 3,
  301: 3,
  302: 4,
  303: 2,
  304: 2,
  305: 2,
  306: 2,
  307: 2,
  308: 2,
  309: 3,
  310: 2,
  311: 2,
  312: 2,
  313: 2,
  314: 2,
  315: 2,
  316: 4,
  325: 2,
  326: 2,
  327: 2,
  328: 2,
  331: 2,
  332: 2,
  337: 2,
  342: 1,
  343: 1,
  346: 2,
  347: 1,
  350: 4,
  351: 3,
  352: 1,
  353: 2,
  360: 1,
  368: 1,
  369: 1,
  370: 1,
  371: 1,
  372: 1,
  373: 1,
  374: 1,
  375: 1,
  376: 1,
  377: 1,
  378: 1,
  382: 3,
  385: 1,
  392: 1,
  393: 1,
  396: 2,
  397: 2,
  398: 2,
  399: 1,
  400: 1,
  401: 1,
  402: 1,
  403: 1,
  404: 1,
  405: 1,
  406: 1,
  407: 1,
  408: 1,
  409: 1,
  410: 1,
  414: 4,
  415: 1,
  416: 1,
  417: 2,
  420: 1,
  421: 1,
  422: 2,
  424: 1,
  425: 2,
  426: 2,
  427: 2,
  428: 2,
  430: 3,
  438: 3,
  439: 3,
  440: 3,
  443: 2,
  444: 2,
  445: 2,
  446: 2,
  447: 6,
  448: 6,
  449: 2,
  450: 2,
  464: 2,
  468: 3,
  476: 2,
  479: 1,
  480: 2,
  65535: 0
};
function $n(e) {
  return e.slice(0, 3) == "of:" && (e = e.slice(3)), e.charCodeAt(0) == 61 && (e = e.slice(1), e.charCodeAt(0) == 61 && (e = e.slice(1))), e = e.replace(/COM\.MICROSOFT\./g, ""), e = e.replace(/\[((?:\.[A-Z]+[0-9]+)(?::\.[A-Z]+[0-9]+)?)\]/g, function(a, r) {
    return r.replace(/\./g, "");
  }), e = e.replace(/\$'([^']|'')+'/g, function(a) {
    return a.slice(1);
  }), e = e.replace(/\$([^\]\. #$]+)/g, function(a, r) {
    return r.match(/^([A-Z]{1,2}|[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D])?(10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5})?$/) ? a : r;
  }), e = e.replace(/\[.(#[A-Z]*[?!])\]/g, "$1"), e.replace(/[;~]/g, ",").replace(/\|/g, ";");
}
function u0(e) {
  e = e.replace(/\$'([^']|'')+'/g, function(t) {
    return t.slice(1);
  }), e = e.replace(/\$([^\]\. #$]+)/g, function(t, n) {
    return n.match(/^([A-Z]{1,2}|[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D])?(10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5})?$/) ? t : n;
  });
  var a = e.split(":"), r = a[0].split(".")[0];
  return [r, a[0].split(".")[1] + (a.length > 1 ? ":" + (a[1].split(".")[1] || a[1].split(".")[0]) : "")];
}
var Qa = {}, Pa = {};
function et(e, a) {
  if (e) {
    var r = [0.7, 0.7, 0.75, 0.75, 0.3, 0.3];
    a == "xlml" && (r = [1, 1, 1, 1, 0.5, 0.5]), e.left == null && (e.left = r[0]), e.right == null && (e.right = r[1]), e.top == null && (e.top = r[2]), e.bottom == null && (e.bottom = r[3]), e.header == null && (e.header = r[4]), e.footer == null && (e.footer = r[5]);
  }
}
function Ts(e, a, r, t, n, i, c) {
  try {
    t.cellNF && (e.z = ge[a]);
  } catch (f) {
    if (t.WTF) throw f;
  }
  if (!(e.t === "z" && !t.cellStyles)) {
    if (e.t === "d" && typeof e.v == "string" && (e.v = fr(e.v)), (!t || t.cellText !== !1) && e.t !== "z") try {
      if (ge[a] == null && ga(Cc[a] || "General", a), e.t === "e") e.w = e.w || Ar[e.v];
      else if (a === 0)
        if (e.t === "n")
          (e.v | 0) === e.v ? e.w = e.v.toString(10) : e.w = nt(e.v);
        else if (e.t === "d") {
          var s = ar(e.v, !!c);
          (s | 0) === s ? e.w = s.toString(10) : e.w = nt(s);
        } else {
          if (e.v === void 0) return "";
          e.w = Ea(e.v, Pa);
        }
      else e.t === "d" ? e.w = Fr(a, ar(e.v, !!c), Pa) : e.w = Fr(a, e.v, Pa);
    } catch (f) {
      if (t.WTF) throw f;
    }
    if (t.cellStyles && r != null)
      try {
        e.s = i.Fills[r], e.s.fgColor && e.s.fgColor.theme && !e.s.fgColor.rgb && (e.s.fgColor.rgb = Ht(n.themeElements.clrScheme[e.s.fgColor.theme].rgb, e.s.fgColor.tint || 0), t.WTF && (e.s.fgColor.raw_rgb = n.themeElements.clrScheme[e.s.fgColor.theme].rgb)), e.s.bgColor && e.s.bgColor.theme && (e.s.bgColor.rgb = Ht(n.themeElements.clrScheme[e.s.bgColor.theme].rgb, e.s.bgColor.tint || 0), t.WTF && (e.s.bgColor.raw_rgb = n.themeElements.clrScheme[e.s.bgColor.theme].rgb));
      } catch (f) {
        if (t.WTF && i.Fills) throw f;
      }
  }
}
function Hh(e, a) {
  var r = Ke(a);
  r.s.r <= r.e.r && r.s.c <= r.e.c && r.s.r >= 0 && r.s.c >= 0 && (e["!ref"] = Ce(r));
}
var Wh = /<(?:\w+:)?mergeCell ref=["'][A-Z0-9:]+['"]\s*[\/]?>/g, Vh = /<(?:\w+:)?hyperlink [^<>]*>/mg, Gh = /"(\w*:\w*)"/, $h = /<(?:\w+:)?col\b[^<>]*[\/]?>/g, Xh = /<(?:\w+:)?autoFilter[^>]*/g, zh = /<(?:\w+:)?pageMargins[^<>]*\/>/g, Es = /<(?:\w+:)?sheetPr\b[^<>]*?\/>/;
function Kh(e, a, r, t, n, i, c) {
  if (!e) return e;
  t || (t = { "!id": {} });
  var s = {};
  a.dense && (s["!data"] = []);
  var f = { s: { r: 2e6, c: 2e6 }, e: { r: 0, c: 0 } }, o = "", l = "", v = ir(e, "sheetData");
  v ? (o = e.slice(0, v.index), l = e.slice(v.index + v[0].length)) : o = l = e;
  var x = o.match(Es);
  x ? G0(x[0], s, n, r) : (x = ir(o, "sheetPr")) && Yh(x[0], x[1] || "", s, n, r);
  var u = (o.match(/<(?:\w*:)?dimension/) || { index: -1 }).index;
  if (u > 0) {
    var p = o.slice(u, u + 50).match(Gh);
    p && !(a && a.nodim) && Hh(s, p[1]);
  }
  var _ = ir(o, "sheetViews");
  _ && _[1] && ex(_[1], n);
  var d = [];
  if (a.cellStyles) {
    var h = o.match($h);
    h && Zh(d, h);
  }
  v && rx(v[1], s, a, f, i, c, n);
  var E = l.match(Xh);
  E && (s["!autofilter"] = qh(E[0]));
  var g = [], C = l.match(Wh);
  if (C) for (u = 0; u != C.length; ++u)
    g[u] = Ke(C[u].slice(C[u].indexOf("=") + 2));
  var P = l.match(Vh);
  P && jh(s, P, t);
  var M = l.match(zh);
  M && (s["!margins"] = Jh(le(M[0])));
  var I;
  if ((I = l.match(/legacyDrawing r:id="(.*?)"/)) && (s["!legrel"] = I[1]), a && a.nodim && (f.s.c = f.s.r = 0), !s["!ref"] && f.e.c >= f.s.c && f.e.r >= f.s.r && (s["!ref"] = Ce(f)), a.sheetRows > 0 && s["!ref"]) {
    var N = Ke(s["!ref"]);
    a.sheetRows <= +N.e.r && (N.e.r = a.sheetRows - 1, N.e.r > f.e.r && (N.e.r = f.e.r), N.e.r < N.s.r && (N.s.r = N.e.r), N.e.c > f.e.c && (N.e.c = f.e.c), N.e.c < N.s.c && (N.s.c = N.e.c), s["!fullref"] = s["!ref"], s["!ref"] = Ce(N));
  }
  return d.length > 0 && (s["!cols"] = d), g.length > 0 && (s["!merges"] = g), t["!id"][s["!legrel"]] && (s["!legdrawel"] = t["!id"][s["!legrel"]]), s;
}
function G0(e, a, r, t) {
  var n = le(e);
  r.Sheets[t] || (r.Sheets[t] = {}), n.codeName && (r.Sheets[t].CodeName = Se(Ue(n.codeName)));
}
function Yh(e, a, r, t, n) {
  G0(e.slice(0, e.indexOf(">")), r, t, n);
}
function jh(e, a, r) {
  for (var t = e["!data"] != null, n = 0; n != a.length; ++n) {
    var i = le(Ue(a[n]), !0);
    if (!i.ref) return;
    var c = ((r || {})["!id"] || [])[i.id];
    c ? (i.Target = c.Target, i.location && (i.Target += "#" + Se(i.location))) : (i.Target = "#" + Se(i.location), c = { Target: i.Target, TargetMode: "Internal" }), i.Rel = c, i.tooltip && (i.Tooltip = i.tooltip, delete i.tooltip);
    for (var s = Ke(i.ref), f = s.s.r; f <= s.e.r; ++f) for (var o = s.s.c; o <= s.e.c; ++o) {
      var l = Pe(o) + Me(f);
      t ? (e["!data"][f] || (e["!data"][f] = []), e["!data"][f][o] || (e["!data"][f][o] = { t: "z", v: void 0 }), e["!data"][f][o].l = i) : (e[l] || (e[l] = { t: "z", v: void 0 }), e[l].l = i);
    }
  }
}
function Jh(e) {
  var a = {};
  return ["left", "right", "top", "bottom", "header", "footer"].forEach(function(r) {
    e[r] && (a[r] = parseFloat(e[r]));
  }), a;
}
function Zh(e, a) {
  for (var r = !1, t = 0; t != a.length; ++t) {
    var n = le(a[t], !0);
    n.hidden && (n.hidden = Be(n.hidden));
    var i = parseInt(n.min, 10) - 1, c = parseInt(n.max, 10) - 1;
    for (n.outlineLevel && (n.level = +n.outlineLevel || 0), delete n.min, delete n.max, n.width = +n.width, !r && n.width && (r = !0, H0(n.width)), Ma(n); i <= c; ) e[i++] = er(n);
  }
}
function qh(e) {
  var a = { ref: (e.match(/ref="([^"]*)"/) || [])[1] };
  return a;
}
var Qh = /<(?:\w:)?sheetView(?:[^<>a-z][^<>]*)?\/?>/g;
function ex(e, a) {
  a.Views || (a.Views = [{}]), (e.match(Qh) || []).forEach(function(r, t) {
    var n = le(r);
    a.Views[t] || (a.Views[t] = {}), +n.zoomScale && (a.Views[t].zoom = +n.zoomScale), n.rightToLeft && Be(n.rightToLeft) && (a.Views[t].RTL = !0);
  });
}
var rx = /* @__PURE__ */ (function() {
  var e = /<(?:\w+:)?c[ \/>]/, a = /<\/(?:\w+:)?row>/, r = /r=["']([^"']*)["']/, t = /ref=["']([^"']*)["']/;
  return function(i, c, s, f, o, l, v) {
    for (var x = 0, u = "", p = [], _ = [], d = 0, h = 0, E = 0, g = "", C, P, M = 0, I = 0, N, O, B = 0, b = 0, G = Array.isArray(l.CellXf), z, ce = [], j = [], he = c["!data"] != null, J = [], ne = {}, pe = !1, X = !!s.sheetStubs, Te = !!((v || {}).WBProps || {}).date1904, _e = i.split(a), de = 0, fe = _e.length; de != fe; ++de) {
      u = _e[de].trim();
      var ke = u.length;
      if (ke !== 0) {
        var me = 0;
        e: for (x = 0; x < ke; ++x) switch (
          /*x.charCodeAt(ri)*/
          u[x]
        ) {
          case ">":
            if (
              /*x.charCodeAt(ri-1) != 47*/
              u[x - 1] != "/"
            ) {
              ++x;
              break e;
            }
            if (s && s.cellStyles) {
              if (P = le(u.slice(me, x), !0), M = P.r != null ? parseInt(P.r, 10) : M + 1, I = -1, s.sheetRows && s.sheetRows < M) continue;
              ne = {}, pe = !1, P.ht && (pe = !0, ne.hpt = parseFloat(P.ht), ne.hpx = ft(ne.hpt)), P.hidden && Be(P.hidden) && (pe = !0, ne.hidden = !0), P.outlineLevel != null && (pe = !0, ne.level = +P.outlineLevel), pe && (J[M - 1] = ne);
            }
            break;
          case "<":
            me = x;
            break;
        }
        if (me >= x) break;
        if (P = le(u.slice(me, x), !0), M = P.r != null ? parseInt(P.r, 10) : M + 1, I = -1, !(s.sheetRows && s.sheetRows < M)) {
          s.nodim || (f.s.r > M - 1 && (f.s.r = M - 1), f.e.r < M - 1 && (f.e.r = M - 1)), s && s.cellStyles && (ne = {}, pe = !1, P.ht && (pe = !0, ne.hpt = parseFloat(P.ht), ne.hpx = ft(ne.hpt)), P.hidden && Be(P.hidden) && (pe = !0, ne.hidden = !0), P.outlineLevel != null && (pe = !0, ne.level = +P.outlineLevel), pe && (J[M - 1] = ne)), p = u.slice(x).split(e);
          for (var Fe = 0; Fe != p.length && p[Fe].trim().charAt(0) == "<"; ++Fe) ;
          for (p = p.slice(Fe), x = 0; x != p.length; ++x)
            if (u = p[x].trim(), u.length !== 0) {
              if (_ = u.match(r), d = x, h = 0, E = 0, u = "<c " + (u.slice(0, 1) == "<" ? ">" : "") + u, _ != null && _.length === 2) {
                for (d = 0, g = _[1], h = 0; h != g.length && !((E = g.charCodeAt(h) - 64) < 1 || E > 26); ++h)
                  d = 26 * d + E;
                --d, I = d;
              } else ++I;
              for (h = 0; h != u.length && u.charCodeAt(h) !== 62; ++h) ;
              if (++h, P = le(u.slice(0, h), !0), P.r || (P.r = Ne({ r: M - 1, c: I })), g = u.slice(h), C = { t: "" }, (_ = ir(g, "v")) != null && /*::cref != null && */
              _[1] !== "" && (C.v = Se(_[1])), s.cellFormula) {
                if ((_ = ir(g, "f")) != null) {
                  if (_[1] == "")
                    /*::cref != null && cref[0] != null && */
                    _[0].indexOf('t="shared"') > -1 && (O = le(_[0]), j[O.si] && (C.f = Un(j[O.si][1], j[O.si][2], P.r)));
                  else if (C.f = Se(Ue(_[1]), !0), s.xlfn || (C.f = Hn(C.f)), /*::cref != null && cref[0] != null && */
                  _[0].indexOf('t="array"') > -1)
                    C.F = (g.match(t) || [])[1], C.F.indexOf(":") > -1 && ce.push([Ke(C.F), C.F]);
                  else if (
                    /*::cref != null && cref[0] != null && */
                    _[0].indexOf('t="shared"') > -1
                  ) {
                    O = le(_[0]);
                    var y = Se(Ue(_[1]));
                    s.xlfn || (y = Hn(y)), j[parseInt(O.si, 10)] = [O, y, P.r];
                  }
                } else (_ = g.match(/<f[^<>]*\/>/)) && (O = le(_[0]), j[O.si] && (C.f = Un(j[O.si][1], j[O.si][2], P.r)));
                var L = dr(P.r);
                for (h = 0; h < ce.length; ++h)
                  L.r >= ce[h][0].s.r && L.r <= ce[h][0].e.r && L.c >= ce[h][0].s.c && L.c <= ce[h][0].e.c && (C.F = ce[h][1]);
              }
              if (P.t == null && C.v === void 0)
                if (C.f || C.F)
                  C.v = 0, C.t = "n";
                else if (X) C.t = "z";
                else continue;
              else C.t = P.t || "n";
              switch (f.s.c > I && (f.s.c = I), f.e.c < I && (f.e.c = I), C.t) {
                case "n":
                  if (C.v == "" || C.v == null) {
                    if (!X) continue;
                    C.t = "z";
                  } else C.v = parseFloat(C.v);
                  break;
                case "s":
                  if (typeof C.v > "u") {
                    if (!X) continue;
                    C.t = "z";
                  } else
                    N = Qa[parseInt(C.v, 10)], C.v = N.t, C.r = N.r, s.cellHTML && (C.h = N.h);
                  break;
                case "str":
                  C.t = "s", C.v = C.v != null ? Se(Ue(C.v), !0) : "", s.cellHTML && (C.h = za(C.v));
                  break;
                case "inlineStr":
                  _ = ir(g, "is"), C.t = "s", _ != null && (N = U0(_[1])) ? (C.v = N.t, s.cellHTML && (C.h = N.h)) : C.v = "";
                  break;
                case "b":
                  C.v = Be(C.v);
                  break;
                case "d":
                  s.cellDates ? C.v = fr(C.v, Te) : (C.v = ar(fr(C.v, Te), Te), C.t = "n");
                  break;
                /* error string in .w, number in .v */
                case "e":
                  (!s || s.cellText !== !1) && (C.w = C.v), C.v = sr[C.v];
                  break;
              }
              if (B = b = 0, z = null, G && P.s !== void 0 && (z = l.CellXf[P.s], z != null && (z.numFmtId != null && (B = z.numFmtId), s.cellStyles && z.fillId != null && (b = z.fillId))), Ts(C, B, b, s, o, l, Te), s.cellDates && G && C.t == "n" && Ur(ge[B]) && (C.v = ca(C.v + (Te ? 1462 : 0)), C.t = typeof C.v == "number" ? "n" : "d"), P.cm && s.xlmeta) {
                var R = (s.xlmeta.Cell || [])[+P.cm - 1];
                R && R.type == "XLDAPR" && (C.D = !0);
              }
              var D;
              s.nodim && (D = dr(P.r), f.s.r > D.r && (f.s.r = D.r), f.e.r < D.r && (f.e.r = D.r)), he ? (D = dr(P.r), c["!data"][D.r] || (c["!data"][D.r] = []), c["!data"][D.r][D.c] = C) : c[P.r] = C;
            }
        }
      }
    }
    J.length > 0 && (c["!rows"] = J);
  };
})();
function ax(e, a) {
  var r = {}, t = e.l + a;
  r.r = e.read_shift(4), e.l += 4;
  var n = e.read_shift(2);
  e.l += 1;
  var i = e.read_shift(1);
  return e.l = t, i & 7 && (r.level = i & 7), i & 16 && (r.hidden = !0), i & 32 && (r.hpt = n / 20), r;
}
var tx = Sa;
function nx() {
}
function ix(e, a) {
  var r = {}, t = e[e.l];
  return ++e.l, r.above = !(t & 64), r.left = !(t & 128), e.l += 18, r.name = Rf(e), r;
}
function sx(e) {
  var a = Wr(e);
  return [a];
}
function cx(e) {
  var a = ya(e);
  return [a];
}
function fx(e) {
  var a = Wr(e), r = e.read_shift(1);
  return [a, r, "b"];
}
function ox(e) {
  var a = ya(e), r = e.read_shift(1);
  return [a, r, "b"];
}
function lx(e) {
  var a = Wr(e), r = e.read_shift(1);
  return [a, r, "e"];
}
function ux(e) {
  var a = ya(e), r = e.read_shift(1);
  return [a, r, "e"];
}
function hx(e) {
  var a = Wr(e), r = e.read_shift(4);
  return [a, r, "s"];
}
function xx(e) {
  var a = ya(e), r = e.read_shift(4);
  return [a, r, "s"];
}
function dx(e) {
  var a = Wr(e), r = xr(e);
  return [a, r, "n"];
}
function ks(e) {
  var a = ya(e), r = xr(e);
  return [a, r, "n"];
}
function vx(e) {
  var a = Wr(e), r = Zt(e);
  return [a, r, "n"];
}
function px(e) {
  var a = ya(e), r = Zt(e);
  return [a, r, "n"];
}
function gx(e) {
  var a = Wr(e), r = L0(e);
  return [a, r, "is"];
}
function mx(e) {
  var a = Wr(e), r = vr(e);
  return [a, r, "str"];
}
function _x(e) {
  var a = ya(e), r = vr(e);
  return [a, r, "str"];
}
function Tx(e, a, r) {
  var t = e.l + a, n = Wr(e);
  n.r = r["!row"];
  var i = e.read_shift(1), c = [n, i, "b"];
  if (r.cellFormula) {
    e.l += 2;
    var s = e0(e, t - e.l, r);
    c[3] = hr(s, null, n, r.supbooks, r);
  } else e.l = t;
  return c;
}
function Ex(e, a, r) {
  var t = e.l + a, n = Wr(e);
  n.r = r["!row"];
  var i = e.read_shift(1), c = [n, i, "e"];
  if (r.cellFormula) {
    e.l += 2;
    var s = e0(e, t - e.l, r);
    c[3] = hr(s, null, n, r.supbooks, r);
  } else e.l = t;
  return c;
}
function kx(e, a, r) {
  var t = e.l + a, n = Wr(e);
  n.r = r["!row"];
  var i = xr(e), c = [n, i, "n"];
  if (r.cellFormula) {
    e.l += 2;
    var s = e0(e, t - e.l, r);
    c[3] = hr(s, null, n, r.supbooks, r);
  } else e.l = t;
  return c;
}
function wx(e, a, r) {
  var t = e.l + a, n = Wr(e);
  n.r = r["!row"];
  var i = vr(e), c = [n, i, "str"];
  if (r.cellFormula) {
    e.l += 2;
    var s = e0(e, t - e.l, r);
    c[3] = hr(s, null, n, r.supbooks, r);
  } else e.l = t;
  return c;
}
var Fx = Sa;
function Ax(e, a) {
  var r = e.l + a, t = Sa(e), n = Jt(e), i = vr(e), c = vr(e), s = vr(e);
  e.l = r;
  var f = { rfx: t, relId: n, loc: i, display: s };
  return c && (f.Tooltip = c), f;
}
function yx() {
}
function Sx(e, a, r) {
  var t = e.l + a, n = Wi(e), i = e.read_shift(1), c = [n];
  if (c[2] = i, r.cellFormula) {
    var s = bh(e, t - e.l, r);
    c[1] = s;
  } else e.l = t;
  return c;
}
function Cx(e, a, r) {
  var t = e.l + a, n = Sa(e), i = [n];
  if (r.cellFormula) {
    var c = Bh(e, t - e.l, r);
    i[1] = c, e.l = t;
  } else e.l = t;
  return i;
}
var Dx = ["left", "right", "top", "bottom", "header", "footer"];
function Ix(e) {
  var a = {};
  return Dx.forEach(function(r) {
    a[r] = xr(e);
  }), a;
}
function Ox(e) {
  var a = e.read_shift(2);
  return e.l += 28, { RTL: a & 32 };
}
function Rx() {
}
function Nx() {
}
function Px(e, a, r, t, n, i, c) {
  if (!e) return e;
  var s = a || {};
  t || (t = { "!id": {} });
  var f = {};
  s.dense && (f["!data"] = []);
  var o, l = { s: { r: 2e6, c: 2e6 }, e: { r: 0, c: 0 } }, v = !1, x = !1, u, p, _, d, h, E, g, C, P, M = [];
  s.biff = 12, s["!row"] = 0;
  var I = 0, N = !1, O = [], B = {}, b = s.supbooks || /*::(*/
  n.supbooks || [[]];
  if (b.sharedf = B, b.arrayf = O, b.SheetNames = n.SheetNames || n.Sheets.map(function(pe) {
    return pe.name;
  }), !s.supbooks && (s.supbooks = b, n.Names))
    for (var G = 0; G < n.Names.length; ++G) b[0][G + 1] = n.Names[G];
  var z = [], ce = [], j = !1;
  Gt[16] = { n: "BrtShortReal", f: ks };
  var he, J = 1462 * +!!((n || {}).WBProps || {}).date1904;
  if (ta(e, function(X, Te, _e) {
    if (!x)
      switch (_e) {
        case 148:
          o = X;
          break;
        case 0:
          u = X, s.sheetRows && s.sheetRows <= u.r && (x = !0), C = Me(d = u.r), s["!row"] = u.r, (X.hidden || X.hpt || X.level != null) && (X.hpt && (X.hpx = ft(X.hpt)), ce[X.r] = X);
          break;
        case 2:
        /* 'BrtCellRk' */
        case 3:
        /* 'BrtCellError' */
        case 4:
        /* 'BrtCellBool' */
        case 5:
        /* 'BrtCellReal' */
        case 6:
        /* 'BrtCellSt' */
        case 7:
        /* 'BrtCellIsst' */
        case 8:
        /* 'BrtFmlaString' */
        case 9:
        /* 'BrtFmlaNum' */
        case 10:
        /* 'BrtFmlaBool' */
        case 11:
        /* 'BrtFmlaError' */
        case 13:
        /* 'BrtShortRk' */
        case 14:
        /* 'BrtShortError' */
        case 15:
        /* 'BrtShortBool' */
        case 16:
        /* 'BrtShortReal' */
        case 17:
        /* 'BrtShortSt' */
        case 18:
        /* 'BrtShortIsst' */
        case 62:
          switch (p = { t: X[2] }, X[2]) {
            case "n":
              p.v = X[1];
              break;
            case "s":
              g = Qa[X[1]], p.v = g.t, p.r = g.r;
              break;
            case "b":
              p.v = !!X[1];
              break;
            case "e":
              p.v = X[1], s.cellText !== !1 && (p.w = Ar[p.v]);
              break;
            case "str":
              p.t = "s", p.v = X[1];
              break;
            case "is":
              p.t = "s", p.v = X[1].t;
              break;
          }
          if ((_ = c.CellXf[X[0].iStyleRef]) && Ts(p, _.numFmtId, null, s, i, c, J > 0), h = X[0].c == -1 ? h + 1 : X[0].c, s.dense ? (f["!data"][d] || (f["!data"][d] = []), f["!data"][d][h] = p) : f[Pe(h) + C] = p, s.cellFormula) {
            for (N = !1, I = 0; I < O.length; ++I) {
              var de = O[I];
              u.r >= de[0].s.r && u.r <= de[0].e.r && h >= de[0].s.c && h <= de[0].e.c && (p.F = Ce(de[0]), N = !0);
            }
            !N && X.length > 3 && (p.f = X[3]);
          }
          if (l.s.r > u.r && (l.s.r = u.r), l.s.c > h && (l.s.c = h), l.e.r < u.r && (l.e.r = u.r), l.e.c < h && (l.e.c = h), s.cellDates && _ && p.t == "n" && Ur(ge[_.numFmtId])) {
            var fe = jr(p.v + J);
            fe && (p.t = "d", p.v = new Date(Date.UTC(fe.y, fe.m - 1, fe.d, fe.H, fe.M, fe.S, fe.u)));
          }
          he && (he.type == "XLDAPR" && (p.D = !0), he = void 0);
          break;
        case 1:
        /* 'BrtCellBlank' */
        case 12:
          if (!s.sheetStubs || v) break;
          p = { t: "z", v: void 0 }, h = X[0].c == -1 ? h + 1 : X[0].c, s.dense ? (f["!data"][d] || (f["!data"][d] = []), f["!data"][d][h] = p) : f[Pe(h) + C] = p, l.s.r > u.r && (l.s.r = u.r), l.s.c > h && (l.s.c = h), l.e.r < u.r && (l.e.r = u.r), l.e.c < h && (l.e.c = h), he && (he.type == "XLDAPR" && (p.D = !0), he = void 0);
          break;
        case 176:
          M.push(X);
          break;
        case 49:
          he = ((s.xlmeta || {}).Cell || [])[X - 1];
          break;
        case 494:
          var ke = t["!id"][X.relId];
          for (ke ? (X.Target = ke.Target, X.loc && (X.Target += "#" + X.loc), X.Rel = ke) : X.relId == "" && (X.Target = "#" + X.loc), d = X.rfx.s.r; d <= X.rfx.e.r; ++d) for (h = X.rfx.s.c; h <= X.rfx.e.c; ++h)
            s.dense ? (f["!data"][d] || (f["!data"][d] = []), f["!data"][d][h] || (f["!data"][d][h] = { t: "z", v: void 0 }), f["!data"][d][h].l = X) : (E = Pe(h) + Me(d), f[E] || (f[E] = { t: "z", v: void 0 }), f[E].l = X);
          break;
        case 426:
          if (!s.cellFormula) break;
          O.push(X), P = s.dense ? f["!data"][d][h] : f[Pe(h) + C], P.f = hr(X[1], l, { r: u.r, c: h }, b, s), P.F = Ce(X[0]);
          break;
        case 427:
          if (!s.cellFormula) break;
          B[Ne(X[0].s)] = X[1], P = s.dense ? f["!data"][d][h] : f[Pe(h) + C], P.f = hr(X[1], l, { r: u.r, c: h }, b, s);
          break;
        /* identical to 'ColInfo' in XLS */
        case 60:
          if (!s.cellStyles) break;
          for (; X.e >= X.s; )
            z[X.e--] = { width: X.w / 256, hidden: !!(X.flags & 1), level: X.level }, j || (j = !0, H0(X.w / 256)), Ma(z[X.e + 1]);
          break;
        case 551:
          X && (f["!legrel"] = X);
          break;
        case 161:
          f["!autofilter"] = { ref: Ce(X) };
          break;
        case 476:
          f["!margins"] = X;
          break;
        case 147:
          n.Sheets[r] || (n.Sheets[r] = {}), X.name && (n.Sheets[r].CodeName = X.name), (X.above || X.left) && (f["!outline"] = { above: X.above, left: X.left });
          break;
        case 137:
          n.Views || (n.Views = [{}]), n.Views[0] || (n.Views[0] = {}), X.RTL && (n.Views[0].RTL = !0);
          break;
        case 485:
          break;
        case 64:
        /* 'BrtDVal' */
        case 1053:
          break;
        case 151:
          break;
        case 152:
        /* 'BrtSel' */
        case 175:
        /* 'BrtAFilterDateGroupItem' */
        case 644:
        /* 'BrtActiveX' */
        case 625:
        /* 'BrtBigName' */
        case 562:
        /* 'BrtBkHim' */
        case 396:
        /* 'BrtBrk' */
        case 1112:
        /* 'BrtCFIcon' */
        case 1146:
        /* 'BrtCFRuleExt' */
        case 471:
        /* 'BrtCFVO' */
        case 1050:
        /* 'BrtCFVO14' */
        case 649:
        /* 'BrtCellIgnoreEC' */
        case 1105:
        /* 'BrtCellIgnoreEC14' */
        case 589:
        /* 'BrtCellSmartTagProperty' */
        case 607:
        /* 'BrtCellWatch' */
        case 564:
        /* 'BrtColor' */
        case 1055:
        /* 'BrtColor14' */
        case 168:
        /* 'BrtColorFilter' */
        case 174:
        /* 'BrtCustomFilter' */
        case 1180:
        /* 'BrtCustomFilter14' */
        case 499:
        /* 'BrtDRef' */
        case 507:
        /* 'BrtDXF' */
        case 550:
        /* 'BrtDrawing' */
        case 171:
        /* 'BrtDynamicFilter' */
        case 167:
        /* 'BrtFilter' */
        case 1177:
        /* 'BrtFilter14' */
        case 169:
        /* 'BrtIconFilter' */
        case 1181:
        /* 'BrtIconFilter14' */
        case 552:
        /* 'BrtLegacyDrawingHF' */
        case 661:
        /* 'BrtListPart' */
        case 639:
        /* 'BrtOleObject' */
        case 478:
        /* 'BrtPageSetup' */
        case 537:
        /* 'BrtPhoneticInfo' */
        case 477:
        /* 'BrtPrintOptions' */
        case 536:
        /* 'BrtRangeProtection' */
        case 1103:
        /* 'BrtRangeProtection14' */
        case 680:
        /* 'BrtRangeProtectionIso' */
        case 1104:
        /* 'BrtRangeProtectionIso14' */
        case 1024:
        /* 'BrtRwDescent' */
        case 663:
        /* 'BrtSheetCalcProp' */
        case 535:
        /* 'BrtSheetProtection' */
        case 678:
        /* 'BrtSheetProtectionIso' */
        case 504:
        /* 'BrtSlc' */
        case 1043:
        /* 'BrtSparkline' */
        case 428:
        /* 'BrtTable' */
        case 170:
        /* 'BrtTop10Filter' */
        case 3072:
        /* 'BrtUid' */
        case 50:
        /* 'BrtValueMeta' */
        case 2070:
        /* 'BrtWebExtension' */
        case 1045:
          break;
        case 35:
          v = !0;
          break;
        case 36:
          v = !1;
          break;
        case 37:
          v = !0;
          break;
        case 38:
          v = !1;
          break;
        default:
          if (!Te.T) {
            if (!v || s.WTF) throw new Error("Unexpected record 0x" + _e.toString(16));
          }
      }
  }, s), delete s.supbooks, delete s["!row"], !f["!ref"] && (l.s.r < 2e6 || o && (o.e.r > 0 || o.e.c > 0 || o.s.r > 0 || o.s.c > 0)) && (f["!ref"] = Ce(o || l)), s.sheetRows && f["!ref"]) {
    var ne = Ke(f["!ref"]);
    s.sheetRows <= +ne.e.r && (ne.e.r = s.sheetRows - 1, ne.e.r > l.e.r && (ne.e.r = l.e.r), ne.e.r < ne.s.r && (ne.s.r = ne.e.r), ne.e.c > l.e.c && (ne.e.c = l.e.c), ne.e.c < ne.s.c && (ne.s.c = ne.e.c), f["!fullref"] = f["!ref"], f["!ref"] = Ce(ne));
  }
  return M.length > 0 && (f["!merges"] = M), z.length > 0 && (f["!cols"] = z), ce.length > 0 && (f["!rows"] = ce), t["!id"][f["!legrel"]] && (f["!legdrawel"] = t["!id"][f["!legrel"]]), f;
}
function bx(e) {
  var a = [], r = e.match(/^<c:numCache>/), t;
  (e.match(/<c:pt idx="(\d*)"[^<>\/]*><c:v>([^<])<\/c:v><\/c:pt>/mg) || []).forEach(function(i) {
    var c = i.match(/<c:pt idx="(\d*)"[^<>\/]*><c:v>([^<]*)<\/c:v><\/c:pt>/);
    c && (a[+c[1]] = r ? +c[2] : c[2]);
  });
  var n = Se((ma(e, "c:formatCode") || ["", "General"])[1]);
  return (O0(e, "<c:f>", "</c:f>") || []).forEach(function(i) {
    t = i.replace(/<[^<>]*>/g, "");
  }), [a, n, t];
}
function Lx(e, a, r, t, n, i) {
  var c = i || { "!type": "chart" };
  if (!e) return i;
  var s = 0, f = 0, o = "A", l = { s: { r: 2e6, c: 2e6 }, e: { r: 0, c: 0 } };
  return (O0(e, "<c:numCache>", "</c:numCache>") || []).forEach(function(v) {
    var x = bx(v);
    l.s.r = l.s.c = 0, l.e.c = s, o = Pe(s), x[0].forEach(function(u, p) {
      c["!data"] ? (c["!data"][p] || (c["!data"][p] = []), c["!data"][p][s] = { t: "n", v: u, z: x[1] }) : c[o + Me(p)] = { t: "n", v: u, z: x[1] }, f = p;
    }), l.e.r < f && (l.e.r = f), ++s;
  }), s > 0 && (c["!ref"] = Ce(l)), c;
}
function Bx(e, a, r, t, n) {
  if (!e) return e;
  t || (t = { "!id": {} });
  var i = { "!type": "chart", "!drawel": null, "!rel": "" }, c, s = e.match(Es);
  return s && G0(s[0], i, n, r), (c = e.match(/drawing r:id="(.*?)"/)) && (i["!rel"] = c[1]), t["!id"][i["!rel"]] && (i["!drawel"] = t["!id"][i["!rel"]]), i;
}
function Mx(e, a) {
  e.l += 10;
  var r = vr(e);
  return { name: r };
}
function Ux(e, a, r, t, n) {
  if (!e) return e;
  t || (t = { "!id": {} });
  var i = { "!type": "chart", "!drawel": null, "!rel": "" }, c = !1;
  return ta(e, function(f, o, l) {
    switch (l) {
      case 550:
        i["!rel"] = f;
        break;
      case 651:
        n.Sheets[r] || (n.Sheets[r] = {}), f.name && (n.Sheets[r].CodeName = f.name);
        break;
      case 562:
      /* 'BrtBkHim' */
      case 652:
      /* 'BrtCsPageSetup' */
      case 669:
      /* 'BrtCsProtection' */
      case 679:
      /* 'BrtCsProtectionIso' */
      case 551:
      /* 'BrtLegacyDrawing' */
      case 552:
      /* 'BrtLegacyDrawingHF' */
      case 476:
      /* 'BrtMargins' */
      case 3072:
        break;
      case 35:
        c = !0;
        break;
      case 36:
        c = !1;
        break;
      case 37:
        break;
      case 38:
        break;
      default:
        if (!(o.T > 0)) {
          if (!(o.T < 0)) {
            if (!c || a.WTF) throw new Error("Unexpected record 0x" + l.toString(16));
          }
        }
    }
  }, a), t["!id"][i["!rel"]] && (i["!drawel"] = t["!id"][i["!rel"]]), i;
}
var ws = [
  ["allowRefreshQuery", !1, "bool"],
  ["autoCompressPictures", !0, "bool"],
  ["backupFile", !1, "bool"],
  ["checkCompatibility", !1, "bool"],
  ["CodeName", ""],
  ["date1904", !1, "bool"],
  ["defaultThemeVersion", 0, "int"],
  ["filterPrivacy", !1, "bool"],
  ["hidePivotFieldList", !1, "bool"],
  ["promptedSolutions", !1, "bool"],
  ["publishItems", !1, "bool"],
  ["refreshAllConnections", !1, "bool"],
  ["saveExternalLinkValues", !0, "bool"],
  ["showBorderUnselectedTables", !0, "bool"],
  ["showInkAnnotation", !0, "bool"],
  ["showObjects", "all"],
  ["showPivotChartFilter", !1, "bool"],
  ["updateLinks", "userSet"]
], Hx = [
  ["activeTab", 0, "int"],
  ["autoFilterDateGrouping", !0, "bool"],
  ["firstSheet", 0, "int"],
  ["minimized", !1, "bool"],
  ["showHorizontalScroll", !0, "bool"],
  ["showSheetTabs", !0, "bool"],
  ["showVerticalScroll", !0, "bool"],
  ["tabRatio", 600, "int"],
  ["visibility", "visible"]
  //window{Height,Width}, {x,y}Window
], Wx = [
  //['state', 'visible']
], Vx = [
  ["calcCompleted", "true"],
  ["calcMode", "auto"],
  ["calcOnSave", "true"],
  ["concurrentCalc", "true"],
  ["fullCalcOnLoad", "false"],
  ["fullPrecision", "true"],
  ["iterate", "false"],
  ["iterateCount", "100"],
  ["iterateDelta", "0.001"],
  ["refMode", "A1"]
];
function Xn(e, a) {
  for (var r = 0; r != e.length; ++r)
    for (var t = e[r], n = 0; n != a.length; ++n) {
      var i = a[n];
      if (t[i[0]] == null) t[i[0]] = i[1];
      else switch (i[2]) {
        case "bool":
          typeof t[i[0]] == "string" && (t[i[0]] = Be(t[i[0]]));
          break;
        case "int":
          typeof t[i[0]] == "string" && (t[i[0]] = parseInt(t[i[0]], 10));
          break;
      }
    }
}
function zn(e, a) {
  for (var r = 0; r != a.length; ++r) {
    var t = a[r];
    if (e[t[0]] == null) e[t[0]] = t[1];
    else switch (t[2]) {
      case "bool":
        typeof e[t[0]] == "string" && (e[t[0]] = Be(e[t[0]]));
        break;
      case "int":
        typeof e[t[0]] == "string" && (e[t[0]] = parseInt(e[t[0]], 10));
        break;
    }
  }
}
function Fs(e) {
  zn(e.WBProps, ws), zn(e.CalcPr, Vx), Xn(e.WBView, Hx), Xn(e.Sheets, Wx), Pa.date1904 = Be(e.WBProps.date1904);
}
var Gx = /* @__PURE__ */ ":][*?/\\".split("");
function $x(e, a) {
  try {
    if (e == "") throw new Error("Sheet name cannot be blank");
    if (e.length > 31) throw new Error("Sheet name cannot exceed 31 chars");
    if (e.charCodeAt(0) == 39 || e.charCodeAt(e.length - 1) == 39) throw new Error("Sheet name cannot start or end with apostrophe (')");
    if (e.toLowerCase() == "history") throw new Error("Sheet name cannot be 'History'");
    Gx.forEach(function(r) {
      if (e.indexOf(r) != -1)
        throw new Error("Sheet name cannot contain : \\ / ? * [ ]");
    });
  } catch (r) {
    throw r;
  }
  return !0;
}
var Xx = /<\w+:workbook/;
function zx(e, a) {
  if (!e) throw new Error("Could not find file");
  var r = (
    /*::(*/
    { AppVersion: {}, WBProps: {}, WBView: [], Sheets: [], CalcPr: {}, Names: [], xmlns: "" }
  ), t = !1, n = "xmlns", i = {}, c = 0;
  if (e.replace(or, function(f, o) {
    var l = le(f);
    switch (Hr(l[0])) {
      case "<?xml":
        break;
      /* 18.2.27 workbook CT_Workbook 1 */
      case "<workbook":
        f.match(Xx) && (n = "xmlns" + f.match(/<(\w+):/)[1]), r.xmlns = l[n];
        break;
      case "</workbook>":
        break;
      /* 18.2.13 fileVersion CT_FileVersion ? */
      case "<fileVersion":
        delete l[0], r.AppVersion = l;
        break;
      case "<fileVersion/>":
      case "</fileVersion>":
        break;
      /* 18.2.12 fileSharing CT_FileSharing ? */
      case "<fileSharing":
        break;
      case "<fileSharing/>":
        break;
      /* 18.2.28 workbookPr CT_WorkbookPr ? */
      case "<workbookPr":
      case "<workbookPr/>":
        ws.forEach(function(v) {
          if (l[v[0]] != null)
            switch (v[2]) {
              case "bool":
                r.WBProps[v[0]] = Be(l[v[0]]);
                break;
              case "int":
                r.WBProps[v[0]] = parseInt(l[v[0]], 10);
                break;
              default:
                r.WBProps[v[0]] = l[v[0]];
            }
        }), l.codeName && (r.WBProps.CodeName = Ue(l.codeName));
        break;
      case "</workbookPr>":
        break;
      /* 18.2.29 workbookProtection CT_WorkbookProtection ? */
      case "<workbookProtection":
        break;
      case "<workbookProtection/>":
        break;
      /* 18.2.1  bookViews CT_BookViews ? */
      case "<bookViews":
      case "<bookViews>":
      case "</bookViews>":
        break;
      /* 18.2.30   workbookView CT_BookView + */
      case "<workbookView":
      case "<workbookView/>":
        delete l[0], r.WBView.push(l);
        break;
      case "</workbookView>":
        break;
      /* 18.2.20 sheets CT_Sheets 1 */
      case "<sheets":
      case "<sheets>":
      case "</sheets>":
        break;
      // aggregate sheet
      /* 18.2.19   sheet CT_Sheet + */
      case "<sheet":
        switch (l.state) {
          case "hidden":
            l.Hidden = 1;
            break;
          case "veryHidden":
            l.Hidden = 2;
            break;
          default:
            l.Hidden = 0;
        }
        delete l.state, l.name = Se(Ue(l.name)), delete l[0], r.Sheets.push(l);
        break;
      case "</sheet>":
        break;
      /* 18.2.15 functionGroups CT_FunctionGroups ? */
      case "<functionGroups":
      case "<functionGroups/>":
        break;
      /* 18.2.14   functionGroup CT_FunctionGroup + */
      case "<functionGroup":
        break;
      /* 18.2.9  externalReferences CT_ExternalReferences ? */
      case "<externalReferences":
      case "</externalReferences>":
      case "<externalReferences>":
        break;
      /* 18.2.8    externalReference CT_ExternalReference + */
      case "<externalReference":
        break;
      /* 18.2.6  definedNames CT_DefinedNames ? */
      case "<definedNames/>":
        break;
      case "<definedNames>":
      case "<definedNames":
        t = !0;
        break;
      case "</definedNames>":
        t = !1;
        break;
      /* 18.2.5    definedName CT_DefinedName + */
      case "<definedName":
        i = {}, i.Name = Ue(l.name), l.comment && (i.Comment = l.comment), l.localSheetId && (i.Sheet = +l.localSheetId), Be(l.hidden || "0") && (i.Hidden = !0), c = o + f.length;
        break;
      case "</definedName>":
        i.Ref = Se(Ue(e.slice(c, o))), r.Names.push(i);
        break;
      case "<definedName/>":
        break;
      /* 18.2.2  calcPr CT_CalcPr ? */
      case "<calcPr":
        delete l[0], r.CalcPr = l;
        break;
      case "<calcPr/>":
        delete l[0], r.CalcPr = l;
        break;
      case "</calcPr>":
        break;
      /* 18.2.16 oleSize CT_OleSize ? (ref required) */
      case "<oleSize":
        break;
      /* 18.2.4  customWorkbookViews CT_CustomWorkbookViews ? */
      case "<customWorkbookViews>":
      case "</customWorkbookViews>":
      case "<customWorkbookViews":
        break;
      /* 18.2.3  customWorkbookView CT_CustomWorkbookView + */
      case "<customWorkbookView":
      case "</customWorkbookView>":
        break;
      /* 18.2.18 pivotCaches CT_PivotCaches ? */
      case "<pivotCaches>":
      case "</pivotCaches>":
      case "<pivotCaches":
        break;
      /* 18.2.17 pivotCache CT_PivotCache ? */
      case "<pivotCache":
        break;
      /* 18.2.21 smartTagPr CT_SmartTagPr ? */
      case "<smartTagPr":
      case "<smartTagPr/>":
        break;
      /* 18.2.23 smartTagTypes CT_SmartTagTypes ? */
      case "<smartTagTypes":
      case "<smartTagTypes>":
      case "</smartTagTypes>":
        break;
      /* 18.2.22 smartTagType CT_SmartTagType ? */
      case "<smartTagType":
        break;
      /* 18.2.24 webPublishing CT_WebPublishing ? */
      case "<webPublishing":
      case "<webPublishing/>":
        break;
      /* 18.2.11 fileRecoveryPr CT_FileRecoveryPr ? */
      case "<fileRecoveryPr":
      case "<fileRecoveryPr/>":
        break;
      /* 18.2.26 webPublishObjects CT_WebPublishObjects ? */
      case "<webPublishObjects>":
      case "<webPublishObjects":
      case "</webPublishObjects>":
        break;
      /* 18.2.25 webPublishObject CT_WebPublishObject ? */
      case "<webPublishObject":
        break;
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
      case "<extLst/>":
        break;
      /* 18.2.7  ext CT_Extension + */
      case "<ext":
        t = !0;
        break;
      //TODO: check with versions of excel
      case "</ext>":
        t = !1;
        break;
      /* Others */
      case "<ArchID":
        break;
      case "<AlternateContent":
      case "<AlternateContent>":
        t = !0;
        break;
      case "</AlternateContent>":
        t = !1;
        break;
      /* TODO */
      case "<revisionPtr":
        break;
      default:
        if (!t && a.WTF) throw new Error("unrecognized " + l[0] + " in workbook");
    }
    return f;
  }), xf.indexOf(r.xmlns) === -1) throw new Error("Unknown Namespace: " + r.xmlns);
  return Fs(r), r;
}
function Kx(e, a) {
  var r = {};
  return r.Hidden = e.read_shift(4), r.iTabID = e.read_shift(4), r.strRelID = g0(e), r.name = vr(e), r;
}
function Yx(e, a) {
  var r = {}, t = e.read_shift(4);
  r.defaultThemeVersion = e.read_shift(4);
  var n = a > 8 ? vr(e) : "";
  return n.length > 0 && (r.CodeName = n), r.autoCompressPictures = !!(t & 65536), r.backupFile = !!(t & 64), r.checkCompatibility = !!(t & 4096), r.date1904 = !!(t & 1), r.filterPrivacy = !!(t & 8), r.hidePivotFieldList = !!(t & 1024), r.promptedSolutions = !!(t & 16), r.publishItems = !!(t & 2048), r.refreshAllConnections = !!(t & 262144), r.saveExternalLinkValues = !!(t & 128), r.showBorderUnselectedTables = !!(t & 4), r.showInkAnnotation = !!(t & 32), r.showObjects = ["all", "placeholders", "none"][t >> 13 & 3], r.showPivotChartFilter = !!(t & 32768), r.updateLinks = ["userSet", "never", "always"][t >> 8 & 3], r;
}
function jx(e, a) {
  var r = {};
  return e.read_shift(4), r.ArchID = e.read_shift(4), e.l += a - 8, r;
}
function Jx(e, a, r) {
  var t = e.l + a, n = e.read_shift(4);
  e.l += 1;
  var i = e.read_shift(4), c = Nf(e), s, f = "";
  try {
    s = Lh(e, 0, r);
    try {
      f = Jt(e);
    } catch {
    }
  } catch {
    console.error("Could not parse defined name " + c);
  }
  n & 32 && (c = "_xlnm." + c), e.l = t;
  var o = { Name: c, Ptg: s, Flags: n };
  return i < 268435455 && (o.Sheet = i), f && (o.Comment = f), o;
}
function Zx(e, a) {
  var r = { AppVersion: {}, WBProps: {}, WBView: [], Sheets: [], CalcPr: {}, xmlns: "" }, t = [], n = !1;
  a || (a = {}), a.biff = 12;
  var i = [], c = [[]];
  return c.SheetNames = [], c.XTI = [], Gt[16] = { n: "BrtFRTArchID$", f: jx }, ta(e, function(f, o, l) {
    switch (l) {
      case 156:
        c.SheetNames.push(f.name), r.Sheets.push(f);
        break;
      case 153:
        r.WBProps = f;
        break;
      case 39:
        f.Sheet != null && (a.SID = f.Sheet), f.Ref = f.Ptg ? hr(f.Ptg, null, null, c, a) : "#REF!", delete a.SID, delete f.Ptg, i.push(f);
        break;
      case 1036:
        break;
      case 357:
      /* 'BrtSupSelf' */
      case 358:
      /* 'BrtSupSame' */
      case 355:
      /* 'BrtSupBookSrc' */
      case 667:
        c[0].length ? c.push([l, f]) : c[0] = [l, f], c[c.length - 1].XTI = [];
        break;
      case 362:
        c.length === 0 && (c[0] = [], c[0].XTI = []), c[c.length - 1].XTI = c[c.length - 1].XTI.concat(f), c.XTI = c.XTI.concat(f);
        break;
      case 361:
        break;
      case 2071:
      /* 'BrtAbsPath15' */
      case 158:
      /* 'BrtBookView' */
      case 143:
      /* 'BrtBeginBundleShs' */
      case 664:
      /* 'BrtBeginFnGroup' */
      case 353:
        break;
      /* case 'BrtModelTimeGroupingCalcCol' */
      case 3072:
      /* 'BrtUid' */
      case 3073:
      /* 'BrtRevisionPtr' */
      case 534:
      /* 'BrtBookProtection' */
      case 677:
      /* 'BrtBookProtectionIso' */
      case 157:
      /* 'BrtCalcProp' */
      case 610:
      /* 'BrtCrashRecErr' */
      case 2050:
      /* 'BrtDecoupledPivotCacheID' */
      case 155:
      /* 'BrtFileRecover' */
      case 548:
      /* 'BrtFileSharing' */
      case 676:
      /* 'BrtFileSharingIso' */
      case 128:
      /* 'BrtFileVersion' */
      case 665:
      /* 'BrtFnGroup' */
      case 2128:
      /* 'BrtModelRelationship' */
      case 2125:
      /* 'BrtModelTable' */
      case 549:
      /* 'BrtOleSize' */
      case 2053:
      /* 'BrtPivotTableRef' */
      case 596:
      /* 'BrtSmartTagType' */
      case 2076:
      /* 'BrtTableSlicerCacheID' */
      case 2075:
      /* 'BrtTableSlicerCacheIDs' */
      case 2082:
      /* 'BrtTimelineCachePivotCacheID' */
      case 397:
      /* 'BrtUserBookView' */
      case 154:
      /* 'BrtWbFactoid' */
      case 1117:
      /* 'BrtWbProp14' */
      case 553:
      /* 'BrtWebOpt' */
      case 2091:
        break;
      case 35:
        t.push(l), n = !0;
        break;
      case 36:
        t.pop(), n = !1;
        break;
      case 37:
        t.push(l), n = !0;
        break;
      case 38:
        t.pop(), n = !1;
        break;
      case 16:
        break;
      default:
        if (!o.T) {
          if (!n || a.WTF && t[t.length - 1] != 37 && t[t.length - 1] != 35) throw new Error("Unexpected record 0x" + l.toString(16));
        }
    }
  }, a), Fs(r), r.Names = i, r.supbooks = c, r;
}
function qx(e, a, r) {
  return a.slice(-4) === ".bin" ? Zx(e, r) : zx(e, r);
}
function Qx(e, a, r, t, n, i, c, s) {
  return a.slice(-4) === ".bin" ? Px(e, t, r, n, i, c, s) : Kh(e, t, r, n, i, c, s);
}
function ed(e, a, r, t, n, i, c, s) {
  return a.slice(-4) === ".bin" ? Ux(e, t, r, n, i) : Bx(e, t, r, n, i);
}
function rd(e, a, r, t, n, i, c, s) {
  return a.slice(-4) === ".bin" ? xu() : du();
}
function ad(e, a, r, t, n, i, c, s) {
  return a.slice(-4) === ".bin" ? uu() : hu();
}
function td(e, a, r, t) {
  return a.slice(-4) === ".bin" ? N1(e, r, t) : S1(e, r, t);
}
function nd(e, a, r) {
  return a.slice(-4) === ".bin" ? Yl(e, r) : zl(e, r);
}
function id(e, a, r) {
  return a.slice(-4) === ".bin" ? fu(e, r) : tu(e, r);
}
function sd(e, a, r) {
  return a.slice(-4) === ".bin" ? Q1(e) : Z1(e);
}
function cd(e, a, r, t) {
  return r.slice(-4) === ".bin" ? eu(e, a, r, t) : void 0;
}
function fd(e, a, r) {
  return a.slice(-4) === ".bin" ? j1(e, a, r) : J1(e, a, r);
}
var As = /\b((?:\w+:)?[\w]+)=((?:")([^"]*)(?:")|(?:')([^']*)(?:'))/g, ys = /\b((?:\w+:)?[\w]+)=((?:")(?:[^"]*)(?:")|(?:')(?:[^']*)(?:'))/;
function Gr(e, a) {
  var r = e.split(/\s+/), t = [];
  if (t[0] = r[0], r.length === 1) return t;
  var n = e.match(As), i, c, s, f;
  if (n) for (f = 0; f != n.length; ++f)
    i = n[f].match(ys), (c = i[1].indexOf(":")) === -1 ? t[i[1]] = i[2].slice(1, i[2].length - 1) : (i[1].slice(0, 6) === "xmlns:" ? s = "xmlns" + i[1].slice(6) : s = i[1].slice(c + 1), t[s] = i[2].slice(1, i[2].length - 1));
  return t;
}
function od(e) {
  var a = e.split(/\s+/), r = {};
  if (a.length === 1) return r;
  var t = e.match(As), n, i, c, s;
  if (t) for (s = 0; s != t.length; ++s)
    n = t[s].match(ys), (i = n[1].indexOf(":")) === -1 ? r[n[1]] = n[2].slice(1, n[2].length - 1) : (n[1].slice(0, 6) === "xmlns:" ? c = "xmlns" + n[1].slice(6) : c = n[1].slice(i + 1), r[c] = n[2].slice(1, n[2].length - 1));
  return r;
}
var rt;
function ld(e, a, r) {
  var t = rt[e] || Se(e);
  return t === "General" ? Ea(a) : Fr(t, a, { date1904: !!r });
}
function ud(e, a, r, t) {
  var n = t;
  switch ((r[0].match(/dt:dt="([\w.]+)"/) || ["", ""])[1]) {
    case "boolean":
      n = Be(t);
      break;
    case "i2":
    case "int":
      n = parseInt(t, 10);
      break;
    case "r4":
    case "float":
      n = parseFloat(t);
      break;
    case "date":
    case "dateTime.tz":
      n = fr(t);
      break;
    case "i8":
    case "string":
    case "fixed":
    case "uuid":
    case "bin.base64":
      break;
    default:
      throw new Error("bad custprop:" + r[0]);
  }
  e[Se(a)] = n;
}
function hd(e, a, r, t) {
  if (e.t !== "z") {
    if (!r || r.cellText !== !1) try {
      e.t === "e" ? e.w = e.w || Ar[e.v] : a === "General" ? e.t === "n" ? (e.v | 0) === e.v ? e.w = e.v.toString(10) : e.w = nt(e.v) : e.w = Ea(e.v) : e.w = ld(a || "General", e.v, t);
    } catch (c) {
      if (r.WTF) throw c;
    }
    try {
      var n = rt[a] || a || "General";
      if (r.cellNF && (e.z = n), r.cellDates && e.t == "n" && Ur(n)) {
        var i = jr(e.v + (t ? 1462 : 0));
        i && (e.t = "d", e.v = new Date(Date.UTC(i.y, i.m - 1, i.d, i.H, i.M, i.S, i.u)));
      }
    } catch (c) {
      if (r.WTF) throw c;
    }
  }
}
function xd(e, a, r) {
  if (r.cellStyles && a.Interior) {
    var t = a.Interior;
    t.Pattern && (t.patternType = E1[t.Pattern] || t.Pattern);
  }
  e[a.ID] = a;
}
function dd(e, a, r, t, n, i, c, s, f, o, l) {
  var v = "General", x = t.StyleID, u = {};
  o = o || {};
  var p = [], _ = 0;
  for (x === void 0 && s && (x = s.StyleID), x === void 0 && c && (x = c.StyleID); i[x] !== void 0; ) {
    var d = i[x];
    if (d.nf && (v = d.nf), d.Interior && p.push(d.Interior), !d.Parent) break;
    x = d.Parent;
  }
  switch (r.Type) {
    case "Boolean":
      t.t = "b", t.v = Be(e);
      break;
    case "String":
      t.t = "s", t.r = hn(Se(e)), t.v = e.indexOf("<") > -1 ? Se(a || e).replace(/<[^<>]*>/g, "") : t.r;
      break;
    case "DateTime":
      e.slice(-1) != "Z" && (e += "Z"), t.v = ar(fr(e, l), l), t.v !== t.v && (t.v = Se(e)), (!v || v == "General") && (v = "yyyy-mm-dd");
    /* falls through */
    case "Number":
      t.v === void 0 && (t.v = +e), t.t || (t.t = "n");
      break;
    case "Error":
      t.t = "e", t.v = sr[e], o.cellText !== !1 && (t.w = e);
      break;
    default:
      e == "" && a == "" ? t.t = "z" : (t.t = "s", t.v = hn(a || e));
      break;
  }
  if (hd(t, v, o, l), o.cellFormula !== !1)
    if (t.Formula) {
      var h = Se(t.Formula);
      h.charCodeAt(0) == 61 && (h = h.slice(1)), t.f = Ta(h, n), delete t.Formula, t.ArrayRange == "RC" ? t.F = Ta("RC:RC", n) : t.ArrayRange && (t.F = Ta(t.ArrayRange, n), f.push([Ke(t.F), t.F]));
    } else
      for (_ = 0; _ < f.length; ++_)
        n.r >= f[_][0].s.r && n.r <= f[_][0].e.r && n.c >= f[_][0].s.c && n.c <= f[_][0].e.c && (t.F = f[_][1]);
  o.cellStyles && (p.forEach(function(E) {
    !u.patternType && E.patternType && (u.patternType = E.patternType);
  }), t.s = u), t.StyleID !== void 0 && (t.ixfe = t.StyleID);
}
function vd(e) {
  return $i.indexOf("_xlnm." + e) > -1 ? "_xlnm." + e : e;
}
function pd(e) {
  e.t = e.v || "", e.t = e.t.replace(/\r\n/g, `
`).replace(/\r/g, `
`), e.v = e.w = e.ixfe = void 0;
}
function h0(e, a) {
  var r = a || {};
  vi();
  var t = Ga(jt(e));
  (r.type == "binary" || r.type == "array" || r.type == "base64") && (t = Ue(t));
  var n = t.slice(0, 1024).toLowerCase(), i = !1;
  if (n = n.replace(/".*?"/g, ""), (n.indexOf(">") & 1023) > Math.min(n.indexOf(",") & 1023, n.indexOf(";") & 1023)) {
    var c = er(r);
    return c.type = "string", st.to_workbook(t, c);
  }
  if (n.indexOf("<?xml") == -1 && ["html", "table", "head", "meta", "script", "style", "div"].forEach(function(xe) {
    n.indexOf("<" + xe) >= 0 && (i = !0);
  }), i) return Ad(t, r);
  rt = {
    "General Number": "General",
    "General Date": ge[22],
    "Long Date": "dddd, mmmm dd, yyyy",
    "Medium Date": ge[15],
    "Short Date": ge[14],
    "Long Time": ge[19],
    "Medium Time": ge[18],
    "Short Time": ge[20],
    Currency: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
    Fixed: ge[2],
    Standard: ge[4],
    Percent: ge[10],
    Scientific: ge[11],
    "Yes/No": '"Yes";"Yes";"No";@',
    "True/False": '"True";"True";"False";@',
    "On/Off": '"Yes";"Yes";"No";@'
  };
  var s, f = [], o, l = {}, v = [], x = {}, u = "";
  r.dense && (x["!data"] = []);
  var p = {}, _ = {}, d = Gr('<Data ss:Type="String">'), h = 0, E = 0, g = 0, C = { s: { r: 2e6, c: 2e6 }, e: { r: 0, c: 0 } }, P = {}, M = {}, I = "", N = 0, O = [], B = {}, b = {}, G = 0, z = [], ce = [], j = {}, he = [], J, ne = !1, pe = [], X = [], Te = {}, _e = 0, de = 0, fe = { Sheets: [], WBProps: { date1904: !1 } }, ke = {};
  qe.lastIndex = 0, t = ut(t, "<!--", "-->");
  for (var me = ""; s = qe.exec(t); ) switch (s[3] = (me = s[3]).toLowerCase()) {
    case "data":
      if (me == "data") {
        if (s[1] === "/") {
          if ((o = f.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
        } else s[0].charAt(s[0].length - 2) !== "/" && f.push([s[3], !0]);
        break;
      }
      if (f[f.length - 1][1]) break;
      s[1] === "/" ? dd(t.slice(h, s.index), I, d, f[f.length - 1][0] == /*"Comment"*/
      "comment" ? j : p, { c: E, r: g }, P, he[E], _, pe, r, fe.WBProps.date1904) : (I = "", d = Gr(s[0]), h = s.index + s[0].length);
      break;
    case "cell":
      if (s[1] === "/")
        if (ce.length > 0 && (p.c = ce), (!r.sheetRows || r.sheetRows > g) && p.v !== void 0 && (r.dense ? (x["!data"][g] || (x["!data"][g] = []), x["!data"][g][E] = p) : x[Pe(E) + Me(g)] = p), p.HRef && (p.l = { Target: Se(p.HRef) }, p.HRefScreenTip && (p.l.Tooltip = p.HRefScreenTip), delete p.HRef, delete p.HRefScreenTip), (p.MergeAcross || p.MergeDown) && (_e = E + (parseInt(p.MergeAcross, 10) | 0), de = g + (parseInt(p.MergeDown, 10) | 0), (_e > E || de > g) && O.push({ s: { c: E, r: g }, e: { c: _e, r: de } })), !r.sheetStubs)
          p.MergeAcross ? E = _e + 1 : ++E;
        else if (p.MergeAcross || p.MergeDown) {
          for (var Fe = E; Fe <= _e; ++Fe)
            for (var y = g; y <= de; ++y)
              (Fe > E || y > g) && (r.dense ? (x["!data"][y] || (x["!data"][y] = []), x["!data"][y][Fe] = { t: "z" }) : x[Pe(Fe) + Me(y)] = { t: "z" });
          E = _e + 1;
        } else ++E;
      else
        p = od(s[0]), p.Index && (E = +p.Index - 1), E < C.s.c && (C.s.c = E), E > C.e.c && (C.e.c = E), s[0].slice(-2) === "/>" && ++E, ce = [];
      break;
    case "row":
      s[1] === "/" || s[0].slice(-2) === "/>" ? (g < C.s.r && (C.s.r = g), g > C.e.r && (C.e.r = g), s[0].slice(-2) === "/>" && (_ = Gr(s[0]), _.Index && (g = +_.Index - 1)), E = 0, ++g) : (_ = Gr(s[0]), _.Index && (g = +_.Index - 1), Te = {}, (_.AutoFitHeight == "0" || _.Height) && (Te.hpx = parseInt(_.Height, 10), Te.hpt = ls(Te.hpx), X[g] = Te), _.Hidden == "1" && (Te.hidden = !0, X[g] = Te));
      break;
    case "worksheet":
      if (s[1] === "/") {
        if ((o = f.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
        v.push(u), C.s.r <= C.e.r && C.s.c <= C.e.c && (x["!ref"] = Ce(C), r.sheetRows && r.sheetRows <= C.e.r && (x["!fullref"] = x["!ref"], C.e.r = r.sheetRows - 1, x["!ref"] = Ce(C))), O.length && (x["!merges"] = O), he.length > 0 && (x["!cols"] = he), X.length > 0 && (x["!rows"] = X), l[u] = x;
      } else
        C = { s: { r: 2e6, c: 2e6 }, e: { r: 0, c: 0 } }, g = E = 0, f.push([s[3], !1]), o = Gr(s[0]), u = Se(o.Name), x = {}, r.dense && (x["!data"] = []), O = [], pe = [], X = [], ke = { name: u, Hidden: 0 }, fe.Sheets.push(ke);
      break;
    case "table":
      if (s[1] === "/") {
        if ((o = f.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
      } else {
        if (s[0].slice(-2) == "/>") break;
        f.push([s[3], !1]), he = [], ne = !1;
      }
      break;
    case "style":
      s[1] === "/" ? xd(P, M, r) : M = Gr(s[0]);
      break;
    case "numberformat":
      M.nf = Se(Gr(s[0]).Format || "General"), rt[M.nf] && (M.nf = rt[M.nf]);
      for (var L = 0; L != 392 && ge[L] != M.nf; ++L) ;
      if (L == 392) {
        for (L = 57; L != 392; ++L) if (ge[L] == null) {
          ga(M.nf, L);
          break;
        }
      }
      break;
    case "column":
      if (f[f.length - 1][0] !== /*'Table'*/
      "table" || s[1] === "/") break;
      if (J = Gr(s[0]), J.Hidden && (J.hidden = !0, delete J.Hidden), J.Width && (J.wpx = parseInt(J.Width, 10)), !ne && J.wpx > 10) {
        ne = !0, _r = fs;
        for (var R = 0; R < he.length; ++R) he[R] && Ma(he[R]);
      }
      ne && Ma(J), he[J.Index - 1 || he.length] = J;
      for (var D = 0; D < +J.Span; ++D) he[he.length] = er(J);
      break;
    case "namedrange":
      if (s[1] === "/") break;
      fe.Names || (fe.Names = []);
      var Y = le(s[0]), w = {
        Name: vd(Y.Name),
        Ref: Ta(Y.RefersTo.slice(1), { r: 0, c: 0 })
      };
      fe.Sheets.length > 0 && (w.Sheet = fe.Sheets.length - 1), fe.Names.push(w);
      break;
    case "namedcell":
      break;
    case "b":
      break;
    case "i":
      break;
    case "u":
      break;
    case "s":
      break;
    case "em":
      break;
    case "h2":
      break;
    case "h3":
      break;
    case "sub":
      break;
    case "sup":
      break;
    case "span":
      break;
    case "alignment":
      break;
    case "borders":
      break;
    case "border":
      break;
    case "font":
      if (s[0].slice(-2) === "/>") break;
      s[1] === "/" ? I += t.slice(N, s.index) : N = s.index + s[0].length;
      break;
    case "interior":
      if (!r.cellStyles) break;
      M.Interior = Gr(s[0]);
      break;
    case "protection":
      break;
    case "author":
    case "title":
    case "description":
    case "created":
    case "keywords":
    case "subject":
    case "category":
    case "company":
    case "lastauthor":
    case "lastsaved":
    case "lastprinted":
    case "version":
    case "revision":
    case "totaltime":
    case "hyperlinkbase":
    case "manager":
    case "contentstatus":
    case "identifier":
    case "language":
    case "appname":
      if (s[0].slice(-2) === "/>") break;
      s[1] === "/" ? to(B, me, t.slice(G, s.index)) : G = s.index + s[0].length;
      break;
    case "paragraphs":
      break;
    case "styles":
    case "workbook":
      if (s[1] === "/") {
        if ((o = f.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
      } else f.push([s[3], !1]);
      break;
    case "comment":
      if (s[1] === "/") {
        if ((o = f.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
        pd(j), ce.push(j);
      } else
        f.push([s[3], !1]), o = Gr(s[0]), Be(o.ShowAlways || "0") || (ce.hidden = !0), j = { a: o.Author };
      break;
    case "autofilter":
      if (s[1] === "/") {
        if ((o = f.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
      } else if (s[0].charAt(s[0].length - 2) !== "/") {
        var te = Gr(s[0]);
        x["!autofilter"] = { ref: Ta(te.Range).replace(/\$/g, "") }, f.push([s[3], !0]);
      }
      break;
    case "name":
      break;
    case "datavalidation":
      if (s[1] === "/") {
        if ((o = f.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
      } else
        s[0].charAt(s[0].length - 2) !== "/" && f.push([s[3], !0]);
      break;
    case "pixelsperinch":
      break;
    case "componentoptions":
    case "documentproperties":
    case "customdocumentproperties":
    case "officedocumentsettings":
    case "pivottable":
    case "pivotcache":
    case "names":
    case "mapinfo":
    case "pagebreaks":
    case "querytable":
    case "sorting":
    case "schema":
    //case 'data' /*case 'data'*/:
    case "conditionalformatting":
    case "smarttagtype":
    case "smarttags":
    case "excelworkbook":
    case "workbookoptions":
    case "worksheetoptions":
      if (s[1] === "/") {
        if ((o = f.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
      } else s[0].charAt(s[0].length - 2) !== "/" && f.push([s[3], !0]);
      break;
    case "null":
      break;
    default:
      if (f.length == 0 && s[3] == "document" || f.length == 0 && s[3] == "uof") return Zn(t, r);
      var ie = !0;
      switch (f[f.length - 1][0]) {
        /* OfficeDocumentSettings */
        case "officedocumentsettings":
          switch (s[3]) {
            case "allowpng":
              break;
            case "removepersonalinformation":
              break;
            case "downloadcomponents":
              break;
            case "locationofcomponents":
              break;
            case "colors":
              break;
            case "color":
              break;
            case "index":
              break;
            case "rgb":
              break;
            case "targetscreensize":
              break;
            case "readonlyrecommended":
              break;
            default:
              ie = !1;
          }
          break;
        /* ComponentOptions */
        case "componentoptions":
          switch (s[3]) {
            case "toolbar":
              break;
            case "hideofficelogo":
              break;
            case "spreadsheetautofit":
              break;
            case "label":
              break;
            case "caption":
              break;
            case "maxheight":
              break;
            case "maxwidth":
              break;
            case "nextsheetnumber":
              break;
            default:
              ie = !1;
          }
          break;
        /* ExcelWorkbook */
        case "excelworkbook":
          switch (s[3]) {
            case "date1904":
              fe.WBProps.date1904 = !0;
              break;
            case "hidehorizontalscrollbar":
              break;
            case "hideverticalscrollbar":
              break;
            case "hideworkbooktabs":
              break;
            case "windowheight":
              break;
            case "windowwidth":
              break;
            case "windowtopx":
              break;
            case "windowtopy":
              break;
            case "tabratio":
              break;
            case "protectstructure":
              break;
            case "protectwindow":
              break;
            case "protectwindows":
              break;
            case "activesheet":
              break;
            case "displayinknotes":
              break;
            case "firstvisiblesheet":
              break;
            case "supbook":
              break;
            case "sheetname":
              break;
            case "sheetindex":
              break;
            case "sheetindexfirst":
              break;
            case "sheetindexlast":
              break;
            case "dll":
              break;
            case "acceptlabelsinformulas":
              break;
            case "donotsavelinkvalues":
              break;
            case "iteration":
              break;
            case "maxiterations":
              break;
            case "maxchange":
              break;
            case "path":
              break;
            case "xct":
              break;
            case "count":
              break;
            case "selectedsheets":
              break;
            case "calculation":
              break;
            case "uncalced":
              break;
            case "startupprompt":
              break;
            case "crn":
              break;
            case "externname":
              break;
            case "formula":
              break;
            case "colfirst":
              break;
            case "collast":
              break;
            case "wantadvise":
              break;
            case "boolean":
              break;
            case "error":
              break;
            case "text":
              break;
            case "ole":
              break;
            case "noautorecover":
              break;
            case "publishobjects":
              break;
            case "donotcalculatebeforesave":
              break;
            case "number":
              break;
            case "refmoder1c1":
              break;
            case "embedsavesmarttags":
              break;
            default:
              ie = !1;
          }
          break;
        /* WorkbookOptions */
        case "workbookoptions":
          switch (s[3]) {
            case "owcversion":
              break;
            case "height":
              break;
            case "width":
              break;
            default:
              ie = !1;
          }
          break;
        /* WorksheetOptions */
        case "worksheetoptions":
          switch (s[3]) {
            case "visible":
              if (s[0].slice(-2) !== "/>") if (s[1] === "/") switch (t.slice(G, s.index)) {
                case "SheetHidden":
                  ke.Hidden = 1;
                  break;
                case "SheetVeryHidden":
                  ke.Hidden = 2;
                  break;
              }
              else G = s.index + s[0].length;
              break;
            case "header":
              x["!margins"] || et(x["!margins"] = {}, "xlml"), isNaN(+le(s[0]).Margin) || (x["!margins"].header = +le(s[0]).Margin);
              break;
            case "footer":
              x["!margins"] || et(x["!margins"] = {}, "xlml"), isNaN(+le(s[0]).Margin) || (x["!margins"].footer = +le(s[0]).Margin);
              break;
            case "pagemargins":
              var Q = le(s[0]);
              x["!margins"] || et(x["!margins"] = {}, "xlml"), isNaN(+Q.Top) || (x["!margins"].top = +Q.Top), isNaN(+Q.Left) || (x["!margins"].left = +Q.Left), isNaN(+Q.Right) || (x["!margins"].right = +Q.Right), isNaN(+Q.Bottom) || (x["!margins"].bottom = +Q.Bottom);
              break;
            case "displayrighttoleft":
              fe.Views || (fe.Views = []), fe.Views[0] || (fe.Views[0] = {}), fe.Views[0].RTL = !0;
              break;
            case "freezepanes":
              break;
            case "frozennosplit":
              break;
            case "splithorizontal":
            case "splitvertical":
              break;
            case "donotdisplaygridlines":
              break;
            case "activerow":
              break;
            case "activecol":
              break;
            case "toprowbottompane":
              break;
            case "leftcolumnrightpane":
              break;
            case "unsynced":
              break;
            case "print":
              break;
            case "printerrors":
              break;
            case "panes":
              break;
            case "scale":
              break;
            case "pane":
              break;
            case "number":
              break;
            case "layout":
              break;
            case "pagesetup":
              break;
            case "selected":
              break;
            case "protectobjects":
              break;
            case "enableselection":
              break;
            case "protectscenarios":
              break;
            case "validprinterinfo":
              break;
            case "horizontalresolution":
              break;
            case "verticalresolution":
              break;
            case "numberofcopies":
              break;
            case "activepane":
              break;
            case "toprowvisible":
              break;
            case "leftcolumnvisible":
              break;
            case "fittopage":
              break;
            case "rangeselection":
              break;
            case "papersizeindex":
              break;
            case "pagelayoutzoom":
              break;
            case "pagebreakzoom":
              break;
            case "filteron":
              break;
            case "fitwidth":
              break;
            case "fitheight":
              break;
            case "commentslayout":
              break;
            case "zoom":
              break;
            case "lefttoright":
              break;
            case "gridlines":
              break;
            case "allowsort":
              break;
            case "allowfilter":
              break;
            case "allowinsertrows":
              break;
            case "allowdeleterows":
              break;
            case "allowinsertcols":
              break;
            case "allowdeletecols":
              break;
            case "allowinserthyperlinks":
              break;
            case "allowformatcells":
              break;
            case "allowsizecols":
              break;
            case "allowsizerows":
              break;
            case "nosummaryrowsbelowdetail":
              x["!outline"] || (x["!outline"] = {}), x["!outline"].above = !0;
              break;
            case "tabcolorindex":
              break;
            case "donotdisplayheadings":
              break;
            case "showpagelayoutzoom":
              break;
            case "nosummarycolumnsrightdetail":
              x["!outline"] || (x["!outline"] = {}), x["!outline"].left = !0;
              break;
            case "blackandwhite":
              break;
            case "donotdisplayzeros":
              break;
            case "displaypagebreak":
              break;
            case "rowcolheadings":
              break;
            case "donotdisplayoutline":
              break;
            case "noorientation":
              break;
            case "allowusepivottables":
              break;
            case "zeroheight":
              break;
            case "viewablerange":
              break;
            case "selection":
              break;
            case "protectcontents":
              break;
            default:
              ie = !1;
          }
          break;
        /* PivotTable */
        case "pivottable":
        case "pivotcache":
          switch (s[3]) {
            case "immediateitemsondrop":
              break;
            case "showpagemultipleitemlabel":
              break;
            case "compactrowindent":
              break;
            case "location":
              break;
            case "pivotfield":
              break;
            case "orientation":
              break;
            case "layoutform":
              break;
            case "layoutsubtotallocation":
              break;
            case "layoutcompactrow":
              break;
            case "position":
              break;
            case "pivotitem":
              break;
            case "datatype":
              break;
            case "datafield":
              break;
            case "sourcename":
              break;
            case "parentfield":
              break;
            case "ptlineitems":
              break;
            case "ptlineitem":
              break;
            case "countofsameitems":
              break;
            case "item":
              break;
            case "itemtype":
              break;
            case "ptsource":
              break;
            case "cacheindex":
              break;
            case "consolidationreference":
              break;
            case "filename":
              break;
            case "reference":
              break;
            case "nocolumngrand":
              break;
            case "norowgrand":
              break;
            case "blanklineafteritems":
              break;
            case "hidden":
              break;
            case "subtotal":
              break;
            case "basefield":
              break;
            case "mapchilditems":
              break;
            case "function":
              break;
            case "refreshonfileopen":
              break;
            case "printsettitles":
              break;
            case "mergelabels":
              break;
            case "defaultversion":
              break;
            case "refreshname":
              break;
            case "refreshdate":
              break;
            case "refreshdatecopy":
              break;
            case "versionlastrefresh":
              break;
            case "versionlastupdate":
              break;
            case "versionupdateablemin":
              break;
            case "versionrefreshablemin":
              break;
            case "calculation":
              break;
            default:
              ie = !1;
          }
          break;
        /* PageBreaks */
        case "pagebreaks":
          switch (s[3]) {
            case "colbreaks":
              break;
            case "colbreak":
              break;
            case "rowbreaks":
              break;
            case "rowbreak":
              break;
            case "colstart":
              break;
            case "colend":
              break;
            case "rowend":
              break;
            default:
              ie = !1;
          }
          break;
        /* AutoFilter */
        case "autofilter":
          switch (s[3]) {
            case "autofiltercolumn":
              break;
            case "autofiltercondition":
              break;
            case "autofilterand":
              break;
            case "autofilteror":
              break;
            default:
              ie = !1;
          }
          break;
        /* QueryTable */
        case "querytable":
          switch (s[3]) {
            case "id":
              break;
            case "autoformatfont":
              break;
            case "autoformatpattern":
              break;
            case "querysource":
              break;
            case "querytype":
              break;
            case "enableredirections":
              break;
            case "refreshedinxl9":
              break;
            case "urlstring":
              break;
            case "htmltables":
              break;
            case "connection":
              break;
            case "commandtext":
              break;
            case "refreshinfo":
              break;
            case "notitles":
              break;
            case "nextid":
              break;
            case "columninfo":
              break;
            case "overwritecells":
              break;
            case "donotpromptforfile":
              break;
            case "textwizardsettings":
              break;
            case "source":
              break;
            case "number":
              break;
            case "decimal":
              break;
            case "thousandseparator":
              break;
            case "trailingminusnumbers":
              break;
            case "formatsettings":
              break;
            case "fieldtype":
              break;
            case "delimiters":
              break;
            case "tab":
              break;
            case "comma":
              break;
            case "autoformatname":
              break;
            case "versionlastedit":
              break;
            case "versionlastrefresh":
              break;
            default:
              ie = !1;
          }
          break;
        case "datavalidation":
          switch (s[3]) {
            case "range":
              break;
            case "type":
              break;
            case "min":
              break;
            case "max":
              break;
            case "sort":
              break;
            case "descending":
              break;
            case "order":
              break;
            case "casesensitive":
              break;
            case "value":
              break;
            case "errorstyle":
              break;
            case "errormessage":
              break;
            case "errortitle":
              break;
            case "inputmessage":
              break;
            case "inputtitle":
              break;
            case "combohide":
              break;
            case "inputhide":
              break;
            case "condition":
              break;
            case "qualifier":
              break;
            case "useblank":
              break;
            case "value1":
              break;
            case "value2":
              break;
            case "format":
              break;
            case "cellrangelist":
              break;
            default:
              ie = !1;
          }
          break;
        case "sorting":
        case "conditionalformatting":
          switch (s[3]) {
            case "range":
              break;
            case "type":
              break;
            case "min":
              break;
            case "max":
              break;
            case "sort":
              break;
            case "descending":
              break;
            case "order":
              break;
            case "casesensitive":
              break;
            case "value":
              break;
            case "errorstyle":
              break;
            case "errormessage":
              break;
            case "errortitle":
              break;
            case "cellrangelist":
              break;
            case "inputmessage":
              break;
            case "inputtitle":
              break;
            case "combohide":
              break;
            case "inputhide":
              break;
            case "condition":
              break;
            case "qualifier":
              break;
            case "useblank":
              break;
            case "value1":
              break;
            case "value2":
              break;
            case "format":
              break;
            default:
              ie = !1;
          }
          break;
        /* MapInfo (schema) */
        case "mapinfo":
        case "schema":
        case "data":
          switch (s[3]) {
            case "map":
              break;
            case "entry":
              break;
            case "range":
              break;
            case "xpath":
              break;
            case "field":
              break;
            case "xsdtype":
              break;
            case "filteron":
              break;
            case "aggregate":
              break;
            case "elementtype":
              break;
            case "attributetype":
              break;
            /* These are from xsd (XML Schema Definition) */
            case "schema":
            case "element":
            case "complextype":
            case "datatype":
            case "all":
            case "attribute":
            case "extends":
              break;
            case "row":
              break;
            default:
              ie = !1;
          }
          break;
        /* SmartTags (can be anything) */
        case "smarttags":
          break;
        default:
          ie = !1;
          break;
      }
      if (ie || s[3].match(/!\[CDATA/)) break;
      if (!f[f.length - 1][1]) throw "Unrecognized tag: " + s[3] + "|" + f.join("|");
      if (f[f.length - 1][0] === /*'CustomDocumentProperties'*/
      "customdocumentproperties") {
        if (s[0].slice(-2) === "/>") break;
        s[1] === "/" ? ud(b, me, z, t.slice(G, s.index)) : (z = s, G = s.index + s[0].length);
        break;
      }
      if (r.WTF) throw "Unrecognized tag: " + s[3] + "|" + f.join("|");
  }
  var ve = {};
  return !r.bookSheets && !r.bookProps && (ve.Sheets = l), ve.SheetNames = v, ve.Workbook = fe, ve.SSF = er(ge), ve.Props = B, ve.Custprops = b, ve.bookType = "xlml", ve;
}
function T0(e, a) {
  switch ($0(a = a || {}), a.type || "base64") {
    case "base64":
      return h0(Rr(e), a);
    case "binary":
    case "buffer":
    case "file":
      return h0(e, a);
    case "array":
      return h0(aa(e), a);
  }
}
function gd(e) {
  var a = {}, r = e.content;
  if (r.l = 28, a.AnsiUserType = r.read_shift(0, "lpstr-ansi"), a.AnsiClipboardFormat = Lf(r), r.length - r.l <= 4) return a;
  var t = r.read_shift(4);
  if (t == 0 || t > 40 || (r.l -= 4, a.Reserved1 = r.read_shift(0, "lpstr-ansi"), r.length - r.l <= 4) || (t = r.read_shift(4), t !== 1907505652) || (a.UnicodeClipboardFormat = Bf(r), t = r.read_shift(4), t == 0 || t > 40)) return a;
  r.l -= 4, a.Reserved2 = r.read_shift(0, "lpwstr");
}
var md = [60, 1084, 2066, 2165, 2175];
function _d(e, a, r, t, n) {
  var i = t, c = [], s = r.slice(r.l, r.l + i);
  if (n && n.enc && n.enc.insitu && s.length > 0) switch (e) {
    case 9:
    case 521:
    case 1033:
    case 2057:
    case 47:
    case 405:
    case 225:
    case 406:
    case 312:
    case 404:
    case 10:
      break;
    case 133:
      break;
    default:
      n.enc.insitu(s);
  }
  c.push(s), r.l += i;
  for (var f = Qr(r, r.l), o = E0[f], l = 0; o != null && md.indexOf(f) > -1; )
    i = Qr(r, r.l + 2), l = r.l + 4, f == 2066 ? l += 4 : (f == 2165 || f == 2175) && (l += 12), s = r.slice(l, r.l + 4 + i), c.push(s), r.l += 4 + i, o = E0[f = Qr(r, r.l)];
  var v = ia(c);
  rr(v, 0);
  var x = 0;
  v.lens = [];
  for (var u = 0; u < c.length; ++u)
    v.lens.push(x), x += c[u].length;
  if (v.length < t) throw "XLS Record 0x" + e.toString(16) + " Truncated: " + v.length + " < " + t;
  return a.f(v, v.length, n);
}
function Kr(e, a, r) {
  if (e.t !== "z" && e.XF) {
    var t = 0;
    try {
      t = e.z || e.XF.numFmtId || 0, a.cellNF && e.z == null && (e.z = ge[t]);
    } catch (i) {
      if (a.WTF) throw i;
    }
    if (!a || a.cellText !== !1) try {
      e.t === "e" ? e.w = e.w || Ar[e.v] : t === 0 || t == "General" ? e.t === "n" ? (e.v | 0) === e.v ? e.w = e.v.toString(10) : e.w = nt(e.v) : e.w = Ea(e.v) : e.w = Fr(t, e.v, { date1904: !!r, dateNF: a && a.dateNF });
    } catch (i) {
      if (a.WTF) throw i;
    }
    if (a.cellDates && t && e.t == "n" && Ur(ge[t] || String(t))) {
      var n = jr(e.v + (r ? 1462 : 0));
      n && (e.t = "d", e.v = new Date(Date.UTC(n.y, n.m - 1, n.d, n.H, n.M, n.S, n.u)));
    }
  }
}
function Dt(e, a, r) {
  return { v: e, ixfe: a, t: r };
}
function Td(e, a) {
  var r = { opts: {} }, t = {}, n = {};
  a.dense && (n["!data"] = []);
  var i = {}, c = {}, s = null, f = [], o = "", l = {}, v, x = "", u, p, _, d, h = {}, E = [], g, C, P = [], M = [], I = { Sheets: [], WBProps: { date1904: !1 }, Views: [{}] }, N = {}, O = !1, B = function(se) {
    return se < 8 ? _a[se] : se < 64 && M[se - 8] || _a[se];
  }, b = function(se, be) {
    var Ye = se.XF.data;
    if (!(!Ye || !Ye.patternType || !be || !be.cellStyles)) {
      se.s = {}, se.s.patternType = Ye.patternType;
      var je;
      (je = ct(B(Ye.icvFore))) && (se.s.fgColor = { rgb: je }), (je = ct(B(Ye.icvBack))) && (se.s.bgColor = { rgb: je });
    }
  }, G = function(se, be, Ye) {
    if (!(!O && _e > 1) && !(Ye.sheetRows && se.r >= Ye.sheetRows)) {
      if (Ye.cellStyles && be.XF && be.XF.data && b(be, Ye), delete be.ixfe, delete be.XF, v = se, x = Ne(se), (!c || !c.s || !c.e) && (c = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }), se.r < c.s.r && (c.s.r = se.r), se.c < c.s.c && (c.s.c = se.c), se.r + 1 > c.e.r && (c.e.r = se.r + 1), se.c + 1 > c.e.c && (c.e.c = se.c + 1), Ye.cellFormula && be.f) {
        for (var je = 0; je < E.length; ++je)
          if (!(E[je][0].s.c > se.c || E[je][0].s.r > se.r) && !(E[je][0].e.c < se.c || E[je][0].e.r < se.r)) {
            be.F = Ce(E[je][0]), (E[je][0].s.c != se.c || E[je][0].s.r != se.r) && delete be.f, be.f && (be.f = "" + hr(E[je][1], c, se, X, z));
            break;
          }
      }
      Ye.dense ? (n["!data"][se.r] || (n["!data"][se.r] = []), n["!data"][se.r][se.c] = be) : n[x] = be;
    }
  }, z = {
    enc: !1,
    // encrypted
    sbcch: 0,
    // cch in the preceding SupBook
    snames: [],
    // sheetnames
    sharedf: h,
    // shared formulae by address
    arrayf: E,
    // array formulae array
    rrtabid: [],
    // RRTabId
    lastuser: "",
    // Last User from WriteAccess
    biff: 8,
    // BIFF version
    codepage: 0,
    // CP from CodePage record
    winlocked: 0,
    // fLockWn from WinProtect
    cellStyles: !!a && !!a.cellStyles,
    WTF: !!a && !!a.wtf
  };
  a.password && (z.password = a.password);
  var ce, j = [], he = [], J = [], ne = [], pe = !1, X = [];
  X.SheetNames = z.snames, X.sharedf = z.sharedf, X.arrayf = z.arrayf, X.names = [], X.XTI = [];
  var Te = 0, _e = 0, de = 0, fe = [], ke = [], me;
  z.codepage = 1200, $r(1200);
  for (var Fe = !1; e.l < e.length - 1; ) {
    var y = e.l, L = e.read_shift(2);
    if (L === 0 && Te === 10) break;
    var R = e.l === e.length ? 0 : e.read_shift(2), D = E0[L];
    if (_e == 0 && [9, 521, 1033, 2057].indexOf(L) == -1) break;
    if (D && D.f) {
      if (a.bookSheets && Te === 133 && L !== 133)
        break;
      if (Te = L, D.r === 2 || D.r == 12) {
        var Y = e.read_shift(2);
        if (R -= 2, !z.enc && Y !== L && ((Y & 255) << 8 | Y >> 8) !== L) throw new Error("rt mismatch: " + Y + "!=" + L);
        D.r == 12 && (e.l += 10, R -= 10);
      }
      var w = {};
      if (L === 10 ? w = /*::(*/
      D.f(e, R, z) : w = /*::(*/
      _d(L, D, e, R, z), _e == 0 && [9, 521, 1033, 2057].indexOf(Te) === -1) continue;
      switch (L) {
        case 34:
          r.opts.Date1904 = I.WBProps.date1904 = w;
          break;
        case 134:
          r.opts.WriteProtect = !0;
          break;
        case 47:
          if (z.enc || (e.l = 0), z.enc = w, !a.password) throw new Error("File is password-protected");
          if (w.valid == null) throw new Error("Encryption scheme unsupported");
          if (!w.valid) throw new Error("Password is incorrect");
          break;
        case 92:
          z.lastuser = w;
          break;
        case 66:
          var te = Number(w);
          switch (te) {
            case 21010:
              te = 1200;
              break;
            case 32768:
              te = 1e4;
              break;
            case 32769:
              te = 1252;
              break;
          }
          $r(z.codepage = te), Fe = !0;
          break;
        case 317:
          z.rrtabid = w;
          break;
        case 25:
          z.winlocked = w;
          break;
        case 439:
          r.opts.RefreshAll = w;
          break;
        case 12:
          r.opts.CalcCount = w;
          break;
        case 16:
          r.opts.CalcDelta = w;
          break;
        case 17:
          r.opts.CalcIter = w;
          break;
        case 13:
          r.opts.CalcMode = w;
          break;
        case 14:
          r.opts.CalcPrecision = w;
          break;
        case 95:
          r.opts.CalcSaveRecalc = w;
          break;
        case 15:
          z.CalcRefMode = w;
          break;
        // TODO: implement R1C1
        case 2211:
          r.opts.FullCalc = w;
          break;
        case 129:
          w.fDialog && (n["!type"] = "dialog"), w.fBelow || ((n["!outline"] || (n["!outline"] = {})).above = !0), w.fRight || ((n["!outline"] || (n["!outline"] = {})).left = !0);
          break;
        // TODO
        case 67:
        /* BIFF2XF */
        case 579:
        /* BIFF3XF */
        case 1091:
        /* BIFF4XF */
        case 224:
          P.push(w);
          break;
        case 430:
          X.push([w]), X[X.length - 1].XTI = [];
          break;
        case 35:
        case 547:
          X[X.length - 1].push(w);
          break;
        case 24:
        case 536:
          me = {
            Name: w.Name,
            Ref: hr(w.rgce, c, null, X, z)
          }, w.itab > 0 && (me.Sheet = w.itab - 1), X.names.push(me), X[0] || (X[0] = [], X[0].XTI = []), X[X.length - 1].push(w), w.Name == "_xlnm._FilterDatabase" && w.itab > 0 && w.rgce && w.rgce[0] && w.rgce[0][0] && w.rgce[0][0][0] == "PtgArea3d" && (ke[w.itab - 1] = { ref: Ce(w.rgce[0][0][1][2]) });
          break;
        case 22:
          z.ExternCount = w;
          break;
        case 23:
          X.length == 0 && (X[0] = [], X[0].XTI = []), X[X.length - 1].XTI = X[X.length - 1].XTI.concat(w), X.XTI = X.XTI.concat(w);
          break;
        case 2196:
          if (z.biff < 8) break;
          me != null && (me.Comment = w[1]);
          break;
        case 18:
          n["!protect"] = w;
          break;
        /* for sheet or book */
        case 19:
          w !== 0 && z.WTF && console.error("Password verifier: " + w);
          break;
        case 133:
          i[z.biff == 4 ? z.snames.length : w.pos] = w, z.snames.push(w.name);
          break;
        case 10:
          {
            if (--_e ? !O : O) break;
            if (c.e) {
              if (c.e.r > 0 && c.e.c > 0) {
                if (c.e.r--, c.e.c--, n["!ref"] = Ce(c), a.sheetRows && a.sheetRows <= c.e.r) {
                  var ie = c.e.r;
                  c.e.r = a.sheetRows - 1, n["!fullref"] = n["!ref"], n["!ref"] = Ce(c), c.e.r = ie;
                }
                c.e.r++, c.e.c++;
              }
              j.length > 0 && (n["!merges"] = j), he.length > 0 && (n["!objects"] = he), J.length > 0 && (n["!cols"] = J), ne.length > 0 && (n["!rows"] = ne), I.Sheets.push(N);
            }
            o === "" ? l = n : t[o] = n, n = {}, a.dense && (n["!data"] = []);
          }
          break;
        case 9:
        case 521:
        case 1033:
        case 2057:
          {
            if (z.biff === 8 && (z.biff = {
              9: 2,
              521: 3,
              1033: 4
            }[L] || {
              512: 2,
              768: 3,
              1024: 4,
              1280: 5,
              1536: 8,
              2: 2,
              7: 2
            }[w.BIFFVer] || 8), z.biffguess = w.BIFFVer == 0, w.BIFFVer == 0 && w.dt == 4096 && (z.biff = 5, Fe = !0, $r(z.codepage = 28591)), z.biff == 4 && w.dt & 256 && (O = !0), z.biff == 8 && w.BIFFVer == 0 && w.dt == 16 && (z.biff = 2), _e++ && !O) break;
            if (n = {}, a.dense && (n["!data"] = []), z.biff < 8 && !Fe && (Fe = !0, $r(z.codepage = a.codepage || 1252)), z.biff == 4 && O)
              o = (i[z.snames.indexOf(o) + 1] || { name: "" }).name;
            else if (z.biff < 5 || w.BIFFVer == 0 && w.dt == 4096) {
              o === "" && (o = "Sheet1"), c = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } };
              var Q = { pos: e.l - R, name: o };
              i[Q.pos] = Q, z.snames.push(o);
            } else o = (i[y] || { name: "" }).name;
            w.dt == 32 && (n["!type"] = "chart"), w.dt == 64 && (n["!type"] = "macro"), j = [], he = [], z.arrayf = E = [], J = [], ne = [], pe = !1, N = { Hidden: (i[y] || { hs: 0 }).hs, name: o };
          }
          break;
        case 515:
        case 3:
        case 2:
          n["!type"] == "chart" && (a.dense ? (n["!data"][w.r] || [])[w.c] : n[Pe(w.c) + Me(w.r)]) && ++w.c, g = { ixfe: w.ixfe, XF: P[w.ixfe] || {}, v: w.val, t: "n" }, de > 0 && (g.z = g.XF && g.XF.numFmtId && fe[g.XF.numFmtId] || fe[g.ixfe >> 8 & 63]), Kr(g, a, r.opts.Date1904), G({ c: w.c, r: w.r }, g, a);
          break;
        case 5:
        case 517:
          g = { ixfe: w.ixfe, XF: P[w.ixfe], v: w.val, t: w.t }, de > 0 && (g.z = g.XF && g.XF.numFmtId && fe[g.XF.numFmtId] || fe[g.ixfe >> 8 & 63]), Kr(g, a, r.opts.Date1904), G({ c: w.c, r: w.r }, g, a);
          break;
        case 638:
          g = { ixfe: w.ixfe, XF: P[w.ixfe], v: w.rknum, t: "n" }, de > 0 && (g.z = g.XF && g.XF.numFmtId && fe[g.XF.numFmtId] || fe[g.ixfe >> 8 & 63]), Kr(g, a, r.opts.Date1904), G({ c: w.c, r: w.r }, g, a);
          break;
        case 189:
          for (var ve = w.c; ve <= w.C; ++ve) {
            var xe = w.rkrec[ve - w.c][0];
            g = { ixfe: xe, XF: P[xe], v: w.rkrec[ve - w.c][1], t: "n" }, de > 0 && (g.z = g.XF && g.XF.numFmtId && fe[g.XF.numFmtId] || fe[g.ixfe >> 8 & 63]), Kr(g, a, r.opts.Date1904), G({ c: ve, r: w.r }, g, a);
          }
          break;
        case 6:
        case 518:
        case 1030:
          {
            if (w.val == "String") {
              s = w;
              break;
            }
            if (g = Dt(w.val, w.cell.ixfe, w.tt), g.XF = P[g.ixfe], a.cellFormula) {
              var Ee = w.formula;
              if (Ee && Ee[0] && Ee[0][0] && Ee[0][0][0] == "PtgExp") {
                var Le = Ee[0][0][1][0], He = Ee[0][0][1][1], $e = Ne({ r: Le, c: He });
                h[$e] ? g.f = "" + hr(w.formula, c, w.cell, X, z) : g.F = ((a.dense ? (n["!data"][Le] || [])[He] : n[$e]) || {}).F;
              } else g.f = "" + hr(w.formula, c, w.cell, X, z);
            }
            de > 0 && (g.z = g.XF && g.XF.numFmtId && fe[g.XF.numFmtId] || fe[g.ixfe >> 8 & 63]), Kr(g, a, r.opts.Date1904), G(w.cell, g, a), s = w;
          }
          break;
        case 7:
        case 519:
          if (s)
            s.val = w, g = Dt(w, s.cell.ixfe, "s"), g.XF = P[g.ixfe], a.cellFormula && (g.f = "" + hr(s.formula, c, s.cell, X, z)), de > 0 && (g.z = g.XF && g.XF.numFmtId && fe[g.XF.numFmtId] || fe[g.ixfe >> 8 & 63]), Kr(g, a, r.opts.Date1904), G(s.cell, g, a), s = null;
          else throw new Error("String record expects Formula");
          break;
        case 33:
        case 545:
          {
            E.push(w);
            var ue = Ne(w[0].s);
            if (u = a.dense ? (n["!data"][w[0].s.r] || [])[w[0].s.c] : n[ue], a.cellFormula && u) {
              if (!s || !ue || !u) break;
              u.f = "" + hr(w[1], c, w[0], X, z), u.F = Ce(w[0]);
            }
          }
          break;
        case 1212:
          {
            if (!a.cellFormula) break;
            if (x) {
              if (!s) break;
              h[Ne(s.cell)] = w[0], u = a.dense ? (n["!data"][s.cell.r] || [])[s.cell.c] : n[Ne(s.cell)], (u || {}).f = "" + hr(w[0], c, v, X, z);
            }
          }
          break;
        case 253:
          g = Dt(f[w.isst].t, w.ixfe, "s"), f[w.isst].h && (g.h = f[w.isst].h), g.XF = P[g.ixfe], de > 0 && (g.z = g.XF && g.XF.numFmtId && fe[g.XF.numFmtId] || fe[g.ixfe >> 8 & 63]), Kr(g, a, r.opts.Date1904), G({ c: w.c, r: w.r }, g, a);
          break;
        case 513:
          a.sheetStubs && (g = { ixfe: w.ixfe, XF: P[w.ixfe], t: "z" }, de > 0 && (g.z = g.XF && g.XF.numFmtId && fe[g.XF.numFmtId] || fe[g.ixfe >> 8 & 63]), Kr(g, a, r.opts.Date1904), G({ c: w.c, r: w.r }, g, a));
          break;
        case 190:
          if (a.sheetStubs)
            for (var De = w.c; De <= w.C; ++De) {
              var re = w.ixfe[De - w.c];
              g = { ixfe: re, XF: P[re], t: "z" }, de > 0 && (g.z = g.XF && g.XF.numFmtId && fe[g.XF.numFmtId] || fe[g.ixfe >> 8 & 63]), Kr(g, a, r.opts.Date1904), G({ c: De, r: w.r }, g, a);
            }
          break;
        case 214:
        case 516:
        case 4:
          g = Dt(w.val, w.ixfe, "s"), g.XF = P[g.ixfe], de > 0 && (g.z = g.XF && g.XF.numFmtId && fe[g.XF.numFmtId] || fe[g.ixfe >> 8 & 63]), Kr(g, a, r.opts.Date1904), G({ c: w.c, r: w.r }, g, a);
          break;
        case 0:
        case 512:
          _e === 1 && (c = w);
          break;
        case 252:
          f = w;
          break;
        case 1054:
          if (z.biff >= 3 && z.biff <= 4) {
            fe[de++] = w[1];
            for (var yr = 0; yr < de + 163 && ge[yr] != w[1]; ++yr) ;
            yr >= 163 && ga(w[1], de + 163);
          } else ga(w[1], w[0]);
          break;
        case 30:
          {
            fe[de++] = w;
            for (var gr = 0; gr < de + 163 && ge[gr] != w; ++gr) ;
            gr >= 163 && ga(w, de + 163);
          }
          break;
        case 229:
          j = j.concat(w);
          break;
        case 93:
          he[w.cmo[0]] = z.lastobj = w;
          break;
        case 438:
          z.lastobj.TxO = w;
          break;
        case 127:
          z.lastobj.ImData = w;
          break;
        case 440:
          for (d = w[0].s.r; d <= w[0].e.r; ++d)
            for (_ = w[0].s.c; _ <= w[0].e.c; ++_)
              u = a.dense ? (n["!data"][d] || [])[_] : n[Ne({ c: _, r: d })], u && (u.l = w[1]);
          break;
        case 2048:
          for (d = w[0].s.r; d <= w[0].e.r; ++d)
            for (_ = w[0].s.c; _ <= w[0].e.c; ++_)
              u = a.dense ? (n["!data"][d] || [])[_] : n[Ne({ c: _, r: d })], u && u.l && (u.l.Tooltip = w[1]);
          break;
        case 28:
          {
            if (u = a.dense ? (n["!data"][w[0].r] || [])[w[0].c] : n[Ne(w[0])], u || (a.dense ? (n["!data"][w[0].r] || (n["!data"][w[0].r] = []), u = n["!data"][w[0].r][w[0].c] = { t: "z" }) : u = n[Ne(w[0])] = { t: "z" }, c.e.r = Math.max(c.e.r, w[0].r), c.s.r = Math.min(c.s.r, w[0].r), c.e.c = Math.max(c.e.c, w[0].c), c.s.c = Math.min(c.s.c, w[0].c)), u.c || (u.c = []), z.biff <= 5 && z.biff >= 2) p = { a: "SheetJ5", t: w[1] };
            else {
              var We = he[w[2]];
              p = { a: w[1], t: We.TxO.t }, w[3] != null && !(w[3] & 2) && (u.c.hidden = !0);
            }
            u.c.push(p);
          }
          break;
        case 2173:
          X1(P[w.ixfe], w.ext);
          break;
        case 125:
          {
            if (!z.cellStyles) break;
            for (; w.e >= w.s; )
              J[w.e--] = { width: w.w / 256, level: w.level || 0, hidden: !!(w.flags & 1) }, pe || (pe = !0, H0(w.w / 256)), Ma(J[w.e + 1]);
          }
          break;
        case 520:
          {
            var Vr = {};
            w.level != null && (ne[w.r] = Vr, Vr.level = w.level), w.hidden && (ne[w.r] = Vr, Vr.hidden = !0), w.hpt && (ne[w.r] = Vr, Vr.hpt = w.hpt, Vr.hpx = ft(w.hpt));
          }
          break;
        case 38:
        case 39:
        case 40:
        case 41:
          n["!margins"] || et(n["!margins"] = {}), n["!margins"][{ 38: "left", 39: "right", 40: "top", 41: "bottom" }[L]] = w;
          break;
        case 161:
          n["!margins"] || et(n["!margins"] = {}), n["!margins"].header = w.header, n["!margins"].footer = w.footer;
          break;
        case 574:
          w.RTL && (I.Views[0].RTL = !0);
          break;
        case 146:
          M = w;
          break;
        case 2198:
          ce = w;
          break;
        case 140:
          C = w;
          break;
        case 442:
          o ? N.CodeName = w || N.name : I.WBProps.CodeName = w || "ThisWorkbook";
          break;
      }
    } else
      D || console.error("Missing Info for XLS Record 0x" + L.toString(16)), e.l += R;
  }
  return r.SheetNames = Br(i).sort(function(Er, se) {
    return Number(Er) - Number(se);
  }).map(function(Er) {
    return i[Er].name;
  }), a.bookSheets || (r.Sheets = t), !r.SheetNames.length && l["!ref"] ? (r.SheetNames.push("Sheet1"), r.Sheets && (r.Sheets.Sheet1 = l)) : r.Preamble = l, r.Sheets && ke.forEach(function(Er, se) {
    r.Sheets[r.SheetNames[se]]["!autofilter"] = Er;
  }), r.Strings = f, r.SSF = er(ge), z.enc && (r.Encryption = z.enc), ce && (r.Themes = ce), r.Metadata = {}, C !== void 0 && (r.Metadata.Country = C), X.names.length > 0 && (I.Names = X.names), r.Workbook = I, r;
}
var Kn = {
  SI: "e0859ff2f94f6810ab9108002b27b3d9",
  DSI: "02d5cdd59c2e1b10939708002b2cf9ae",
  UDI: "05d5cdd59c2e1b10939708002b2cf9ae"
};
function Ed(e, a, r) {
  var t = Oe.find(e, "/!DocumentSummaryInformation");
  if (t && t.size > 0) try {
    var n = Dn(t, Gf, Kn.DSI);
    for (var i in n) a[i] = n[i];
  } catch (o) {
    if (r.WTF) throw o;
  }
  var c = Oe.find(e, "/!SummaryInformation");
  if (c && c.size > 0) try {
    var s = Dn(c, $f, Kn.SI);
    for (var f in s) a[f] == null && (a[f] = s[f]);
  } catch (o) {
    if (r.WTF) throw o;
  }
  a.HeadingPairs && a.TitlesOfParts && (zi(a.HeadingPairs, a.TitlesOfParts, a, r), delete a.HeadingPairs, delete a.TitlesOfParts);
}
function Ss(e, a) {
  a || (a = {}), $0(a), ni(), a.codepage && F0(a.codepage);
  var r, t;
  if (e.FullPaths) {
    if (Oe.find(e, "/encryption")) throw new Error("File is password-protected");
    r = Oe.find(e, "!CompObj"), t = Oe.find(e, "/Workbook") || Oe.find(e, "/Book");
  } else {
    switch (a.type) {
      case "base64":
        e = Dr(Rr(e));
        break;
      case "binary":
        e = Dr(e);
        break;
      case "buffer":
        break;
      case "array":
        Array.isArray(e) || (e = Array.prototype.slice.call(e));
        break;
    }
    rr(e, 0), t = { content: e };
  }
  var n, i;
  if (r && gd(r), a.bookProps && !a.bookSheets) n = {};
  else {
    var c = ye ? "buffer" : "array";
    if (t && t.content) n = Td(t.content, a);
    else if ((i = Oe.find(e, "PerfectOffice_MAIN")) && i.content) n = qa.to_workbook(i.content, (a.type = c, a));
    else if ((i = Oe.find(e, "NativeContent_MAIN")) && i.content) n = qa.to_workbook(i.content, (a.type = c, a));
    else throw (i = Oe.find(e, "MN0")) && i.content ? new Error("Unsupported Works 4 for Mac file") : new Error("Cannot find Workbook stream");
    a.bookVBA && e.FullPaths && Oe.find(e, "/_VBA_PROJECT_CUR/VBA/dir") && (n.vbaraw = lu(e));
  }
  var s = {};
  return e.FullPaths && Ed(
    /*::((*/
    e,
    s,
    a
  ), n.Props = n.Custprops = s, a.bookFiles && (n.cfb = e), n;
}
var Gt = {
  0: {
    /* n:"BrtRowHdr", */
    f: ax
  },
  1: {
    /* n:"BrtCellBlank", */
    f: sx
  },
  2: {
    /* n:"BrtCellRk", */
    f: vx
  },
  3: {
    /* n:"BrtCellError", */
    f: lx
  },
  4: {
    /* n:"BrtCellBool", */
    f: fx
  },
  5: {
    /* n:"BrtCellReal", */
    f: dx
  },
  6: {
    /* n:"BrtCellSt", */
    f: mx
  },
  7: {
    /* n:"BrtCellIsst", */
    f: hx
  },
  8: {
    /* n:"BrtFmlaString", */
    f: wx
  },
  9: {
    /* n:"BrtFmlaNum", */
    f: kx
  },
  10: {
    /* n:"BrtFmlaBool", */
    f: Tx
  },
  11: {
    /* n:"BrtFmlaError", */
    f: Ex
  },
  12: {
    /* n:"BrtShortBlank", */
    f: cx
  },
  13: {
    /* n:"BrtShortRk", */
    f: px
  },
  14: {
    /* n:"BrtShortError", */
    f: ux
  },
  15: {
    /* n:"BrtShortBool", */
    f: ox
  },
  16: {
    /* n:"BrtShortReal", */
    f: ks
  },
  17: {
    /* n:"BrtShortSt", */
    f: _x
  },
  18: {
    /* n:"BrtShortIsst", */
    f: xx
  },
  19: {
    /* n:"BrtSSTItem", */
    f: L0
  },
  20: {
    /* n:"BrtPCDIMissing" */
  },
  21: {
    /* n:"BrtPCDINumber" */
  },
  22: {
    /* n:"BrtPCDIBoolean" */
  },
  23: {
    /* n:"BrtPCDIError" */
  },
  24: {
    /* n:"BrtPCDIString" */
  },
  25: {
    /* n:"BrtPCDIDatetime" */
  },
  26: {
    /* n:"BrtPCDIIndex" */
  },
  27: {
    /* n:"BrtPCDIAMissing" */
  },
  28: {
    /* n:"BrtPCDIANumber" */
  },
  29: {
    /* n:"BrtPCDIABoolean" */
  },
  30: {
    /* n:"BrtPCDIAError" */
  },
  31: {
    /* n:"BrtPCDIAString" */
  },
  32: {
    /* n:"BrtPCDIADatetime" */
  },
  33: {
    /* n:"BrtPCRRecord" */
  },
  34: {
    /* n:"BrtPCRRecordDt" */
  },
  35: {
    /* n:"BrtFRTBegin", */
    T: 1
  },
  36: {
    /* n:"BrtFRTEnd", */
    T: -1
  },
  37: {
    /* n:"BrtACBegin", */
    T: 1
  },
  38: {
    /* n:"BrtACEnd", */
    T: -1
  },
  39: {
    /* n:"BrtName", */
    f: Jx
  },
  40: {
    /* n:"BrtIndexRowBlock" */
  },
  42: {
    /* n:"BrtIndexBlock" */
  },
  43: {
    /* n:"BrtFont", */
    f: D1
  },
  44: {
    /* n:"BrtFmt", */
    f: C1
  },
  45: {
    /* n:"BrtFill", */
    f: I1
  },
  46: {
    /* n:"BrtBorder", */
    f: R1
  },
  47: {
    /* n:"BrtXF", */
    f: O1
  },
  48: {
    /* n:"BrtStyle" */
  },
  49: {
    /* n:"BrtCellMeta", */
    f: Df
  },
  50: {
    /* n:"BrtValueMeta" */
  },
  51: {
    /* n:"BrtMdb" */
    f: K1
  },
  52: {
    /* n:"BrtBeginFmd", */
    T: 1
  },
  53: {
    /* n:"BrtEndFmd", */
    T: -1
  },
  54: {
    /* n:"BrtBeginMdx", */
    T: 1
  },
  55: {
    /* n:"BrtEndMdx", */
    T: -1
  },
  56: {
    /* n:"BrtBeginMdxTuple", */
    T: 1
  },
  57: {
    /* n:"BrtEndMdxTuple", */
    T: -1
  },
  58: {
    /* n:"BrtMdxMbrIstr" */
  },
  59: {
    /* n:"BrtStr" */
  },
  60: {
    /* n:"BrtColInfo", */
    f: ts
  },
  62: {
    /* n:"BrtCellRString", */
    f: gx
  },
  63: {
    /* n:"BrtCalcChainItem$", */
    f: q1
  },
  64: {
    /* n:"BrtDVal", */
    f: Rx
  },
  65: {
    /* n:"BrtSxvcellNum" */
  },
  66: {
    /* n:"BrtSxvcellStr" */
  },
  67: {
    /* n:"BrtSxvcellBool" */
  },
  68: {
    /* n:"BrtSxvcellErr" */
  },
  69: {
    /* n:"BrtSxvcellDate" */
  },
  70: {
    /* n:"BrtSxvcellNil" */
  },
  128: {
    /* n:"BrtFileVersion" */
  },
  129: {
    /* n:"BrtBeginSheet", */
    T: 1
  },
  130: {
    /* n:"BrtEndSheet", */
    T: -1
  },
  131: {
    /* n:"BrtBeginBook", */
    T: 1,
    f: pr,
    p: 0
  },
  132: {
    /* n:"BrtEndBook", */
    T: -1
  },
  133: {
    /* n:"BrtBeginWsViews", */
    T: 1
  },
  134: {
    /* n:"BrtEndWsViews", */
    T: -1
  },
  135: {
    /* n:"BrtBeginBookViews", */
    T: 1
  },
  136: {
    /* n:"BrtEndBookViews", */
    T: -1
  },
  137: {
    /* n:"BrtBeginWsView", */
    T: 1,
    f: Ox
  },
  138: {
    /* n:"BrtEndWsView", */
    T: -1
  },
  139: {
    /* n:"BrtBeginCsViews", */
    T: 1
  },
  140: {
    /* n:"BrtEndCsViews", */
    T: -1
  },
  141: {
    /* n:"BrtBeginCsView", */
    T: 1
  },
  142: {
    /* n:"BrtEndCsView", */
    T: -1
  },
  143: {
    /* n:"BrtBeginBundleShs", */
    T: 1
  },
  144: {
    /* n:"BrtEndBundleShs", */
    T: -1
  },
  145: {
    /* n:"BrtBeginSheetData", */
    T: 1
  },
  146: {
    /* n:"BrtEndSheetData", */
    T: -1
  },
  147: {
    /* n:"BrtWsProp", */
    f: ix
  },
  148: {
    /* n:"BrtWsDim", */
    f: tx,
    p: 16
  },
  151: {
    /* n:"BrtPane", */
    f: yx
  },
  152: {
    /* n:"BrtSel" */
  },
  153: {
    /* n:"BrtWbProp", */
    f: Yx
  },
  154: {
    /* n:"BrtWbFactoid" */
  },
  155: {
    /* n:"BrtFileRecover" */
  },
  156: {
    /* n:"BrtBundleSh", */
    f: Kx
  },
  157: {
    /* n:"BrtCalcProp" */
  },
  158: {
    /* n:"BrtBookView" */
  },
  159: {
    /* n:"BrtBeginSst", */
    T: 1,
    f: Kl
  },
  160: {
    /* n:"BrtEndSst", */
    T: -1
  },
  161: {
    /* n:"BrtBeginAFilter", */
    T: 1,
    f: Sa
  },
  162: {
    /* n:"BrtEndAFilter", */
    T: -1
  },
  163: {
    /* n:"BrtBeginFilterColumn", */
    T: 1
  },
  164: {
    /* n:"BrtEndFilterColumn", */
    T: -1
  },
  165: {
    /* n:"BrtBeginFilters", */
    T: 1
  },
  166: {
    /* n:"BrtEndFilters", */
    T: -1
  },
  167: {
    /* n:"BrtFilter" */
  },
  168: {
    /* n:"BrtColorFilter" */
  },
  169: {
    /* n:"BrtIconFilter" */
  },
  170: {
    /* n:"BrtTop10Filter" */
  },
  171: {
    /* n:"BrtDynamicFilter" */
  },
  172: {
    /* n:"BrtBeginCustomFilters", */
    T: 1
  },
  173: {
    /* n:"BrtEndCustomFilters", */
    T: -1
  },
  174: {
    /* n:"BrtCustomFilter" */
  },
  175: {
    /* n:"BrtAFilterDateGroupItem" */
  },
  176: {
    /* n:"BrtMergeCell", */
    f: Fx
  },
  177: {
    /* n:"BrtBeginMergeCells", */
    T: 1
  },
  178: {
    /* n:"BrtEndMergeCells", */
    T: -1
  },
  179: {
    /* n:"BrtBeginPivotCacheDef", */
    T: 1
  },
  180: {
    /* n:"BrtEndPivotCacheDef", */
    T: -1
  },
  181: {
    /* n:"BrtBeginPCDFields", */
    T: 1
  },
  182: {
    /* n:"BrtEndPCDFields", */
    T: -1
  },
  183: {
    /* n:"BrtBeginPCDField", */
    T: 1
  },
  184: {
    /* n:"BrtEndPCDField", */
    T: -1
  },
  185: {
    /* n:"BrtBeginPCDSource", */
    T: 1
  },
  186: {
    /* n:"BrtEndPCDSource", */
    T: -1
  },
  187: {
    /* n:"BrtBeginPCDSRange", */
    T: 1
  },
  188: {
    /* n:"BrtEndPCDSRange", */
    T: -1
  },
  189: {
    /* n:"BrtBeginPCDFAtbl", */
    T: 1
  },
  190: {
    /* n:"BrtEndPCDFAtbl", */
    T: -1
  },
  191: {
    /* n:"BrtBeginPCDIRun", */
    T: 1
  },
  192: {
    /* n:"BrtEndPCDIRun", */
    T: -1
  },
  193: {
    /* n:"BrtBeginPivotCacheRecords", */
    T: 1
  },
  194: {
    /* n:"BrtEndPivotCacheRecords", */
    T: -1
  },
  195: {
    /* n:"BrtBeginPCDHierarchies", */
    T: 1
  },
  196: {
    /* n:"BrtEndPCDHierarchies", */
    T: -1
  },
  197: {
    /* n:"BrtBeginPCDHierarchy", */
    T: 1
  },
  198: {
    /* n:"BrtEndPCDHierarchy", */
    T: -1
  },
  199: {
    /* n:"BrtBeginPCDHFieldsUsage", */
    T: 1
  },
  200: {
    /* n:"BrtEndPCDHFieldsUsage", */
    T: -1
  },
  201: {
    /* n:"BrtBeginExtConnection", */
    T: 1
  },
  202: {
    /* n:"BrtEndExtConnection", */
    T: -1
  },
  203: {
    /* n:"BrtBeginECDbProps", */
    T: 1
  },
  204: {
    /* n:"BrtEndECDbProps", */
    T: -1
  },
  205: {
    /* n:"BrtBeginECOlapProps", */
    T: 1
  },
  206: {
    /* n:"BrtEndECOlapProps", */
    T: -1
  },
  207: {
    /* n:"BrtBeginPCDSConsol", */
    T: 1
  },
  208: {
    /* n:"BrtEndPCDSConsol", */
    T: -1
  },
  209: {
    /* n:"BrtBeginPCDSCPages", */
    T: 1
  },
  210: {
    /* n:"BrtEndPCDSCPages", */
    T: -1
  },
  211: {
    /* n:"BrtBeginPCDSCPage", */
    T: 1
  },
  212: {
    /* n:"BrtEndPCDSCPage", */
    T: -1
  },
  213: {
    /* n:"BrtBeginPCDSCPItem", */
    T: 1
  },
  214: {
    /* n:"BrtEndPCDSCPItem", */
    T: -1
  },
  215: {
    /* n:"BrtBeginPCDSCSets", */
    T: 1
  },
  216: {
    /* n:"BrtEndPCDSCSets", */
    T: -1
  },
  217: {
    /* n:"BrtBeginPCDSCSet", */
    T: 1
  },
  218: {
    /* n:"BrtEndPCDSCSet", */
    T: -1
  },
  219: {
    /* n:"BrtBeginPCDFGroup", */
    T: 1
  },
  220: {
    /* n:"BrtEndPCDFGroup", */
    T: -1
  },
  221: {
    /* n:"BrtBeginPCDFGItems", */
    T: 1
  },
  222: {
    /* n:"BrtEndPCDFGItems", */
    T: -1
  },
  223: {
    /* n:"BrtBeginPCDFGRange", */
    T: 1
  },
  224: {
    /* n:"BrtEndPCDFGRange", */
    T: -1
  },
  225: {
    /* n:"BrtBeginPCDFGDiscrete", */
    T: 1
  },
  226: {
    /* n:"BrtEndPCDFGDiscrete", */
    T: -1
  },
  227: {
    /* n:"BrtBeginPCDSDTupleCache", */
    T: 1
  },
  228: {
    /* n:"BrtEndPCDSDTupleCache", */
    T: -1
  },
  229: {
    /* n:"BrtBeginPCDSDTCEntries", */
    T: 1
  },
  230: {
    /* n:"BrtEndPCDSDTCEntries", */
    T: -1
  },
  231: {
    /* n:"BrtBeginPCDSDTCEMembers", */
    T: 1
  },
  232: {
    /* n:"BrtEndPCDSDTCEMembers", */
    T: -1
  },
  233: {
    /* n:"BrtBeginPCDSDTCEMember", */
    T: 1
  },
  234: {
    /* n:"BrtEndPCDSDTCEMember", */
    T: -1
  },
  235: {
    /* n:"BrtBeginPCDSDTCQueries", */
    T: 1
  },
  236: {
    /* n:"BrtEndPCDSDTCQueries", */
    T: -1
  },
  237: {
    /* n:"BrtBeginPCDSDTCQuery", */
    T: 1
  },
  238: {
    /* n:"BrtEndPCDSDTCQuery", */
    T: -1
  },
  239: {
    /* n:"BrtBeginPCDSDTCSets", */
    T: 1
  },
  240: {
    /* n:"BrtEndPCDSDTCSets", */
    T: -1
  },
  241: {
    /* n:"BrtBeginPCDSDTCSet", */
    T: 1
  },
  242: {
    /* n:"BrtEndPCDSDTCSet", */
    T: -1
  },
  243: {
    /* n:"BrtBeginPCDCalcItems", */
    T: 1
  },
  244: {
    /* n:"BrtEndPCDCalcItems", */
    T: -1
  },
  245: {
    /* n:"BrtBeginPCDCalcItem", */
    T: 1
  },
  246: {
    /* n:"BrtEndPCDCalcItem", */
    T: -1
  },
  247: {
    /* n:"BrtBeginPRule", */
    T: 1
  },
  248: {
    /* n:"BrtEndPRule", */
    T: -1
  },
  249: {
    /* n:"BrtBeginPRFilters", */
    T: 1
  },
  250: {
    /* n:"BrtEndPRFilters", */
    T: -1
  },
  251: {
    /* n:"BrtBeginPRFilter", */
    T: 1
  },
  252: {
    /* n:"BrtEndPRFilter", */
    T: -1
  },
  253: {
    /* n:"BrtBeginPNames", */
    T: 1
  },
  254: {
    /* n:"BrtEndPNames", */
    T: -1
  },
  255: {
    /* n:"BrtBeginPName", */
    T: 1
  },
  256: {
    /* n:"BrtEndPName", */
    T: -1
  },
  257: {
    /* n:"BrtBeginPNPairs", */
    T: 1
  },
  258: {
    /* n:"BrtEndPNPairs", */
    T: -1
  },
  259: {
    /* n:"BrtBeginPNPair", */
    T: 1
  },
  260: {
    /* n:"BrtEndPNPair", */
    T: -1
  },
  261: {
    /* n:"BrtBeginECWebProps", */
    T: 1
  },
  262: {
    /* n:"BrtEndECWebProps", */
    T: -1
  },
  263: {
    /* n:"BrtBeginEcWpTables", */
    T: 1
  },
  264: {
    /* n:"BrtEndECWPTables", */
    T: -1
  },
  265: {
    /* n:"BrtBeginECParams", */
    T: 1
  },
  266: {
    /* n:"BrtEndECParams", */
    T: -1
  },
  267: {
    /* n:"BrtBeginECParam", */
    T: 1
  },
  268: {
    /* n:"BrtEndECParam", */
    T: -1
  },
  269: {
    /* n:"BrtBeginPCDKPIs", */
    T: 1
  },
  270: {
    /* n:"BrtEndPCDKPIs", */
    T: -1
  },
  271: {
    /* n:"BrtBeginPCDKPI", */
    T: 1
  },
  272: {
    /* n:"BrtEndPCDKPI", */
    T: -1
  },
  273: {
    /* n:"BrtBeginDims", */
    T: 1
  },
  274: {
    /* n:"BrtEndDims", */
    T: -1
  },
  275: {
    /* n:"BrtBeginDim", */
    T: 1
  },
  276: {
    /* n:"BrtEndDim", */
    T: -1
  },
  277: {
    /* n:"BrtIndexPartEnd" */
  },
  278: {
    /* n:"BrtBeginStyleSheet", */
    T: 1
  },
  279: {
    /* n:"BrtEndStyleSheet", */
    T: -1
  },
  280: {
    /* n:"BrtBeginSXView", */
    T: 1
  },
  281: {
    /* n:"BrtEndSXVI", */
    T: -1
  },
  282: {
    /* n:"BrtBeginSXVI", */
    T: 1
  },
  283: {
    /* n:"BrtBeginSXVIs", */
    T: 1
  },
  284: {
    /* n:"BrtEndSXVIs", */
    T: -1
  },
  285: {
    /* n:"BrtBeginSXVD", */
    T: 1
  },
  286: {
    /* n:"BrtEndSXVD", */
    T: -1
  },
  287: {
    /* n:"BrtBeginSXVDs", */
    T: 1
  },
  288: {
    /* n:"BrtEndSXVDs", */
    T: -1
  },
  289: {
    /* n:"BrtBeginSXPI", */
    T: 1
  },
  290: {
    /* n:"BrtEndSXPI", */
    T: -1
  },
  291: {
    /* n:"BrtBeginSXPIs", */
    T: 1
  },
  292: {
    /* n:"BrtEndSXPIs", */
    T: -1
  },
  293: {
    /* n:"BrtBeginSXDI", */
    T: 1
  },
  294: {
    /* n:"BrtEndSXDI", */
    T: -1
  },
  295: {
    /* n:"BrtBeginSXDIs", */
    T: 1
  },
  296: {
    /* n:"BrtEndSXDIs", */
    T: -1
  },
  297: {
    /* n:"BrtBeginSXLI", */
    T: 1
  },
  298: {
    /* n:"BrtEndSXLI", */
    T: -1
  },
  299: {
    /* n:"BrtBeginSXLIRws", */
    T: 1
  },
  300: {
    /* n:"BrtEndSXLIRws", */
    T: -1
  },
  301: {
    /* n:"BrtBeginSXLICols", */
    T: 1
  },
  302: {
    /* n:"BrtEndSXLICols", */
    T: -1
  },
  303: {
    /* n:"BrtBeginSXFormat", */
    T: 1
  },
  304: {
    /* n:"BrtEndSXFormat", */
    T: -1
  },
  305: {
    /* n:"BrtBeginSXFormats", */
    T: 1
  },
  306: {
    /* n:"BrtEndSxFormats", */
    T: -1
  },
  307: {
    /* n:"BrtBeginSxSelect", */
    T: 1
  },
  308: {
    /* n:"BrtEndSxSelect", */
    T: -1
  },
  309: {
    /* n:"BrtBeginISXVDRws", */
    T: 1
  },
  310: {
    /* n:"BrtEndISXVDRws", */
    T: -1
  },
  311: {
    /* n:"BrtBeginISXVDCols", */
    T: 1
  },
  312: {
    /* n:"BrtEndISXVDCols", */
    T: -1
  },
  313: {
    /* n:"BrtEndSXLocation", */
    T: -1
  },
  314: {
    /* n:"BrtBeginSXLocation", */
    T: 1
  },
  315: {
    /* n:"BrtEndSXView", */
    T: -1
  },
  316: {
    /* n:"BrtBeginSXTHs", */
    T: 1
  },
  317: {
    /* n:"BrtEndSXTHs", */
    T: -1
  },
  318: {
    /* n:"BrtBeginSXTH", */
    T: 1
  },
  319: {
    /* n:"BrtEndSXTH", */
    T: -1
  },
  320: {
    /* n:"BrtBeginISXTHRws", */
    T: 1
  },
  321: {
    /* n:"BrtEndISXTHRws", */
    T: -1
  },
  322: {
    /* n:"BrtBeginISXTHCols", */
    T: 1
  },
  323: {
    /* n:"BrtEndISXTHCols", */
    T: -1
  },
  324: {
    /* n:"BrtBeginSXTDMPS", */
    T: 1
  },
  325: {
    /* n:"BrtEndSXTDMPs", */
    T: -1
  },
  326: {
    /* n:"BrtBeginSXTDMP", */
    T: 1
  },
  327: {
    /* n:"BrtEndSXTDMP", */
    T: -1
  },
  328: {
    /* n:"BrtBeginSXTHItems", */
    T: 1
  },
  329: {
    /* n:"BrtEndSXTHItems", */
    T: -1
  },
  330: {
    /* n:"BrtBeginSXTHItem", */
    T: 1
  },
  331: {
    /* n:"BrtEndSXTHItem", */
    T: -1
  },
  332: {
    /* n:"BrtBeginMetadata", */
    T: 1
  },
  333: {
    /* n:"BrtEndMetadata", */
    T: -1
  },
  334: {
    /* n:"BrtBeginEsmdtinfo", */
    T: 1
  },
  335: {
    /* n:"BrtMdtinfo", */
    f: z1
  },
  336: {
    /* n:"BrtEndEsmdtinfo", */
    T: -1
  },
  337: {
    /* n:"BrtBeginEsmdb", */
    f: Y1,
    T: 1
  },
  338: {
    /* n:"BrtEndEsmdb", */
    T: -1
  },
  339: {
    /* n:"BrtBeginEsfmd", */
    T: 1
  },
  340: {
    /* n:"BrtEndEsfmd", */
    T: -1
  },
  341: {
    /* n:"BrtBeginSingleCells", */
    T: 1
  },
  342: {
    /* n:"BrtEndSingleCells", */
    T: -1
  },
  343: {
    /* n:"BrtBeginList", */
    T: 1
  },
  344: {
    /* n:"BrtEndList", */
    T: -1
  },
  345: {
    /* n:"BrtBeginListCols", */
    T: 1
  },
  346: {
    /* n:"BrtEndListCols", */
    T: -1
  },
  347: {
    /* n:"BrtBeginListCol", */
    T: 1
  },
  348: {
    /* n:"BrtEndListCol", */
    T: -1
  },
  349: {
    /* n:"BrtBeginListXmlCPr", */
    T: 1
  },
  350: {
    /* n:"BrtEndListXmlCPr", */
    T: -1
  },
  351: {
    /* n:"BrtListCCFmla" */
  },
  352: {
    /* n:"BrtListTrFmla" */
  },
  353: {
    /* n:"BrtBeginExternals", */
    T: 1
  },
  354: {
    /* n:"BrtEndExternals", */
    T: -1
  },
  355: {
    /* n:"BrtSupBookSrc", */
    f: g0
  },
  357: {
    /* n:"BrtSupSelf" */
  },
  358: {
    /* n:"BrtSupSame" */
  },
  359: {
    /* n:"BrtSupTabs" */
  },
  360: {
    /* n:"BrtBeginSupBook", */
    T: 1
  },
  361: {
    /* n:"BrtPlaceholderName" */
  },
  362: {
    /* n:"BrtExternSheet", */
    f: as
  },
  363: {
    /* n:"BrtExternTableStart" */
  },
  364: {
    /* n:"BrtExternTableEnd" */
  },
  366: {
    /* n:"BrtExternRowHdr" */
  },
  367: {
    /* n:"BrtExternCellBlank" */
  },
  368: {
    /* n:"BrtExternCellReal" */
  },
  369: {
    /* n:"BrtExternCellBool" */
  },
  370: {
    /* n:"BrtExternCellError" */
  },
  371: {
    /* n:"BrtExternCellString" */
  },
  372: {
    /* n:"BrtBeginEsmdx", */
    T: 1
  },
  373: {
    /* n:"BrtEndEsmdx", */
    T: -1
  },
  374: {
    /* n:"BrtBeginMdxSet", */
    T: 1
  },
  375: {
    /* n:"BrtEndMdxSet", */
    T: -1
  },
  376: {
    /* n:"BrtBeginMdxMbrProp", */
    T: 1
  },
  377: {
    /* n:"BrtEndMdxMbrProp", */
    T: -1
  },
  378: {
    /* n:"BrtBeginMdxKPI", */
    T: 1
  },
  379: {
    /* n:"BrtEndMdxKPI", */
    T: -1
  },
  380: {
    /* n:"BrtBeginEsstr", */
    T: 1
  },
  381: {
    /* n:"BrtEndEsstr", */
    T: -1
  },
  382: {
    /* n:"BrtBeginPRFItem", */
    T: 1
  },
  383: {
    /* n:"BrtEndPRFItem", */
    T: -1
  },
  384: {
    /* n:"BrtBeginPivotCacheIDs", */
    T: 1
  },
  385: {
    /* n:"BrtEndPivotCacheIDs", */
    T: -1
  },
  386: {
    /* n:"BrtBeginPivotCacheID", */
    T: 1
  },
  387: {
    /* n:"BrtEndPivotCacheID", */
    T: -1
  },
  388: {
    /* n:"BrtBeginISXVIs", */
    T: 1
  },
  389: {
    /* n:"BrtEndISXVIs", */
    T: -1
  },
  390: {
    /* n:"BrtBeginColInfos", */
    T: 1
  },
  391: {
    /* n:"BrtEndColInfos", */
    T: -1
  },
  392: {
    /* n:"BrtBeginRwBrk", */
    T: 1
  },
  393: {
    /* n:"BrtEndRwBrk", */
    T: -1
  },
  394: {
    /* n:"BrtBeginColBrk", */
    T: 1
  },
  395: {
    /* n:"BrtEndColBrk", */
    T: -1
  },
  396: {
    /* n:"BrtBrk" */
  },
  397: {
    /* n:"BrtUserBookView" */
  },
  398: {
    /* n:"BrtInfo" */
  },
  399: {
    /* n:"BrtCUsr" */
  },
  400: {
    /* n:"BrtUsr" */
  },
  401: {
    /* n:"BrtBeginUsers", */
    T: 1
  },
  403: {
    /* n:"BrtEOF" */
  },
  404: {
    /* n:"BrtUCR" */
  },
  405: {
    /* n:"BrtRRInsDel" */
  },
  406: {
    /* n:"BrtRREndInsDel" */
  },
  407: {
    /* n:"BrtRRMove" */
  },
  408: {
    /* n:"BrtRREndMove" */
  },
  409: {
    /* n:"BrtRRChgCell" */
  },
  410: {
    /* n:"BrtRREndChgCell" */
  },
  411: {
    /* n:"BrtRRHeader" */
  },
  412: {
    /* n:"BrtRRUserView" */
  },
  413: {
    /* n:"BrtRRRenSheet" */
  },
  414: {
    /* n:"BrtRRInsertSh" */
  },
  415: {
    /* n:"BrtRRDefName" */
  },
  416: {
    /* n:"BrtRRNote" */
  },
  417: {
    /* n:"BrtRRConflict" */
  },
  418: {
    /* n:"BrtRRTQSIF" */
  },
  419: {
    /* n:"BrtRRFormat" */
  },
  420: {
    /* n:"BrtRREndFormat" */
  },
  421: {
    /* n:"BrtRRAutoFmt" */
  },
  422: {
    /* n:"BrtBeginUserShViews", */
    T: 1
  },
  423: {
    /* n:"BrtBeginUserShView", */
    T: 1
  },
  424: {
    /* n:"BrtEndUserShView", */
    T: -1
  },
  425: {
    /* n:"BrtEndUserShViews", */
    T: -1
  },
  426: {
    /* n:"BrtArrFmla", */
    f: Sx
  },
  427: {
    /* n:"BrtShrFmla", */
    f: Cx
  },
  428: {
    /* n:"BrtTable" */
  },
  429: {
    /* n:"BrtBeginExtConnections", */
    T: 1
  },
  430: {
    /* n:"BrtEndExtConnections", */
    T: -1
  },
  431: {
    /* n:"BrtBeginPCDCalcMems", */
    T: 1
  },
  432: {
    /* n:"BrtEndPCDCalcMems", */
    T: -1
  },
  433: {
    /* n:"BrtBeginPCDCalcMem", */
    T: 1
  },
  434: {
    /* n:"BrtEndPCDCalcMem", */
    T: -1
  },
  435: {
    /* n:"BrtBeginPCDHGLevels", */
    T: 1
  },
  436: {
    /* n:"BrtEndPCDHGLevels", */
    T: -1
  },
  437: {
    /* n:"BrtBeginPCDHGLevel", */
    T: 1
  },
  438: {
    /* n:"BrtEndPCDHGLevel", */
    T: -1
  },
  439: {
    /* n:"BrtBeginPCDHGLGroups", */
    T: 1
  },
  440: {
    /* n:"BrtEndPCDHGLGroups", */
    T: -1
  },
  441: {
    /* n:"BrtBeginPCDHGLGroup", */
    T: 1
  },
  442: {
    /* n:"BrtEndPCDHGLGroup", */
    T: -1
  },
  443: {
    /* n:"BrtBeginPCDHGLGMembers", */
    T: 1
  },
  444: {
    /* n:"BrtEndPCDHGLGMembers", */
    T: -1
  },
  445: {
    /* n:"BrtBeginPCDHGLGMember", */
    T: 1
  },
  446: {
    /* n:"BrtEndPCDHGLGMember", */
    T: -1
  },
  447: {
    /* n:"BrtBeginQSI", */
    T: 1
  },
  448: {
    /* n:"BrtEndQSI", */
    T: -1
  },
  449: {
    /* n:"BrtBeginQSIR", */
    T: 1
  },
  450: {
    /* n:"BrtEndQSIR", */
    T: -1
  },
  451: {
    /* n:"BrtBeginDeletedNames", */
    T: 1
  },
  452: {
    /* n:"BrtEndDeletedNames", */
    T: -1
  },
  453: {
    /* n:"BrtBeginDeletedName", */
    T: 1
  },
  454: {
    /* n:"BrtEndDeletedName", */
    T: -1
  },
  455: {
    /* n:"BrtBeginQSIFs", */
    T: 1
  },
  456: {
    /* n:"BrtEndQSIFs", */
    T: -1
  },
  457: {
    /* n:"BrtBeginQSIF", */
    T: 1
  },
  458: {
    /* n:"BrtEndQSIF", */
    T: -1
  },
  459: {
    /* n:"BrtBeginAutoSortScope", */
    T: 1
  },
  460: {
    /* n:"BrtEndAutoSortScope", */
    T: -1
  },
  461: {
    /* n:"BrtBeginConditionalFormatting", */
    T: 1
  },
  462: {
    /* n:"BrtEndConditionalFormatting", */
    T: -1
  },
  463: {
    /* n:"BrtBeginCFRule", */
    T: 1
  },
  464: {
    /* n:"BrtEndCFRule", */
    T: -1
  },
  465: {
    /* n:"BrtBeginIconSet", */
    T: 1
  },
  466: {
    /* n:"BrtEndIconSet", */
    T: -1
  },
  467: {
    /* n:"BrtBeginDatabar", */
    T: 1
  },
  468: {
    /* n:"BrtEndDatabar", */
    T: -1
  },
  469: {
    /* n:"BrtBeginColorScale", */
    T: 1
  },
  470: {
    /* n:"BrtEndColorScale", */
    T: -1
  },
  471: {
    /* n:"BrtCFVO" */
  },
  472: {
    /* n:"BrtExternValueMeta" */
  },
  473: {
    /* n:"BrtBeginColorPalette", */
    T: 1
  },
  474: {
    /* n:"BrtEndColorPalette", */
    T: -1
  },
  475: {
    /* n:"BrtIndexedColor" */
  },
  476: {
    /* n:"BrtMargins", */
    f: Ix
  },
  477: {
    /* n:"BrtPrintOptions" */
  },
  478: {
    /* n:"BrtPageSetup" */
  },
  479: {
    /* n:"BrtBeginHeaderFooter", */
    T: 1
  },
  480: {
    /* n:"BrtEndHeaderFooter", */
    T: -1
  },
  481: {
    /* n:"BrtBeginSXCrtFormat", */
    T: 1
  },
  482: {
    /* n:"BrtEndSXCrtFormat", */
    T: -1
  },
  483: {
    /* n:"BrtBeginSXCrtFormats", */
    T: 1
  },
  484: {
    /* n:"BrtEndSXCrtFormats", */
    T: -1
  },
  485: {
    /* n:"BrtWsFmtInfo", */
    f: nx
  },
  486: {
    /* n:"BrtBeginMgs", */
    T: 1
  },
  487: {
    /* n:"BrtEndMGs", */
    T: -1
  },
  488: {
    /* n:"BrtBeginMGMaps", */
    T: 1
  },
  489: {
    /* n:"BrtEndMGMaps", */
    T: -1
  },
  490: {
    /* n:"BrtBeginMG", */
    T: 1
  },
  491: {
    /* n:"BrtEndMG", */
    T: -1
  },
  492: {
    /* n:"BrtBeginMap", */
    T: 1
  },
  493: {
    /* n:"BrtEndMap", */
    T: -1
  },
  494: {
    /* n:"BrtHLink", */
    f: Ax
  },
  495: {
    /* n:"BrtBeginDCon", */
    T: 1
  },
  496: {
    /* n:"BrtEndDCon", */
    T: -1
  },
  497: {
    /* n:"BrtBeginDRefs", */
    T: 1
  },
  498: {
    /* n:"BrtEndDRefs", */
    T: -1
  },
  499: {
    /* n:"BrtDRef" */
  },
  500: {
    /* n:"BrtBeginScenMan", */
    T: 1
  },
  501: {
    /* n:"BrtEndScenMan", */
    T: -1
  },
  502: {
    /* n:"BrtBeginSct", */
    T: 1
  },
  503: {
    /* n:"BrtEndSct", */
    T: -1
  },
  504: {
    /* n:"BrtSlc" */
  },
  505: {
    /* n:"BrtBeginDXFs", */
    T: 1
  },
  506: {
    /* n:"BrtEndDXFs", */
    T: -1
  },
  507: {
    /* n:"BrtDXF" */
  },
  508: {
    /* n:"BrtBeginTableStyles", */
    T: 1
  },
  509: {
    /* n:"BrtEndTableStyles", */
    T: -1
  },
  510: {
    /* n:"BrtBeginTableStyle", */
    T: 1
  },
  511: {
    /* n:"BrtEndTableStyle", */
    T: -1
  },
  512: {
    /* n:"BrtTableStyleElement" */
  },
  513: {
    /* n:"BrtTableStyleClient" */
  },
  514: {
    /* n:"BrtBeginVolDeps", */
    T: 1
  },
  515: {
    /* n:"BrtEndVolDeps", */
    T: -1
  },
  516: {
    /* n:"BrtBeginVolType", */
    T: 1
  },
  517: {
    /* n:"BrtEndVolType", */
    T: -1
  },
  518: {
    /* n:"BrtBeginVolMain", */
    T: 1
  },
  519: {
    /* n:"BrtEndVolMain", */
    T: -1
  },
  520: {
    /* n:"BrtBeginVolTopic", */
    T: 1
  },
  521: {
    /* n:"BrtEndVolTopic", */
    T: -1
  },
  522: {
    /* n:"BrtVolSubtopic" */
  },
  523: {
    /* n:"BrtVolRef" */
  },
  524: {
    /* n:"BrtVolNum" */
  },
  525: {
    /* n:"BrtVolErr" */
  },
  526: {
    /* n:"BrtVolStr" */
  },
  527: {
    /* n:"BrtVolBool" */
  },
  528: {
    /* n:"BrtBeginCalcChain$", */
    T: 1
  },
  529: {
    /* n:"BrtEndCalcChain$", */
    T: -1
  },
  530: {
    /* n:"BrtBeginSortState", */
    T: 1
  },
  531: {
    /* n:"BrtEndSortState", */
    T: -1
  },
  532: {
    /* n:"BrtBeginSortCond", */
    T: 1
  },
  533: {
    /* n:"BrtEndSortCond", */
    T: -1
  },
  534: {
    /* n:"BrtBookProtection" */
  },
  535: {
    /* n:"BrtSheetProtection" */
  },
  536: {
    /* n:"BrtRangeProtection" */
  },
  537: {
    /* n:"BrtPhoneticInfo" */
  },
  538: {
    /* n:"BrtBeginECTxtWiz", */
    T: 1
  },
  539: {
    /* n:"BrtEndECTxtWiz", */
    T: -1
  },
  540: {
    /* n:"BrtBeginECTWFldInfoLst", */
    T: 1
  },
  541: {
    /* n:"BrtEndECTWFldInfoLst", */
    T: -1
  },
  542: {
    /* n:"BrtBeginECTwFldInfo", */
    T: 1
  },
  548: {
    /* n:"BrtFileSharing" */
  },
  549: {
    /* n:"BrtOleSize" */
  },
  550: {
    /* n:"BrtDrawing", */
    f: g0
  },
  551: {
    /* n:"BrtLegacyDrawing", */
    f: Jt
  },
  552: {
    /* n:"BrtLegacyDrawingHF" */
  },
  553: {
    /* n:"BrtWebOpt" */
  },
  554: {
    /* n:"BrtBeginWebPubItems", */
    T: 1
  },
  555: {
    /* n:"BrtEndWebPubItems", */
    T: -1
  },
  556: {
    /* n:"BrtBeginWebPubItem", */
    T: 1
  },
  557: {
    /* n:"BrtEndWebPubItem", */
    T: -1
  },
  558: {
    /* n:"BrtBeginSXCondFmt", */
    T: 1
  },
  559: {
    /* n:"BrtEndSXCondFmt", */
    T: -1
  },
  560: {
    /* n:"BrtBeginSXCondFmts", */
    T: 1
  },
  561: {
    /* n:"BrtEndSXCondFmts", */
    T: -1
  },
  562: {
    /* n:"BrtBkHim" */
  },
  564: {
    /* n:"BrtColor" */
  },
  565: {
    /* n:"BrtBeginIndexedColors", */
    T: 1
  },
  566: {
    /* n:"BrtEndIndexedColors", */
    T: -1
  },
  569: {
    /* n:"BrtBeginMRUColors", */
    T: 1
  },
  570: {
    /* n:"BrtEndMRUColors", */
    T: -1
  },
  572: {
    /* n:"BrtMRUColor" */
  },
  573: {
    /* n:"BrtBeginDVals", */
    T: 1
  },
  574: {
    /* n:"BrtEndDVals", */
    T: -1
  },
  577: {
    /* n:"BrtSupNameStart" */
  },
  578: {
    /* n:"BrtSupNameValueStart" */
  },
  579: {
    /* n:"BrtSupNameValueEnd" */
  },
  580: {
    /* n:"BrtSupNameNum" */
  },
  581: {
    /* n:"BrtSupNameErr" */
  },
  582: {
    /* n:"BrtSupNameSt" */
  },
  583: {
    /* n:"BrtSupNameNil" */
  },
  584: {
    /* n:"BrtSupNameBool" */
  },
  585: {
    /* n:"BrtSupNameFmla" */
  },
  586: {
    /* n:"BrtSupNameBits" */
  },
  587: {
    /* n:"BrtSupNameEnd" */
  },
  588: {
    /* n:"BrtEndSupBook", */
    T: -1
  },
  589: {
    /* n:"BrtCellSmartTagProperty" */
  },
  590: {
    /* n:"BrtBeginCellSmartTag", */
    T: 1
  },
  591: {
    /* n:"BrtEndCellSmartTag", */
    T: -1
  },
  592: {
    /* n:"BrtBeginCellSmartTags", */
    T: 1
  },
  593: {
    /* n:"BrtEndCellSmartTags", */
    T: -1
  },
  594: {
    /* n:"BrtBeginSmartTags", */
    T: 1
  },
  595: {
    /* n:"BrtEndSmartTags", */
    T: -1
  },
  596: {
    /* n:"BrtSmartTagType" */
  },
  597: {
    /* n:"BrtBeginSmartTagTypes", */
    T: 1
  },
  598: {
    /* n:"BrtEndSmartTagTypes", */
    T: -1
  },
  599: {
    /* n:"BrtBeginSXFilters", */
    T: 1
  },
  600: {
    /* n:"BrtEndSXFilters", */
    T: -1
  },
  601: {
    /* n:"BrtBeginSXFILTER", */
    T: 1
  },
  602: {
    /* n:"BrtEndSXFilter", */
    T: -1
  },
  603: {
    /* n:"BrtBeginFills", */
    T: 1
  },
  604: {
    /* n:"BrtEndFills", */
    T: -1
  },
  605: {
    /* n:"BrtBeginCellWatches", */
    T: 1
  },
  606: {
    /* n:"BrtEndCellWatches", */
    T: -1
  },
  607: {
    /* n:"BrtCellWatch" */
  },
  608: {
    /* n:"BrtBeginCRErrs", */
    T: 1
  },
  609: {
    /* n:"BrtEndCRErrs", */
    T: -1
  },
  610: {
    /* n:"BrtCrashRecErr" */
  },
  611: {
    /* n:"BrtBeginFonts", */
    T: 1
  },
  612: {
    /* n:"BrtEndFonts", */
    T: -1
  },
  613: {
    /* n:"BrtBeginBorders", */
    T: 1
  },
  614: {
    /* n:"BrtEndBorders", */
    T: -1
  },
  615: {
    /* n:"BrtBeginFmts", */
    T: 1
  },
  616: {
    /* n:"BrtEndFmts", */
    T: -1
  },
  617: {
    /* n:"BrtBeginCellXFs", */
    T: 1
  },
  618: {
    /* n:"BrtEndCellXFs", */
    T: -1
  },
  619: {
    /* n:"BrtBeginStyles", */
    T: 1
  },
  620: {
    /* n:"BrtEndStyles", */
    T: -1
  },
  625: {
    /* n:"BrtBigName" */
  },
  626: {
    /* n:"BrtBeginCellStyleXFs", */
    T: 1
  },
  627: {
    /* n:"BrtEndCellStyleXFs", */
    T: -1
  },
  628: {
    /* n:"BrtBeginComments", */
    T: 1
  },
  629: {
    /* n:"BrtEndComments", */
    T: -1
  },
  630: {
    /* n:"BrtBeginCommentAuthors", */
    T: 1
  },
  631: {
    /* n:"BrtEndCommentAuthors", */
    T: -1
  },
  632: {
    /* n:"BrtCommentAuthor", */
    f: cu
  },
  633: {
    /* n:"BrtBeginCommentList", */
    T: 1
  },
  634: {
    /* n:"BrtEndCommentList", */
    T: -1
  },
  635: {
    /* n:"BrtBeginComment", */
    T: 1,
    f: su
  },
  636: {
    /* n:"BrtEndComment", */
    T: -1
  },
  637: {
    /* n:"BrtCommentText", */
    f: Of
  },
  638: {
    /* n:"BrtBeginOleObjects", */
    T: 1
  },
  639: {
    /* n:"BrtOleObject" */
  },
  640: {
    /* n:"BrtEndOleObjects", */
    T: -1
  },
  641: {
    /* n:"BrtBeginSxrules", */
    T: 1
  },
  642: {
    /* n:"BrtEndSxRules", */
    T: -1
  },
  643: {
    /* n:"BrtBeginActiveXControls", */
    T: 1
  },
  644: {
    /* n:"BrtActiveX" */
  },
  645: {
    /* n:"BrtEndActiveXControls", */
    T: -1
  },
  646: {
    /* n:"BrtBeginPCDSDTCEMembersSortBy", */
    T: 1
  },
  648: {
    /* n:"BrtBeginCellIgnoreECs", */
    T: 1
  },
  649: {
    /* n:"BrtCellIgnoreEC" */
  },
  650: {
    /* n:"BrtEndCellIgnoreECs", */
    T: -1
  },
  651: {
    /* n:"BrtCsProp", */
    f: Mx
  },
  652: {
    /* n:"BrtCsPageSetup" */
  },
  653: {
    /* n:"BrtBeginUserCsViews", */
    T: 1
  },
  654: {
    /* n:"BrtEndUserCsViews", */
    T: -1
  },
  655: {
    /* n:"BrtBeginUserCsView", */
    T: 1
  },
  656: {
    /* n:"BrtEndUserCsView", */
    T: -1
  },
  657: {
    /* n:"BrtBeginPcdSFCIEntries", */
    T: 1
  },
  658: {
    /* n:"BrtEndPCDSFCIEntries", */
    T: -1
  },
  659: {
    /* n:"BrtPCDSFCIEntry" */
  },
  660: {
    /* n:"BrtBeginListParts", */
    T: 1
  },
  661: {
    /* n:"BrtListPart" */
  },
  662: {
    /* n:"BrtEndListParts", */
    T: -1
  },
  663: {
    /* n:"BrtSheetCalcProp" */
  },
  664: {
    /* n:"BrtBeginFnGroup", */
    T: 1
  },
  665: {
    /* n:"BrtFnGroup" */
  },
  666: {
    /* n:"BrtEndFnGroup", */
    T: -1
  },
  667: {
    /* n:"BrtSupAddin" */
  },
  668: {
    /* n:"BrtSXTDMPOrder" */
  },
  669: {
    /* n:"BrtCsProtection" */
  },
  671: {
    /* n:"BrtBeginWsSortMap", */
    T: 1
  },
  672: {
    /* n:"BrtEndWsSortMap", */
    T: -1
  },
  673: {
    /* n:"BrtBeginRRSort", */
    T: 1
  },
  674: {
    /* n:"BrtEndRRSort", */
    T: -1
  },
  675: {
    /* n:"BrtRRSortItem" */
  },
  676: {
    /* n:"BrtFileSharingIso" */
  },
  677: {
    /* n:"BrtBookProtectionIso" */
  },
  678: {
    /* n:"BrtSheetProtectionIso" */
  },
  679: {
    /* n:"BrtCsProtectionIso" */
  },
  680: {
    /* n:"BrtRangeProtectionIso" */
  },
  681: {
    /* n:"BrtDValList" */
  },
  1024: {
    /* n:"BrtRwDescent" */
  },
  1025: {
    /* n:"BrtKnownFonts" */
  },
  1026: {
    /* n:"BrtBeginSXTupleSet", */
    T: 1
  },
  1027: {
    /* n:"BrtEndSXTupleSet", */
    T: -1
  },
  1028: {
    /* n:"BrtBeginSXTupleSetHeader", */
    T: 1
  },
  1029: {
    /* n:"BrtEndSXTupleSetHeader", */
    T: -1
  },
  1030: {
    /* n:"BrtSXTupleSetHeaderItem" */
  },
  1031: {
    /* n:"BrtBeginSXTupleSetData", */
    T: 1
  },
  1032: {
    /* n:"BrtEndSXTupleSetData", */
    T: -1
  },
  1033: {
    /* n:"BrtBeginSXTupleSetRow", */
    T: 1
  },
  1034: {
    /* n:"BrtEndSXTupleSetRow", */
    T: -1
  },
  1035: {
    /* n:"BrtSXTupleSetRowItem" */
  },
  1036: {
    /* n:"BrtNameExt" */
  },
  1037: {
    /* n:"BrtPCDH14" */
  },
  1038: {
    /* n:"BrtBeginPCDCalcMem14", */
    T: 1
  },
  1039: {
    /* n:"BrtEndPCDCalcMem14", */
    T: -1
  },
  1040: {
    /* n:"BrtSXTH14" */
  },
  1041: {
    /* n:"BrtBeginSparklineGroup", */
    T: 1
  },
  1042: {
    /* n:"BrtEndSparklineGroup", */
    T: -1
  },
  1043: {
    /* n:"BrtSparkline" */
  },
  1044: {
    /* n:"BrtSXDI14" */
  },
  1045: {
    /* n:"BrtWsFmtInfoEx14" */
  },
  1046: {
    /* n:"BrtBeginConditionalFormatting14", */
    T: 1
  },
  1047: {
    /* n:"BrtEndConditionalFormatting14", */
    T: -1
  },
  1048: {
    /* n:"BrtBeginCFRule14", */
    T: 1
  },
  1049: {
    /* n:"BrtEndCFRule14", */
    T: -1
  },
  1050: {
    /* n:"BrtCFVO14" */
  },
  1051: {
    /* n:"BrtBeginDatabar14", */
    T: 1
  },
  1052: {
    /* n:"BrtBeginIconSet14", */
    T: 1
  },
  1053: {
    /* n:"BrtDVal14", */
    f: Nx
  },
  1054: {
    /* n:"BrtBeginDVals14", */
    T: 1
  },
  1055: {
    /* n:"BrtColor14" */
  },
  1056: {
    /* n:"BrtBeginSparklines", */
    T: 1
  },
  1057: {
    /* n:"BrtEndSparklines", */
    T: -1
  },
  1058: {
    /* n:"BrtBeginSparklineGroups", */
    T: 1
  },
  1059: {
    /* n:"BrtEndSparklineGroups", */
    T: -1
  },
  1061: {
    /* n:"BrtSXVD14" */
  },
  1062: {
    /* n:"BrtBeginSXView14", */
    T: 1
  },
  1063: {
    /* n:"BrtEndSXView14", */
    T: -1
  },
  1064: {
    /* n:"BrtBeginSXView16", */
    T: 1
  },
  1065: {
    /* n:"BrtEndSXView16", */
    T: -1
  },
  1066: {
    /* n:"BrtBeginPCD14", */
    T: 1
  },
  1067: {
    /* n:"BrtEndPCD14", */
    T: -1
  },
  1068: {
    /* n:"BrtBeginExtConn14", */
    T: 1
  },
  1069: {
    /* n:"BrtEndExtConn14", */
    T: -1
  },
  1070: {
    /* n:"BrtBeginSlicerCacheIDs", */
    T: 1
  },
  1071: {
    /* n:"BrtEndSlicerCacheIDs", */
    T: -1
  },
  1072: {
    /* n:"BrtBeginSlicerCacheID", */
    T: 1
  },
  1073: {
    /* n:"BrtEndSlicerCacheID", */
    T: -1
  },
  1075: {
    /* n:"BrtBeginSlicerCache", */
    T: 1
  },
  1076: {
    /* n:"BrtEndSlicerCache", */
    T: -1
  },
  1077: {
    /* n:"BrtBeginSlicerCacheDef", */
    T: 1
  },
  1078: {
    /* n:"BrtEndSlicerCacheDef", */
    T: -1
  },
  1079: {
    /* n:"BrtBeginSlicersEx", */
    T: 1
  },
  1080: {
    /* n:"BrtEndSlicersEx", */
    T: -1
  },
  1081: {
    /* n:"BrtBeginSlicerEx", */
    T: 1
  },
  1082: {
    /* n:"BrtEndSlicerEx", */
    T: -1
  },
  1083: {
    /* n:"BrtBeginSlicer", */
    T: 1
  },
  1084: {
    /* n:"BrtEndSlicer", */
    T: -1
  },
  1085: {
    /* n:"BrtSlicerCachePivotTables" */
  },
  1086: {
    /* n:"BrtBeginSlicerCacheOlapImpl", */
    T: 1
  },
  1087: {
    /* n:"BrtEndSlicerCacheOlapImpl", */
    T: -1
  },
  1088: {
    /* n:"BrtBeginSlicerCacheLevelsData", */
    T: 1
  },
  1089: {
    /* n:"BrtEndSlicerCacheLevelsData", */
    T: -1
  },
  1090: {
    /* n:"BrtBeginSlicerCacheLevelData", */
    T: 1
  },
  1091: {
    /* n:"BrtEndSlicerCacheLevelData", */
    T: -1
  },
  1092: {
    /* n:"BrtBeginSlicerCacheSiRanges", */
    T: 1
  },
  1093: {
    /* n:"BrtEndSlicerCacheSiRanges", */
    T: -1
  },
  1094: {
    /* n:"BrtBeginSlicerCacheSiRange", */
    T: 1
  },
  1095: {
    /* n:"BrtEndSlicerCacheSiRange", */
    T: -1
  },
  1096: {
    /* n:"BrtSlicerCacheOlapItem" */
  },
  1097: {
    /* n:"BrtBeginSlicerCacheSelections", */
    T: 1
  },
  1098: {
    /* n:"BrtSlicerCacheSelection" */
  },
  1099: {
    /* n:"BrtEndSlicerCacheSelections", */
    T: -1
  },
  1100: {
    /* n:"BrtBeginSlicerCacheNative", */
    T: 1
  },
  1101: {
    /* n:"BrtEndSlicerCacheNative", */
    T: -1
  },
  1102: {
    /* n:"BrtSlicerCacheNativeItem" */
  },
  1103: {
    /* n:"BrtRangeProtection14" */
  },
  1104: {
    /* n:"BrtRangeProtectionIso14" */
  },
  1105: {
    /* n:"BrtCellIgnoreEC14" */
  },
  1111: {
    /* n:"BrtList14" */
  },
  1112: {
    /* n:"BrtCFIcon" */
  },
  1113: {
    /* n:"BrtBeginSlicerCachesPivotCacheIDs", */
    T: 1
  },
  1114: {
    /* n:"BrtEndSlicerCachesPivotCacheIDs", */
    T: -1
  },
  1115: {
    /* n:"BrtBeginSlicers", */
    T: 1
  },
  1116: {
    /* n:"BrtEndSlicers", */
    T: -1
  },
  1117: {
    /* n:"BrtWbProp14" */
  },
  1118: {
    /* n:"BrtBeginSXEdit", */
    T: 1
  },
  1119: {
    /* n:"BrtEndSXEdit", */
    T: -1
  },
  1120: {
    /* n:"BrtBeginSXEdits", */
    T: 1
  },
  1121: {
    /* n:"BrtEndSXEdits", */
    T: -1
  },
  1122: {
    /* n:"BrtBeginSXChange", */
    T: 1
  },
  1123: {
    /* n:"BrtEndSXChange", */
    T: -1
  },
  1124: {
    /* n:"BrtBeginSXChanges", */
    T: 1
  },
  1125: {
    /* n:"BrtEndSXChanges", */
    T: -1
  },
  1126: {
    /* n:"BrtSXTupleItems" */
  },
  1128: {
    /* n:"BrtBeginSlicerStyle", */
    T: 1
  },
  1129: {
    /* n:"BrtEndSlicerStyle", */
    T: -1
  },
  1130: {
    /* n:"BrtSlicerStyleElement" */
  },
  1131: {
    /* n:"BrtBeginStyleSheetExt14", */
    T: 1
  },
  1132: {
    /* n:"BrtEndStyleSheetExt14", */
    T: -1
  },
  1133: {
    /* n:"BrtBeginSlicerCachesPivotCacheID", */
    T: 1
  },
  1134: {
    /* n:"BrtEndSlicerCachesPivotCacheID", */
    T: -1
  },
  1135: {
    /* n:"BrtBeginConditionalFormattings", */
    T: 1
  },
  1136: {
    /* n:"BrtEndConditionalFormattings", */
    T: -1
  },
  1137: {
    /* n:"BrtBeginPCDCalcMemExt", */
    T: 1
  },
  1138: {
    /* n:"BrtEndPCDCalcMemExt", */
    T: -1
  },
  1139: {
    /* n:"BrtBeginPCDCalcMemsExt", */
    T: 1
  },
  1140: {
    /* n:"BrtEndPCDCalcMemsExt", */
    T: -1
  },
  1141: {
    /* n:"BrtPCDField14" */
  },
  1142: {
    /* n:"BrtBeginSlicerStyles", */
    T: 1
  },
  1143: {
    /* n:"BrtEndSlicerStyles", */
    T: -1
  },
  1144: {
    /* n:"BrtBeginSlicerStyleElements", */
    T: 1
  },
  1145: {
    /* n:"BrtEndSlicerStyleElements", */
    T: -1
  },
  1146: {
    /* n:"BrtCFRuleExt" */
  },
  1147: {
    /* n:"BrtBeginSXCondFmt14", */
    T: 1
  },
  1148: {
    /* n:"BrtEndSXCondFmt14", */
    T: -1
  },
  1149: {
    /* n:"BrtBeginSXCondFmts14", */
    T: 1
  },
  1150: {
    /* n:"BrtEndSXCondFmts14", */
    T: -1
  },
  1152: {
    /* n:"BrtBeginSortCond14", */
    T: 1
  },
  1153: {
    /* n:"BrtEndSortCond14", */
    T: -1
  },
  1154: {
    /* n:"BrtEndDVals14", */
    T: -1
  },
  1155: {
    /* n:"BrtEndIconSet14", */
    T: -1
  },
  1156: {
    /* n:"BrtEndDatabar14", */
    T: -1
  },
  1157: {
    /* n:"BrtBeginColorScale14", */
    T: 1
  },
  1158: {
    /* n:"BrtEndColorScale14", */
    T: -1
  },
  1159: {
    /* n:"BrtBeginSxrules14", */
    T: 1
  },
  1160: {
    /* n:"BrtEndSxrules14", */
    T: -1
  },
  1161: {
    /* n:"BrtBeginPRule14", */
    T: 1
  },
  1162: {
    /* n:"BrtEndPRule14", */
    T: -1
  },
  1163: {
    /* n:"BrtBeginPRFilters14", */
    T: 1
  },
  1164: {
    /* n:"BrtEndPRFilters14", */
    T: -1
  },
  1165: {
    /* n:"BrtBeginPRFilter14", */
    T: 1
  },
  1166: {
    /* n:"BrtEndPRFilter14", */
    T: -1
  },
  1167: {
    /* n:"BrtBeginPRFItem14", */
    T: 1
  },
  1168: {
    /* n:"BrtEndPRFItem14", */
    T: -1
  },
  1169: {
    /* n:"BrtBeginCellIgnoreECs14", */
    T: 1
  },
  1170: {
    /* n:"BrtEndCellIgnoreECs14", */
    T: -1
  },
  1171: {
    /* n:"BrtDxf14" */
  },
  1172: {
    /* n:"BrtBeginDxF14s", */
    T: 1
  },
  1173: {
    /* n:"BrtEndDxf14s", */
    T: -1
  },
  1177: {
    /* n:"BrtFilter14" */
  },
  1178: {
    /* n:"BrtBeginCustomFilters14", */
    T: 1
  },
  1180: {
    /* n:"BrtCustomFilter14" */
  },
  1181: {
    /* n:"BrtIconFilter14" */
  },
  1182: {
    /* n:"BrtPivotCacheConnectionName" */
  },
  2048: {
    /* n:"BrtBeginDecoupledPivotCacheIDs", */
    T: 1
  },
  2049: {
    /* n:"BrtEndDecoupledPivotCacheIDs", */
    T: -1
  },
  2050: {
    /* n:"BrtDecoupledPivotCacheID" */
  },
  2051: {
    /* n:"BrtBeginPivotTableRefs", */
    T: 1
  },
  2052: {
    /* n:"BrtEndPivotTableRefs", */
    T: -1
  },
  2053: {
    /* n:"BrtPivotTableRef" */
  },
  2054: {
    /* n:"BrtSlicerCacheBookPivotTables" */
  },
  2055: {
    /* n:"BrtBeginSxvcells", */
    T: 1
  },
  2056: {
    /* n:"BrtEndSxvcells", */
    T: -1
  },
  2057: {
    /* n:"BrtBeginSxRow", */
    T: 1
  },
  2058: {
    /* n:"BrtEndSxRow", */
    T: -1
  },
  2060: {
    /* n:"BrtPcdCalcMem15" */
  },
  2067: {
    /* n:"BrtQsi15" */
  },
  2068: {
    /* n:"BrtBeginWebExtensions", */
    T: 1
  },
  2069: {
    /* n:"BrtEndWebExtensions", */
    T: -1
  },
  2070: {
    /* n:"BrtWebExtension" */
  },
  2071: {
    /* n:"BrtAbsPath15" */
  },
  2072: {
    /* n:"BrtBeginPivotTableUISettings", */
    T: 1
  },
  2073: {
    /* n:"BrtEndPivotTableUISettings", */
    T: -1
  },
  2075: {
    /* n:"BrtTableSlicerCacheIDs" */
  },
  2076: {
    /* n:"BrtTableSlicerCacheID" */
  },
  2077: {
    /* n:"BrtBeginTableSlicerCache", */
    T: 1
  },
  2078: {
    /* n:"BrtEndTableSlicerCache", */
    T: -1
  },
  2079: {
    /* n:"BrtSxFilter15" */
  },
  2080: {
    /* n:"BrtBeginTimelineCachePivotCacheIDs", */
    T: 1
  },
  2081: {
    /* n:"BrtEndTimelineCachePivotCacheIDs", */
    T: -1
  },
  2082: {
    /* n:"BrtTimelineCachePivotCacheID" */
  },
  2083: {
    /* n:"BrtBeginTimelineCacheIDs", */
    T: 1
  },
  2084: {
    /* n:"BrtEndTimelineCacheIDs", */
    T: -1
  },
  2085: {
    /* n:"BrtBeginTimelineCacheID", */
    T: 1
  },
  2086: {
    /* n:"BrtEndTimelineCacheID", */
    T: -1
  },
  2087: {
    /* n:"BrtBeginTimelinesEx", */
    T: 1
  },
  2088: {
    /* n:"BrtEndTimelinesEx", */
    T: -1
  },
  2089: {
    /* n:"BrtBeginTimelineEx", */
    T: 1
  },
  2090: {
    /* n:"BrtEndTimelineEx", */
    T: -1
  },
  2091: {
    /* n:"BrtWorkBookPr15" */
  },
  2092: {
    /* n:"BrtPCDH15" */
  },
  2093: {
    /* n:"BrtBeginTimelineStyle", */
    T: 1
  },
  2094: {
    /* n:"BrtEndTimelineStyle", */
    T: -1
  },
  2095: {
    /* n:"BrtTimelineStyleElement" */
  },
  2096: {
    /* n:"BrtBeginTimelineStylesheetExt15", */
    T: 1
  },
  2097: {
    /* n:"BrtEndTimelineStylesheetExt15", */
    T: -1
  },
  2098: {
    /* n:"BrtBeginTimelineStyles", */
    T: 1
  },
  2099: {
    /* n:"BrtEndTimelineStyles", */
    T: -1
  },
  2100: {
    /* n:"BrtBeginTimelineStyleElements", */
    T: 1
  },
  2101: {
    /* n:"BrtEndTimelineStyleElements", */
    T: -1
  },
  2102: {
    /* n:"BrtDxf15" */
  },
  2103: {
    /* n:"BrtBeginDxfs15", */
    T: 1
  },
  2104: {
    /* n:"BrtEndDxfs15", */
    T: -1
  },
  2105: {
    /* n:"BrtSlicerCacheHideItemsWithNoData" */
  },
  2106: {
    /* n:"BrtBeginItemUniqueNames", */
    T: 1
  },
  2107: {
    /* n:"BrtEndItemUniqueNames", */
    T: -1
  },
  2108: {
    /* n:"BrtItemUniqueName" */
  },
  2109: {
    /* n:"BrtBeginExtConn15", */
    T: 1
  },
  2110: {
    /* n:"BrtEndExtConn15", */
    T: -1
  },
  2111: {
    /* n:"BrtBeginOledbPr15", */
    T: 1
  },
  2112: {
    /* n:"BrtEndOledbPr15", */
    T: -1
  },
  2113: {
    /* n:"BrtBeginDataFeedPr15", */
    T: 1
  },
  2114: {
    /* n:"BrtEndDataFeedPr15", */
    T: -1
  },
  2115: {
    /* n:"BrtTextPr15" */
  },
  2116: {
    /* n:"BrtRangePr15" */
  },
  2117: {
    /* n:"BrtDbCommand15" */
  },
  2118: {
    /* n:"BrtBeginDbTables15", */
    T: 1
  },
  2119: {
    /* n:"BrtEndDbTables15", */
    T: -1
  },
  2120: {
    /* n:"BrtDbTable15" */
  },
  2121: {
    /* n:"BrtBeginDataModel", */
    T: 1
  },
  2122: {
    /* n:"BrtEndDataModel", */
    T: -1
  },
  2123: {
    /* n:"BrtBeginModelTables", */
    T: 1
  },
  2124: {
    /* n:"BrtEndModelTables", */
    T: -1
  },
  2125: {
    /* n:"BrtModelTable" */
  },
  2126: {
    /* n:"BrtBeginModelRelationships", */
    T: 1
  },
  2127: {
    /* n:"BrtEndModelRelationships", */
    T: -1
  },
  2128: {
    /* n:"BrtModelRelationship" */
  },
  2129: {
    /* n:"BrtBeginECTxtWiz15", */
    T: 1
  },
  2130: {
    /* n:"BrtEndECTxtWiz15", */
    T: -1
  },
  2131: {
    /* n:"BrtBeginECTWFldInfoLst15", */
    T: 1
  },
  2132: {
    /* n:"BrtEndECTWFldInfoLst15", */
    T: -1
  },
  2133: {
    /* n:"BrtBeginECTWFldInfo15", */
    T: 1
  },
  2134: {
    /* n:"BrtFieldListActiveItem" */
  },
  2135: {
    /* n:"BrtPivotCacheIdVersion" */
  },
  2136: {
    /* n:"BrtSXDI15" */
  },
  2137: {
    /* n:"BrtBeginModelTimeGroupings", */
    T: 1
  },
  2138: {
    /* n:"BrtEndModelTimeGroupings", */
    T: -1
  },
  2139: {
    /* n:"BrtBeginModelTimeGrouping", */
    T: 1
  },
  2140: {
    /* n:"BrtEndModelTimeGrouping", */
    T: -1
  },
  2141: {
    /* n:"BrtModelTimeGroupingCalcCol" */
  },
  3072: {
    /* n:"BrtUid" */
  },
  3073: {
    /* n:"BrtRevisionPtr" */
  },
  4096: {
    /* n:"BrtBeginDynamicArrayPr", */
    T: 1
  },
  4097: {
    /* n:"BrtEndDynamicArrayPr", */
    T: -1
  },
  5002: {
    /* n:"BrtBeginRichValueBlock", */
    T: 1
  },
  5003: {
    /* n:"BrtEndRichValueBlock", */
    T: -1
  },
  5081: {
    /* n:"BrtBeginRichFilters", */
    T: 1
  },
  5082: {
    /* n:"BrtEndRichFilters", */
    T: -1
  },
  5083: {
    /* n:"BrtRichFilter" */
  },
  5084: {
    /* n:"BrtBeginRichFilterColumn", */
    T: 1
  },
  5085: {
    /* n:"BrtEndRichFilterColumn", */
    T: -1
  },
  5086: {
    /* n:"BrtBeginCustomRichFilters", */
    T: 1
  },
  5087: {
    /* n:"BrtEndCustomRichFilters", */
    T: -1
  },
  5088: {
    /* n:"BrtCustomRichFilter" */
  },
  5089: {
    /* n:"BrtTop10RichFilter" */
  },
  5090: {
    /* n:"BrtDynamicRichFilter" */
  },
  5092: {
    /* n:"BrtBeginRichSortCondition", */
    T: 1
  },
  5093: {
    /* n:"BrtEndRichSortCondition", */
    T: -1
  },
  5094: {
    /* n:"BrtRichFilterDateGroupItem" */
  },
  5095: {
    /* n:"BrtBeginCalcFeatures", */
    T: 1
  },
  5096: {
    /* n:"BrtEndCalcFeatures", */
    T: -1
  },
  5097: {
    /* n:"BrtCalcFeature" */
  },
  5099: {
    /* n:"BrtExternalLinksPr" */
  },
  65535: { n: "" }
}, E0 = {
  /* [MS-XLS] 2.3 Record Enumeration 2021-08-17 */
  6: {
    /* n:"Formula", */
    f: l0
  },
  10: {
    /* n:"EOF", */
    f: na
  },
  12: {
    /* n:"CalcCount", */
    f: Xe
  },
  //
  13: {
    /* n:"CalcMode", */
    f: Xe
  },
  //
  14: {
    /* n:"CalcPrecision", */
    f: ze
  },
  //
  15: {
    /* n:"CalcRefMode", */
    f: ze
  },
  //
  16: {
    /* n:"CalcDelta", */
    f: xr
  },
  //
  17: {
    /* n:"CalcIter", */
    f: ze
  },
  //
  18: {
    /* n:"Protect", */
    f: ze
  },
  19: {
    /* n:"Password", */
    f: Xe
  },
  20: {
    /* n:"Header", */
    f: Rn
  },
  21: {
    /* n:"Footer", */
    f: Rn
  },
  23: {
    /* n:"ExternSheet", */
    f: as
  },
  24: {
    /* n:"Lbl", */
    f: Pn
  },
  25: {
    /* n:"WinProtect", */
    f: ze
  },
  26: {
    /* n:"VerticalPageBreaks", */
  },
  27: {
    /* n:"HorizontalPageBreaks", */
  },
  28: {
    /* n:"Note", */
    f: fl
  },
  29: {
    /* n:"Selection", */
  },
  34: {
    /* n:"Date1904", */
    f: ze
  },
  35: {
    /* n:"ExternName", */
    f: Nn
  },
  38: {
    /* n:"LeftMargin", */
    f: xr
  },
  // *
  39: {
    /* n:"RightMargin", */
    f: xr
  },
  // *
  40: {
    /* n:"TopMargin", */
    f: xr
  },
  // *
  41: {
    /* n:"BottomMargin", */
    f: xr
  },
  // *
  42: {
    /* n:"PrintRowCol", */
    f: ze
  },
  43: {
    /* n:"PrintGrid", */
    f: ze
  },
  47: {
    /* n:"FilePass", */
    f: h1
  },
  49: {
    /* n:"Font", */
    f: Wo
  },
  51: {
    /* n:"PrintSize", */
    f: Xe
  },
  60: {
    /* n:"Continue", */
  },
  61: {
    /* n:"Window1", */
    f: Mo
  },
  64: {
    /* n:"Backup", */
    f: ze
  },
  65: {
    /* n:"Pane", */
    f: Ho
  },
  66: {
    /* n:"CodePage", */
    f: Xe
  },
  77: {
    /* n:"Pls", */
  },
  80: {
    /* n:"DCon", */
  },
  81: {
    /* n:"DConRef", */
  },
  82: {
    /* n:"DConName", */
  },
  85: {
    /* n:"DefColWidth", */
    f: Xe
  },
  89: {
    /* n:"XCT", */
  },
  90: {
    /* n:"CRN", */
  },
  91: {
    /* n:"FileSharing", */
  },
  92: {
    /* n:"WriteAccess", */
    f: Io
  },
  93: {
    /* n:"Obj", */
    f: ll
  },
  94: {
    /* n:"Uncalced", */
  },
  95: {
    /* n:"CalcSaveRecalc", */
    f: ze
  },
  //
  96: {
    /* n:"Template", */
  },
  97: {
    /* n:"Intl", */
  },
  99: {
    /* n:"ObjProtect", */
    f: ze
  },
  125: {
    /* n:"ColInfo", */
    f: ts
  },
  128: {
    /* n:"Guts", */
    f: el
  },
  129: {
    /* n:"WsBool", */
    f: Oo
  },
  130: {
    /* n:"GridSet", */
    f: Xe
  },
  131: {
    /* n:"HCenter", */
    f: ze
  },
  132: {
    /* n:"VCenter", */
    f: ze
  },
  133: {
    /* n:"BoundSheet8", */
    f: Ro
  },
  134: {
    /* n:"WriteProtect", */
  },
  140: {
    /* n:"Country", */
    f: pl
  },
  141: {
    /* n:"HideObj", */
    f: Xe
  },
  144: {
    /* n:"Sort", */
  },
  146: {
    /* n:"Palette", */
    f: ml
  },
  151: {
    /* n:"Sync", */
  },
  152: {
    /* n:"LPr", */
  },
  153: {
    /* n:"DxGCol", */
  },
  154: {
    /* n:"FnGroupName", */
  },
  155: {
    /* n:"FilterMode", */
  },
  156: {
    /* n:"BuiltInFnGroupCount", */
    f: Xe
  },
  157: {
    /* n:"AutoFilterInfo", */
  },
  158: {
    /* n:"AutoFilter", */
  },
  160: {
    /* n:"Scl", */
    f: wl
  },
  161: {
    /* n:"Setup", */
    f: Tl
  },
  174: {
    /* n:"ScenMan", */
  },
  175: {
    /* n:"SCENARIO", */
  },
  176: {
    /* n:"SxView", */
  },
  177: {
    /* n:"Sxvd", */
  },
  178: {
    /* n:"SXVI", */
  },
  180: {
    /* n:"SxIvd", */
  },
  181: {
    /* n:"SXLI", */
  },
  182: {
    /* n:"SXPI", */
  },
  184: {
    /* n:"DocRoute", */
  },
  185: {
    /* n:"RecipName", */
  },
  189: {
    /* n:"MulRk", */
    f: Ko
  },
  190: {
    /* n:"MulBlank", */
    f: Yo
  },
  193: {
    /* n:"Mms", */
    f: na
  },
  197: {
    /* n:"SXDI", */
  },
  198: {
    /* n:"SXDB", */
  },
  199: {
    /* n:"SXFDB", */
  },
  200: {
    /* n:"SXDBB", */
  },
  201: {
    /* n:"SXNum", */
  },
  202: {
    /* n:"SxBool", */
    f: ze
  },
  203: {
    /* n:"SxErr", */
  },
  204: {
    /* n:"SXInt", */
  },
  205: {
    /* n:"SXString", */
  },
  206: {
    /* n:"SXDtr", */
  },
  207: {
    /* n:"SxNil", */
  },
  208: {
    /* n:"SXTbl", */
  },
  209: {
    /* n:"SXTBRGIITM", */
  },
  210: {
    /* n:"SxTbpg", */
  },
  211: {
    /* n:"ObProj", */
  },
  213: {
    /* n:"SXStreamID", */
  },
  215: {
    /* n:"DBCell", */
  },
  216: {
    /* n:"SXRng", */
  },
  217: {
    /* n:"SxIsxoper", */
  },
  218: {
    /* n:"BookBool", */
    f: Xe
  },
  220: {
    /* n:"DbOrParamQry", */
  },
  221: {
    /* n:"ScenarioProtect", */
    f: ze
  },
  222: {
    /* n:"OleObjectSize", */
  },
  224: {
    /* n:"XF", */
    f: Jo
  },
  225: {
    /* n:"InterfaceHdr", */
    f: Do
  },
  226: {
    /* n:"InterfaceEnd", */
    f: na
  },
  227: {
    /* n:"SXVS", */
  },
  229: {
    /* n:"MergeCells", */
    f: ol
  },
  233: {
    /* n:"BkHim", */
  },
  235: {
    /* n:"MsoDrawingGroup", */
  },
  236: {
    /* n:"MsoDrawing", */
  },
  237: {
    /* n:"MsoDrawingSelection", */
  },
  239: {
    /* n:"PhoneticInfo", */
  },
  240: {
    /* n:"SxRule", */
  },
  241: {
    /* n:"SXEx", */
  },
  242: {
    /* n:"SxFilt", */
  },
  244: {
    /* n:"SxDXF", */
  },
  245: {
    /* n:"SxItm", */
  },
  246: {
    /* n:"SxName", */
  },
  247: {
    /* n:"SxSelect", */
  },
  248: {
    /* n:"SXPair", */
  },
  249: {
    /* n:"SxFmla", */
  },
  251: {
    /* n:"SxFormat", */
  },
  252: {
    /* n:"SST", */
    f: No
  },
  253: {
    /* n:"LabelSst", */
    f: Vo
  },
  255: {
    /* n:"ExtSST", */
    f: Po
  },
  256: {
    /* n:"SXVDEx", */
  },
  259: {
    /* n:"SXFormula", */
  },
  290: {
    /* n:"SXDBEx", */
  },
  311: {
    /* n:"RRDInsDel", */
  },
  312: {
    /* n:"RRDHead", */
  },
  315: {
    /* n:"RRDChgCell", */
  },
  317: {
    /* n:"RRTabId", */
    f: ji
  },
  318: {
    /* n:"RRDRenSheet", */
  },
  319: {
    /* n:"RRSort", */
  },
  320: {
    /* n:"RRDMove", */
  },
  330: {
    /* n:"RRFormat", */
  },
  331: {
    /* n:"RRAutoFmt", */
  },
  333: {
    /* n:"RRInsertSh", */
  },
  334: {
    /* n:"RRDMoveBegin", */
  },
  335: {
    /* n:"RRDMoveEnd", */
  },
  336: {
    /* n:"RRDInsDelBegin", */
  },
  337: {
    /* n:"RRDInsDelEnd", */
  },
  338: {
    /* n:"RRDConflict", */
  },
  339: {
    /* n:"RRDDefName", */
  },
  340: {
    /* n:"RRDRstEtxp", */
  },
  351: {
    /* n:"LRng", */
  },
  352: {
    /* n:"UsesELFs", */
    f: ze
  },
  353: {
    /* n:"DSF", */
    f: na
  },
  401: {
    /* n:"CUsr", */
  },
  402: {
    /* n:"CbUsr", */
  },
  403: {
    /* n:"UsrInfo", */
  },
  404: {
    /* n:"UsrExcl", */
  },
  405: {
    /* n:"FileLock", */
  },
  406: {
    /* n:"RRDInfo", */
  },
  407: {
    /* n:"BCUsrs", */
  },
  408: {
    /* n:"UsrChk", */
  },
  425: {
    /* n:"UserBView", */
  },
  426: {
    /* n:"UserSViewBegin", */
  },
  427: {
    /* n:"UserSViewEnd", */
  },
  428: {
    /* n:"RRDUserView", */
  },
  429: {
    /* n:"Qsi", */
  },
  430: {
    /* n:"SupBook", */
    f: tl
  },
  431: {
    /* n:"Prot4Rev", */
    f: ze
  },
  432: {
    /* n:"CondFmt", */
  },
  433: {
    /* n:"CF", */
  },
  434: {
    /* n:"DVal", */
  },
  437: {
    /* n:"DConBin", */
  },
  438: {
    /* n:"TxO", */
    f: xl
  },
  439: {
    /* n:"RefreshAll", */
    f: ze
  },
  //
  440: {
    /* n:"HLink", */
    f: dl
  },
  441: {
    /* n:"Lel", */
  },
  442: {
    /* n:"CodeName", */
    f: xt
  },
  443: {
    /* n:"SXFDBType", */
  },
  444: {
    /* n:"Prot4RevPass", */
    f: Xe
  },
  445: {
    /* n:"ObNoMacros", */
  },
  446: {
    /* n:"Dv", */
  },
  448: {
    /* n:"Excel9File", */
    f: na
  },
  449: {
    /* n:"RecalcId", */
    f: Bo,
    r: 2
  },
  450: {
    /* n:"EntExU2", */
    f: na
  },
  512: {
    /* n:"Dimensions", */
    f: On
  },
  513: {
    /* n:"Blank", */
    f: kl
  },
  515: {
    /* n:"Number", */
    f: al
  },
  516: {
    /* n:"Label", */
    f: Go
  },
  517: {
    /* n:"BoolErr", */
    f: rl
  },
  519: {
    /* n:"String", */
    f: Fl
  },
  520: {
    /* n:"Row", */
    f: bo
  },
  523: {
    /* n:"Index", */
  },
  545: {
    /* n:"Array", */
    f: Ln
  },
  549: {
    /* n:"DefaultRowHeight", */
    f: In
  },
  566: {
    /* n:"Table", */
  },
  574: {
    /* n:"Window2", */
    f: Uo
  },
  638: {
    /* n:"RK", */
    f: zo
  },
  659: {
    /* n:"Style", */
  },
  1048: {
    /* n:"BigName", */
  },
  1054: {
    /* n:"Format", */
    f: $o
  },
  1084: {
    /* n:"ContinueBigName", */
  },
  1212: {
    /* n:"ShrFmla", */
    f: il
  },
  2048: {
    /* n:"HLinkTooltip", */
    f: vl
  },
  2049: {
    /* n:"WebPub", */
  },
  2050: {
    /* n:"QsiSXTag", */
  },
  2051: {
    /* n:"DBQueryExt", */
  },
  2052: {
    /* n:"ExtString", */
  },
  2053: {
    /* n:"TxtQry", */
  },
  2054: {
    /* n:"Qsir", */
  },
  2055: {
    /* n:"Qsif", */
  },
  2056: {
    /* n:"RRDTQSIF", */
  },
  2057: {
    /* n:"BOF", */
    f: At
  },
  2058: {
    /* n:"OleDbConn", */
  },
  2059: {
    /* n:"WOpt", */
  },
  2060: {
    /* n:"SXViewEx", */
  },
  2061: {
    /* n:"SXTH", */
  },
  2062: {
    /* n:"SXPIEx", */
  },
  2063: {
    /* n:"SXVDTEx", */
  },
  2064: {
    /* n:"SXViewEx9", */
  },
  2066: {
    /* n:"ContinueFrt", */
  },
  2067: {
    /* n:"RealTimeData", */
  },
  2128: {
    /* n:"ChartFrtInfo", */
  },
  2129: {
    /* n:"FrtWrapper", */
  },
  2130: {
    /* n:"StartBlock", */
  },
  2131: {
    /* n:"EndBlock", */
  },
  2132: {
    /* n:"StartObject", */
  },
  2133: {
    /* n:"EndObject", */
  },
  2134: {
    /* n:"CatLab", */
  },
  2135: {
    /* n:"YMult", */
  },
  2136: {
    /* n:"SXViewLink", */
  },
  2137: {
    /* n:"PivotChartBits", */
  },
  2138: {
    /* n:"FrtFontList", */
  },
  2146: {
    /* n:"SheetExt", */
  },
  2147: {
    /* n:"BookExt", */
    r: 12
  },
  2148: {
    /* n:"SXAddl", */
  },
  2149: {
    /* n:"CrErr", */
  },
  2150: {
    /* n:"HFPicture", */
  },
  2151: {
    /* n:"FeatHdr", */
    f: na
  },
  2152: {
    /* n:"Feat", */
  },
  2154: {
    /* n:"DataLabExt", */
  },
  2155: {
    /* n:"DataLabExtContents", */
  },
  2156: {
    /* n:"CellWatch", */
  },
  2161: {
    /* n:"FeatHdr11", */
  },
  2162: {
    /* n:"Feature11", */
  },
  2164: {
    /* n:"DropDownObjIds", */
  },
  2165: {
    /* n:"ContinueFrt11", */
  },
  2166: {
    /* n:"DConn", */
  },
  2167: {
    /* n:"List12", */
  },
  2168: {
    /* n:"Feature12", */
  },
  2169: {
    /* n:"CondFmt12", */
  },
  2170: {
    /* n:"CF12", */
  },
  2171: {
    /* n:"CFEx", */
  },
  2172: {
    /* n:"XFCRC", */
    f: _l,
    r: 12
  },
  2173: {
    /* n:"XFExt", */
    f: $1,
    r: 12
  },
  2174: {
    /* n:"AutoFilter12", */
  },
  2175: {
    /* n:"ContinueFrt12", */
  },
  2180: {
    /* n:"MDTInfo", */
  },
  2181: {
    /* n:"MDXStr", */
  },
  2182: {
    /* n:"MDXTuple", */
  },
  2183: {
    /* n:"MDXSet", */
  },
  2184: {
    /* n:"MDXProp", */
  },
  2185: {
    /* n:"MDXKPI", */
  },
  2186: {
    /* n:"MDB", */
  },
  2187: {
    /* n:"PLV", */
  },
  2188: {
    /* n:"Compat12", */
    f: ze,
    r: 12
  },
  2189: {
    /* n:"DXF", */
  },
  2190: {
    /* n:"TableStyles", */
    r: 12
  },
  2191: {
    /* n:"TableStyle", */
  },
  2192: {
    /* n:"TableStyleElement", */
  },
  2194: {
    /* n:"StyleExt", */
  },
  2195: {
    /* n:"NamePublish", */
  },
  2196: {
    /* n:"NameCmt", */
    f: nl,
    r: 12
  },
  2197: {
    /* n:"SortData", */
  },
  2198: {
    /* n:"Theme", */
    f: M1,
    r: 12
  },
  2199: {
    /* n:"GUIDTypeLib", */
  },
  2200: {
    /* n:"FnGrp12", */
  },
  2201: {
    /* n:"NameFnGrp12", */
  },
  2202: {
    /* n:"MTRSettings", */
    f: sl,
    r: 12
  },
  2203: {
    /* n:"CompressPictures", */
    f: na
  },
  2204: {
    /* n:"HeaderFooter", */
  },
  2205: {
    /* n:"CrtLayout12", */
  },
  2206: {
    /* n:"CrtMlFrt", */
  },
  2207: {
    /* n:"CrtMlFrtContinue", */
  },
  2211: {
    /* n:"ForceFullCalculation", */
    f: Lo
  },
  2212: {
    /* n:"ShapePropsStream", */
  },
  2213: {
    /* n:"TextPropsStream", */
  },
  2214: {
    /* n:"RichTextStream", */
  },
  2215: {
    /* n:"CrtLayout12A", */
  },
  4097: {
    /* n:"Units", */
  },
  4098: {
    /* n:"Chart", */
  },
  4099: {
    /* n:"Series", */
  },
  4102: {
    /* n:"DataFormat", */
  },
  4103: {
    /* n:"LineFormat", */
  },
  4105: {
    /* n:"MarkerFormat", */
  },
  4106: {
    /* n:"AreaFormat", */
  },
  4107: {
    /* n:"PieFormat", */
  },
  4108: {
    /* n:"AttachedLabel", */
  },
  4109: {
    /* n:"SeriesText", */
  },
  4116: {
    /* n:"ChartFormat", */
  },
  4117: {
    /* n:"Legend", */
  },
  4118: {
    /* n:"SeriesList", */
  },
  4119: {
    /* n:"Bar", */
  },
  4120: {
    /* n:"Line", */
  },
  4121: {
    /* n:"Pie", */
  },
  4122: {
    /* n:"Area", */
  },
  4123: {
    /* n:"Scatter", */
  },
  4124: {
    /* n:"CrtLine", */
  },
  4125: {
    /* n:"Axis", */
  },
  4126: {
    /* n:"Tick", */
  },
  4127: {
    /* n:"ValueRange", */
  },
  4128: {
    /* n:"CatSerRange", */
  },
  4129: {
    /* n:"AxisLine", */
  },
  4130: {
    /* n:"CrtLink", */
  },
  4132: {
    /* n:"DefaultText", */
  },
  4133: {
    /* n:"Text", */
  },
  4134: {
    /* n:"FontX", */
    f: Xe
  },
  4135: {
    /* n:"ObjectLink", */
  },
  4146: {
    /* n:"Frame", */
  },
  4147: {
    /* n:"Begin", */
  },
  4148: {
    /* n:"End", */
  },
  4149: {
    /* n:"PlotArea", */
  },
  4154: {
    /* n:"Chart3d", */
  },
  4156: {
    /* n:"PicF", */
  },
  4157: {
    /* n:"DropBar", */
  },
  4158: {
    /* n:"Radar", */
  },
  4159: {
    /* n:"Surf", */
  },
  4160: {
    /* n:"RadarArea", */
  },
  4161: {
    /* n:"AxisParent", */
  },
  4163: {
    /* n:"LegendException", */
  },
  4164: {
    /* n:"ShtProps", */
    f: El
  },
  4165: {
    /* n:"SerToCrt", */
  },
  4166: {
    /* n:"AxesUsed", */
  },
  4168: {
    /* n:"SBaseRef", */
  },
  4170: {
    /* n:"SerParent", */
  },
  4171: {
    /* n:"SerAuxTrend", */
  },
  4174: {
    /* n:"IFmtRecord", */
  },
  4175: {
    /* n:"Pos", */
  },
  4176: {
    /* n:"AlRuns", */
  },
  4177: {
    /* n:"BRAI", */
  },
  4187: {
    /* n:"SerAuxErrBar", */
  },
  4188: {
    /* n:"ClrtClient", */
    f: gl
  },
  4189: {
    /* n:"SerFmt", */
  },
  4191: {
    /* n:"Chart3DBarShape", */
  },
  4192: {
    /* n:"Fbi", */
  },
  4193: {
    /* n:"BopPop", */
  },
  4194: {
    /* n:"AxcExt", */
  },
  4195: {
    /* n:"Dat", */
  },
  4196: {
    /* n:"PlotGrowth", */
  },
  4197: {
    /* n:"SIIndex", */
  },
  4198: {
    /* n:"GelFrame", */
  },
  4199: {
    /* n:"BopPopCustom", */
  },
  4200: {
    /* n:"Fbi2", */
  },
  0: {
    /* n:"Dimensions", */
    f: On
  },
  1: {
    /* n:"BIFF2BLANK", */
  },
  2: {
    /* n:"BIFF2INT", */
    f: Cl
  },
  3: {
    /* n:"BIFF2NUM", */
    f: Sl
  },
  4: {
    /* n:"BIFF2STR", */
    f: yl
  },
  5: {
    /* n:"BIFF2BOOLERR", */
    f: Il
  },
  7: {
    /* n:"String", */
    f: Dl
  },
  8: {
    /* n:"BIFF2ROW", */
  },
  9: {
    /* n:"BOF", */
    f: At
  },
  11: {
    /* n:"Index", */
  },
  22: {
    /* n:"ExternCount", */
    f: Xe
  },
  30: {
    /* n:"BIFF2FORMAT", */
    f: Xo
  },
  31: {
    /* n:"BIFF2FMTCNT", */
  },
  /* 16-bit cnt of BIFF2FORMAT records */
  32: {
    /* n:"BIFF2COLINFO", */
  },
  33: {
    /* n:"Array", */
    f: Ln
  },
  36: {
    /* n:"COLWIDTH", */
  },
  37: {
    /* n:"DefaultRowHeight", */
    f: In
  },
  // 0x002c ??
  // 0x002d ??
  // 0x002e ??
  // 0x0030 FONTCOUNT: number of fonts
  50: {
    /* n:"BIFF2FONTXTRA", */
    f: Ol
  },
  // 0x0035: INFOOPTS
  // 0x0036: TABLE (BIFF2 only)
  // 0x0037: TABLE2 (BIFF2 only)
  // 0x0038: WNDESK
  // 0x0039 ??
  // 0x003a: BEGINPREF
  // 0x003b: ENDPREF
  62: {
    /* n:"BIFF2WINDOW2", */
  },
  // 0x003f ??
  // 0x0046: SHOWSCROLL
  // 0x0047: SHOWFORMULA
  // 0x0048: STATUSBAR
  // 0x0049: SHORTMENUS
  // 0x004A:
  // 0x004B:
  // 0x004C:
  // 0x004E:
  // 0x004F:
  // 0x0058: TOOLBAR (BIFF3)
  /* - - - */
  52: {
    /* n:"DDEObjName", */
  },
  67: {
    /* n:"BIFF2XF", */
    f: Zo
  },
  68: {
    /* n:"BIFF2XFINDEX", */
    f: Xe
  },
  69: {
    /* n:"BIFF2FONTCLR", */
  },
  86: {
    /* n:"BIFF4FMTCNT", */
  },
  /* 16-bit cnt, similar to BIFF2 */
  126: {
    /* n:"RK", */
  },
  /* Not necessarily same as 0x027e */
  127: {
    /* n:"ImData", */
    f: Al
  },
  135: {
    /* n:"Addin", */
  },
  136: {
    /* n:"Edg", */
  },
  137: {
    /* n:"Pub", */
  },
  // 0x8A
  // 0x8B LH: alternate menu key flag (BIFF3/4)
  // 0x8E
  143: {
    /* n:"BIFF4SheetInfo", */
    f: Nl
  },
  145: {
    /* n:"Sub", */
  },
  // 0x93 STYLE
  148: {
    /* n:"LHRecord", */
  },
  149: {
    /* n:"LHNGraph", */
  },
  150: {
    /* n:"Sound", */
  },
  // 0xA2 FNPROTO: function prototypes (BIFF4)
  // 0xA3
  // 0xA8
  169: {
    /* n:"CoordList", */
  },
  171: {
    /* n:"GCW", */
  },
  188: {
    /* n:"ShrFmla", */
  },
  /* Not necessarily same as 0x04bc */
  191: {
    /* n:"ToolbarHdr", */
  },
  192: {
    /* n:"ToolbarEnd", */
  },
  194: {
    /* n:"AddMenu", */
  },
  195: {
    /* n:"DelMenu", */
  },
  214: {
    /* n:"RString", */
    f: Rl
  },
  223: {
    /* n:"UDDesc", */
  },
  234: {
    /* n:"TabIdConf", */
  },
  354: {
    /* n:"XL5Modify", */
  },
  421: {
    /* n:"FileSharing2", */
  },
  518: {
    /* n:"Formula", */
    f: l0
  },
  521: {
    /* n:"BOF", */
    f: At
  },
  536: {
    /* n:"Lbl", */
    f: Pn
  },
  547: {
    /* n:"ExternName", */
    f: Nn
  },
  561: {
    /* n:"Font", */
  },
  579: {
    /* n:"BIFF3XF", */
    f: qo
  },
  1030: {
    /* n:"Formula", */
    f: l0
  },
  1033: {
    /* n:"BOF", */
    f: At
  },
  1091: {
    /* n:"BIFF4XF", */
    f: Qo
  },
  2157: {
    /* n:"FeatInfo", */
  },
  2163: {
    /* n:"FeatInfo11", */
  },
  2177: {
    /* n:"SXAddl12", */
  },
  2240: {
    /* n:"AutoWebPub", */
  },
  2241: {
    /* n:"ListObj", */
  },
  2242: {
    /* n:"ListField", */
  },
  2243: {
    /* n:"ListDV", */
  },
  2244: {
    /* n:"ListCondFmt", */
  },
  2245: {
    /* n:"ListCF", */
  },
  2246: {
    /* n:"FMQry", */
  },
  2247: {
    /* n:"FMSQry", */
  },
  2248: {
    /* n:"PLV", */
  },
  2249: {
    /* n:"LnExt", */
  },
  2250: {
    /* n:"MkrExt", */
  },
  2251: {
    /* n:"CrtCoopt", */
  },
  2262: {
    /* n:"FRTArchId$", */
    r: 12
  },
  /* --- multiplan 4 records --- */
  101: {
    /* n:"", */
  },
  // one per window
  102: {
    /* n:"", */
  },
  // calc settings
  105: {
    /* n:"", */
  },
  // print header
  106: {
    /* n:"", */
  },
  // print footer
  107: {
    /* n:"", */
  },
  // print settings
  109: {
    /* n:"", */
  },
  // one per window
  112: {
    /* n:"", */
  },
  // includes default col width
  114: {
    /* n:"", */
  },
  // includes selected cell
  29282: {}
};
function Sr(e, a, r, t) {
  var n = a;
  if (!isNaN(n)) {
    var i = (r || []).length || 0, c = e.next(4);
    c.write_shift(2, n), c.write_shift(2, i), /*:: len != null &&*/
    i > 0 && Mi(r) && e.push(r);
  }
}
function Yn(e, a) {
  var r = a || {}, t = r.dense != null ? r.dense : nc, n = {};
  t && (n["!data"] = []), e = ut(e, "<!--", "-->");
  var i = e.match(/<table/i);
  if (!i) throw new Error("Invalid HTML: could not find <table>");
  var c = e.match(/<\/table/i), s = i.index, f = c && c.index || e.length, o = zc(e.slice(s, f), /(:?<tr[^<>]*>)/i, "<tr>"), l = -1, v = 0, x = 0, u = 0, p = { s: { r: 1e7, c: 1e7 }, e: { r: 0, c: 0 } }, _ = [];
  for (s = 0; s < o.length; ++s) {
    var d = o[s].trim(), h = d.slice(0, 3).toLowerCase();
    if (h == "<tr") {
      if (++l, r.sheetRows && r.sheetRows <= l) {
        --l;
        break;
      }
      v = 0;
      continue;
    }
    if (!(h != "<td" && h != "<th")) {
      var E = d.split(/<\/t[dh]>/i);
      for (f = 0; f < E.length; ++f) {
        var g = E[f].trim();
        if (g.match(/<t[dh]/i)) {
          for (var C = g, P = 0; C.charAt(0) == "<" && (P = C.indexOf(">")) > -1; ) C = C.slice(P + 1);
          for (var M = 0; M < _.length; ++M) {
            var I = _[M];
            I.s.c == v && I.s.r < l && l <= I.e.r && (v = I.e.c + 1, M = -1);
          }
          var N = le(g.slice(0, g.indexOf(">")));
          u = N.colspan ? +N.colspan : 1, ((x = +N.rowspan) > 1 || u > 1) && _.push({ s: { r: l, c: v }, e: { r: l + (x || 1) - 1, c: v + u - 1 } });
          var O = N.t || N["data-t"] || "";
          if (!C.length) {
            v += u;
            continue;
          }
          if (C = Ai(C), p.s.r > l && (p.s.r = l), p.e.r < l && (p.e.r = l), p.s.c > v && (p.s.c = v), p.e.c < v && (p.e.c = v), !C.length) {
            v += u;
            continue;
          }
          var B = { t: "s", v: C };
          r.raw || !C.trim().length || O == "s" || (C === "TRUE" ? B = { t: "b", v: !0 } : C === "FALSE" ? B = { t: "b", v: !1 } : isNaN(Or(C)) ? isNaN(it(C).getDate()) ? C.charCodeAt(0) == 35 && sr[C] != null && (B.t = "e", B.w = C, B.v = sr[C]) : (B = { t: "d", v: fr(C) }, r.UTC === !1 && (B.v = wa(B.v)), r.cellDates || (B = { t: "n", v: ar(B.v) }), B.z = r.dateNF || ge[14]) : B = { t: "n", v: Or(C) }), B.cellText !== !1 && (B.w = C), t ? (n["!data"][l] || (n["!data"][l] = []), n["!data"][l][v] = B) : n[Ne({ r: l, c: v })] = B, v += u;
        }
      }
    }
  }
  return n["!ref"] = Ce(p), _.length && (n["!merges"] = _), n;
}
function kd(e, a, r, t) {
  for (var n = e["!merges"] || [], i = [], c = {}, s = e["!data"] != null, f = a.s.c; f <= a.e.c; ++f) {
    for (var o = 0, l = 0, v = 0; v < n.length; ++v)
      if (!(n[v].s.r > r || n[v].s.c > f) && !(n[v].e.r < r || n[v].e.c < f)) {
        if (n[v].s.r < r || n[v].s.c < f) {
          o = -1;
          break;
        }
        o = n[v].e.r - n[v].s.r + 1, l = n[v].e.c - n[v].s.c + 1;
        break;
      }
    if (!(o < 0)) {
      var x = Pe(f) + Me(r), u = s ? (e["!data"][r] || [])[f] : e[x];
      u && u.t == "n" && u.v != null && !isFinite(u.v) && (isNaN(u.v) ? u = { t: "e", v: 36, w: Ar[36] } : u = { t: "e", v: 7, w: Ar[7] });
      var p = u && u.v != null && (u.h || za(u.w || (oa(u), u.w) || "")) || "";
      c = {}, o > 1 && (c.rowspan = o), l > 1 && (c.colspan = l), t.editable ? p = '<span contenteditable="true">' + p + "</span>" : u && (c["data-t"] = u && u.t || "z", u.v != null && (c["data-v"] = za(u.v instanceof Date ? u.v.toISOString() : u.v)), u.z != null && (c["data-z"] = u.z), u.l && (u.l.Target || "#").charAt(0) != "#" && (p = '<a href="' + za(u.l.Target) + '">' + p + "</a>")), c.id = (t.id || "sjs") + "-" + x, i.push(uf("td", p, c));
    }
  }
  var _ = "<tr>";
  return _ + i.join("") + "</tr>";
}
var wd = '<html><head><meta charset="utf-8"/><title>SheetJS Table Export</title></head><body>', Fd = "</body></html>";
function Ad(e, a) {
  var r = jc(e, "table");
  if (!r || r.length == 0) throw new Error("Invalid HTML: could not find <table>");
  if (r.length == 1) {
    var t = ha(Yn(r[0], a), a);
    return t.bookType = "html", t;
  }
  var n = z0();
  return r.forEach(function(i, c) {
    gt(n, Yn(i, a), "Sheet" + (c + 1));
  }), n.bookType = "html", n;
}
function yd(e, a, r) {
  var t = [];
  return t.join("") + "<table" + (r && r.id ? ' id="' + r.id + '"' : "") + ">";
}
function Sd(e, a) {
  var r = a || {}, t = r.header != null ? r.header : wd, n = r.footer != null ? r.footer : Fd, i = [t], c = Aa(e["!ref"] || "A1");
  if (i.push(yd(e, c, r)), e["!ref"]) for (var s = c.s.r; s <= c.e.r; ++s) i.push(kd(e, c, s, r));
  return i.push("</table>" + n), i.join("");
}
function Cs(e, a, r) {
  var t = a.rows;
  if (!t)
    throw "Unsupported origin when " + a.tagName + " is not a TABLE";
  var n = r || {}, i = e["!data"] != null, c = 0, s = 0;
  if (n.origin != null)
    if (typeof n.origin == "number") c = n.origin;
    else {
      var f = typeof n.origin == "string" ? dr(n.origin) : n.origin;
      c = f.r, s = f.c;
    }
  var o = Math.min(n.sheetRows || 1e7, t.length), l = { s: { r: 0, c: 0 }, e: { r: c, c: s } };
  if (e["!ref"]) {
    var v = Aa(e["!ref"]);
    l.s.r = Math.min(l.s.r, v.s.r), l.s.c = Math.min(l.s.c, v.s.c), l.e.r = Math.max(l.e.r, v.e.r), l.e.c = Math.max(l.e.c, v.e.c), c == -1 && (l.e.r = c = v.e.r + 1);
  }
  var x = [], u = 0, p = e["!rows"] || (e["!rows"] = []), _ = 0, d = 0, h = 0, E = 0, g = 0, C = 0;
  for (e["!cols"] || (e["!cols"] = []); _ < t.length && d < o; ++_) {
    var P = t[_];
    if (jn(P)) {
      if (n.display) continue;
      p[d] = { hidden: !0 };
    }
    var M = P.cells;
    for (h = E = 0; h < M.length; ++h) {
      var I = M[h];
      if (!(n.display && jn(I))) {
        var N = I.hasAttribute("data-v") ? I.getAttribute("data-v") : I.hasAttribute("v") ? I.getAttribute("v") : Ai(I.innerHTML), O = I.getAttribute("data-z") || I.getAttribute("z");
        for (u = 0; u < x.length; ++u) {
          var B = x[u];
          B.s.c == E + s && B.s.r < d + c && d + c <= B.e.r && (E = B.e.c + 1 - s, u = -1);
        }
        C = +I.getAttribute("colspan") || 1, ((g = +I.getAttribute("rowspan") || 1) > 1 || C > 1) && x.push({ s: { r: d + c, c: E + s }, e: { r: d + c + (g || 1) - 1, c: E + s + (C || 1) - 1 } });
        var b = { t: "s", v: N }, G = I.getAttribute("data-t") || I.getAttribute("t") || "";
        N != null && (N.length == 0 ? b.t = G || "z" : n.raw || N.trim().length == 0 || G == "s" || (G == "e" && Ar[+N] ? b = { t: "e", v: +N, w: Ar[+N] } : N === "TRUE" ? b = { t: "b", v: !0 } : N === "FALSE" ? b = { t: "b", v: !1 } : isNaN(Or(N)) ? isNaN(it(N).getDate()) ? N.charCodeAt(0) == 35 && sr[N] != null && (b = { t: "e", v: sr[N], w: N }) : (b = { t: "d", v: fr(N) }, n.UTC && (b.v = Yt(b.v)), n.cellDates || (b = { t: "n", v: ar(b.v) }), b.z = n.dateNF || ge[14]) : b = { t: "n", v: Or(N) })), b.z === void 0 && O != null && (b.z = O);
        var z = "", ce = I.getElementsByTagName("A");
        if (ce && ce.length) for (var j = 0; j < ce.length && !(ce[j].hasAttribute("href") && (z = ce[j].getAttribute("href"), z.charAt(0) != "#")); ++j) ;
        z && z.charAt(0) != "#" && z.slice(0, 11).toLowerCase() != "javascript:" && (b.l = { Target: z }), i ? (e["!data"][d + c] || (e["!data"][d + c] = []), e["!data"][d + c][E + s] = b) : e[Ne({ c: E + s, r: d + c })] = b, l.e.c < E + s && (l.e.c = E + s), E += C;
      }
    }
    ++d;
  }
  return x.length && (e["!merges"] = (e["!merges"] || []).concat(x)), l.e.r = Math.max(l.e.r, d - 1 + c), e["!ref"] = Ce(l), d >= o && (e["!fullref"] = Ce((l.e.r = t.length - _ + d - 1 + c, l))), e;
}
function Ds(e, a) {
  var r = a || {}, t = {};
  return r.dense && (t["!data"] = []), Cs(t, e, a);
}
function Cd(e, a) {
  var r = ha(Ds(e, a), a);
  return r;
}
function jn(e) {
  var a = "", r = Dd(e);
  return r && (a = r(e).getPropertyValue("display")), a || (a = e.style && e.style.display), a === "none";
}
function Dd(e) {
  return e.ownerDocument.defaultView && typeof e.ownerDocument.defaultView.getComputedStyle == "function" ? e.ownerDocument.defaultView.getComputedStyle : typeof getComputedStyle == "function" ? getComputedStyle : null;
}
function Id(e) {
  var a = e.replace(/[\t\r\n]/g, " ").trim().replace(/ +/g, " ").replace(/<text:s\/>/g, " ").replace(/<text:s text:c="(\d+)"\/>/g, function(t, n) {
    return Array(parseInt(n, 10) + 1).join(" ");
  }).replace(/<text:tab[^<>]*\/>/g, "	").replace(/<text:line-break\/>/g, `
`), r = Se(a.replace(/<[^<>]*>/g, ""));
  return [r];
}
function Is(e, a, r) {
  var t = r || {}, n = jt(e);
  qe.lastIndex = 0, n = I0(ut(n, "<!--", "-->"));
  for (var i, c, s = "", f = "", o, l = 0, v = -1, x = ""; i = qe.exec(n); )
    switch (i[3] = i[3].replace(/_[\s\S]*$/, "")) {
      /* Number Format Definitions */
      case "number-style":
      // <number:number-style> 16.29.2
      case "currency-style":
      // <number:currency-style> 16.29.8
      case "percentage-style":
      // <number:percentage-style> 16.29.10
      case "date-style":
      // <number:date-style> 16.29.11
      case "time-style":
      // <number:time-style> 16.29.19
      case "text-style":
        i[1] === "/" ? (c["truncate-on-overflow"] == "false" && (s.match(/h/) ? s = s.replace(/h+/, "[$&]") : s.match(/m/) ? s = s.replace(/m+/, "[$&]") : s.match(/s/) && (s = s.replace(/s+/, "[$&]"))), t[c.name] = s, s = "") : i[0].charAt(i[0].length - 2) !== "/" && (s = "", c = le(i[0], !1));
        break;
      // LibreOffice bug https://bugs.documentfoundation.org/show_bug.cgi?id=149484
      case "boolean-style":
        i[1] === "/" ? (t[c.name] = "General", s = "") : i[0].charAt(i[0].length - 2) !== "/" && (s = "", c = le(i[0], !1));
        break;
      /* Number Format Elements */
      case "boolean":
        s += "General";
        break;
      case "text":
        i[1] === "/" ? (x = n.slice(v, qe.lastIndex - i[0].length), x == "%" && c[0] == "<number:percentage-style" ? s += "%" : s += '"' + x.replace(/"/g, '""') + '"') : i[0].charAt(i[0].length - 2) !== "/" && (v = qe.lastIndex);
        break;
      case "day":
        switch (o = le(i[0], !1), o.style) {
          case "short":
            s += "d";
            break;
          case "long":
            s += "dd";
            break;
          default:
            s += "dd";
            break;
        }
        break;
      case "day-of-week":
        switch (o = le(i[0], !1), o.style) {
          case "short":
            s += "ddd";
            break;
          case "long":
            s += "dddd";
            break;
          default:
            s += "ddd";
            break;
        }
        break;
      case "era":
        switch (o = le(i[0], !1), o.style) {
          case "short":
            s += "ee";
            break;
          case "long":
            s += "eeee";
            break;
          default:
            s += "eeee";
            break;
        }
        break;
      case "hours":
        switch (o = le(i[0], !1), o.style) {
          case "short":
            s += "h";
            break;
          case "long":
            s += "hh";
            break;
          default:
            s += "hh";
            break;
        }
        break;
      case "minutes":
        switch (o = le(i[0], !1), o.style) {
          case "short":
            s += "m";
            break;
          case "long":
            s += "mm";
            break;
          default:
            s += "mm";
            break;
        }
        break;
      case "month":
        switch (o = le(i[0], !1), o.textual && (s += "mm"), o.style) {
          case "short":
            s += "m";
            break;
          case "long":
            s += "mm";
            break;
          default:
            s += "m";
            break;
        }
        break;
      case "seconds":
        {
          switch (o = le(i[0], !1), o.style) {
            case "short":
              s += "s";
              break;
            case "long":
              s += "ss";
              break;
            default:
              s += "ss";
              break;
          }
          o["decimal-places"] && (s += "." + Ie("0", +o["decimal-places"]));
        }
        break;
      case "year":
        switch (o = le(i[0], !1), o.style) {
          case "short":
            s += "yy";
            break;
          case "long":
            s += "yyyy";
            break;
          default:
            s += "yy";
            break;
        }
        break;
      case "am-pm":
        s += "AM/PM";
        break;
      case "week-of-year":
      // <number:week-of-year> 16.29.17
      case "quarter":
        console.error("Excel does not support ODS format token " + i[3]);
        break;
      case "fill-character":
        i[1] === "/" ? (x = n.slice(v, qe.lastIndex - i[0].length), s += '"' + x.replace(/"/g, '""') + '"*') : i[0].charAt(i[0].length - 2) !== "/" && (v = qe.lastIndex);
        break;
      case "scientific-number":
        o = le(i[0], !1), s += "0." + Ie("0", +o["min-decimal-places"] || +o["decimal-places"] || 2) + Ie("?", +o["decimal-places"] - +o["min-decimal-places"] || 0) + "E" + (Be(o["forced-exponent-sign"]) ? "+" : "") + Ie("0", +o["min-exponent-digits"] || 2);
        break;
      case "fraction":
        o = le(i[0], !1), +o["min-integer-digits"] ? s += Ie("0", +o["min-integer-digits"]) : s += "#", s += " ", s += Ie("?", +o["min-numerator-digits"] || 1), s += "/", +o["denominator-value"] ? s += o["denominator-value"] : s += Ie("?", +o["min-denominator-digits"] || 1);
        break;
      case "currency-symbol":
        i[1] === "/" ? s += '"' + n.slice(v, qe.lastIndex - i[0].length).replace(/"/g, '""') + '"' : i[0].charAt(i[0].length - 2) !== "/" ? v = qe.lastIndex : s += "$";
        break;
      case "text-properties":
        switch (o = le(i[0], !1), (o.color || "").toLowerCase().replace("#", "")) {
          case "ff0000":
          case "red":
            s = "[Red]" + s;
            break;
        }
        break;
      case "text-content":
        s += "@";
        break;
      case "map":
        o = le(i[0], !1), Se(o.condition) == "value()>=0" ? s = t[o["apply-style-name"]] + ";" + s : console.error("ODS number format may be incorrect: " + o.condition);
        break;
      case "number":
        if (i[1] === "/") break;
        o = le(i[0], !1), f = "", f += Ie("0", +o["min-integer-digits"] || 1), Be(o.grouping) && (f = qr(Ie("#", Math.max(0, 4 - f.length)) + f)), (+o["min-decimal-places"] || +o["decimal-places"]) && (f += "."), +o["min-decimal-places"] && (f += Ie("0", +o["min-decimal-places"] || 1)), +o["decimal-places"] - (+o["min-decimal-places"] || 0) && (f += Ie("0", +o["decimal-places"] - (+o["min-decimal-places"] || 0))), s += f;
        break;
      case "embedded-text":
        i[1] === "/" ? l == 0 ? s += '"' + n.slice(v, qe.lastIndex - i[0].length).replace(/"/g, '""') + '"' : s = s.slice(0, l) + '"' + n.slice(v, qe.lastIndex - i[0].length).replace(/"/g, '""') + '"' + s.slice(l) : i[0].charAt(i[0].length - 2) !== "/" && (v = qe.lastIndex, l = -+le(i[0], !1).position || 0);
        break;
    }
  return t;
}
function Os(e, a, r) {
  var t = a || {}, n = jt(e), i = [], c, s, f, o = "", l = 0, v, x, u = {}, p = [], _ = {};
  t.dense && (_["!data"] = []);
  var d, h, E = { value: "" }, g = {}, C = "", P = 0, M = "", I = 0, N = [], O = [], B = -1, b = -1, G = { s: { r: 1e6, c: 1e7 }, e: { r: 0, c: 0 } }, z = 0, ce = r || {}, j = {}, he = [], J = {}, ne = 0, pe = 0, X = [], Te = 1, _e = 1, de = [], fe = { Names: [], WBProps: {} }, ke = {}, me = ["", ""], Fe = [], y = {}, L = "", R = 0, D = !1, Y = !1, w = 0;
  for (qe.lastIndex = 0, n = I0(ut(n, "<!--", "-->")); d = qe.exec(n); ) switch (d[3] = d[3].replace(/_[\s\S]*$/, "")) {
    case "table":
    case "工作表":
      d[1] === "/" ? (G.e.c >= G.s.c && G.e.r >= G.s.r ? _["!ref"] = Ce(G) : _["!ref"] = "A1:A1", t.sheetRows > 0 && t.sheetRows <= G.e.r && (_["!fullref"] = _["!ref"], G.e.r = t.sheetRows - 1, _["!ref"] = Ce(G)), he.length && (_["!merges"] = he), X.length && (_["!rows"] = X), v.name = v.名称 || v.name, typeof JSON < "u" && JSON.stringify(v), p.push(v.name), u[v.name] = _, Y = !1) : d[0].charAt(d[0].length - 2) !== "/" && (v = le(d[0], !1), B = b = -1, G.s.r = G.s.c = 1e7, G.e.r = G.e.c = 0, _ = {}, t.dense && (_["!data"] = []), he = [], X = [], Y = !0);
      break;
    case "table-row-group":
      d[1] === "/" ? --z : ++z;
      break;
    case "table-row":
    case "行":
      if (d[1] === "/") {
        B += Te, Te = 1;
        break;
      }
      if (x = le(d[0], !1), x.行号 ? B = x.行号 - 1 : B == -1 && (B = 0), Te = +x["number-rows-repeated"] || 1, Te < 10) for (w = 0; w < Te; ++w) z > 0 && (X[B + w] = { level: z });
      b = -1;
      break;
    case "covered-table-cell":
      if (d[1] !== "/")
        if (++b, E = le(d[0], !1), _e = parseInt(E["number-columns-repeated"] || "1", 10) || 1, t.sheetStubs) {
          for (; _e-- > 0; )
            t.dense ? (_["!data"][B] || (_["!data"][B] = []), _["!data"][B][b] = { t: "z" }) : _[Ne({ r: B, c: b })] = { t: "z" }, ++b;
          --b;
        } else b += _e - 1;
      C = "", N = [];
      break;
    /* stub */
    case "table-cell":
    case "数据":
      if (d[0].charAt(d[0].length - 2) === "/")
        ++b, E = le(d[0], !1), _e = parseInt(E["number-columns-repeated"] || "1", 10) || 1, h = {
          t: "z",
          v: null
          /*:: , z:null, w:"",c:[]*/
        }, E.formula && t.cellFormula != !1 && (h.f = $n(Se(E.formula))), E["style-name"] && j[E["style-name"]] && (h.z = j[E["style-name"]]), (E.数据类型 || E["value-type"]) == "string" && (h.t = "s", h.v = Se(E["string-value"] || ""), t.dense ? (_["!data"][B] || (_["!data"][B] = []), _["!data"][B][b] = h) : _[Pe(b) + Me(B)] = h), b += _e - 1;
      else if (d[1] !== "/") {
        ++b, C = M = "", P = I = 0, N = [], O = [], _e = 1;
        var te = Te ? B + Te - 1 : B;
        if (b > G.e.c && (G.e.c = b), b < G.s.c && (G.s.c = b), B < G.s.r && (G.s.r = B), te > G.e.r && (G.e.r = te), E = le(d[0], !1), g = af(d[0]), Fe = [], y = {}, h = {
          t: E.数据类型 || E["value-type"],
          v: null
          /*:: , z:null, w:"",c:[]*/
        }, E["style-name"] && j[E["style-name"]] && (h.z = j[E["style-name"]]), t.cellFormula)
          if (E.formula && (E.formula = Se(E.formula)), E["number-matrix-columns-spanned"] && E["number-matrix-rows-spanned"] && (ne = parseInt(E["number-matrix-rows-spanned"], 10) || 0, pe = parseInt(E["number-matrix-columns-spanned"], 10) || 0, J = { s: { r: B, c: b }, e: { r: B + ne - 1, c: b + pe - 1 } }, h.F = Ce(J), de.push([J, h.F])), E.formula) h.f = $n(E.formula);
          else for (w = 0; w < de.length; ++w)
            B >= de[w][0].s.r && B <= de[w][0].e.r && b >= de[w][0].s.c && b <= de[w][0].e.c && (h.F = de[w][1]);
        switch ((E["number-columns-spanned"] || E["number-rows-spanned"]) && (ne = parseInt(E["number-rows-spanned"] || "1", 10) || 1, pe = parseInt(E["number-columns-spanned"] || "1", 10) || 1, ne * pe > 1 && (J = { s: { r: B, c: b }, e: { r: B + ne - 1, c: b + pe - 1 } }, he.push(J))), E["number-columns-repeated"] && (_e = parseInt(E["number-columns-repeated"], 10)), h.t) {
          case "boolean":
            h.t = "b", h.v = Be(E["boolean-value"]) || +E["boolean-value"] >= 1;
            break;
          case "float":
            h.t = "n", h.v = parseFloat(E.value), t.cellDates && h.z && Ur(h.z) && (h.v = ca(h.v + (fe.WBProps.date1904 ? 1462 : 0)), h.t = typeof h.v == "number" ? "n" : "d");
            break;
          case "percentage":
            h.t = "n", h.v = parseFloat(E.value);
            break;
          case "currency":
            h.t = "n", h.v = parseFloat(E.value);
            break;
          case "date":
            h.t = "d", h.v = fr(E["date-value"], fe.WBProps.date1904), t.cellDates || (h.t = "n", h.v = ar(h.v, fe.WBProps.date1904)), h.z || (h.z = "m/d/yy");
            break;
          /* NOTE: for `time`, Excel ODS export incorrectly uses durations relative to 1900 epoch even if 1904 is specified */
          case "time":
            h.t = "n", h.v = Lc(E["time-value"]) / 86400, t.cellDates && (h.v = ca(h.v), h.t = typeof h.v == "number" ? "n" : "d"), h.z || (h.z = "HH:MM:SS");
            break;
          case "number":
            h.t = "n", h.v = parseFloat(E.数据数值);
            break;
          default:
            if (h.t === "string" || h.t === "text" || !h.t)
              h.t = "s", E["string-value"] != null && (C = Se(E["string-value"]), N = []);
            else throw new Error("Unsupported value type " + h.t);
        }
      } else {
        if (D = !1, g["calcext:value-type"] == "error" && sr[C] != null && (h.t = "e", h.w = C, h.v = sr[C]), h.t === "s" && (h.v = C || "", N.length && (h.R = N), D = P == 0), ke.Target && (h.l = ke), Fe.length > 0 && (h.c = Fe, Fe = []), C && t.cellText !== !1 && (h.w = C), D && (h.t = "z", delete h.v), (!D || t.sheetStubs) && !(t.sheetRows && t.sheetRows <= B))
          for (var ie = 0; ie < Te; ++ie) {
            if (_e = parseInt(E["number-columns-repeated"] || "1", 10), t.dense)
              for (_["!data"][B + ie] || (_["!data"][B + ie] = []), _["!data"][B + ie][b] = ie == 0 ? h : er(h); --_e > 0; ) _["!data"][B + ie][b + _e] = er(h);
            else
              for (_[Ne({ r: B + ie, c: b })] = h; --_e > 0; ) _[Ne({ r: B + ie, c: b + _e })] = er(h);
            G.e.c <= b && (G.e.c = b);
          }
        _e = parseInt(E["number-columns-repeated"] || "1", 10), b += _e - 1, _e = 0, h = {
          /*:: t:"", v:null, z:null, w:"",c:[]*/
        }, C = "", N = [];
      }
      ke = {};
      break;
    // 9.1.4 <table:table-cell>
    /* pure state */
    case "document":
    // TODO: <office:document> is the root for FODS
    case "document-content":
    case "电子表格文档":
    // 3.1.3.2 <office:document-content>
    case "spreadsheet":
    case "主体":
    // 3.7 <office:spreadsheet>
    case "scripts":
    // 3.12 <office:scripts>
    case "styles":
    // TODO <office:styles>
    case "font-face-decls":
    // 3.14 <office:font-face-decls>
    case "master-styles":
      if (d[1] === "/") {
        if ((c = i.pop())[0] !== d[3]) throw "Bad state: " + c;
      } else d[0].charAt(d[0].length - 2) !== "/" && i.push([d[3], !0]);
      break;
    case "annotation":
      if (d[1] === "/") {
        if ((c = i.pop())[0] !== d[3]) throw "Bad state: " + c;
        y.t = C, N.length && (y.R = N), y.a = L, Fe.push(y), C = M, P = I, N = O;
      } else if (d[0].charAt(d[0].length - 2) !== "/") {
        i.push([d[3], !1]);
        var Q = le(d[0], !0);
        Q.display && Be(Q.display) || (Fe.hidden = !0), M = C, I = P, O = N, C = "", P = 0, N = [];
      }
      L = "", R = 0;
      break;
    case "creator":
      d[1] === "/" ? L = n.slice(R, d.index) : R = d.index + d[0].length;
      break;
    /* ignore state */
    case "meta":
    case "元数据":
    // TODO: <office:meta> <uof:元数据> FODS/UOF
    case "settings":
    // TODO: <office:settings>
    case "config-item-set":
    // TODO: <office:config-item-set>
    case "config-item-map-indexed":
    // TODO: <office:config-item-map-indexed>
    case "config-item-map-entry":
    // TODO: <office:config-item-map-entry>
    case "config-item-map-named":
    // TODO: <office:config-item-map-entry>
    case "shapes":
    // 9.2.8 <table:shapes>
    case "frame":
    // 10.4.2 <draw:frame>
    case "text-box":
    // 10.4.3 <draw:text-box>
    case "image":
    // 10.4.4 <draw:image>
    case "data-pilot-tables":
    // 9.6.2 <table:data-pilot-tables>
    case "list-style":
    // 16.30 <text:list-style>
    case "form":
    // 13.13 <form:form>
    case "dde-links":
    // 9.8 <table:dde-links>
    case "event-listeners":
    // TODO
    case "chart":
      if (d[1] === "/") {
        if ((c = i.pop())[0] !== d[3]) throw "Bad state: " + c;
      } else d[0].charAt(d[0].length - 2) !== "/" && i.push([d[3], !1]);
      C = "", P = 0, N = [];
      break;
    case "scientific-number":
    // <number:scientific-number>
    case "currency-symbol":
    // <number:currency-symbol>
    case "fill-character":
      break;
    case "text-style":
    // 16.27.25 <number:text-style>
    case "boolean-style":
    // 16.27.23 <number:boolean-style>
    case "number-style":
    // 16.27.2 <number:number-style>
    case "currency-style":
    // 16.29.8 <number:currency-style>
    case "percentage-style":
    // 16.27.9 <number:percentage-style>
    case "date-style":
    // 16.27.10 <number:date-style>
    case "time-style":
      if (d[1] === "/") {
        var ve = qe.lastIndex;
        Is(n.slice(f, qe.lastIndex), a, ce), qe.lastIndex = ve;
      } else d[0].charAt(d[0].length - 2) !== "/" && (f = qe.lastIndex - d[0].length);
      break;
    case "script":
      break;
    // 3.13 <office:script>
    case "libraries":
      break;
    // TODO: <ooo:libraries>
    case "automatic-styles":
      break;
    // 3.15.3 <office:automatic-styles>
    case "default-style":
    // TODO: <style:default-style>
    case "page-layout":
      break;
    // TODO: <style:page-layout>
    case "style":
      {
        var xe = le(d[0], !1);
        xe.family == "table-cell" && ce[xe["data-style-name"]] && (j[xe.name] = ce[xe["data-style-name"]]);
      }
      break;
    case "map":
      break;
    // 16.3 <style:map>
    case "font-face":
      break;
    // 16.21 <style:font-face>
    case "paragraph-properties":
      break;
    // 17.6 <style:paragraph-properties>
    case "table-properties":
      break;
    // 17.15 <style:table-properties>
    case "table-column-properties":
      break;
    // 17.16 <style:table-column-properties>
    case "table-row-properties":
      break;
    // 17.17 <style:table-row-properties>
    case "table-cell-properties":
      break;
    // 17.18 <style:table-cell-properties>
    case "number":
      break;
    case "fraction":
      break;
    // TODO 16.27.6 <number:fraction>
    case "day":
    // 16.27.11 <number:day>
    case "month":
    // 16.27.12 <number:month>
    case "year":
    // 16.27.13 <number:year>
    case "era":
    // 16.27.14 <number:era>
    case "day-of-week":
    // 16.27.15 <number:day-of-week>
    case "week-of-year":
    // 16.27.16 <number:week-of-year>
    case "quarter":
    // 16.27.17 <number:quarter>
    case "hours":
    // 16.27.19 <number:hours>
    case "minutes":
    // 16.27.20 <number:minutes>
    case "seconds":
    // 16.27.21 <number:seconds>
    case "am-pm":
      break;
    case "boolean":
      break;
    // 16.27.24 <number:boolean>
    case "text":
      if (d[0].slice(-2) === "/>") break;
      if (d[1] === "/") switch (i[i.length - 1][0]) {
        case "number-style":
        case "date-style":
        case "time-style":
          o += n.slice(l, d.index);
          break;
      }
      else l = d.index + d[0].length;
      break;
    case "named-range":
      s = le(d[0], !1), me = u0(s["cell-range-address"]);
      var Ee = { Name: s.name, Ref: me[0] + "!" + me[1] };
      Y && (Ee.Sheet = p.length), fe.Names.push(Ee);
      break;
    case "text-content":
      break;
    // 16.27.27 <number:text-content>
    case "text-properties":
      break;
    // 16.27.27 <style:text-properties>
    case "embedded-text":
      break;
    // 16.27.4 <number:embedded-text>
    case "body":
    case "电子表格":
      break;
    // 3.3 16.9.6 19.726.3
    case "forms":
      break;
    // 12.25.2 13.2
    case "table-column":
      break;
    // 9.1.6 <table:table-column>
    case "table-header-rows":
      break;
    // 9.1.7 <table:table-header-rows>
    case "table-rows":
      break;
    // 9.1.12 <table:table-rows>
    /* TODO: outline levels */
    case "table-column-group":
      break;
    // 9.1.10 <table:table-column-group>
    case "table-header-columns":
      break;
    // 9.1.11 <table:table-header-columns>
    case "table-columns":
      break;
    // 9.1.12 <table:table-columns>
    case "null-date":
      switch (s = le(d[0], !1), s["date-value"]) {
        case "1904-01-01":
          fe.WBProps.date1904 = !0;
          break;
      }
      break;
    case "graphic-properties":
      break;
    // 17.21 <style:graphic-properties>
    case "calculation-settings":
      break;
    // 9.4.1 <table:calculation-settings>
    case "named-expressions":
      break;
    // 9.4.11 <table:named-expressions>
    case "label-range":
      break;
    // 9.4.9 <table:label-range>
    case "label-ranges":
      break;
    // 9.4.10 <table:label-ranges>
    case "named-expression":
      break;
    // 9.4.13 <table:named-expression>
    case "sort":
      break;
    // 9.4.19 <table:sort>
    case "sort-by":
      break;
    // 9.4.20 <table:sort-by>
    case "sort-groups":
      break;
    // 9.4.22 <table:sort-groups>
    case "tab":
      break;
    // 6.1.4 <text:tab>
    case "line-break":
      break;
    // 6.1.5 <text:line-break>
    case "span":
      break;
    // 6.1.7 <text:span>
    case "p":
    case "文本串":
      if (["master-styles"].indexOf(i[i.length - 1][0]) > -1) break;
      if (d[1] === "/" && (!E || !E["string-value"])) {
        var Le = Id(n.slice(P, d.index));
        C = (C.length > 0 ? C + `
` : "") + Le[0];
      } else d[0].slice(-2) == "/>" ? C += `
` : (le(d[0], !1), P = d.index + d[0].length);
      break;
    // <text:p>
    case "s":
      break;
    // <text:s>
    case "database-range":
      if (d[1] === "/") break;
      try {
        me = u0(le(d[0])["target-range-address"]), u[me[0]]["!autofilter"] = { ref: me[1] };
      } catch {
      }
      break;
    case "date":
      break;
    // <*:date>
    case "object":
      break;
    // 10.4.6.2 <draw:object>
    case "title":
    case "标题":
      break;
    // <*:title> OR <uof:标题>
    case "desc":
      break;
    // <*:desc>
    case "binary-data":
      break;
    // 10.4.5 TODO: b64 blob
    /* 9.2 Advanced Tables */
    case "table-source":
      break;
    // 9.2.6
    case "scenario":
      break;
    // 9.2.6
    case "iteration":
      break;
    // 9.4.3 <table:iteration>
    case "content-validations":
      break;
    // 9.4.4 <table:
    case "content-validation":
      break;
    // 9.4.5 <table:
    case "help-message":
      break;
    // 9.4.6 <table:
    case "error-message":
      break;
    // 9.4.7 <table:
    case "database-ranges":
      break;
    // 9.4.14 <table:database-ranges>
    /* 9.5 Filters */
    case "filter":
      break;
    // 9.5.2 <table:filter>
    case "filter-and":
      break;
    // 9.5.3 <table:filter-and>
    case "filter-or":
      break;
    // 9.5.4 <table:filter-or>
    case "filter-condition":
      break;
    // 9.5.5 <table:filter-condition>
    case "filter-set-item":
      break;
    // 9.5.6 <table:filter-condition>
    case "list-level-style-bullet":
      break;
    // 16.31 <text:
    case "list-level-style-number":
      break;
    // 16.32 <text:
    case "list-level-properties":
      break;
    // 17.19 <style:
    /* 7.3 Document Fields */
    case "sender-firstname":
    // 7.3.6.2
    case "sender-lastname":
    // 7.3.6.3
    case "sender-initials":
    // 7.3.6.4
    case "sender-title":
    // 7.3.6.5
    case "sender-position":
    // 7.3.6.6
    case "sender-email":
    // 7.3.6.7
    case "sender-phone-private":
    // 7.3.6.8
    case "sender-fax":
    // 7.3.6.9
    case "sender-company":
    // 7.3.6.10
    case "sender-phone-work":
    // 7.3.6.11
    case "sender-street":
    // 7.3.6.12
    case "sender-city":
    // 7.3.6.13
    case "sender-postal-code":
    // 7.3.6.14
    case "sender-country":
    // 7.3.6.15
    case "sender-state-or-province":
    // 7.3.6.16
    case "author-name":
    // 7.3.7.1
    case "author-initials":
    // 7.3.7.2
    case "chapter":
    // 7.3.8
    case "file-name":
    // 7.3.9
    case "template-name":
    // 7.3.9
    case "sheet-name":
      break;
    case "event-listener":
      break;
    /* TODO: FODS Properties */
    case "initial-creator":
    case "creation-date":
    case "print-date":
    case "generator":
    case "document-statistic":
    case "user-defined":
    case "editing-duration":
    case "editing-cycles":
      break;
    /* TODO: FODS Config */
    case "config-item":
      break;
    /* TODO: style tokens */
    case "page-number":
      break;
    // TODO <text:page-number>
    case "page-count":
      break;
    // TODO <text:page-count>
    case "time":
      break;
    // TODO <text:time>
    /* 9.3 Advanced Table Cells */
    case "cell-range-source":
      break;
    // 9.3.1 <table:
    case "detective":
      break;
    // 9.3.2 <table:
    case "operation":
      break;
    // 9.3.3 <table:
    case "highlighted-range":
      break;
    // 9.3.4 <table:
    /* 9.6 Data Pilot Tables <table: */
    case "data-pilot-table":
    // 9.6.3
    case "source-cell-range":
    // 9.6.5
    case "source-service":
    // 9.6.6
    case "data-pilot-field":
    // 9.6.7
    case "data-pilot-level":
    // 9.6.8
    case "data-pilot-subtotals":
    // 9.6.9
    case "data-pilot-subtotal":
    // 9.6.10
    case "data-pilot-members":
    // 9.6.11
    case "data-pilot-member":
    // 9.6.12
    case "data-pilot-display-info":
    // 9.6.13
    case "data-pilot-sort-info":
    // 9.6.14
    case "data-pilot-layout-info":
    // 9.6.15
    case "data-pilot-field-reference":
    // 9.6.16
    case "data-pilot-groups":
    // 9.6.17
    case "data-pilot-group":
    // 9.6.18
    case "data-pilot-group-member":
      break;
    /* 10.3 Drawing Shapes */
    case "rect":
      break;
    /* 14.6 DDE Connections */
    case "dde-connection-decls":
    // 14.6.2 <text:
    case "dde-connection-decl":
    // 14.6.3 <text:
    case "dde-link":
    // 14.6.4 <table:
    case "dde-source":
      break;
    case "properties":
      break;
    // 13.7 <form:properties>
    case "property":
      break;
    // 13.8 <form:property>
    case "a":
      if (d[1] !== "/") {
        if (ke = le(d[0], !1), !ke.href) break;
        ke.Target = Se(ke.href), delete ke.href, ke.Target.charAt(0) == "#" && ke.Target.indexOf(".") > -1 ? (me = u0(ke.Target.slice(1)), ke.Target = "#" + me[0] + "!" + me[1]) : ke.Target.match(/^\.\.[\\\/]/) && (ke.Target = ke.Target.slice(3));
      }
      break;
    /* non-standard */
    case "table-protection":
      break;
    case "data-pilot-grand-total":
      break;
    // <table:
    case "office-document-common-attrs":
      break;
    // bare
    default:
      switch (d[2]) {
        case "dc:":
        // TODO: properties
        case "calcext:":
        // ignore undocumented extensions
        case "loext:":
        // ignore undocumented extensions
        case "ooo:":
        // ignore undocumented extensions
        case "chartooo:":
        // ignore undocumented extensions
        case "draw:":
        // TODO: drawing
        case "style:":
        // TODO: styles
        case "chart:":
        // TODO: charts
        case "form:":
        // TODO: forms
        case "uof:":
        // TODO: uof
        case "表:":
        // TODO: uof
        case "字:":
          break;
        default:
          if (t.WTF) throw new Error(d);
      }
  }
  var He = {
    Sheets: u,
    SheetNames: p,
    Workbook: fe
  };
  return t.bookSheets && delete /*::(*/
  He.Sheets, He;
}
function Jn(e, a) {
  a = a || {}, br(e, "META-INF/manifest.xml") && Zf(Ze(e, "META-INF/manifest.xml"), a);
  var r = Tr(e, "styles.xml"), t = r && Is(Ue(r)), n = Tr(e, "content.xml");
  if (!n) throw new Error("Missing content.xml in ODS / UOF file");
  var i = Os(Ue(n), a, t);
  return br(e, "meta.xml") && (i.Props = Xi(Ze(e, "meta.xml"))), i.bookType = "ods", i;
}
function Zn(e, a) {
  var r = Os(e, a);
  return r.bookType = "fods", r;
}
/*! sheetjs (C) 2013-present SheetJS -- http://sheetjs.com */
var cr = (function() {
  try {
    return typeof Uint8Array > "u" || typeof Uint8Array.prototype.subarray > "u" ? "slice" : typeof Buffer < "u" ? typeof Buffer.prototype.subarray > "u" ? "slice" : (typeof Buffer.from == "function" ? Buffer.from([72, 62]) : new Buffer([72, 62])) instanceof Uint8Array ? "subarray" : "slice" : "subarray";
  } catch {
    return "slice";
  }
})();
function ot(e) {
  return new DataView(e.buffer, e.byteOffset, e.byteLength);
}
function ba(e) {
  return typeof TextDecoder < "u" ? new TextDecoder().decode(e) : Ue(aa(e));
}
function Rs(e) {
  for (var a = 0, r = 0; r < e.length; ++r)
    a += e[r].length;
  var t = new Uint8Array(a), n = 0;
  for (r = 0; r < e.length; ++r) {
    var i = e[r], c = i.length;
    if (c < 250)
      for (var s = 0; s < c; ++s)
        t[n++] = i[s];
    else
      t.set(i, n), n += c;
  }
  return t;
}
function at(e) {
  return e -= e >> 1 & 1431655765, e = (e & 858993459) + (e >> 2 & 858993459), (e + (e >> 4) & 252645135) * 16843009 >>> 24;
}
function Od(e, a) {
  for (var r = (e[a + 15] & 127) << 7 | e[a + 14] >> 1, t = e[a + 14] & 1, n = a + 13; n >= a; --n)
    t = t * 256 + e[n];
  return (e[a + 15] & 128 ? -t : t) * Math.pow(10, r - 6176);
}
function $t(e, a) {
  var r = a.l, t = e[r] & 127;
  e:
    if (e[r++] >= 128 && (t |= (e[r] & 127) << 7, e[r++] < 128 || (t |= (e[r] & 127) << 14, e[r++] < 128) || (t |= (e[r] & 127) << 21, e[r++] < 128) || (t += (e[r] & 127) * Math.pow(2, 28), ++r, e[r++] < 128) || (t += (e[r] & 127) * Math.pow(2, 35), ++r, e[r++] < 128) || (t += (e[r] & 127) * Math.pow(2, 42), ++r, e[r++] < 128)))
      break e;
  return a.l = r, t;
}
function Re(e) {
  var a = 0, r = e[a] & 127;
  return e[a++] < 128 || (r |= (e[a] & 127) << 7, e[a++] < 128) || (r |= (e[a] & 127) << 14, e[a++] < 128) || (r |= (e[a] & 127) << 21, e[a++] < 128) || (r |= (e[a] & 15) << 28), r;
}
function Ae(e) {
  for (var a = [], r = { l: 0 }; r.l < e.length; ) {
    var t = r.l, n = $t(e, r), i = n & 7;
    n = n / 8 | 0;
    var c, s = r.l;
    switch (i) {
      case 0:
        {
          for (; e[s++] >= 128; )
            ;
          c = e[cr](r.l, s), r.l = s;
        }
        break;
      case 1:
        c = e[cr](s, s + 8), r.l = s + 8;
        break;
      case 2:
        {
          var f = $t(e, r);
          c = e[cr](r.l, r.l + f), r.l += f;
        }
        break;
      case 5:
        c = e[cr](s, s + 4), r.l = s + 4;
        break;
      default:
        throw new Error("PB Type ".concat(i, " for Field ").concat(n, " at offset ").concat(t));
    }
    var o = { data: c, type: i };
    a[n] == null && (a[n] = []), a[n].push(o);
  }
  return a;
}
function r0(e, a) {
  return e?.map(function(r) {
    return a(r.data);
  }) || [];
}
function Rd(e) {
  for (var a, r = [], t = { l: 0 }; t.l < e.length; ) {
    var n = $t(e, t), i = Ae(e[cr](t.l, t.l + n));
    t.l += n;
    var c = {
      id: Re(i[1][0].data),
      messages: []
    };
    i[2].forEach(function(s) {
      var f = Ae(s.data), o = Re(f[3][0].data);
      c.messages.push({
        meta: f,
        data: e[cr](t.l, t.l + o)
      }), t.l += o;
    }), (a = i[3]) != null && a[0] && (c.merge = Re(i[3][0].data) >>> 0 > 0), r.push(c);
  }
  return r;
}
function Nd(e, a) {
  if (e != 0)
    throw new Error("Unexpected Snappy chunk type ".concat(e));
  for (var r = { l: 0 }, t = $t(a, r), n = [], i = r.l; i < a.length; ) {
    var c = a[i] & 3;
    if (c == 0) {
      var s = a[i++] >> 2;
      if (s < 60)
        ++s;
      else {
        var f = s - 59;
        s = a[i], f > 1 && (s |= a[i + 1] << 8), f > 2 && (s |= a[i + 2] << 16), f > 3 && (s |= a[i + 3] << 24), s >>>= 0, s++, i += f;
      }
      n.push(a[cr](i, i + s)), i += s;
      continue;
    } else {
      var o = 0, l = 0;
      if (c == 1 ? (l = (a[i] >> 2 & 7) + 4, o = (a[i++] & 224) << 3, o |= a[i++]) : (l = (a[i++] >> 2) + 1, c == 2 ? (o = a[i] | a[i + 1] << 8, i += 2) : (o = (a[i] | a[i + 1] << 8 | a[i + 2] << 16 | a[i + 3] << 24) >>> 0, i += 4)), o == 0)
        throw new Error("Invalid offset 0");
      for (var v = n.length - 1, x = o; v >= 0 && x >= n[v].length; )
        x -= n[v].length, --v;
      if (v < 0)
        if (x == 0)
          x = n[v = 0].length;
        else
          throw new Error("Invalid offset beyond length");
      if (l < x)
        n.push(n[v][cr](n[v].length - x, n[v].length - x + l));
      else {
        for (x > 0 && (n.push(n[v][cr](n[v].length - x)), l -= x), ++v; l >= n[v].length; )
          n.push(n[v]), l -= n[v].length, ++v;
        l && n.push(n[v][cr](0, l));
      }
      n.length > 25 && (n = [Rs(n)]);
    }
  }
  for (var u = 0, p = 0; p < n.length; ++p)
    u += n[p].length;
  if (u != t)
    throw new Error("Unexpected length: ".concat(u, " != ").concat(t));
  return n;
}
function Pd(e) {
  Array.isArray(e) && (e = new Uint8Array(e));
  for (var a = [], r = 0; r < e.length; ) {
    var t = e[r++], n = e[r] | e[r + 1] << 8 | e[r + 2] << 16;
    r += 3, a.push.apply(a, Nd(t, e[cr](r, r + n))), r += n;
  }
  if (r !== e.length)
    throw new Error("data is not a valid framed stream!");
  return a.length == 1 ? a[0] : Rs(a);
}
var bd = function() {
  return { sst: [], rsst: [], ofmt: [], nfmt: [], fmla: [], ferr: [], cmnt: [] };
};
function Ns(e, a, r, t, n) {
  var i, c, s, f, o = a & 255, l = a >> 8, v = l >= 5 ? n : t;
  e:
    if (r & (l > 4 ? 8 : 4) && e.t == "n" && o == 7) {
      var x = (i = v[7]) != null && i[0] ? Re(v[7][0].data) : -1;
      if (x == -1)
        break e;
      var u = (c = v[15]) != null && c[0] ? Re(v[15][0].data) : -1, p = (s = v[16]) != null && s[0] ? Re(v[16][0].data) : -1, _ = (f = v[40]) != null && f[0] ? Re(v[40][0].data) : -1, d = e.v, h = d;
      r:
        if (_) {
          if (d == 0) {
            u = p = 2;
            break r;
          }
          d >= 604800 ? u = 1 : d >= 86400 ? u = 2 : d >= 3600 ? u = 4 : d >= 60 ? u = 8 : d >= 1 ? u = 16 : u = 32, Math.floor(d) != d ? p = 32 : d % 60 ? p = 16 : d % 3600 ? p = 8 : d % 86400 ? p = 4 : d % 604800 && (p = 2), p < u && (p = u);
        }
      if (u == -1 || p == -1)
        break e;
      var E = [], g = [];
      u == 1 && (h = d / 604800, p == 1 ? g.push('d"d"') : (h |= 0, d -= 604800 * h), E.push(h + (x == 2 ? " week" + (h == 1 ? "" : "s") : x == 1 ? "w" : ""))), u <= 2 && p >= 2 && (h = d / 86400, p > 2 && (h |= 0, d -= 86400 * h), g.push('d"d"'), E.push(h + (x == 2 ? " day" + (h == 1 ? "" : "s") : x == 1 ? "d" : ""))), u <= 4 && p >= 4 && (h = d / 3600, p > 4 && (h |= 0, d -= 3600 * h), g.push((u >= 4 ? "[h]" : "h") + '"h"'), E.push(h + (x == 2 ? " hour" + (h == 1 ? "" : "s") : x == 1 ? "h" : ""))), u <= 8 && p >= 8 && (h = d / 60, p > 8 && (h |= 0, d -= 60 * h), g.push((u >= 8 ? "[m]" : "m") + '"m"'), x == 0 ? E.push((u == 8 && p == 8 || h >= 10 ? "" : "0") + h) : E.push(h + (x == 2 ? " minute" + (h == 1 ? "" : "s") : x == 1 ? "m" : ""))), u <= 16 && p >= 16 && (h = d, p > 16 && (h |= 0, d -= h), g.push((u >= 16 ? "[s]" : "s") + '"s"'), x == 0 ? E.push((p == 16 && u == 16 || h >= 10 ? "" : "0") + h) : E.push(h + (x == 2 ? " second" + (h == 1 ? "" : "s") : x == 1 ? "s" : ""))), p >= 32 && (h = Math.round(1e3 * d), u < 32 && g.push('.000"ms"'), x == 0 ? E.push((h >= 100 ? "" : h >= 10 ? "0" : "00") + h) : E.push(h + (x == 2 ? " millisecond" + (h == 1 ? "" : "s") : x == 1 ? "ms" : ""))), e.w = E.join(x == 0 ? ":" : " "), e.z = g.join(x == 0 ? '":"' : " "), x == 0 && (e.w = e.w.replace(/:(\d\d\d)$/, ".$1"));
    }
}
function Ld(e, a, r, t) {
  var n = ot(e), i = n.getUint32(4, !0), c = -1, s = -1, f = -1, o = NaN, l = 0, v = new Date(Date.UTC(2001, 0, 1)), x = r > 1 ? 12 : 8;
  i & 2 && (f = n.getUint32(x, !0), x += 4), x += at(i & (r > 1 ? 3468 : 396)) * 4, i & 512 && (c = n.getUint32(x, !0), x += 4), x += at(i & (r > 1 ? 12288 : 4096)) * 4, i & 16 && (s = n.getUint32(x, !0), x += 4), i & 32 && (o = n.getFloat64(x, !0), x += 8), i & 64 && (v.setTime(v.getTime() + (l = n.getFloat64(x, !0)) * 1e3), x += 8), r > 1 && (i = n.getUint32(8, !0) >>> 16, i & 255 && (f == -1 && (f = n.getUint32(x, !0)), x += 4));
  var u, p = e[r >= 4 ? 1 : 2];
  switch (p) {
    case 0:
      return;
    case 2:
      u = { t: "n", v: o };
      break;
    case 3:
      u = { t: "s", v: a.sst[s] };
      break;
    case 5:
      t?.cellDates ? u = { t: "d", v } : u = { t: "n", v: l / 86400 + 35430, z: ge[14] };
      break;
    case 6:
      u = { t: "b", v: o > 0 };
      break;
    case 7:
      u = { t: "n", v: o };
      break;
    case 8:
      u = { t: "e", v: 0 };
      break;
    case 9:
      if (c > -1) {
        var _ = a.rsst[c];
        u = { t: "s", v: _.v }, _.l && (u.l = { Target: _.l });
      } else
        throw new Error("Unsupported cell type ".concat(e[cr](0, 4)));
      break;
    default:
      throw new Error("Unsupported cell type ".concat(e[cr](0, 4)));
  }
  return f > -1 && Ns(u, p | r << 8, i, a.ofmt[f], a.nfmt[f]), p == 7 && (u.v /= 86400), u;
}
function Bd(e, a, r) {
  var t = ot(e);
  t.getUint32(4, !0);
  var n = t.getUint32(8, !0), i = 12, c = -1, s = -1, f = -1, o = NaN, l = NaN, v = 0, x = new Date(Date.UTC(2001, 0, 1));
  n & 1 && (o = Od(e, i), i += 16), n & 2 && (l = t.getFloat64(i, !0), i += 8), n & 4 && (x.setTime(x.getTime() + (v = t.getFloat64(i, !0)) * 1e3), i += 8), n & 8 && (s = t.getUint32(i, !0), i += 4), n & 16 && (c = t.getUint32(i, !0), i += 4), i += at(n & 480) * 4, n & 512 && (t.getUint32(i, !0), i += 4), i += at(n & 1024) * 4, n & 2048 && (t.getUint32(i, !0), i += 4);
  var u, p = e[1];
  switch (p) {
    case 0:
      u = { t: "z" };
      break;
    case 2:
      u = { t: "n", v: o };
      break;
    case 3:
      u = { t: "s", v: a.sst[s] };
      break;
    case 5:
      r?.cellDates ? u = { t: "d", v: x } : u = { t: "n", v: v / 86400 + 35430, z: ge[14] };
      break;
    case 6:
      u = { t: "b", v: l > 0 };
      break;
    case 7:
      u = { t: "n", v: l };
      break;
    case 8:
      u = { t: "e", v: 0 };
      break;
    case 9:
      if (c > -1) {
        var _ = a.rsst[c];
        u = { t: "s", v: _.v }, _.l && (u.l = { Target: _.l });
      } else
        throw new Error("Unsupported cell type ".concat(e[1], " : ").concat(n & 31, " : ").concat(e[cr](0, 4)));
      break;
    case 10:
      u = { t: "n", v: o };
      break;
    default:
      throw new Error("Unsupported cell type ".concat(e[1], " : ").concat(n & 31, " : ").concat(e[cr](0, 4)));
  }
  if (i += at(n & 4096) * 4, n & 516096 && (f == -1 && (f = t.getUint32(i, !0)), i += 4), n & 524288) {
    var d = t.getUint32(i, !0);
    i += 4, a.cmnt[d] && (u.c = Wd(a.cmnt[d]));
  }
  return f > -1 && Ns(u, p | 1280, n >> 13, a.ofmt[f], a.nfmt[f]), p == 7 && (u.v /= 86400), u;
}
function Md(e, a, r) {
  switch (e[0]) {
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
      return Ld(e, a, e[0], r);
    case 5:
      return Bd(e, a, r);
    default:
      throw new Error("Unsupported payload version ".concat(e[0]));
  }
}
function nr(e) {
  var a = Ae(e);
  return Re(a[1][0].data);
}
function va(e, a) {
  var r = Ae(a.data), t = Re(r[1][0].data), n = r[3], i = [];
  return (n || []).forEach(function(c) {
    var s, f, o = Ae(c.data);
    if (o[1]) {
      var l = Re(o[1][0].data) >>> 0;
      switch (t) {
        case 1:
          i[l] = ba(o[3][0].data);
          break;
        case 8:
          {
            var v = e[nr(o[9][0].data)][0], x = Ae(v.data), u = e[nr(x[1][0].data)][0], p = Re(u.meta[1][0].data);
            if (p != 2001)
              throw new Error("2000 unexpected reference to ".concat(p));
            var _ = Ae(u.data), d = { v: _[3].map(function(g) {
              return ba(g.data);
            }).join("") };
            i[l] = d;
            e:
              if ((s = _?.[11]) != null && s[0]) {
                var h = (f = Ae(_[11][0].data)) == null ? void 0 : f[1];
                if (!h)
                  break e;
                h.forEach(function(g) {
                  var C, P, M, I = Ae(g.data);
                  if ((C = I[2]) != null && C[0]) {
                    var N = e[nr((P = I[2]) == null ? void 0 : P[0].data)][0], O = Re(N.meta[1][0].data);
                    switch (O) {
                      case 2032:
                        var B = Ae(N.data);
                        (M = B?.[2]) != null && M[0] && !d.l && (d.l = ba(B[2][0].data));
                        break;
                      case 2039:
                        break;
                      default:
                        console.log("unrecognized ObjectAttribute type ".concat(O));
                    }
                  }
                });
              }
          }
          break;
        case 2:
          i[l] = Ae(o[6][0].data);
          break;
        case 3:
          i[l] = Ae(o[5][0].data);
          break;
        case 10:
          {
            var E = e[nr(o[10][0].data)][0];
            i[l] = Ps(e, E.data);
          }
          break;
        default:
          throw t;
      }
    }
  }), i;
}
function Ud(e, a) {
  var r, t, n, i, c, s, f, o, l, v, x, u, p, _, d = Ae(e), h = Re(d[1][0].data) >>> 0, E = Re(d[2][0].data) >>> 0, g = ((t = (r = d[8]) == null ? void 0 : r[0]) == null ? void 0 : t.data) && Re(d[8][0].data) > 0 || !1, C, P;
  if ((i = (n = d[7]) == null ? void 0 : n[0]) != null && i.data && a != 0)
    C = (s = (c = d[7]) == null ? void 0 : c[0]) == null ? void 0 : s.data, P = (o = (f = d[6]) == null ? void 0 : f[0]) == null ? void 0 : o.data;
  else if ((v = (l = d[4]) == null ? void 0 : l[0]) != null && v.data && a != 1)
    C = (u = (x = d[4]) == null ? void 0 : x[0]) == null ? void 0 : u.data, P = (_ = (p = d[3]) == null ? void 0 : p[0]) == null ? void 0 : _.data;
  else
    throw "NUMBERS Tile missing ".concat(a, " cell storage");
  for (var M = g ? 4 : 1, I = ot(C), N = [], O = 0; O < C.length / 2; ++O) {
    var B = I.getUint16(O * 2, !0);
    B < 65535 && N.push([O, B]);
  }
  if (N.length != E)
    throw "Expected ".concat(E, " cells, found ").concat(N.length);
  var b = [];
  for (O = 0; O < N.length - 1; ++O)
    b[N[O][0]] = P[cr](N[O][1] * M, N[O + 1][1] * M);
  return N.length >= 1 && (b[N[N.length - 1][0]] = P[cr](N[N.length - 1][1] * M)), { R: h, cells: b };
}
function Hd(e, a) {
  var r, t = Ae(a.data), n = -1;
  (r = t?.[7]) != null && r[0] && (Re(t[7][0].data) >>> 0 ? n = 1 : n = 0);
  var i = r0(t[5], function(c) {
    return Ud(c, n);
  });
  return {
    nrows: Re(t[4][0].data) >>> 0,
    data: i.reduce(function(c, s) {
      return c[s.R] || (c[s.R] = []), s.cells.forEach(function(f, o) {
        if (c[s.R][o])
          throw new Error("Duplicate cell r=".concat(s.R, " c=").concat(o));
        c[s.R][o] = f;
      }), c;
    }, [])
  };
}
function Ps(e, a) {
  var r, t, n, i, c, s, f, o, l, v, x = { t: "", a: "" }, u = Ae(a);
  if ((t = (r = u?.[1]) == null ? void 0 : r[0]) != null && t.data && (x.t = ba((i = (n = u?.[1]) == null ? void 0 : n[0]) == null ? void 0 : i.data) || ""), (s = (c = u?.[3]) == null ? void 0 : c[0]) != null && s.data) {
    var p = e[nr((o = (f = u?.[3]) == null ? void 0 : f[0]) == null ? void 0 : o.data)][0], _ = Ae(p.data);
    (v = (l = _[1]) == null ? void 0 : l[0]) != null && v.data && (x.a = ba(_[1][0].data));
  }
  return u?.[4] && (x.replies = [], u[4].forEach(function(d) {
    var h = e[nr(d.data)][0];
    x.replies.push(Ps(e, h.data));
  })), x;
}
function Wd(e) {
  var a = [];
  return a.push({ t: e.t || "", a: e.a, T: e.replies && e.replies.length > 0 }), e.replies && e.replies.forEach(function(r) {
    a.push({ t: r.t || "", a: r.a, T: !0 });
  }), a;
}
function Vd(e, a, r, t) {
  var n, i, c, s, f, o, l, v, x, u, p, _, d, h, E = Ae(a.data), g = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } };
  if (g.e.r = (Re(E[6][0].data) >>> 0) - 1, g.e.r < 0)
    throw new Error("Invalid row varint ".concat(E[6][0].data));
  if (g.e.c = (Re(E[7][0].data) >>> 0) - 1, g.e.c < 0)
    throw new Error("Invalid col varint ".concat(E[7][0].data));
  r["!ref"] = Ce(g);
  var C = r["!data"] != null, P = r, M = Ae(E[4][0].data), I = bd();
  (n = M[4]) != null && n[0] && (I.sst = va(e, e[nr(M[4][0].data)][0])), (i = M[6]) != null && i[0] && (I.fmla = va(e, e[nr(M[6][0].data)][0])), (c = M[11]) != null && c[0] && (I.ofmt = va(e, e[nr(M[11][0].data)][0])), (s = M[12]) != null && s[0] && (I.ferr = va(e, e[nr(M[12][0].data)][0])), (f = M[17]) != null && f[0] && (I.rsst = va(e, e[nr(M[17][0].data)][0])), (o = M[19]) != null && o[0] && (I.cmnt = va(e, e[nr(M[19][0].data)][0])), (l = M[22]) != null && l[0] && (I.nfmt = va(e, e[nr(M[22][0].data)][0]));
  var N = Ae(M[3][0].data), O = 0;
  if (!((v = M[9]) != null && v[0]))
    throw "NUMBERS file missing row tree";
  var B = Ae(M[9][0].data)[1].map(function(j) {
    return Ae(j.data);
  });
  if (B.forEach(function(j) {
    O = Re(j[1][0].data);
    var he = Re(j[2][0].data), J = N[1][he];
    if (!J)
      throw "NUMBERS missing tile " + he;
    var ne = Ae(J.data), pe = e[nr(ne[2][0].data)][0], X = Re(pe.meta[1][0].data);
    if (X != 6002)
      throw new Error("6001 unexpected reference to ".concat(X));
    var Te = Hd(e, pe);
    Te.data.forEach(function(_e, de) {
      _e.forEach(function(fe, ke) {
        var me = Md(fe, I, t);
        me && (C ? (P["!data"][O + de] || (P["!data"][O + de] = []), P["!data"][O + de][ke] = me) : r[Pe(ke) + Me(O + de)] = me);
      });
    }), O += Te.nrows;
  }), (x = M[13]) != null && x[0]) {
    var b = e[nr(M[13][0].data)][0], G = Re(b.meta[1][0].data);
    if (G != 6144)
      throw new Error("Expected merge type 6144, found ".concat(G));
    r["!merges"] = (u = Ae(b.data)) == null ? void 0 : u[1].map(function(j) {
      var he = Ae(j.data), J = ot(Ae(he[1][0].data)[1][0].data), ne = ot(Ae(he[2][0].data)[1][0].data);
      return {
        s: { r: J.getUint16(0, !0), c: J.getUint16(2, !0) },
        e: {
          r: J.getUint16(0, !0) + ne.getUint16(0, !0) - 1,
          c: J.getUint16(2, !0) + ne.getUint16(2, !0) - 1
        }
      };
    });
  }
  if (!((p = r["!merges"]) != null && p.length) && ((_ = E[47]) != null && _[0])) {
    var z = Ae(E[47][0].data);
    if ((d = z[2]) != null && d[0]) {
      var ce = Ae(z[2][0].data);
      (h = ce[3]) != null && h[0] && (r["!merges"] = r0(ce[3], function(j) {
        var he, J, ne, pe, X, Te = Ae(j), _e = Ae(Te[2][0].data), de = Ae(_e[1][0].data);
        if ((he = de[1]) != null && he[0]) {
          var fe = Ae(de[1][0].data), ke = Re(fe[1][0].data);
          if (ke == 67) {
            var me = Ae(fe[40][0].data);
            if (!(!((J = me[3]) != null && J[0]) || !((ne = me[4]) != null && ne[0]))) {
              var Fe = Ae(me[3][0].data), y = Ae(me[4][0].data), L = Re(Fe[1][0].data), R = (pe = Fe[2]) != null && pe[0] ? Re(Fe[2][0].data) : L, D = Re(y[1][0].data), Y = (X = y[2]) != null && X[0] ? Re(y[2][0].data) : D;
              return { s: { r: D, c: L }, e: { r: Y, c: R } };
            }
          }
        }
      }).filter(function(j) {
        return j != null;
      }));
    }
  }
}
function Gd(e, a, r) {
  var t = Ae(a.data), n = { "!ref": "A1" };
  r?.dense && (n["!data"] = []);
  var i = e[nr(t[2][0].data)], c = Re(i[0].meta[1][0].data);
  if (c != 6001)
    throw new Error("6000 unexpected reference to ".concat(c));
  return Vd(e, i[0], n, r), n;
}
function $d(e, a, r) {
  var t, n = Ae(a.data), i = {
    name: (t = n[1]) != null && t[0] ? ba(n[1][0].data) : "",
    sheets: []
  }, c = r0(n[2], nr);
  return c.forEach(function(s) {
    e[s].forEach(function(f) {
      var o = Re(f.meta[1][0].data);
      o == 6e3 && i.sheets.push(Gd(e, f, r));
    });
  }), i;
}
function Xd(e, a, r) {
  var t, n = z0();
  n.Workbook = { WBProps: { date1904: !0 } };
  var i = Ae(a.data);
  if ((t = i[2]) != null && t[0])
    throw new Error("Keynote presentations are not supported");
  var c = r0(i[1], nr);
  if (c.forEach(function(s) {
    e[s].forEach(function(f) {
      var o = Re(f.meta[1][0].data);
      if (o == 2) {
        var l = $d(e, f, r);
        l.sheets.forEach(function(v, x) {
          gt(n, v, x == 0 ? l.name : l.name + "_" + x, !0);
        });
      }
    });
  }), n.SheetNames.length == 0)
    throw new Error("Empty NUMBERS file");
  return n.bookType = "numbers", n;
}
function x0(e, a) {
  var r, t, n, i, c, s, f, o = {}, l = [];
  if (e.FullPaths.forEach(function(x) {
    if (x.match(/\.iwpv2/))
      throw new Error("Unsupported password protection");
  }), e.FileIndex.forEach(function(x) {
    if (x.name.match(/\.iwa$/) && x.content[0] == 0) {
      var u;
      try {
        u = Pd(x.content);
      } catch (_) {
        return console.log("?? " + x.content.length + " " + (_.message || _));
      }
      var p;
      try {
        p = Rd(u);
      } catch (_) {
        return console.log("## " + (_.message || _));
      }
      p.forEach(function(_) {
        o[_.id] = _.messages, l.push(_.id);
      });
    }
  }), !l.length)
    throw new Error("File has no messages");
  if ((n = (t = (r = o?.[1]) == null ? void 0 : r[0].meta) == null ? void 0 : t[1]) != null && n[0].data && Re(o[1][0].meta[1][0].data) == 1e4)
    throw new Error("Pages documents are not supported");
  var v = ((f = (s = (c = (i = o?.[1]) == null ? void 0 : i[0]) == null ? void 0 : c.meta) == null ? void 0 : s[1]) == null ? void 0 : f[0].data) && Re(o[1][0].meta[1][0].data) == 1 && o[1][0];
  if (v || l.forEach(function(x) {
    o[x].forEach(function(u) {
      var p = Re(u.meta[1][0].data) >>> 0;
      if (p == 1)
        if (!v)
          v = u;
        else
          throw new Error("Document has multiple roots");
    });
  }), !v)
    throw new Error("Cannot find Document root");
  return Xd(o, v, a);
}
function zd(e) {
  return function(r) {
    for (var t = 0; t != e.length; ++t) {
      var n = e[t];
      r[n[0]] === void 0 && (r[n[0]] = n[1]), n[2] === "n" && (r[n[0]] = Number(r[n[0]]));
    }
  };
}
function $0(e) {
  zd([
    ["cellNF", !1],
    /* emit cell number format string as .z */
    ["cellHTML", !0],
    /* emit html string as .h */
    ["cellFormula", !0],
    /* emit formulae as .f */
    ["cellStyles", !1],
    /* emits style/theme as .s */
    ["cellText", !0],
    /* emit formatted text as .w */
    ["cellDates", !1],
    /* emit date cells with type `d` */
    ["sheetStubs", !1],
    /* emit empty cells */
    ["sheetRows", 0, "n"],
    /* read n rows (0 = read all rows) */
    ["bookDeps", !1],
    /* parse calculation chains */
    ["bookSheets", !1],
    /* only try to get sheet names (no Sheets) */
    ["bookProps", !1],
    /* only try to get properties (no Sheets) */
    ["bookFiles", !1],
    /* include raw file structure (keys, files, cfb) */
    ["bookVBA", !1],
    /* include vba raw data (vbaraw) */
    ["password", ""],
    /* password */
    ["WTF", !1]
    /* WTF mode (throws errors) */
  ])(e);
}
function Kd(e) {
  return Ra.WS.indexOf(e) > -1 ? "sheet" : e == Ra.CS ? "chart" : e == Ra.DS ? "dialog" : e == Ra.MS ? "macro" : e && e.length ? e : "sheet";
}
function Yd(e, a) {
  if (!e) return 0;
  try {
    e = a.map(function(t) {
      return t.id || (t.id = t.strRelID), [t.name, e["!id"][t.id].Target, Kd(e["!id"][t.id].Type)];
    });
  } catch {
    return null;
  }
  return !e || e.length === 0 ? null : e;
}
function jd(e, a, r, t, n, i, c, s) {
  if (!(!e || !e["!legdrawel"])) {
    var f = Oa(e["!legdrawel"].Target, t), o = Tr(r, f, !0);
    o && au(Ue(o), e, s || []);
  }
}
function Jd(e, a, r, t, n, i, c, s, f, o, l, v) {
  try {
    i[t] = Ja(Tr(e, r, !0), a);
    var x = Ze(e, a), u;
    switch (s) {
      case "sheet":
        u = Qx(x, a, n, f, i[t], o, l, v);
        break;
      case "chart":
        if (u = ed(x, a, n, f, i[t], o, l, v), !u || !u["!drawel"]) break;
        var p = Oa(u["!drawel"].Target, a), _ = m0(p), d = ru(Tr(e, p, !0), Ja(Tr(e, _, !0), p)), h = Oa(d, p), E = m0(h);
        u = Lx(Tr(e, h, !0), h, f, Ja(Tr(e, E, !0), h), o, u);
        break;
      case "macro":
        u = rd(x, a, n, f, i[t], o, l, v);
        break;
      case "dialog":
        u = ad(x, a, n, f, i[t], o, l, v);
        break;
      default:
        throw new Error("Unrecognized sheet type " + s);
    }
    c[t] = u;
    var g = [], C = [];
    i && i[t] && Br(i[t]).forEach(function(P) {
      var M = "";
      if (i[t][P].Type == Ra.CMNT) {
        if (M = Oa(i[t][P].Target, a), g = id(Ze(e, M, !0), M, f), !g || !g.length) return;
        Mn(u, g, !1);
      }
      i[t][P].Type == Ra.TCMNT && (M = Oa(i[t][P].Target, a), C = C.concat(nu(Ze(e, M, !0), f)));
    }), C && C.length && Mn(u, C, !0, f.people || []), jd(u, s, e, a, n, f, o, g);
  } catch (P) {
    if (f.WTF) throw P;
  }
}
function Nr(e) {
  return e.charAt(0) == "/" ? e.slice(1) : e;
}
function Zd(e, a) {
  if (vi(), a = a || {}, $0(a), br(e, "META-INF/manifest.xml") || br(e, "objectdata.xml")) return Jn(e, a);
  if (br(e, "Index/Document.iwa")) {
    if (typeof Uint8Array > "u") throw new Error("NUMBERS file parsing requires Uint8Array support");
    if (typeof x0 < "u") {
      if (e.FileIndex) return x0(e, a);
      var r = Oe.utils.cfb_new();
      return ln(e).forEach(function(j) {
        qc(r, j, Zc(e, j));
      }), x0(r, a);
    }
    throw new Error("Unsupported NUMBERS file");
  }
  if (!br(e, "[Content_Types].xml")) {
    if (br(e, "index.xml.gz")) throw new Error("Unsupported NUMBERS 08 file");
    if (br(e, "index.xml")) throw new Error("Unsupported NUMBERS 09 file");
    var t = Oe.find(e, "Index.zip");
    if (t)
      return a = er(a), delete a.type, typeof t.content == "string" && (a.type = "binary"), typeof Bun < "u" && Buffer.isBuffer(t.content) ? La(new Uint8Array(t.content), a) : La(t.content, a);
    throw new Error("Unsupported ZIP file");
  }
  var n = ln(e), i = jf(Tr(e, "[Content_Types].xml")), c = !1, s, f;
  if (i.workbooks.length === 0 && (f = "xl/workbook.xml", Ze(e, f, !0) && i.workbooks.push(f)), i.workbooks.length === 0) {
    if (f = "xl/workbook.bin", !Ze(e, f, !0)) throw new Error("Could not find workbook");
    i.workbooks.push(f), c = !0;
  }
  i.workbooks[0].slice(-3) == "bin" && (c = !0);
  var o = {}, l = {};
  if (!a.bookSheets && !a.bookProps) {
    if (Qa = [], i.sst) try {
      Qa = nd(Ze(e, Nr(i.sst)), i.sst, a);
    } catch (j) {
      if (a.WTF) throw j;
    }
    a.cellStyles && i.themes.length && (o = us(Tr(e, i.themes[0].replace(/^\//, ""), !0) || "", a)), i.style && (l = td(Ze(e, Nr(i.style)), i.style, o, a));
  }
  i.links.map(function(j) {
    try {
      var he = Ja(Tr(e, m0(Nr(j))), j);
      return cd(Ze(e, Nr(j)), he, j, a);
    } catch {
    }
  });
  var v = qx(Ze(e, Nr(i.workbooks[0])), i.workbooks[0], a), x = {}, u = "";
  i.coreprops.length && (u = Ze(e, Nr(i.coreprops[0]), !0), u && (x = Xi(u)), i.extprops.length !== 0 && (u = Ze(e, Nr(i.extprops[0]), !0), u && Qf(u, x, a)));
  var p = {};
  (!a.bookSheets || a.bookProps) && i.custprops.length !== 0 && (u = Tr(e, Nr(i.custprops[0]), !0), u && (p = ro(u, a)));
  var _ = {};
  if ((a.bookSheets || a.bookProps) && (v.Sheets ? s = v.Sheets.map(function(he) {
    return he.name;
  }) : x.Worksheets && x.SheetNames.length > 0 && (s = x.SheetNames), a.bookProps && (_.Props = x, _.Custprops = p), a.bookSheets && typeof s < "u" && (_.SheetNames = s), a.bookSheets ? _.SheetNames : a.bookProps))
    return _;
  s = {};
  var d = {};
  a.bookDeps && i.calcchain && (d = sd(Ze(e, Nr(i.calcchain)), i.calcchain));
  var h = 0, E = {}, g, C;
  {
    var P = v.Sheets;
    x.Worksheets = P.length, x.SheetNames = [];
    for (var M = 0; M != P.length; ++M)
      x.SheetNames[M] = P[M].name;
  }
  var I = c ? "bin" : "xml", N = i.workbooks[0].lastIndexOf("/"), O = (i.workbooks[0].slice(0, N + 1) + "_rels/" + i.workbooks[0].slice(N + 1) + ".rels").replace(/^\//, "");
  br(e, O) || (O = "xl/_rels/workbook." + I + ".rels");
  var B = Ja(Tr(e, O, !0), O.replace(/_rels.*/, "s5s"));
  (i.metadata || []).length >= 1 && (a.xlmeta = fd(Ze(e, Nr(i.metadata[0])), i.metadata[0], a)), (i.people || []).length >= 1 && (a.people = iu(Ze(e, Nr(i.people[0])), a)), B && (B = Yd(B, v.Sheets));
  var b = Ze(e, "xl/worksheets/sheet.xml", !0) ? 1 : 0;
  e: for (h = 0; h != x.Worksheets; ++h) {
    var G = "sheet";
    if (B && B[h] ? (g = "xl/" + B[h][1].replace(/[\/]?xl\//, ""), br(e, g) || (g = B[h][1]), br(e, g) || (g = O.replace(/_rels\/[\S\s]*$/, "") + B[h][1]), G = B[h][2]) : (g = "xl/worksheets/sheet" + (h + 1 - b) + "." + I, g = g.replace(/sheet0\./, "sheet.")), C = g.replace(/^(.*)(\/)([^\/]*)$/, "$1/_rels/$3.rels"), a && a.sheets != null) switch (typeof a.sheets) {
      case "number":
        if (h != a.sheets) continue e;
        break;
      case "string":
        if (x.SheetNames[h].toLowerCase() != a.sheets.toLowerCase()) continue e;
        break;
      default:
        if (Array.isArray && Array.isArray(a.sheets)) {
          for (var z = !1, ce = 0; ce != a.sheets.length; ++ce)
            typeof a.sheets[ce] == "number" && a.sheets[ce] == h && (z = 1), typeof a.sheets[ce] == "string" && a.sheets[ce].toLowerCase() == x.SheetNames[h].toLowerCase() && (z = 1);
          if (!z) continue e;
        }
    }
    Jd(e, g, C, x.SheetNames[h], h, E, s, G, a, v, o, l);
  }
  return _ = {
    Directory: i,
    Workbook: v,
    Props: x,
    Custprops: p,
    Deps: d,
    Sheets: s,
    SheetNames: x.SheetNames,
    Strings: Qa,
    Styles: l,
    Themes: o,
    SSF: er(ge)
  }, a && a.bookFiles && (e.files ? (_.keys = n, _.files = e.files) : (_.keys = [], _.files = {}, e.FullPaths.forEach(function(j, he) {
    j = j.replace(/^Root Entry[\/]/, ""), _.keys.push(j), _.files[j] = e.FileIndex[he];
  }))), a && a.bookVBA && (i.vba.length > 0 ? _.vbaraw = Ze(e, Nr(i.vba[0]), !0) : i.defaults && i.defaults.bin === ou && (_.vbaraw = Ze(e, "xl/vbaProject.bin", !0))), _.bookType = c ? "xlsb" : "xlsx", _;
}
function qd(e, a) {
  var r = a || {}, t = "Workbook", n = Oe.find(e, t);
  try {
    if (t = "/!DataSpaces/Version", n = Oe.find(e, t), !n || !n.content) throw new Error("ECMA-376 Encrypted file missing " + t);
    if (jl(n.content), t = "/!DataSpaces/DataSpaceMap", n = Oe.find(e, t), !n || !n.content) throw new Error("ECMA-376 Encrypted file missing " + t);
    var i = Zl(n.content);
    if (i.length !== 1 || i[0].comps.length !== 1 || i[0].comps[0].t !== 0 || i[0].name !== "StrongEncryptionDataSpace" || i[0].comps[0].v !== "EncryptedPackage")
      throw new Error("ECMA-376 Encrypted file bad " + t);
    if (t = "/!DataSpaces/DataSpaceInfo/StrongEncryptionDataSpace", n = Oe.find(e, t), !n || !n.content) throw new Error("ECMA-376 Encrypted file missing " + t);
    var c = ql(n.content);
    if (c.length != 1 || c[0] != "StrongEncryptionTransform")
      throw new Error("ECMA-376 Encrypted file bad " + t);
    if (t = "/!DataSpaces/TransformInfo/StrongEncryptionTransform/!Primary", n = Oe.find(e, t), !n || !n.content) throw new Error("ECMA-376 Encrypted file missing " + t);
    e1(n.content);
  } catch {
  }
  if (t = "/EncryptionInfo", n = Oe.find(e, t), !n || !n.content) throw new Error("ECMA-376 Encrypted file missing " + t);
  var s = r1(n.content);
  if (t = "/EncryptedPackage", n = Oe.find(e, t), !n || !n.content) throw new Error("ECMA-376 Encrypted file missing " + t);
  if (s[0] == 4 && typeof decrypt_agile < "u") return decrypt_agile(s[1], n.content, r.password || "", r);
  if (s[0] == 2 && typeof decrypt_std76 < "u") return decrypt_std76(s[1], n.content, r.password || "", r);
  throw new Error("File is password-protected");
}
function X0(e, a) {
  var r = "";
  switch ((a || {}).type || "base64") {
    case "buffer":
      return [e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7]];
    case "base64":
      r = Rr(e.slice(0, 12));
      break;
    case "binary":
      r = e;
      break;
    case "array":
      return [e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7]];
    default:
      throw new Error("Unrecognized type " + (a && a.type || "undefined"));
  }
  return [r.charCodeAt(0), r.charCodeAt(1), r.charCodeAt(2), r.charCodeAt(3), r.charCodeAt(4), r.charCodeAt(5), r.charCodeAt(6), r.charCodeAt(7)];
}
function Qd(e, a) {
  return Oe.find(e, "EncryptedPackage") ? qd(e, a) : Ss(e, a);
}
function e2(e, a) {
  var r, t = e, n = a || {};
  return n.type || (n.type = ye && Buffer.isBuffer(e) ? "buffer" : "base64"), r = Ei(t, n), Zd(r, n);
}
function bs(e, a) {
  var r = 0;
  e: for (; r < e.length; ) switch (e.charCodeAt(r)) {
    case 10:
    case 13:
    case 32:
      ++r;
      break;
    case 60:
      return T0(e.slice(r), a);
    default:
      break e;
  }
  return st.to_workbook(e, a);
}
function r2(e, a) {
  var r = "", t = X0(e, a);
  switch (a.type) {
    case "base64":
      r = Rr(e);
      break;
    case "binary":
      r = e;
      break;
    case "buffer":
      r = e.toString("binary");
      break;
    case "array":
      r = ka(e);
      break;
    default:
      throw new Error("Unrecognized type " + a.type);
  }
  return t[0] == 239 && t[1] == 187 && t[2] == 191 && (r = Ue(r)), a.type = "binary", bs(r, a);
}
function a2(e, a) {
  var r = e;
  return a.type == "base64" && (r = Rr(r)), typeof ArrayBuffer < "u" && e instanceof ArrayBuffer && (r = new Uint8Array(e)), r = ye && Buffer.isBuffer(e) ? e.slice(2).toString("utf16le") : typeof Uint8Array < "u" && r instanceof Uint8Array ? typeof TextDecoder < "u" ? new TextDecoder("utf-16le").decode(r.slice(2)) : tc(r.slice(2)) : ii(r.slice(2)), a.type = "binary", bs(r, a);
}
function t2(e) {
  return e.match(/[^\x00-\x7F]/) ? Xa(e) : e;
}
function d0(e, a, r, t) {
  return t ? (r.type = "string", st.to_workbook(e, r)) : st.to_workbook(a, r);
}
function La(e, a) {
  ni();
  var r = a || {};
  if (r.codepage && console.error("Codepage tables are not loaded.  Non-ASCII characters may not give expected results"), typeof ArrayBuffer < "u" && e instanceof ArrayBuffer) return La(new Uint8Array(e), (r = er(r), r.type = "array", r));
  if (typeof Int8Array < "u" && e instanceof Int8Array) return La(new Uint8Array(e.buffer, e.byteOffset, e.length), r);
  typeof Uint8Array < "u" && e instanceof Uint8Array && !r.type && (r.type = typeof Deno < "u" ? "buffer" : "array");
  var t = e, n = [0, 0, 0, 0], i = !1;
  if (r.cellStyles && (r.cellNF = !0, r.sheetStubs = !0), Pa = {}, r.dateNF && (Pa.dateNF = r.dateNF), r.type || (r.type = ye && Buffer.isBuffer(e) ? "buffer" : "base64"), r.type == "file" && (r.type = ye ? "buffer" : "binary", t = Nc(e), typeof Uint8Array < "u" && !ye && (r.type = "array")), r.type == "string" && (i = !0, r.type = "binary", r.codepage = 65001, t = t2(e)), r.type == "array" && typeof Uint8Array < "u" && e instanceof Uint8Array && typeof ArrayBuffer < "u") {
    var c = new ArrayBuffer(3), s = new Uint8Array(c);
    if (s.foo = "bar", !s.foo)
      return r = er(r), r.type = "array", La(A0(t), r);
  }
  switch ((n = X0(t, r))[0]) {
    case 208:
      if (n[1] === 207 && n[2] === 17 && n[3] === 224 && n[4] === 161 && n[5] === 177 && n[6] === 26 && n[7] === 225) return Qd(Oe.read(t, r), r);
      break;
    case 9:
      if (n[1] <= 8) return Ss(t, r);
      break;
    case 60:
      return T0(t, r);
    case 73:
      if (n[1] === 73 && n[2] === 42 && n[3] === 0) throw new Error("TIFF Image File is not a spreadsheet");
      if (n[1] === 68) return Ml(t, r);
      break;
    case 84:
      if (n[1] === 65 && n[2] === 66 && n[3] === 76) return Ll.to_workbook(t, r);
      break;
    case 80:
      return n[1] === 75 && n[2] < 9 && n[3] < 9 ? e2(t, r) : d0(e, t, r, i);
    case 239:
      return n[3] === 60 ? T0(t, r) : d0(e, t, r, i);
    case 255:
      if (n[1] === 254)
        return a2(t, r);
      if (n[1] === 0 && n[2] === 2 && n[3] === 0) return qa.to_workbook(t, r);
      break;
    case 0:
      if (n[1] === 0 && (n[2] >= 2 && n[3] === 0 || n[2] === 0 && (n[3] === 8 || n[3] === 9)))
        return qa.to_workbook(t, r);
      break;
    case 3:
    case 131:
    case 139:
    case 140:
      return Bn.to_workbook(t, r);
    case 123:
      if (n[1] === 92 && n[2] === 114 && n[3] === 116) return d1(t, r);
      break;
    case 10:
    case 13:
    case 32:
      return r2(t, r);
    case 137:
      if (n[1] === 80 && n[2] === 78 && n[3] === 71) throw new Error("PNG Image File is not a spreadsheet");
      break;
    case 8:
      if (n[1] === 231) throw new Error("Unsupported Multiplan 1.x file!");
      break;
    case 12:
      if (n[1] === 236) throw new Error("Unsupported Multiplan 2.x file!");
      if (n[1] === 237) throw new Error("Unsupported Multiplan 3.x file!");
      break;
  }
  return Pl.indexOf(n[0]) > -1 && n[2] <= 12 && n[3] <= 31 ? Bn.to_workbook(t, r) : d0(e, t, r, i);
}
function n2(e, a, r, t, n, i, c) {
  var s = Me(r), f = c.defval, o = c.raw || !Object.prototype.hasOwnProperty.call(c, "raw"), l = !0, v = e["!data"] != null, x = n === 1 ? [] : {};
  if (n !== 1)
    if (Object.defineProperty) try {
      Object.defineProperty(x, "__rowNum__", { value: r, enumerable: !1 });
    } catch {
      x.__rowNum__ = r;
    }
    else x.__rowNum__ = r;
  if (!v || e["!data"][r]) for (var u = a.s.c; u <= a.e.c; ++u) {
    var p = v ? (e["!data"][r] || [])[u] : e[t[u] + s];
    if (p == null || p.t === void 0) {
      if (f === void 0) continue;
      i[u] != null && (x[i[u]] = f);
      continue;
    }
    var _ = p.v;
    switch (p.t) {
      case "z":
        if (_ == null) break;
        continue;
      case "e":
        _ = _ == 0 ? null : void 0;
        break;
      case "s":
      case "b":
      case "n":
        if (!p.z || !Ur(p.z) || (_ = ca(_), typeof _ == "number")) break;
      /* falls through */
      case "d":
        c && (c.UTC || c.raw === !1) || (_ = wa(new Date(_)));
        break;
      default:
        throw new Error("unrecognized type " + p.t);
    }
    if (i[u] != null) {
      if (_ == null)
        if (p.t == "e" && _ === null) x[i[u]] = null;
        else if (f !== void 0) x[i[u]] = f;
        else if (o && _ === null) x[i[u]] = null;
        else continue;
      else
        x[i[u]] = (p.t === "n" && typeof c.rawNumbers == "boolean" ? c.rawNumbers : o) ? _ : oa(p, _, c);
      _ != null && (l = !1);
    }
  }
  return { row: x, isempty: l };
}
function k0(e, a) {
  if (e == null || e["!ref"] == null) return [];
  var r = { t: "n", v: 0 }, t = 0, n = 1, i = [], c = 0, s = "", f = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }, o = a || {}, l = o.range != null ? o.range : e["!ref"];
  switch (o.header === 1 ? t = 1 : o.header === "A" ? t = 2 : Array.isArray(o.header) ? t = 3 : o.header == null && (t = 0), typeof l) {
    case "string":
      f = Ke(l);
      break;
    case "number":
      f = Ke(e["!ref"]), f.s.r = l;
      break;
    default:
      f = l;
  }
  t > 0 && (n = 0);
  var v = Me(f.s.r), x = [], u = [], p = 0, _ = 0, d = e["!data"] != null, h = f.s.r, E = 0, g = {};
  d && !e["!data"][h] && (e["!data"][h] = []);
  var C = o.skipHidden && e["!cols"] || [], P = o.skipHidden && e["!rows"] || [];
  for (E = f.s.c; E <= f.e.c; ++E)
    if (!(C[E] || {}).hidden)
      switch (x[E] = Pe(E), r = d ? e["!data"][h][E] : e[x[E] + v], t) {
        case 1:
          i[E] = E - f.s.c;
          break;
        case 2:
          i[E] = x[E];
          break;
        case 3:
          i[E] = o.header[E - f.s.c];
          break;
        default:
          if (r == null && (r = { w: "__EMPTY", t: "s" }), s = c = oa(r, null, o), _ = g[c] || 0, !_) g[c] = 1;
          else {
            do
              s = c + "_" + _++;
            while (g[s]);
            g[c] = _, g[s] = 1;
          }
          i[E] = s;
      }
  for (h = f.s.r + n; h <= f.e.r; ++h)
    if (!(P[h] || {}).hidden) {
      var M = n2(e, f, h, x, t, i, o);
      (M.isempty === !1 || (t === 1 ? o.blankrows !== !1 : o.blankrows)) && (u[p++] = M.row);
    }
  return u.length = p, u;
}
var qn = /"/g;
function i2(e, a, r, t, n, i, c, s, f) {
  for (var o = !0, l = [], v = "", x = Me(r), u = e["!data"] != null, p = u && e["!data"][r] || [], _ = a.s.c; _ <= a.e.c; ++_)
    if (t[_]) {
      var d = u ? p[_] : e[t[_] + x];
      if (d == null) v = "";
      else if (d.v != null) {
        o = !1, v = "" + (f.rawNumbers && d.t == "n" ? d.v : oa(d, null, f));
        for (var h = 0, E = 0; h !== v.length; ++h) if ((E = v.charCodeAt(h)) === n || E === i || E === 34 || f.forceQuotes) {
          v = '"' + v.replace(qn, '""') + '"';
          break;
        }
        v == "ID" && s == 0 && l.length == 0 && (v = '"ID"');
      } else d.f != null && !d.F ? (o = !1, v = "=" + d.f, v.indexOf(",") >= 0 && (v = '"' + v.replace(qn, '""') + '"')) : v = "";
      l.push(v);
    }
  if (f.strip) for (; l[l.length - 1] === ""; ) --l.length;
  return f.blankrows === !1 && o ? null : l.join(c);
}
function Ls(e, a) {
  var r = [], t = a ?? {};
  if (e == null || e["!ref"] == null) return "";
  for (var n = Ke(e["!ref"]), i = t.FS !== void 0 ? t.FS : ",", c = i.charCodeAt(0), s = t.RS !== void 0 ? t.RS : `
`, f = s.charCodeAt(0), o = "", l = [], v = t.skipHidden && e["!cols"] || [], x = t.skipHidden && e["!rows"] || [], u = n.s.c; u <= n.e.c; ++u) (v[u] || {}).hidden || (l[u] = Pe(u));
  for (var p = 0, _ = n.s.r; _ <= n.e.r; ++_)
    (x[_] || {}).hidden || (o = i2(e, n, _, l, c, f, i, p, t), o != null && (o || t.blankrows !== !1) && r.push((p++ ? s : "") + o));
  return r.join("");
}
function s2(e, a) {
  a || (a = {}), a.FS = "	", a.RS = `
`;
  var r = Ls(e, a);
  return r;
}
function c2(e, a) {
  var r = "", t, n = "";
  if (e == null || e["!ref"] == null) return [];
  var i = Ke(e["!ref"]), c = "", s = [], f, o = [], l = e["!data"] != null;
  for (f = i.s.c; f <= i.e.c; ++f) s[f] = Pe(f);
  for (var v = i.s.r; v <= i.e.r; ++v)
    for (c = Me(v), f = i.s.c; f <= i.e.c; ++f)
      if (r = s[f] + c, t = l ? (e["!data"][v] || [])[f] : e[r], n = "", t !== void 0) {
        if (t.F != null) {
          if (r = t.F, !t.f) continue;
          n = t.f, r.indexOf(":") == -1 && (r = r + ":" + r);
        }
        if (t.f != null) n = t.f;
        else {
          if (a && a.values === !1) continue;
          if (t.t == "z") continue;
          if (t.t == "n" && t.v != null) n = "" + t.v;
          else if (t.t == "b") n = t.v ? "TRUE" : "FALSE";
          else if (t.w !== void 0) n = "'" + t.w;
          else {
            if (t.v === void 0) continue;
            t.t == "s" ? n = "'" + t.v : n = "" + t.v;
          }
        }
        o[o.length] = r + "=" + n;
      }
  return o;
}
function Bs(e, a, r) {
  var t = r || {}, n = e ? e["!data"] != null : t.dense, i = +!t.skipHeader, c = e || {};
  !e && n && (c["!data"] = []);
  var s = 0, f = 0;
  if (c && t.origin != null)
    if (typeof t.origin == "number") s = t.origin;
    else {
      var o = typeof t.origin == "string" ? dr(t.origin) : t.origin;
      s = o.r, f = o.c;
    }
  var l = { s: { c: 0, r: 0 }, e: { c: f, r: s + a.length - 1 + i } };
  if (c["!ref"]) {
    var v = Ke(c["!ref"]);
    l.e.c = Math.max(l.e.c, v.e.c), l.e.r = Math.max(l.e.r, v.e.r), s == -1 && (s = v.e.r + 1, l.e.r = s + a.length - 1 + i);
  } else
    s == -1 && (s = 0, l.e.r = a.length - 1 + i);
  var x = t.header || [], u = 0, p = [];
  a.forEach(function(d, h) {
    n && !c["!data"][s + h + i] && (c["!data"][s + h + i] = []), n && (p = c["!data"][s + h + i]), Br(d).forEach(function(E) {
      (u = x.indexOf(E)) == -1 && (x[u = x.length] = E);
      var g = d[E], C = "z", P = "", M = n ? "" : Pe(f + u) + Me(s + h + i), I = n ? p[f + u] : c[M];
      g && typeof g == "object" && !(g instanceof Date) ? n ? p[f + u] = g : c[M] = g : (typeof g == "number" ? C = "n" : typeof g == "boolean" ? C = "b" : typeof g == "string" ? C = "s" : g instanceof Date ? (C = "d", t.UTC || (g = Yt(g)), t.cellDates || (C = "n", g = ar(g)), P = I != null && I.z && Ur(I.z) ? I.z : t.dateNF || ge[14]) : g === null && t.nullError && (C = "e", g = 0), I ? (I.t = C, I.v = g, delete I.w, delete I.R, P && (I.z = P)) : n ? p[f + u] = I = { t: C, v: g } : c[M] = I = { t: C, v: g }, P && (I.z = P));
    });
  }), l.e.c = Math.max(l.e.c, f + x.length - 1);
  var _ = Me(s);
  if (n && !c["!data"][s] && (c["!data"][s] = []), i) for (u = 0; u < x.length; ++u)
    n ? c["!data"][s][u + f] = { t: "s", v: x[u] } : c[Pe(u + f) + _] = { t: "s", v: x[u] };
  return c["!ref"] = Ce(l), c;
}
function f2(e, a) {
  return Bs(null, e, a);
}
function lt(e, a, r) {
  if (typeof a == "string") {
    if (e["!data"] != null) {
      var t = dr(a);
      return e["!data"][t.r] || (e["!data"][t.r] = []), e["!data"][t.r][t.c] || (e["!data"][t.r][t.c] = { t: "z" });
    }
    return e[a] || (e[a] = { t: "z" });
  }
  return typeof a != "number" ? lt(e, Ne(a)) : lt(e, Pe(r || 0) + Me(a));
}
function o2(e, a) {
  if (typeof a == "number") {
    if (a >= 0 && e.SheetNames.length > a) return a;
    throw new Error("Cannot find sheet # " + a);
  } else if (typeof a == "string") {
    var r = e.SheetNames.indexOf(a);
    if (r > -1) return r;
    throw new Error("Cannot find sheet name |" + a + "|");
  } else throw new Error("Cannot find sheet |" + a + "|");
}
function z0(e, a) {
  var r = { SheetNames: [], Sheets: {} };
  return e && gt(r, e, a || "Sheet1"), r;
}
function gt(e, a, r, t) {
  var n = 1;
  if (!r) for (; n <= 65535 && e.SheetNames.indexOf(r = "Sheet" + n) != -1; ++n, r = void 0) ;
  if (!r || e.SheetNames.length >= 65535) throw new Error("Too many worksheets");
  if (t && e.SheetNames.indexOf(r) >= 0 && r.length < 32) {
    var i = r.match(/\d+$/);
    n = i && +i[0] || 0;
    var c = i && r.slice(0, i.index) || r;
    for (++n; n <= 65535 && e.SheetNames.indexOf(r = c + n) != -1; ++n) ;
  }
  if ($x(r), e.SheetNames.indexOf(r) >= 0) throw new Error("Worksheet with name |" + r + "| already exists!");
  return e.SheetNames.push(r), e.Sheets[r] = a, r;
}
function l2(e, a, r) {
  e.Workbook || (e.Workbook = {}), e.Workbook.Sheets || (e.Workbook.Sheets = []);
  var t = o2(e, a);
  switch (e.Workbook.Sheets[t] || (e.Workbook.Sheets[t] = {}), r) {
    case 0:
    case 1:
    case 2:
      break;
    default:
      throw new Error("Bad sheet visibility setting " + r);
  }
  e.Workbook.Sheets[t].Hidden = r;
}
function u2(e, a) {
  return e.z = a, e;
}
function Ms(e, a, r) {
  return a ? (e.l = { Target: a }, r && (e.l.Tooltip = r)) : delete e.l, e;
}
function h2(e, a, r) {
  return Ms(e, "#" + a, r);
}
function x2(e, a, r) {
  e.c || (e.c = []), e.c.push({ t: a, a: r || "SheetJS" });
}
function d2(e, a, r, t) {
  for (var n = typeof a != "string" ? a : Ke(a), i = typeof a == "string" ? a : Ce(a), c = n.s.r; c <= n.e.r; ++c) for (var s = n.s.c; s <= n.e.c; ++s) {
    var f = lt(e, c, s);
    f.t = "n", f.F = i, delete f.v, c == n.s.r && s == n.s.c && (f.f = r, t && (f.D = !0));
  }
  var o = Aa(e["!ref"]);
  return o.s.r > n.s.r && (o.s.r = n.s.r), o.s.c > n.s.c && (o.s.c = n.s.c), o.e.r < n.e.r && (o.e.r = n.e.r), o.e.c < n.e.c && (o.e.c = n.e.c), e["!ref"] = Ce(o), e;
}
var Qn = {
  encode_col: Pe,
  encode_row: Me,
  encode_cell: Ne,
  encode_range: Ce,
  decode_col: b0,
  decode_row: P0,
  split_cell: yf,
  decode_cell: dr,
  decode_range: Aa,
  format_cell: oa,
  sheet_new: Cf,
  sheet_add_aoa: Hi,
  sheet_add_json: Bs,
  sheet_add_dom: Cs,
  aoa_to_sheet: Ua,
  json_to_sheet: f2,
  table_to_sheet: Ds,
  table_to_book: Cd,
  sheet_to_csv: Ls,
  sheet_to_txt: s2,
  sheet_to_json: k0,
  sheet_to_html: Sd,
  sheet_to_formulae: c2,
  sheet_to_row_object_array: k0,
  sheet_get_cell: lt,
  book_new: z0,
  book_append_sheet: gt,
  book_set_sheet_visibility: l2,
  cell_set_number_format: u2,
  cell_set_hyperlink: Ms,
  cell_set_internal_link: h2,
  cell_add_comment: x2,
  sheet_set_array_formula: d2,
  consts: {
    SHEET_VISIBLE: 0,
    SHEET_HIDDEN: 1,
    SHEET_VERY_HIDDEN: 2
  }
};
function v2(e) {
  const a = { count: e.length, sum: {}, avg: {}, min: {}, max: {}, distinctCount: {}, first: {} };
  if (!e.length) return a;
  const r = Object.keys(e[0]);
  for (const t of r) {
    const n = e.map((c) => c[t]).filter((c) => c != null);
    a.first[t] = n[0], a.distinctCount[t] = new Set(n.map((c) => c instanceof Date ? c.toISOString() : String(c))).size;
    const i = n.filter((c) => typeof c == "number" && Number.isFinite(c));
    i.length && (a.sum[t] = i.reduce((c, s) => c + s, 0), a.avg[t] = a.sum[t] / i.length, a.min[t] = Math.min(...i), a.max[t] = Math.max(...i));
  }
  return a;
}
function Xt(e) {
  return e.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Za-z0-9]+/g, "_").replace(/^_+|_+$/g, "").toLowerCase() || "field";
}
const p2 = { mode: "core", basemap: { provider: "none", enabled: !1 }, geocoder: { provider: "none", enabled: !1, autocomplete: !1, userTriggeredOnly: !0, cache: !0, minScore: 80 }, privacyAcknowledged: !1 }, g2 = p2, m2 = {
  version: "1.0",
  bindings: { map: {} },
  interactions: { crossFilter: !0, multiSelect: !0, externalMode: "auto" },
  renderer: { showHeader: !1, showRowCount: !1, showStudioButton: !0 },
  security: { cssMode: "scoped", htmlMode: "sanitized", svgMode: "sanitized", showSanitizerWarnings: !1 },
  providers: g2,
  fields: { aliases: {} },
  motion: { enabled: !0, reducedMotion: "respect-system", maxConcurrentAnimations: 12 }
};
JSON.stringify(m2, null, 2);
function Cr(e, a) {
  const r = a === "latitude" ? Object.values(e).find((i) => i.type === "latitude")?.key : a === "longitude" ? Object.values(e).find((i) => i.type === "longitude")?.key : a === "geometry" ? Object.values(e).find((i) => i.type === "geometry")?.key : void 0;
  if (r) return r;
  const n = {
    latitude: ["latitude", "lat"],
    longitude: ["longitude", "lon", "lng"],
    geometry: ["geometry", "geojson", "wkt"],
    address: ["address", "street address"]
  }[a];
  if (n) return Object.values(e).find((i) => n.includes((i.sourceColumn ?? i.displayName ?? i.key).trim().toLowerCase()))?.key;
}
function ei(e, a) {
  return Object.values(e).filter((r) => r.roles.includes(a)).map((r) => r.key);
}
function _2(e, a) {
  return {
    layer: Cr(e, "layer"),
    type: Cr(e, "type"),
    latitude: Cr(e, "latitude"),
    longitude: Cr(e, "longitude"),
    x: Cr(e, "x"),
    y: Cr(e, "y"),
    address: Cr(e, "address"),
    city: Cr(e, "city"),
    state: Cr(e, "state"),
    zip: Cr(e, "zip"),
    geometry: Cr(e, "geometry"),
    color: Cr(e, "color"),
    size: Cr(e, "size"),
    tooltip: ei(e, "mapTooltip"),
    details: ei(e, "mapDetails")
  };
}
function T2(e) {
  return e.geometry ? "geometry" : e.latitude && e.longitude ? "latLon" : e.x && e.y ? "xy" : e.address ? "address" : "none";
}
function Us(e) {
  return !Array.isArray(e) || e.length === 0 ? !1 : typeof e[0] == "number" ? e.length >= 2 && e.every((a) => typeof a == "number" && Number.isFinite(a)) : e.every(Us);
}
function Hs(e) {
  const a = e.type.toLowerCase();
  return a.includes("point") ? "point" : a.includes("line") ? "line" : a.includes("polygon") ? "polygon" : a === "feature" ? Hs(e.geometry) : "geometry";
}
function Rt(e) {
  if (!e || typeof e != "object" || !("type" in e) || typeof e.type != "string") return null;
  const a = e;
  return a.type === "Feature" ? a.geometry && Rt(a.geometry) ? a : null : a.type === "FeatureCollection" ? a.features.every((r) => Rt(r)) ? a : null : a.type === "GeometryCollection" ? a.geometries.every((r) => Rt(r)) ? a : null : "coordinates" in a && Us(a.coordinates) ? a : null;
}
function ri(e) {
  const a = e.split(",").map((r) => r.trim().split(/\s+/).map(Number));
  return a.every((r) => r.length >= 2 && Number.isFinite(r[0]) && Number.isFinite(r[1])) ? a.map((r) => [r[0], r[1]]) : null;
}
function E2(e) {
  if (typeof e != "string" || !e.trim()) return null;
  const a = e.trim();
  if (a.startsWith("{") || a.startsWith("["))
    try {
      const s = Rt(JSON.parse(a));
      return s ? { geometry: s, type: Hs(s) } : null;
    } catch {
      return null;
    }
  const r = /^POINT\s*\(\s*(-?[\d.]+)\s+(-?[\d.]+)\s*\)$/i.exec(a);
  if (r) return { geometry: { type: "Point", coordinates: [Number(r[1]), Number(r[2])] }, type: "point" };
  const t = /^LINESTRING\s*\((.+)\)$/i.exec(a), n = t ? ri(t[1]) : null;
  if (n) return { geometry: { type: "LineString", coordinates: n }, type: "line" };
  const i = /^POLYGON\s*\(\((.+)\)\)$/i.exec(a), c = i ? ri(i[1]) : null;
  return c ? { geometry: { type: "Polygon", coordinates: [c] }, type: "polygon" } : null;
}
function It(e) {
  return typeof e == "number" && Number.isFinite(e) ? e : null;
}
function Ot(e, a) {
  return a ? String(e[a] ?? "").trim() : "";
}
function k2(e, a, r) {
  if (r === "geometry" && a.geometry) {
    const t = E2(e[a.geometry]);
    return t ? { type: t.type, geometry: t.geometry, lat: null, lon: null, x: null, y: null, address: null } : null;
  }
  if (r === "latLon" && a.latitude && a.longitude) {
    const t = It(e[a.latitude]), n = It(e[a.longitude]);
    return t !== null && n !== null && Math.abs(t) <= 90 && Math.abs(n) <= 180 ? { type: "point", geometry: null, lat: t, lon: n, x: null, y: null, address: null } : null;
  }
  if (r === "xy" && a.x && a.y) {
    const t = It(e[a.x]), n = It(e[a.y]);
    return t !== null && n !== null && Math.abs(n) <= 90 && Math.abs(t) <= 180 ? { type: "point", geometry: null, lat: n, lon: t, x: t, y: n, address: null } : null;
  }
  if (r === "address" && a.address) {
    const t = [Ot(e, a.address), Ot(e, a.city), Ot(e, a.state), Ot(e, a.zip)].filter(Boolean).join(", ");
    return t ? { type: "address", geometry: null, lat: null, lon: null, x: null, y: null, address: t } : null;
  }
  return null;
}
function w2(e) {
  return (Array.isArray(e) ? e : [e]).map((a) => String(a ?? "").trim()).filter(Boolean).join(", ").replace(/\s+/g, " ").toLocaleLowerCase();
}
function F2(e, a) {
  const r = /* @__PURE__ */ Object.create(null);
  for (const [t, n] of Object.entries(e)) r[t] = n;
  for (const t of Object.values(a)) r[t.displayName] = e[t.key];
  return r;
}
function A2(e, a, r) {
  if (!a || !r) return "incomplete";
  const t = e[a], n = e[r], i = (c) => c == null || typeof c == "string" && !c.trim();
  return i(t) || i(n) ? "incomplete" : typeof t != "number" || typeof n != "number" || !Number.isFinite(t) || !Number.isFinite(n) ? "non-numeric" : t < -90 || t > 90 || n < -180 || n > 180 ? "out-of-range" : "valid";
}
function ai(e, a) {
  if (!e) return [];
  const r = [], t = { fieldKey: e.key, fieldDisplayName: e.displayName, queryName: e.queryName, queryAggregation: e.queryAggregation, sourceTable: e.sourceTable, sourceColumn: e.sourceColumn, roles: [...e.roles] };
  if (e.isImplicitAggregation && e.queryAggregation) {
    const n = e.queryName || `${e.queryAggregation}(${e.sourceColumn ?? e.displayName})`;
    r.push({ code: "MAP_COORDINATE_QUERY_AGGREGATED", severity: "warning", message: `Power BI’s current HyperPBI visual query reports ${a} as ${n}. The model’s default summarization and this visual-query aggregation are separate. Keep the field in Values and change this field instance in the HyperPBI visual query to Don’t summarize when row-level coordinates are required.`, ...t });
  }
  return r;
}
function y2(e, a, r, t = {}, n = []) {
  const i = _2(a), c = T2(i), s = /* @__PURE__ */ new Map();
  let f = 0, o = 0;
  const l = { dataViewRowCount: e.length, validPairCount: 0, invalidPairCount: 0, incompletePairCount: 0, nonNumericPairCount: 0, outOfRangePairCount: 0 };
  e.forEach((u, p) => {
    if (c === "latLon") {
      const I = A2(u, i.latitude, i.longitude);
      I === "valid" ? l.validPairCount += 1 : (l.invalidPairCount += 1, I === "incomplete" ? l.incompletePairCount += 1 : I === "non-numeric" ? l.nonNumericPairCount += 1 : l.outOfRangePairCount += 1);
    }
    let _ = k2(u, i, c);
    if (!_) {
      f += 1;
      return;
    }
    if (_.type === "address" && _.address) {
      const I = t[w2(_.address)];
      I && (_ = { ..._, type: "point", lat: I.latitude, lon: I.longitude });
    }
    const d = i.layer ? String(u[i.layer] ?? "(Blank)") : "Map data", h = i.size ? Number(u[i.size]) : NaN, E = i.type ? String(u[i.type] ?? "").trim().toLowerCase() : "", g = _.type === "geometry" && ["point", "line", "polygon"].includes(E) ? E : _.type;
    (c === "latLon" || c === "xy") && E && E !== "point" && (o += 1);
    const C = n[p] ?? `fallback-map-row:${p}`, P = {
      id: C,
      rowIndex: p,
      rowKey: C,
      ..._,
      type: g,
      colorValue: i.color ? u[i.color] : null,
      sizeValue: Number.isFinite(h) ? h : null,
      properties: F2(u, a),
      row: u
    }, M = s.get(d) ?? [];
    M.push(P), s.set(d, M);
  });
  const v = [];
  if (c === "latLon") {
    v.push(...ai(i.latitude ? a[i.latitude] : void 0, "Latitude")), v.push(...ai(i.longitude ? a[i.longitude] : void 0, "Longitude"));
    const u = l.validPairCount > 0 ? "warning" : "error";
    l.incompletePairCount && v.push({ code: "MAP_COORDINATE_PAIR_INCOMPLETE", severity: u, message: `${l.incompletePairCount.toLocaleString()} current data-view row(s) have an incomplete latitude/longitude pair.` }), l.nonNumericPairCount && v.push({ code: "MAP_COORDINATE_NON_NUMERIC", severity: u, message: `${l.nonNumericPairCount.toLocaleString()} current data-view row(s) contain nonnumeric latitude or longitude values.` }), l.outOfRangePairCount && v.push({ code: "MAP_COORDINATE_OUT_OF_RANGE", severity: u, message: `${l.outOfRangePairCount.toLocaleString()} current data-view row(s) are outside latitude −90…90 or longitude −180…180.` }), l.invalidPairCount && v.push({ code: "MAP_COORDINATE_ROWS_DROPPED", severity: u, message: `${l.invalidPairCount.toLocaleString()} of ${l.dataViewRowCount.toLocaleString()} current data-view row(s) were excluded; ${l.validPairCount.toLocaleString()} valid coordinate pair(s) remain.` }), l.validPairCount && v.push({ code: "MAP_COORDINATE_BINDING_VALID", severity: "info", message: `${l.validPairCount.toLocaleString()} valid coordinate pair(s) were loaded from ${l.dataViewRowCount.toLocaleString()} current data-view row(s).` });
  }
  const x = v.filter((u) => u.severity !== "info").map((u) => u.message);
  if (c === "address") {
    const u = Array.from(s.values()).flat().filter((_) => _.type === "point").length, p = Array.from(s.values()).flat().length - u;
    x.push(u ? `${u.toLocaleString()} cached address location(s) loaded; ${p.toLocaleString()} remain unresolved.` : "Address fields are bound. Geocoding is user-triggered in Studio; no address data was transmitted automatically.");
  }
  return c === "none" && x.push("Choose geometry, coordinate, or address fields through the map layer source bindings. All source fields must be present in Values."), f > 0 && c !== "address" && c !== "latLon" && x.push(`${f.toLocaleString()} row(s) have invalid or missing map locations.`), o > 0 && x.push(`${o.toLocaleString()} row(s) declare a non-point Map Type, but coordinate pairs render as points. Bind Geometry for lines or polygons.`), {
    hasGeometry: !!i.geometry,
    hasLatLon: !!(i.latitude && i.longitude),
    hasXY: !!(i.x && i.y),
    hasAddress: !!i.address,
    mode: c,
    bindings: i,
    layers: Array.from(s, ([u, p]) => ({ name: u, features: p })),
    warnings: x,
    invalidFeatureCount: f,
    diagnostics: v,
    coordinateCounts: l,
    locationCounts: {
      totalInputRows: e.length,
      validFeatureCount: e.length - f,
      incompletePairCount: l.incompletePairCount,
      nonNumericCount: l.nonNumericPairCount,
      outOfRangeCount: l.outOfRangePairCount,
      geometryParseFailureCount: c === "geometry" ? f : 0,
      filteredRowCount: 0
    }
  };
}
const ti = 50 * 1024 * 1024, zt = 25e4, Kt = 5e6;
class Mr extends Error {
  constructor(a, r) {
    super(a), this.code = r, this.name = "DataImportError";
  }
}
function K0(e) {
  let a = 2166136261;
  for (let r = 0; r < e.length; r += 1)
    a ^= e.charCodeAt(r), a = Math.imul(a, 16777619);
  return (a >>> 0).toString(36);
}
function S2(e) {
  return e instanceof Date ? e.toISOString() : e;
}
function C2(e) {
  const a = [], r = /* @__PURE__ */ new Set();
  return e.forEach((t, n) => {
    const i = t.trim() ? Xt(t) : `column_${n + 1}`;
    let c = i, s = 2;
    for (; r.has(c); )
      c = `${i}_${s}`, s += 1;
    r.add(c), a.push(c);
  }), a;
}
const a0 = (e) => e == null || typeof e == "string" && e.trim() === "", D2 = (e) => /^[+-]?0\d+$/.test(e.trim()), I2 = (e) => /^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i.test(e.trim()), O2 = (e) => /^\d{4}-\d{2}-\d{2}$/.test(e.trim()) && !Number.isNaN(Date.parse(`${e.trim()}T00:00:00Z`)), R2 = (e) => /^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:?\d{2})?$/.test(e.trim()) && !Number.isNaN(Date.parse(e.trim())), N2 = (e) => /^(true|false)$/i.test(e.trim());
function P2(e) {
  const a = e.trim().toLowerCase().replace(/[^a-z0-9]+/g, "");
  if (["latitude", "lat", "ycoordinate"].includes(a)) return "latitude";
  if (["longitude", "lon", "lng", "long", "xcoordinate"].includes(a)) return "longitude";
  if (["geometry", "geom", "geojson", "wkt", "shape"].includes(a)) return "geometry";
}
function b2(e) {
  if (typeof e != "string") return !1;
  const a = e.trim();
  if (/^(POINT|LINESTRING|POLYGON|MULTI(?:POINT|LINESTRING|POLYGON))\s*\(/i.test(a)) return !0;
  if (!a.startsWith("{") && !a.startsWith("[")) return !1;
  try {
    const r = JSON.parse(a);
    return typeof r == "object" && r !== null && typeof r.type == "string";
  } catch {
    return !1;
  }
}
function L2(e, a, r) {
  const t = a.filter((p) => !a0(p)), n = t.map((p) => p instanceof Date ? p.toISOString() : String(p).trim()), i = P2(e), c = t.length > 0 && t.every(
    (p) => typeof p == "number" && Number.isFinite(p) || typeof p == "string" && I2(p) && !D2(p)
  ), s = t.length > 0 && t.every((p) => typeof p == "boolean" || typeof p == "string" && N2(p)), f = t.length > 0 && n.every(O2), o = t.length > 0 && t.every((p) => p instanceof Date || R2(String(p))), l = i === "geometry" && t.length > 0 && t.every(b2), v = c ? t.map(Number) : [], x = i === "latitude" && v.every((p) => p >= -90 && p <= 90) ? "latitude" : i === "longitude" && v.every((p) => p >= -180 && p <= 180) ? "longitude" : void 0, u = s ? "boolean" : c ? "number" : f ? "date" : o ? "datetime" : "text";
  return {
    key: r,
    displayName: e,
    type: l ? "geometry" : x ?? (u === "number" ? "measure" : u === "date" || u === "datetime" ? "date" : "dimension"),
    roles: x ? [x] : l ? ["geometry"] : [],
    kind: "column",
    dataType: u,
    origin: "uploaded-column"
  };
}
function B2(e, a) {
  if (a0(e)) return null;
  if (a.dataType === "number") {
    const r = Number(e);
    return Number.isFinite(r) ? r : null;
  }
  return a.dataType === "boolean" ? typeof e == "boolean" ? e : String(e).trim().toLowerCase() === "true" : e instanceof Date ? e.toISOString() : typeof e == "string" ? e : String(e);
}
function Ws(e, a, r) {
  if (!e.length) throw new Mr("The file does not contain a header row.", "EMPTY_FILE");
  if (a.length > zt)
    throw new Mr(`The source has ${a.length.toLocaleString()} rows; the limit is ${zt.toLocaleString()}. No rows were imported.`, "TOO_MANY_ROWS");
  if (e.length * a.length > Kt)
    throw new Mr(`The source has more than ${Kt.toLocaleString()} cells. No rows were imported.`, "TOO_MANY_CELLS");
  const t = C2(e), n = Object.fromEntries(
    t.map((f, o) => [
      f,
      L2(e[o], a.map((l) => l[o]), f)
    ])
  ), i = a.map((f) => Object.fromEntries(
    t.map((o, l) => [o, B2(f[l], n[o])])
  )), c = /* @__PURE__ */ new Map(), s = i.map((f) => {
    const o = JSON.stringify(t.map((v) => [v, S2(f[v])])), l = c.get(o) ?? 0;
    return c.set(o, l + 1), `row_${K0(`${r}\0${o}\0${l}`)}`;
  });
  return {
    fields: n,
    rows: i,
    rowKeys: s,
    aggregates: v2(i),
    map: y2(i, n, void 0, void 0, s),
    loadStatus: { loadedRowCount: i.length, moreRowsAvailable: !1, fetchInProgress: !1 }
  };
}
function M2(e) {
  const a = e.replace(/^\uFEFF/, ""), r = [];
  let t = [], n = "", i = !1;
  for (let c = 0; c < a.length; c += 1) {
    const s = a[c];
    if (i) {
      s === '"' && a[c + 1] === '"' ? (n += '"', c += 1) : s === '"' ? i = !1 : n += s;
      continue;
    }
    s === '"' && n === "" ? i = !0 : s === "," ? (t.push(n), n = "") : s === `
` || s === "\r" ? (s === "\r" && a[c + 1] === `
` && (c += 1), t.push(n), r.push(t), t = [], n = "") : n += s;
  }
  if (i) throw new Mr("The CSV contains an unterminated quoted field.", "INVALID_FILE");
  for ((n !== "" || t.length) && (t.push(n), r.push(t)); r.length && r[r.length - 1].every((c) => c === ""); ) r.pop();
  return r;
}
function U2(e, a = "data.csv") {
  const r = M2(e);
  if (!r.length) throw new Mr("The CSV is empty.", "EMPTY_FILE");
  const t = r[0].map((s) => s), n = r.slice(1).map((s) => t.map((f, o) => s[o] ?? null)), i = Ws(t, n, a);
  return { id: `src_${Xt(a.replace(/\.csv$/i, ""))}_${K0(JSON.stringify([t, i.rowKeys]))}`, name: a.replace(/\.csv$/i, "") || "CSV data", kind: "csv", fileName: a, data: i };
}
function H2(e) {
  if (!e || e.f) return null;
  if (e.t === "d" && e.v instanceof Date) return e.v;
  if (e.t === "n" && e.z && v0?.is_date?.(e.z)) {
    const a = v0.parse_date_code(Number(e.v));
    if (a) {
      const r = new Date(Date.UTC(a.y, a.m - 1, a.d, a.H, a.M, Math.floor(a.S))).toISOString();
      return a.H || a.M || a.S ? r : r.slice(0, 10);
    }
  }
  return e.t === "n" && typeof e.w == "string" && /^0\d+$/.test(e.w.trim()) ? e.w.trim() : e.v === void 0 || e.v === null ? null : e.v;
}
function W2(e) {
  if (!e["!ref"]) return [];
  const a = Qn.decode_range(e["!ref"]), r = [], t = a.e.c - a.s.c + 1, n = a.e.r - a.s.r + 1;
  if (n > zt + 1) throw new Mr(`The sheet has more than ${zt.toLocaleString()} data rows. No rows were imported.`, "TOO_MANY_ROWS");
  if (n * t > Kt) throw new Mr(`The sheet has more than ${Kt.toLocaleString()} cells. No rows were imported.`, "TOO_MANY_CELLS");
  for (let i = a.s.r; i <= a.e.r; i += 1) {
    const c = [];
    for (let s = a.s.c; s <= a.e.c; s += 1)
      c.push(H2(e[Qn.encode_cell({ r: i, c: s })]));
    r.push(c);
  }
  for (; r.length && r[r.length - 1].every(a0); ) r.pop();
  return r;
}
function V2(e, a = "workbook.xlsx") {
  let r;
  try {
    r = La(e, {
      type: "array",
      raw: !0,
      cellDates: !0,
      cellFormula: !0,
      cellHTML: !1,
      cellText: !0,
      dense: !1
    });
  } catch (t) {
    throw new Mr(`The workbook could not be read: ${t instanceof Error ? t.message : String(t)}`, "INVALID_FILE");
  }
  if (!r.SheetNames.length) throw new Mr("The workbook has no sheets.", "EMPTY_FILE");
  return r.SheetNames.map((t, n) => {
    const i = W2(r.Sheets[t]), c = (i[0] ?? []).map((v) => a0(v) ? "" : String(v));
    if (!c.length) throw new Mr(`Sheet “${t}” is empty.`, "EMPTY_FILE");
    const s = i.slice(1).map((v) => c.map((x, u) => v[u] ?? null)), f = `${a}\0${t}`, o = Ws(c, s, f);
    return { id: `src_${Xt(a.replace(/\.xlsx$/i, ""))}_${Xt(t)}_${K0(JSON.stringify([n, c, o.rowKeys]))}`, name: t, kind: "xlsx-sheet", fileName: a, sheetName: t, data: o };
  });
}
async function G2(e) {
  if (e.size > ti)
    throw new Mr(`“${e.name}” is ${(e.size / 1024 / 1024).toFixed(1)} MB; the limit is ${ti / 1024 / 1024} MB.`, "FILE_TOO_LARGE");
  if (/\.csv$/i.test(e.name)) return [U2(await e.text(), e.name)];
  if (/\.xlsx$/i.test(e.name)) return V2(await e.arrayBuffer(), e.name);
  throw new Mr(`“${e.name}” is not supported. Upload .csv or .xlsx files.`, "UNSUPPORTED_FILE");
}
self.onmessage = async (e) => {
  const { requestId: a, file: r } = e.data;
  try {
    const t = await G2(r);
    self.postMessage({ requestId: a, sources: t });
  } catch (t) {
    self.postMessage({
      requestId: a,
      error: t instanceof Error ? t.message : String(t)
    });
  }
};
