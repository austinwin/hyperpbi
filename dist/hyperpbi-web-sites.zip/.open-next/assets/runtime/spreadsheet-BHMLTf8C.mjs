/*! xlsx.js (C) 2013-present SheetJS -- http://sheetjs.com */
var br = 1200, Ls = [874, 932, 936, 949, 950, 1250, 1251, 1252, 1253, 1254, 1255, 1256, 1257, 1258, 1e4], x0 = {
  0: 1252,
  /* ANSI */
  1: 65001,
  /* DEFAULT */
  2: 65001,
  /* SYMBOL */
  77: 1e4,
  /* MAC */
  128: 932,
  /* SHIFTJIS */
  129: 949,
  /* HANGUL */
  130: 1361,
  /* JOHAB */
  134: 936,
  /* GB2312 */
  136: 950,
  /* CHINESEBIG5 */
  161: 1253,
  /* GREEK */
  162: 1254,
  /* TURKISH */
  163: 1258,
  /* VIETNAMESE */
  177: 1255,
  /* HEBREW */
  178: 1256,
  /* ARABIC */
  186: 1257,
  /* BALTIC */
  204: 1251,
  /* RUSSIAN */
  222: 874,
  /* THAI */
  238: 1250,
  /* EASTEUROPE */
  255: 1252,
  /* OEM */
  69: 6969
  /* MISC */
}, d0 = function(e) {
  Ls.indexOf(e) != -1 && (x0[0] = e);
};
function Bs() {
  d0(1252);
}
var Vr = function(e) {
  br = e, d0(e);
};
function Vn() {
  Vr(1200), Bs();
}
function H0(e) {
  for (var a = [], r = 0, t = e.length; r < t; ++r) a[r] = e.charCodeAt(r);
  return a;
}
function Gn(e) {
  for (var a = [], r = 0; r < e.length >> 1; ++r) a[r] = String.fromCharCode(e.charCodeAt(2 * r) + (e.charCodeAt(2 * r + 1) << 8));
  return a.join("");
}
function Ms(e) {
  for (var a = [], r = 0; r < e.length >> 1; ++r) a[r] = String.fromCharCode(e[2 * r] + (e[2 * r + 1] << 8));
  return a.join("");
}
function Xn(e) {
  for (var a = [], r = 0; r < e.length >> 1; ++r) a[r] = String.fromCharCode(e.charCodeAt(2 * r + 1) + (e.charCodeAt(2 * r) << 8));
  return a.join("");
}
var Ha = function(e) {
  var a = e.charCodeAt(0), r = e.charCodeAt(1);
  return a == 255 && r == 254 ? Gn(e.slice(2)) : a == 254 && r == 255 ? Xn(e.slice(2)) : a == 65279 ? e.slice(1) : e;
}, mt = function(a) {
  return String.fromCharCode(a);
}, W0 = function(a) {
  return String.fromCharCode(a);
}, Us = null, na = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
function V0(e) {
  for (var a = "", r = 0, t = 0, n = 0, i = 0, f = 0, s = 0, c = 0, o = 0; o < e.length; )
    r = e.charCodeAt(o++), i = r >> 2, t = e.charCodeAt(o++), f = (r & 3) << 4 | t >> 4, n = e.charCodeAt(o++), s = (t & 15) << 2 | n >> 6, c = n & 63, isNaN(t) ? s = c = 64 : isNaN(n) && (c = 64), a += na.charAt(i) + na.charAt(f) + na.charAt(s) + na.charAt(c);
  return a;
}
function Or(e) {
  var a = "", r = 0, t = 0, n = 0, i = 0, f = 0, s = 0, c = 0;
  if (e.slice(0, 5) == "data:") {
    var o = e.slice(0, 1024).indexOf(";base64,");
    o > -1 && (e = e.slice(o + 8));
  }
  e = e.replace(/[^\w\+\/\=]/g, "");
  for (var o = 0; o < e.length; )
    i = na.indexOf(e.charAt(o++)), f = na.indexOf(e.charAt(o++)), r = i << 2 | f >> 4, a += String.fromCharCode(r), s = na.indexOf(e.charAt(o++)), t = (f & 15) << 4 | s >> 2, s !== 64 && (a += String.fromCharCode(t)), c = na.indexOf(e.charAt(o++)), n = (s & 3) << 6 | c, c !== 64 && (a += String.fromCharCode(n));
  return a;
}
var Se = /* @__PURE__ */ (function() {
  return typeof Buffer < "u" && typeof process < "u" && typeof process.versions < "u" && !!process.versions.node;
})(), oa = /* @__PURE__ */ (function() {
  if (typeof Buffer < "u") {
    var e = !Buffer.from;
    if (!e) try {
      Buffer.from("foo", "utf8");
    } catch {
      e = !0;
    }
    return e ? function(a, r) {
      return r ? new Buffer(a, r) : new Buffer(a);
    } : Buffer.from.bind(Buffer);
  }
  return function() {
  };
})(), rt = /* @__PURE__ */ (function() {
  if (typeof Buffer > "u") return !1;
  var e = oa([65, 0]);
  if (!e) return !1;
  var a = e.toString("utf16le");
  return a.length == 1;
})();
function sa(e) {
  return Se ? Buffer.alloc ? Buffer.alloc(e) : new Buffer(e) : typeof Uint8Array < "u" ? new Uint8Array(e) : new Array(e);
}
function G0(e) {
  return Se ? Buffer.allocUnsafe ? Buffer.allocUnsafe(e) : new Buffer(e) : typeof Uint8Array < "u" ? new Uint8Array(e) : new Array(e);
}
var yr = function(a) {
  return Se ? oa(a, "binary") : a.split("").map(function(r) {
    return r.charCodeAt(0) & 255;
  });
};
function ea(e) {
  if (Array.isArray(e)) return e.map(function(t) {
    return String.fromCharCode(t);
  }).join("");
  for (var a = [], r = 0; r < e.length; ++r) a[r] = String.fromCharCode(e[r]);
  return a.join("");
}
function v0(e) {
  if (typeof ArrayBuffer > "u") throw new Error("Unsupported");
  if (e instanceof ArrayBuffer) return v0(new Uint8Array(e));
  for (var a = new Array(e.length), r = 0; r < e.length; ++r) a[r] = e[r];
  return a;
}
var ta = Se ? function(e) {
  return Buffer.concat(e.map(function(a) {
    return Buffer.isBuffer(a) ? a : oa(a);
  }));
} : function(e) {
  if (typeof Uint8Array < "u") {
    var a = 0, r = 0;
    for (a = 0; a < e.length; ++a) r += e[a].length;
    var t = new Uint8Array(r), n = 0;
    for (a = 0, r = 0; a < e.length; r += n, ++a)
      n = e[a].length, e[a] instanceof Uint8Array ? t.set(e[a], r) : typeof e[a] == "string" ? t.set(new Uint8Array(yr(e[a])), r) : t.set(new Uint8Array(e[a]), r);
    return t;
  }
  return [].concat.apply([], e.map(function(i) {
    return Array.isArray(i) ? i : [].slice.call(i);
  }));
};
function Hs(e) {
  for (var a = [], r = 0, t = e.length + 250, n = sa(e.length + 255), i = 0; i < e.length; ++i) {
    var f = e.charCodeAt(i);
    if (f < 128) n[r++] = f;
    else if (f < 2048)
      n[r++] = 192 | f >> 6 & 31, n[r++] = 128 | f & 63;
    else if (f >= 55296 && f < 57344) {
      f = (f & 1023) + 64;
      var s = e.charCodeAt(++i) & 1023;
      n[r++] = 240 | f >> 8 & 7, n[r++] = 128 | f >> 2 & 63, n[r++] = 128 | s >> 6 & 15 | (f & 3) << 4, n[r++] = 128 | s & 63;
    } else
      n[r++] = 224 | f >> 12 & 15, n[r++] = 128 | f >> 6 & 63, n[r++] = 128 | f & 63;
    r > t && (a.push(n.slice(0, r)), r = 0, n = sa(65535), t = 65530);
  }
  return a.push(n.slice(0, r)), ta(a);
}
var wr = /\u0000/g, Wa = /[\u0001-\u0006]/g;
function Oa(e) {
  for (var a = "", r = e.length - 1; r >= 0; ) a += e.charAt(r--);
  return a;
}
function Gr(e, a) {
  var r = "" + e;
  return r.length >= a ? r : Ie("0", a - r.length) + r;
}
function p0(e, a) {
  var r = "" + e;
  return r.length >= a ? r : Ie(" ", a - r.length) + r;
}
function yt(e, a) {
  var r = "" + e;
  return r.length >= a ? r : r + Ie(" ", a - r.length);
}
function Ws(e, a) {
  var r = "" + Math.round(e);
  return r.length >= a ? r : Ie("0", a - r.length) + r;
}
function Vs(e, a) {
  var r = "" + e;
  return r.length >= a ? r : Ie("0", a - r.length) + r;
}
var X0 = /* @__PURE__ */ Math.pow(2, 32);
function Ca(e, a) {
  if (e > X0 || e < -X0) return Ws(e, a);
  var r = Math.round(e);
  return Vs(r, a);
}
function Dt(e, a) {
  return a = a || 0, e.length >= 7 + a && (e.charCodeAt(a) | 32) === 103 && (e.charCodeAt(a + 1) | 32) === 101 && (e.charCodeAt(a + 2) | 32) === 110 && (e.charCodeAt(a + 3) | 32) === 101 && (e.charCodeAt(a + 4) | 32) === 114 && (e.charCodeAt(a + 5) | 32) === 97 && (e.charCodeAt(a + 6) | 32) === 108;
}
var z0 = [
  ["Sun", "Sunday"],
  ["Mon", "Monday"],
  ["Tue", "Tuesday"],
  ["Wed", "Wednesday"],
  ["Thu", "Thursday"],
  ["Fri", "Friday"],
  ["Sat", "Saturday"]
], Jt = [
  ["J", "Jan", "January"],
  ["F", "Feb", "February"],
  ["M", "Mar", "March"],
  ["A", "Apr", "April"],
  ["M", "May", "May"],
  ["J", "Jun", "June"],
  ["J", "Jul", "July"],
  ["A", "Aug", "August"],
  ["S", "Sep", "September"],
  ["O", "Oct", "October"],
  ["N", "Nov", "November"],
  ["D", "Dec", "December"]
];
function Gs(e) {
  return e || (e = {}), e[0] = "General", e[1] = "0", e[2] = "0.00", e[3] = "#,##0", e[4] = "#,##0.00", e[9] = "0%", e[10] = "0.00%", e[11] = "0.00E+00", e[12] = "# ?/?", e[13] = "# ??/??", e[14] = "m/d/yy", e[15] = "d-mmm-yy", e[16] = "d-mmm", e[17] = "mmm-yy", e[18] = "h:mm AM/PM", e[19] = "h:mm:ss AM/PM", e[20] = "h:mm", e[21] = "h:mm:ss", e[22] = "m/d/yy h:mm", e[37] = "#,##0 ;(#,##0)", e[38] = "#,##0 ;[Red](#,##0)", e[39] = "#,##0.00;(#,##0.00)", e[40] = "#,##0.00;[Red](#,##0.00)", e[45] = "mm:ss", e[46] = "[h]:mm:ss", e[47] = "mmss.0", e[48] = "##0.0E+0", e[49] = "@", e[56] = '"上午/下午 "hh"時"mm"分"ss"秒 "', e;
}
var ge = {
  0: "General",
  1: "0",
  2: "0.00",
  3: "#,##0",
  4: "#,##0.00",
  9: "0%",
  10: "0.00%",
  11: "0.00E+00",
  12: "# ?/?",
  13: "# ??/??",
  14: "m/d/yy",
  15: "d-mmm-yy",
  16: "d-mmm",
  17: "mmm-yy",
  18: "h:mm AM/PM",
  19: "h:mm:ss AM/PM",
  20: "h:mm",
  21: "h:mm:ss",
  22: "m/d/yy h:mm",
  37: "#,##0 ;(#,##0)",
  38: "#,##0 ;[Red](#,##0)",
  39: "#,##0.00;(#,##0.00)",
  40: "#,##0.00;[Red](#,##0.00)",
  45: "mm:ss",
  46: "[h]:mm:ss",
  47: "mmss.0",
  48: "##0.0E+0",
  49: "@",
  56: '"上午/下午 "hh"時"mm"分"ss"秒 "'
}, $0 = {
  5: 37,
  6: 38,
  7: 39,
  8: 40,
  //  5 -> 37 ...  8 -> 40
  23: 0,
  24: 0,
  25: 0,
  26: 0,
  // 23 ->  0 ... 26 ->  0
  27: 14,
  28: 14,
  29: 14,
  30: 14,
  31: 14,
  // 27 -> 14 ... 31 -> 14
  50: 14,
  51: 14,
  52: 14,
  53: 14,
  54: 14,
  // 50 -> 14 ... 58 -> 14
  55: 14,
  56: 14,
  57: 14,
  58: 14,
  59: 1,
  60: 2,
  61: 3,
  62: 4,
  // 59 ->  1 ... 62 ->  4
  67: 9,
  68: 10,
  // 67 ->  9 ... 68 -> 10
  69: 12,
  70: 13,
  71: 14,
  // 69 -> 12 ... 71 -> 14
  72: 14,
  73: 15,
  74: 16,
  75: 17,
  // 72 -> 14 ... 75 -> 17
  76: 20,
  77: 21,
  78: 22,
  // 76 -> 20 ... 78 -> 22
  79: 45,
  80: 46,
  81: 47,
  // 79 -> 45 ... 81 -> 47
  82: 0
  // 82 ->  0 ... 65536 -> 0 (omitted)
}, Xs = {
  //  5 -- Currency,   0 decimal, black negative
  5: '"$"#,##0_);\\("$"#,##0\\)',
  63: '"$"#,##0_);\\("$"#,##0\\)',
  //  6 -- Currency,   0 decimal, red   negative
  6: '"$"#,##0_);[Red]\\("$"#,##0\\)',
  64: '"$"#,##0_);[Red]\\("$"#,##0\\)',
  //  7 -- Currency,   2 decimal, black negative
  7: '"$"#,##0.00_);\\("$"#,##0.00\\)',
  65: '"$"#,##0.00_);\\("$"#,##0.00\\)',
  //  8 -- Currency,   2 decimal, red   negative
  8: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
  66: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
  // 41 -- Accounting, 0 decimal, No Symbol
  41: '_(* #,##0_);_(* \\(#,##0\\);_(* "-"_);_(@_)',
  // 42 -- Accounting, 0 decimal, $  Symbol
  42: '_("$"* #,##0_);_("$"* \\(#,##0\\);_("$"* "-"_);_(@_)',
  // 43 -- Accounting, 2 decimal, No Symbol
  43: '_(* #,##0.00_);_(* \\(#,##0.00\\);_(* "-"??_);_(@_)',
  // 44 -- Accounting, 2 decimal, $  Symbol
  44: '_("$"* #,##0.00_);_("$"* \\(#,##0.00\\);_("$"* "-"??_);_(@_)'
};
function It(e, a, r) {
  for (var t = e < 0 ? -1 : 1, n = e * t, i = 0, f = 1, s = 0, c = 1, o = 0, l = 0, v = Math.floor(n); o < a && (v = Math.floor(n), s = v * f + i, l = v * o + c, !(n - v < 5e-8)); )
    n = 1 / (n - v), i = f, f = s, c = o, o = l;
  if (l > a && (o > a ? (l = c, s = i) : (l = o, s = f)), !r) return [0, t * s, l];
  var d = Math.floor(t * s / l);
  return [d, t * s - d * l, l];
}
function zs(e) {
  var a = e.toPrecision(16);
  if (a.indexOf("e") > -1) {
    var r = a.slice(0, a.indexOf("e"));
    return r = r.indexOf(".") > -1 ? r.slice(0, r.slice(0, 2) == "0." ? 17 : 16) : r.slice(0, 15) + Ie("0", r.length - 15), r + a.slice(a.indexOf("e"));
  }
  var t = a.indexOf(".") > -1 ? a.slice(0, a.slice(0, 2) == "0." ? 17 : 16) : a.slice(0, 15) + Ie("0", a.length - 15);
  return Number(t);
}
function Kr(e, a, r) {
  if (e > 2958465 || e < 0) return null;
  e = zs(e);
  var t = e | 0, n = Math.floor(86400 * (e - t)), i = 0, f = [], s = { D: t, T: n, u: 86400 * (e - t) - n, y: 0, m: 0, d: 0, H: 0, M: 0, S: 0, q: 0 };
  if (Math.abs(s.u) < 1e-6 && (s.u = 0), a && a.date1904 && (t += 1462), s.u > 0.9999 && (s.u = 0, ++n == 86400 && (s.T = n = 0, ++t, ++s.D)), t === 60)
    f = r ? [1317, 10, 29] : [1900, 2, 29], i = 3;
  else if (t === 0)
    f = r ? [1317, 8, 29] : [1900, 1, 0], i = 6;
  else {
    t > 60 && --t;
    var c = new Date(1900, 0, 1);
    c.setDate(c.getDate() + t - 1), f = [c.getFullYear(), c.getMonth() + 1, c.getDate()], i = c.getDay(), t < 60 && (i = (i + 6) % 7), r && (i = js(c, f));
  }
  return s.y = f[0], s.m = f[1], s.d = f[2], s.S = n % 60, n = Math.floor(n / 60), s.M = n % 60, n = Math.floor(n / 60), s.H = n, s.q = i, s;
}
function g0(e) {
  return e.indexOf(".") == -1 ? e : e.replace(/(?:\.0*|(\.\d*[1-9])0+)$/, "$1");
}
function $s(e) {
  return e.indexOf("E") == -1 ? e : e.replace(/(?:\.0*|(\.\d*[1-9])0+)[Ee]/, "$1E").replace(/(E[+-])(\d)$/, "$10$2");
}
function Ks(e) {
  var a = e < 0 ? 12 : 11, r = g0(e.toFixed(12));
  return r.length <= a || (r = e.toPrecision(10), r.length <= a) ? r : e.toExponential(5);
}
function Ys(e) {
  var a = g0(e.toFixed(11));
  return a.length > (e < 0 ? 12 : 11) || a === "0" || a === "-0" ? e.toPrecision(6) : a;
}
function at(e) {
  if (!isFinite(e)) return isNaN(e) ? "#NUM!" : "#DIV/0!";
  var a = Math.floor(Math.log(Math.abs(e)) * Math.LOG10E), r;
  return a >= -4 && a <= -1 ? r = e.toPrecision(10 + a) : Math.abs(a) <= 9 ? r = Ks(e) : a === 10 ? r = e.toFixed(10).substr(0, 12) : r = Ys(e), g0($s(r.toUpperCase()));
}
function _a(e, a) {
  switch (typeof e) {
    case "string":
      return e;
    case "boolean":
      return e ? "TRUE" : "FALSE";
    case "number":
      return (e | 0) === e ? e.toString(10) : at(e);
    case "undefined":
      return "";
    case "object":
      if (e == null) return "";
      if (e instanceof Date) return Fr(14, ar(e, a && a.date1904), a);
  }
  throw new Error("unsupported value in General format: " + e);
}
function js(e, a) {
  a[0] -= 581;
  var r = e.getDay();
  return e < 60 && (r = (r + 6) % 7), r;
}
function Js(e, a, r, t) {
  var n = "", i = 0, f = 0, s = r.y, c, o = 0;
  switch (e) {
    case 98:
      s = r.y + 543;
    /* falls through */
    case 121:
      switch (a.length) {
        case 1:
        case 2:
          c = s % 100, o = 2;
          break;
        default:
          c = s % 1e4, o = 4;
          break;
      }
      break;
    case 109:
      switch (a.length) {
        case 1:
        case 2:
          c = r.m, o = a.length;
          break;
        case 3:
          return Jt[r.m - 1][1];
        case 5:
          return Jt[r.m - 1][0];
        default:
          return Jt[r.m - 1][2];
      }
      break;
    case 100:
      switch (a.length) {
        case 1:
        case 2:
          c = r.d, o = a.length;
          break;
        case 3:
          return z0[r.q][0];
        default:
          return z0[r.q][1];
      }
      break;
    case 104:
      switch (a.length) {
        case 1:
        case 2:
          c = 1 + (r.H + 11) % 12, o = a.length;
          break;
        default:
          throw "bad hour format: " + a;
      }
      break;
    case 72:
      switch (a.length) {
        case 1:
        case 2:
          c = r.H, o = a.length;
          break;
        default:
          throw "bad hour format: " + a;
      }
      break;
    case 77:
      switch (a.length) {
        case 1:
        case 2:
          c = r.M, o = a.length;
          break;
        default:
          throw "bad minute format: " + a;
      }
      break;
    case 115:
      if (a != "s" && a != "ss" && a != ".0" && a != ".00" && a != ".000") throw "bad second format: " + a;
      return r.u === 0 && (a == "s" || a == "ss") ? Gr(r.S, a.length) : (t >= 2 ? f = t === 3 ? 1e3 : 100 : f = t === 1 ? 10 : 1, i = Math.round(f * (r.S + r.u)), i >= 60 * f && (i = 0), a === "s" ? i === 0 ? "0" : "" + i / f : (n = Gr(i, 2 + t), a === "ss" ? n.substr(0, 2) : "." + n.substr(2, a.length - 1)));
    case 90:
      switch (a) {
        case "[h]":
        case "[hh]":
          c = r.D * 24 + r.H;
          break;
        case "[m]":
        case "[mm]":
          c = (r.D * 24 + r.H) * 60 + r.M;
          break;
        case "[s]":
        case "[ss]":
          c = ((r.D * 24 + r.H) * 60 + r.M) * 60 + (t == 0 ? Math.round(r.S + r.u) : r.S);
          break;
        default:
          throw "bad abstime format: " + a;
      }
      o = a.length === 3 ? 1 : 2;
      break;
    case 101:
      c = s, o = 1;
      break;
  }
  var l = o > 0 ? Gr(c, o) : "";
  return l;
}
function Jr(e) {
  var a = 3;
  if (e.length <= a) return e;
  for (var r = e.length % a, t = e.substr(0, r); r != e.length; r += a) t += (t.length > 0 ? "," : "") + e.substr(r, a);
  return t;
}
var zn = /%/g;
function Zs(e, a, r) {
  var t = a.replace(zn, ""), n = a.length - t.length;
  return qr(e, t, r * Math.pow(10, 2 * n)) + Ie("%", n);
}
function qs(e, a, r) {
  for (var t = a.length - 1; a.charCodeAt(t - 1) === 44; ) --t;
  return qr(e, a.substr(0, t), r / Math.pow(10, 3 * (a.length - t)));
}
function $n(e, a) {
  var r, t = e.indexOf("E") - e.indexOf(".") - 1;
  if (e.match(/^#+0.0E\+0$/)) {
    if (a == 0) return "0.0E+0";
    if (a < 0) return "-" + $n(e, -a);
    var n = e.indexOf(".");
    n === -1 && (n = e.indexOf("E"));
    var i = Math.floor(Math.log(a) * Math.LOG10E) % n;
    if (i < 0 && (i += n), r = (a / Math.pow(10, i)).toPrecision(t + 1 + (n + i) % n), r.indexOf("e") === -1) {
      var f = Math.floor(Math.log(a) * Math.LOG10E);
      for (r.indexOf(".") === -1 ? r = r.charAt(0) + "." + r.substr(1) + "E+" + (f - r.length + i) : r += "E+" + (f - i); r.substr(0, 2) === "0."; )
        r = r.charAt(0) + r.substr(2, n) + "." + r.substr(2 + n), r = r.replace(/^0+([1-9])/, "$1").replace(/^0+\./, "0.");
      r = r.replace(/\+-/, "-");
    }
    r = r.replace(/^([+-]?)(\d*)\.(\d*)[Ee]/, function(s, c, o, l) {
      return c + o + l.substr(0, (n + i) % n) + "." + l.substr(i) + "E";
    });
  } else r = a.toExponential(t);
  return e.match(/E\+00$/) && r.match(/e[+-]\d$/) && (r = r.substr(0, r.length - 1) + "0" + r.charAt(r.length - 1)), e.match(/E\-/) && r.match(/e\+/) && (r = r.replace(/e\+/, "e")), r.replace("e", "E");
}
var Kn = /# (\?+)( ?)\/( ?)(\d+)/;
function Qs(e, a, r) {
  var t = parseInt(e[4], 10), n = Math.round(a * t), i = Math.floor(n / t), f = n - i * t, s = t;
  return r + (i === 0 ? "" : "" + i) + " " + (f === 0 ? Ie(" ", e[1].length + 1 + e[4].length) : p0(f, e[1].length) + e[2] + "/" + e[3] + Gr(s, e[4].length));
}
function ef(e, a, r) {
  return r + (a === 0 ? "" : "" + a) + Ie(" ", e[1].length + 2 + e[4].length);
}
var Yn = /^#*0*\.([0#]+)/, jn = /\)[^)]*[0#]/, Jn = /\(###\) ###\\?-####/;
function mr(e) {
  for (var a = "", r, t = 0; t != e.length; ++t) switch (r = e.charCodeAt(t)) {
    case 35:
      break;
    case 63:
      a += " ";
      break;
    case 48:
      a += "0";
      break;
    default:
      a += String.fromCharCode(r);
  }
  return a;
}
function K0(e, a) {
  var r = Math.pow(10, a);
  return "" + Math.round(e * r) / r;
}
function Y0(e, a) {
  var r = e - Math.floor(e), t = Math.pow(10, a);
  return a < ("" + Math.round(r * t)).length ? 0 : Math.round(r * t);
}
function rf(e, a) {
  return a < ("" + Math.round((e - Math.floor(e)) * Math.pow(10, a))).length ? 1 : 0;
}
function af(e) {
  return e < 2147483647 && e > -2147483648 ? "" + (e >= 0 ? e | 0 : e - 1 | 0) : "" + Math.floor(e);
}
function Nr(e, a, r) {
  if (e.charCodeAt(0) === 40 && !a.match(jn)) {
    var t = a.replace(/\( */, "").replace(/ \)/, "").replace(/\)/, "");
    return r >= 0 ? Nr("n", t, r) : "(" + Nr("n", t, -r) + ")";
  }
  if (a.charCodeAt(a.length - 1) === 44) return qs(e, a, r);
  if (a.indexOf("%") !== -1) return Zs(e, a, r);
  if (a.indexOf("E") !== -1) return $n(a, r);
  if (a.charCodeAt(0) === 36) return "$" + Nr(e, a.substr(a.charAt(1) == " " ? 2 : 1), r);
  var n, i, f, s, c = Math.abs(r), o = r < 0 ? "-" : "";
  if (a.match(/^00+$/)) return o + Ca(c, a.length);
  if (a.match(/^[#?]+$/))
    return n = Ca(r, 0), n === "0" && (n = ""), n.length > a.length ? n : mr(a.substr(0, a.length - n.length)) + n;
  if (i = a.match(Kn)) return Qs(i, c, o);
  if (a.match(/^#+0+$/)) return o + Ca(c, a.length - a.indexOf("0"));
  if (i = a.match(Yn))
    return n = K0(r, i[1].length).replace(/^([^\.]+)$/, "$1." + mr(i[1])).replace(/\.$/, "." + mr(i[1])).replace(/\.(\d*)$/, function(p, _) {
      return "." + _ + Ie("0", mr(
        /*::(*/
        i[1]
      ).length - _.length);
    }), a.indexOf("0.") !== -1 ? n : n.replace(/^0\./, ".");
  if (a = a.replace(/^#+([0.])/, "$1"), i = a.match(/^(0*)\.(#*)$/))
    return o + K0(c, i[2].length).replace(/\.(\d*[1-9])0*$/, ".$1").replace(/^(-?\d*)$/, "$1.").replace(/^0\./, i[1].length ? "0." : ".");
  if (i = a.match(/^#{1,3},##0(\.?)$/)) return o + Jr(Ca(c, 0));
  if (i = a.match(/^#,##0\.([#0]*0)$/))
    return r < 0 ? "-" + Nr(e, a, -r) : Jr("" + (Math.floor(r) + rf(r, i[1].length))) + "." + Gr(Y0(r, i[1].length), i[1].length);
  if (i = a.match(/^#,#*,#0/)) return Nr(e, a.replace(/^#,#*,/, ""), r);
  if (i = a.match(/^([0#]+)(\\?-([0#]+))+$/))
    return n = Oa(Nr(e, a.replace(/[\\-]/g, ""), r)), f = 0, Oa(Oa(a.replace(/\\/g, "")).replace(/[0#]/g, function(p) {
      return f < n.length ? n.charAt(f++) : p === "0" ? "0" : "";
    }));
  if (a.match(Jn))
    return n = Nr(e, "##########", r), "(" + n.substr(0, 3) + ") " + n.substr(3, 3) + "-" + n.substr(6);
  var l = "";
  if (i = a.match(/^([#0?]+)( ?)\/( ?)([#0?]+)/))
    return f = Math.min(
      /*::String(*/
      i[4].length,
      7
    ), s = It(c, Math.pow(10, f) - 1, !1), n = "" + o, l = qr(
      "n",
      /*::String(*/
      i[1],
      s[1]
    ), l.charAt(l.length - 1) == " " && (l = l.substr(0, l.length - 1) + "0"), n += l + /*::String(*/
    i[2] + "/" + /*::String(*/
    i[3], l = yt(s[2], f), l.length < i[4].length && (l = mr(i[4].substr(i[4].length - l.length)) + l), n += l, n;
  if (i = a.match(/^# ([#0?]+)( ?)\/( ?)([#0?]+)/))
    return f = Math.min(Math.max(i[1].length, i[4].length), 7), s = It(c, Math.pow(10, f) - 1, !0), o + (s[0] || (s[1] ? "" : "0")) + " " + (s[1] ? p0(s[1], f) + i[2] + "/" + i[3] + yt(s[2], f) : Ie(" ", 2 * f + 1 + i[2].length + i[3].length));
  if (i = a.match(/^[#0?]+$/))
    return n = Ca(r, 0), a.length <= n.length ? n : mr(a.substr(0, a.length - n.length)) + n;
  if (i = a.match(/^([#0?]+)\.([#0]+)$/)) {
    n = "" + r.toFixed(Math.min(i[2].length, 10)).replace(/([^0])0+$/, "$1"), f = n.indexOf(".");
    var v = a.indexOf(".") - f, d = a.length - n.length - v;
    return mr(a.substr(0, v) + n + a.substr(a.length - d));
  }
  if (i = a.match(/^00,000\.([#0]*0)$/))
    return f = Y0(r, i[1].length), r < 0 ? "-" + Nr(e, a, -r) : Jr(af(r)).replace(/^\d,\d{3}$/, "0$&").replace(/^\d*$/, function(p) {
      return "00," + (p.length < 3 ? Gr(0, 3 - p.length) : "") + p;
    }) + "." + Gr(f, i[1].length);
  switch (a) {
    case "###,##0.00":
      return Nr(e, "#,##0.00", r);
    case "###,###":
    case "##,###":
    case "#,###":
      var u = Jr(Ca(c, 0));
      return u !== "0" ? o + u : "";
    case "###,###.00":
      return Nr(e, "###,##0.00", r).replace(/^0\./, ".");
    case "#,###.00":
      return Nr(e, "#,##0.00", r).replace(/^0\./, ".");
  }
  throw new Error("unsupported format |" + a + "|");
}
function tf(e, a, r) {
  for (var t = a.length - 1; a.charCodeAt(t - 1) === 44; ) --t;
  return qr(e, a.substr(0, t), r / Math.pow(10, 3 * (a.length - t)));
}
function nf(e, a, r) {
  var t = a.replace(zn, ""), n = a.length - t.length;
  return qr(e, t, r * Math.pow(10, 2 * n)) + Ie("%", n);
}
function Zn(e, a) {
  var r, t = e.indexOf("E") - e.indexOf(".") - 1;
  if (e.match(/^#+0.0E\+0$/)) {
    if (a == 0) return "0.0E+0";
    if (a < 0) return "-" + Zn(e, -a);
    var n = e.indexOf(".");
    n === -1 && (n = e.indexOf("E"));
    var i = Math.floor(Math.log(a) * Math.LOG10E) % n;
    if (i < 0 && (i += n), r = (a / Math.pow(10, i)).toPrecision(t + 1 + (n + i) % n), !r.match(/[Ee]/)) {
      var f = Math.floor(Math.log(a) * Math.LOG10E);
      r.indexOf(".") === -1 ? r = r.charAt(0) + "." + r.substr(1) + "E+" + (f - r.length + i) : r += "E+" + (f - i), r = r.replace(/\+-/, "-");
    }
    r = r.replace(/^([+-]?)(\d*)\.(\d*)[Ee]/, function(s, c, o, l) {
      return c + o + l.substr(0, (n + i) % n) + "." + l.substr(i) + "E";
    });
  } else r = a.toExponential(t);
  return e.match(/E\+00$/) && r.match(/e[+-]\d$/) && (r = r.substr(0, r.length - 1) + "0" + r.charAt(r.length - 1)), e.match(/E\-/) && r.match(/e\+/) && (r = r.replace(/e\+/, "e")), r.replace("e", "E");
}
function $r(e, a, r) {
  if (e.charCodeAt(0) === 40 && !a.match(jn)) {
    var t = a.replace(/\( */, "").replace(/ \)/, "").replace(/\)/, "");
    return r >= 0 ? $r("n", t, r) : "(" + $r("n", t, -r) + ")";
  }
  if (a.charCodeAt(a.length - 1) === 44) return tf(e, a, r);
  if (a.indexOf("%") !== -1) return nf(e, a, r);
  if (a.indexOf("E") !== -1) return Zn(a, r);
  if (a.charCodeAt(0) === 36) return "$" + $r(e, a.substr(a.charAt(1) == " " ? 2 : 1), r);
  var n, i, f, s, c = Math.abs(r), o = r < 0 ? "-" : "";
  if (a.match(/^00+$/)) return o + Gr(c, a.length);
  if (a.match(/^[#?]+$/))
    return n = "" + r, r === 0 && (n = ""), n.length > a.length ? n : mr(a.substr(0, a.length - n.length)) + n;
  if (i = a.match(Kn)) return ef(i, c, o);
  if (a.match(/^#+0+$/)) return o + Gr(c, a.length - a.indexOf("0"));
  if (i = a.match(Yn))
    return n = ("" + r).replace(/^([^\.]+)$/, "$1." + mr(i[1])).replace(/\.$/, "." + mr(i[1])), n = n.replace(/\.(\d*)$/, function(p, _) {
      return "." + _ + Ie("0", mr(i[1]).length - _.length);
    }), a.indexOf("0.") !== -1 ? n : n.replace(/^0\./, ".");
  if (a = a.replace(/^#+([0.])/, "$1"), i = a.match(/^(0*)\.(#*)$/))
    return o + ("" + c).replace(/\.(\d*[1-9])0*$/, ".$1").replace(/^(-?\d*)$/, "$1.").replace(/^0\./, i[1].length ? "0." : ".");
  if (i = a.match(/^#{1,3},##0(\.?)$/)) return o + Jr("" + c);
  if (i = a.match(/^#,##0\.([#0]*0)$/))
    return r < 0 ? "-" + $r(e, a, -r) : Jr("" + r) + "." + Ie("0", i[1].length);
  if (i = a.match(/^#,#*,#0/)) return $r(e, a.replace(/^#,#*,/, ""), r);
  if (i = a.match(/^([0#]+)(\\?-([0#]+))+$/))
    return n = Oa($r(e, a.replace(/[\\-]/g, ""), r)), f = 0, Oa(Oa(a.replace(/\\/g, "")).replace(/[0#]/g, function(p) {
      return f < n.length ? n.charAt(f++) : p === "0" ? "0" : "";
    }));
  if (a.match(Jn))
    return n = $r(e, "##########", r), "(" + n.substr(0, 3) + ") " + n.substr(3, 3) + "-" + n.substr(6);
  var l = "";
  if (i = a.match(/^([#0?]+)( ?)\/( ?)([#0?]+)/))
    return f = Math.min(
      /*::String(*/
      i[4].length,
      7
    ), s = It(c, Math.pow(10, f) - 1, !1), n = "" + o, l = qr(
      "n",
      /*::String(*/
      i[1],
      s[1]
    ), l.charAt(l.length - 1) == " " && (l = l.substr(0, l.length - 1) + "0"), n += l + /*::String(*/
    i[2] + "/" + /*::String(*/
    i[3], l = yt(s[2], f), l.length < i[4].length && (l = mr(i[4].substr(i[4].length - l.length)) + l), n += l, n;
  if (i = a.match(/^# ([#0?]+)( ?)\/( ?)([#0?]+)/))
    return f = Math.min(Math.max(i[1].length, i[4].length), 7), s = It(c, Math.pow(10, f) - 1, !0), o + (s[0] || (s[1] ? "" : "0")) + " " + (s[1] ? p0(s[1], f) + i[2] + "/" + i[3] + yt(s[2], f) : Ie(" ", 2 * f + 1 + i[2].length + i[3].length));
  if (i = a.match(/^[#0?]+$/))
    return n = "" + r, a.length <= n.length ? n : mr(a.substr(0, a.length - n.length)) + n;
  if (i = a.match(/^([#0]+)\.([#0]+)$/)) {
    n = "" + r.toFixed(Math.min(i[2].length, 10)).replace(/([^0])0+$/, "$1"), f = n.indexOf(".");
    var v = a.indexOf(".") - f, d = a.length - n.length - v;
    return mr(a.substr(0, v) + n + a.substr(a.length - d));
  }
  if (i = a.match(/^00,000\.([#0]*0)$/))
    return r < 0 ? "-" + $r(e, a, -r) : Jr("" + r).replace(/^\d,\d{3}$/, "0$&").replace(/^\d*$/, function(p) {
      return "00," + (p.length < 3 ? Gr(0, 3 - p.length) : "") + p;
    }) + "." + Gr(0, i[1].length);
  switch (a) {
    case "###,###":
    case "##,###":
    case "#,###":
      var u = Jr("" + c);
      return u !== "0" ? o + u : "";
    default:
      if (a.match(/\.[0#?]*$/)) return $r(e, a.slice(0, a.lastIndexOf(".")), r) + mr(a.slice(a.lastIndexOf(".")));
  }
  throw new Error("unsupported format |" + a + "|");
}
function qr(e, a, r) {
  return (r | 0) === r ? $r(e, a, r) : Nr(e, a, r);
}
function sf(e) {
  for (var a = [], r = !1, t = 0, n = 0; t < e.length; ++t) switch (
    /*cc=*/
    e.charCodeAt(t)
  ) {
    case 34:
      r = !r;
      break;
    case 95:
    case 42:
    case 92:
      ++t;
      break;
    case 59:
      a[a.length] = e.substr(n, t - n), n = t + 1;
  }
  if (a[a.length] = e.substr(n), r === !0) throw new Error("Format |" + e + "| unterminated string ");
  return a;
}
var qn = /\[[HhMmSs\u0E0A\u0E19\u0E17]*\]/;
function Br(e) {
  for (var a = 0, r = "", t = ""; a < e.length; )
    switch (r = e.charAt(a)) {
      case "G":
        Dt(e, a) && (a += 6), a++;
        break;
      case '"':
        for (
          ;
          /*cc=*/
          e.charCodeAt(++a) !== 34 && a < e.length;
        )
          ;
        ++a;
        break;
      case "\\":
        a += 2;
        break;
      case "_":
        a += 2;
        break;
      case "@":
        ++a;
        break;
      case "B":
      case "b":
        if (e.charAt(a + 1) === "1" || e.charAt(a + 1) === "2") return !0;
      /* falls through */
      case "M":
      case "D":
      case "Y":
      case "H":
      case "S":
      case "E":
      /* falls through */
      case "m":
      case "d":
      case "y":
      case "h":
      case "s":
      case "e":
      case "g":
        return !0;
      case "A":
      case "a":
      case "上":
        if (e.substr(a, 3).toUpperCase() === "A/P" || e.substr(a, 5).toUpperCase() === "AM/PM" || e.substr(a, 5).toUpperCase() === "上午/下午") return !0;
        ++a;
        break;
      case "[":
        for (t = r; e.charAt(a++) !== "]" && a < e.length; ) t += e.charAt(a);
        if (t.match(qn)) return !0;
        break;
      case ".":
      /* falls through */
      case "0":
      case "#":
        for (; a < e.length && ("0#?.,E+-%".indexOf(r = e.charAt(++a)) > -1 || r == "\\" && e.charAt(a + 1) == "-" && "0#".indexOf(e.charAt(a + 2)) > -1); )
          ;
        break;
      case "?":
        for (; e.charAt(++a) === r; )
          ;
        break;
      case "*":
        ++a, (e.charAt(a) == " " || e.charAt(a) == "*") && ++a;
        break;
      case "(":
      case ")":
        ++a;
        break;
      case "1":
      case "2":
      case "3":
      case "4":
      case "5":
      case "6":
      case "7":
      case "8":
      case "9":
        for (; a < e.length && "0123456789".indexOf(e.charAt(++a)) > -1; )
          ;
        break;
      case " ":
        ++a;
        break;
      default:
        ++a;
        break;
    }
  return !1;
}
function ff(e, a, r, t) {
  for (var n = [], i = "", f = 0, s = "", c = "t", o, l, v, d = "H"; f < e.length; )
    switch (s = e.charAt(f)) {
      case "G":
        if (!Dt(e, f)) throw new Error("unrecognized character " + s + " in " + e);
        n[n.length] = { t: "G", v: "General" }, f += 7;
        break;
      case '"':
        for (i = ""; (v = e.charCodeAt(++f)) !== 34 && f < e.length; ) i += String.fromCharCode(v);
        n[n.length] = { t: "t", v: i }, ++f;
        break;
      case "\\":
        var u = e.charAt(++f), p = u === "(" || u === ")" ? u : "t";
        n[n.length] = { t: p, v: u }, ++f;
        break;
      case "_":
        n[n.length] = { t: "t", v: " " }, f += 2;
        break;
      case "@":
        n[n.length] = { t: "T", v: a }, ++f;
        break;
      case "B":
      case "b":
        if (e.charAt(f + 1) === "1" || e.charAt(f + 1) === "2") {
          if (o == null && (o = Kr(a, r, e.charAt(f + 1) === "2"), o == null))
            return "";
          n[n.length] = { t: "X", v: e.substr(f, 2) }, c = s, f += 2;
          break;
        }
      /* falls through */
      case "M":
      case "D":
      case "Y":
      case "H":
      case "S":
      case "E":
        s = s.toLowerCase();
      /* falls through */
      case "m":
      case "d":
      case "y":
      case "h":
      case "s":
      case "e":
      case "g":
        if (a < 0 || o == null && (o = Kr(a, r), o == null))
          return "";
        for (i = s; ++f < e.length && e.charAt(f).toLowerCase() === s; ) i += s;
        s === "m" && c.toLowerCase() === "h" && (s = "M"), s === "h" && (s = d), n[n.length] = { t: s, v: i }, c = s;
        break;
      case "A":
      case "a":
      case "上":
        var _ = { t: s, v: s };
        if (o == null && (o = Kr(a, r)), e.substr(f, 3).toUpperCase() === "A/P" ? (o != null && (_.v = o.H >= 12 ? e.charAt(f + 2) : s), _.t = "T", d = "h", f += 3) : e.substr(f, 5).toUpperCase() === "AM/PM" ? (o != null && (_.v = o.H >= 12 ? "PM" : "AM"), _.t = "T", f += 5, d = "h") : e.substr(f, 5).toUpperCase() === "上午/下午" ? (o != null && (_.v = o.H >= 12 ? "下午" : "上午"), _.t = "T", f += 5, d = "h") : (_.t = "t", ++f), o == null && _.t === "T") return "";
        n[n.length] = _, c = s;
        break;
      case "[":
        for (i = s; e.charAt(f++) !== "]" && f < e.length; ) i += e.charAt(f);
        if (i.slice(-1) !== "]") throw 'unterminated "[" block: |' + i + "|";
        if (i.match(qn)) {
          if (o == null && (o = Kr(a, r), o == null))
            return "";
          n[n.length] = { t: "Z", v: i.toLowerCase() }, c = i.charAt(1);
        } else i.indexOf("$") > -1 && (i = (i.match(/\$([^-\[\]]*)/) || [])[1] || "$", Br(e) || (n[n.length] = { t: "t", v: i }));
        break;
      /* Numbers */
      case ".":
        if (o != null) {
          for (i = s; ++f < e.length && (s = e.charAt(f)) === "0"; ) i += s;
          n[n.length] = { t: "s", v: i };
          break;
        }
      /* falls through */
      case "0":
      case "#":
        for (i = s; ++f < e.length && "0#?.,E+-%".indexOf(s = e.charAt(f)) > -1; ) i += s;
        n[n.length] = { t: "n", v: i };
        break;
      case "?":
        for (i = s; e.charAt(++f) === s; ) i += s;
        n[n.length] = { t: s, v: i }, c = s;
        break;
      case "*":
        ++f, (e.charAt(f) == " " || e.charAt(f) == "*") && ++f;
        break;
      // **
      case "(":
      case ")":
        n[n.length] = { t: t === 1 ? "t" : s, v: s }, ++f;
        break;
      case "1":
      case "2":
      case "3":
      case "4":
      case "5":
      case "6":
      case "7":
      case "8":
      case "9":
        for (i = s; f < e.length && "0123456789".indexOf(e.charAt(++f)) > -1; ) i += e.charAt(f);
        n[n.length] = { t: "D", v: i };
        break;
      case " ":
        n[n.length] = { t: s, v: s }, ++f;
        break;
      case "$":
        n[n.length] = { t: "t", v: "$" }, ++f;
        break;
      default:
        if (",$-+/():!^&'~{}<>=€acfijklopqrtuvwxzP".indexOf(s) === -1) throw new Error("unrecognized character " + s + " in " + e);
        n[n.length] = { t: "t", v: s }, ++f;
        break;
    }
  var x = 0, h = 0, E;
  for (f = n.length - 1, c = "t"; f >= 0; --f)
    switch (n[f].t) {
      case "h":
      case "H":
        n[f].t = d, c = "h", x < 1 && (x = 1);
        break;
      case "s":
        (E = n[f].v.match(/\.0+$/)) && (h = Math.max(h, E[0].length - 1), x = 4), x < 3 && (x = 3);
      /* falls through */
      case "d":
      case "y":
      case "e":
        c = n[f].t;
        break;
      case "M":
        c = n[f].t, x < 2 && (x = 2);
        break;
      case "m":
        c === "s" && (n[f].t = "M", x < 2 && (x = 2));
        break;
      case "X":
        break;
      case "Z":
        x < 1 && n[f].v.match(/[Hh]/) && (x = 1), x < 2 && n[f].v.match(/[Mm]/) && (x = 2), x < 3 && n[f].v.match(/[Ss]/) && (x = 3);
    }
  var g;
  switch (x) {
    case 0:
      break;
    case 1:
    case 2:
    case 3:
      o.u >= 0.5 && (o.u = 0, ++o.S), o.S >= 60 && (o.S = 0, ++o.M), o.M >= 60 && (o.M = 0, ++o.H), o.H >= 24 && (o.H = 0, ++o.D, g = Kr(o.D), g.u = o.u, g.S = o.S, g.M = o.M, g.H = o.H, o = g);
      break;
    case 4:
      switch (h) {
        case 1:
          o.u = Math.round(o.u * 10) / 10;
          break;
        case 2:
          o.u = Math.round(o.u * 100) / 100;
          break;
        case 3:
          o.u = Math.round(o.u * 1e3) / 1e3;
          break;
      }
      o.u >= 1 && (o.u = 0, ++o.S), o.S >= 60 && (o.S = 0, ++o.M), o.M >= 60 && (o.M = 0, ++o.H), o.H >= 24 && (o.H = 0, ++o.D, g = Kr(o.D), g.u = o.u, g.S = o.S, g.M = o.M, g.H = o.H, o = g);
      break;
  }
  var y = "", P;
  for (f = 0; f < n.length; ++f)
    switch (n[f].t) {
      case "t":
      case "T":
      case " ":
      case "D":
        break;
      case "X":
        n[f].v = "", n[f].t = ";";
        break;
      case "d":
      case "m":
      case "y":
      case "h":
      case "H":
      case "M":
      case "s":
      case "e":
      case "b":
      case "Z":
        n[f].v = Js(n[f].t.charCodeAt(0), n[f].v, o, h), n[f].t = "t";
        break;
      case "n":
      case "?":
        for (P = f + 1; n[P] != null && ((s = n[P].t) === "?" || s === "D" || (s === " " || s === "t") && n[P + 1] != null && (n[P + 1].t === "?" || n[P + 1].t === "t" && n[P + 1].v === "/") || n[f].t === "(" && (s === " " || s === "n" || s === ")") || s === "t" && (n[P].v === "/" || n[P].v === " " && n[P + 1] != null && n[P + 1].t == "?")); )
          n[f].v += n[P].v, n[P] = { v: "", t: ";" }, ++P;
        y += n[f].v, f = P - 1;
        break;
      case "G":
        n[f].t = "t", n[f].v = _a(a, r);
        break;
    }
  var M = "", I, N;
  if (y.length > 0) {
    y.charCodeAt(0) == 40 ? (I = a < 0 && y.charCodeAt(0) === 45 ? -a : a, N = qr("n", y, I)) : (I = a < 0 && t > 1 ? -a : a, N = qr("n", y, I), I < 0 && n[0] && n[0].t == "t" && (N = N.substr(1), n[0].v = "-" + n[0].v)), P = N.length - 1;
    var O = n.length;
    for (f = 0; f < n.length; ++f) if (n[f] != null && n[f].t != "t" && n[f].v.indexOf(".") > -1) {
      O = f;
      break;
    }
    var B = n.length;
    if (O === n.length && N.indexOf("E") === -1) {
      for (f = n.length - 1; f >= 0; --f)
        n[f] == null || "n?".indexOf(n[f].t) === -1 || (P >= n[f].v.length - 1 ? (P -= n[f].v.length, n[f].v = N.substr(P + 1, n[f].v.length)) : P < 0 ? n[f].v = "" : (n[f].v = N.substr(0, P + 1), P = -1), n[f].t = "t", B = f);
      P >= 0 && B < n.length && (n[B].v = N.substr(0, P + 1) + n[B].v);
    } else if (O !== n.length && N.indexOf("E") === -1) {
      for (P = N.indexOf(".") - 1, f = O; f >= 0; --f)
        if (!(n[f] == null || "n?".indexOf(n[f].t) === -1)) {
          for (l = n[f].v.indexOf(".") > -1 && f === O ? n[f].v.indexOf(".") - 1 : n[f].v.length - 1, M = n[f].v.substr(l + 1); l >= 0; --l)
            P >= 0 && (n[f].v.charAt(l) === "0" || n[f].v.charAt(l) === "#") && (M = N.charAt(P--) + M);
          n[f].v = M, n[f].t = "t", B = f;
        }
      for (P >= 0 && B < n.length && (n[B].v = N.substr(0, P + 1) + n[B].v), P = N.indexOf(".") + 1, f = O; f < n.length; ++f)
        if (!(n[f] == null || "n?(".indexOf(n[f].t) === -1 && f !== O)) {
          for (l = n[f].v.indexOf(".") > -1 && f === O ? n[f].v.indexOf(".") + 1 : 0, M = n[f].v.substr(0, l); l < n[f].v.length; ++l)
            P < N.length && (M += N.charAt(P++));
          n[f].v = M, n[f].t = "t", B = f;
        }
    }
  }
  for (f = 0; f < n.length; ++f) n[f] != null && "n?".indexOf(n[f].t) > -1 && (I = t > 1 && a < 0 && f > 0 && n[f - 1].v === "-" ? -a : a, n[f].v = qr(n[f].t, n[f].v, I), n[f].t = "t");
  var b = "";
  for (f = 0; f !== n.length; ++f) n[f] != null && (b += n[f].v);
  return b;
}
var j0 = /\[(=|>[=]?|<[>=]?)(-?\d+(?:\.\d*)?)\]/;
function J0(e, a) {
  if (a == null) return !1;
  var r = parseFloat(a[2]);
  switch (a[1]) {
    case "=":
      if (e == r) return !0;
      break;
    case ">":
      if (e > r) return !0;
      break;
    case "<":
      if (e < r) return !0;
      break;
    case "<>":
      if (e != r) return !0;
      break;
    case ">=":
      if (e >= r) return !0;
      break;
    case "<=":
      if (e <= r) return !0;
      break;
  }
  return !1;
}
function cf(e, a) {
  var r = sf(e), t = r.length, n = r[t - 1].indexOf("@");
  if (t < 4 && n > -1 && --t, r.length > 4) throw new Error("cannot find right format for |" + r.join("|") + "|");
  if (typeof a != "number") return [4, r.length === 4 || n > -1 ? r[r.length - 1] : "@"];
  switch (typeof a == "number" && !isFinite(a) && (a = 0), r.length) {
    case 1:
      r = n > -1 ? ["General", "General", "General", r[0]] : [r[0], r[0], r[0], "@"];
      break;
    case 2:
      r = n > -1 ? [r[0], r[0], r[0], r[1]] : [r[0], r[1], r[0], "@"];
      break;
    case 3:
      r = n > -1 ? [r[0], r[1], r[0], r[2]] : [r[0], r[1], r[2], "@"];
      break;
  }
  var i = a > 0 ? r[0] : a < 0 ? r[1] : r[2];
  if (r[0].indexOf("[") === -1 && r[1].indexOf("[") === -1) return [t, i];
  if (r[0].match(/\[[=<>]/) != null || r[1].match(/\[[=<>]/) != null) {
    var f = r[0].match(j0), s = r[1].match(j0);
    return J0(a, f) ? [t, r[0]] : J0(a, s) ? [t, r[1]] : [t, r[f != null && s != null ? 2 : 1]];
  }
  return [t, i];
}
function Fr(e, a, r) {
  r == null && (r = {});
  var t = "";
  switch (typeof e) {
    case "string":
      e == "m/d/yy" && r.dateNF ? t = r.dateNF : t = e;
      break;
    case "number":
      e == 14 && r.dateNF ? t = r.dateNF : t = (r.table != null ? r.table : ge)[e], t == null && (t = r.table && r.table[$0[e]] || ge[$0[e]]), t == null && (t = Xs[e] || "General");
      break;
  }
  if (Dt(t, 0)) return _a(a, r);
  a instanceof Date && (a = ar(a, r.date1904));
  var n = cf(t, a);
  if (Dt(n[1])) return _a(a, r);
  if (a === !0) a = "TRUE";
  else if (a === !1) a = "FALSE";
  else {
    if (a === "" || a == null) return "";
    if (isNaN(a) && n[1].indexOf("0") > -1) return "#NUM!";
    if (!isFinite(a) && n[1].indexOf("0") > -1) return "#DIV/0!";
  }
  return ff(n[1], a, r, n[0]);
}
function m0(e, a) {
  if (typeof a != "number") {
    a = +a || -1;
    for (var r = 0; r < 392; ++r) {
      if (ge[r] == null) {
        a < 0 && (a = r);
        continue;
      }
      if (ge[r] == e) {
        a = r;
        break;
      }
    }
    a < 0 && (a = 391);
  }
  return ge[a] = e, a;
}
function of(e) {
  for (var a = 0; a != 392; ++a)
    e[a] !== void 0 && m0(e[a], a);
}
function Qn() {
  ge = Gs();
}
var lf = {
  format: Fr,
  load: m0,
  _table: ge,
  load_table: of,
  parse_date_code: Kr,
  is_date: Br,
  get_table: function() {
    return lf._table = ge;
  }
}, uf = {
  5: '"$"#,##0_);\\("$"#,##0\\)',
  6: '"$"#,##0_);[Red]\\("$"#,##0\\)',
  7: '"$"#,##0.00_);\\("$"#,##0.00\\)',
  8: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
  23: "General",
  24: "General",
  25: "General",
  26: "General",
  27: "m/d/yy",
  28: "m/d/yy",
  29: "m/d/yy",
  30: "m/d/yy",
  31: "m/d/yy",
  32: "h:mm:ss",
  33: "h:mm:ss",
  34: "h:mm:ss",
  35: "h:mm:ss",
  36: "m/d/yy",
  41: '_(* #,##0_);_(* (#,##0);_(* "-"_);_(@_)',
  42: '_("$"* #,##0_);_("$"* (#,##0);_("$"* "-"_);_(@_)',
  43: '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)',
  44: '_("$"* #,##0.00_);_("$"* (#,##0.00);_("$"* "-"??_);_(@_)',
  50: "m/d/yy",
  51: "m/d/yy",
  52: "m/d/yy",
  53: "m/d/yy",
  54: "m/d/yy",
  55: "m/d/yy",
  56: "m/d/yy",
  57: "m/d/yy",
  58: "m/d/yy",
  59: "0",
  60: "0.00",
  61: "#,##0",
  62: "#,##0.00",
  63: '"$"#,##0_);\\("$"#,##0\\)',
  64: '"$"#,##0_);[Red]\\("$"#,##0\\)',
  65: '"$"#,##0.00_);\\("$"#,##0.00\\)',
  66: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
  67: "0%",
  68: "0.00%",
  69: "# ?/?",
  70: "# ??/??",
  71: "m/d/yy",
  72: "m/d/yy",
  73: "d-mmm-yy",
  74: "d-mmm",
  75: "mmm-yy",
  76: "h:mm",
  77: "h:mm:ss",
  78: "m/d/yy h:mm",
  79: "mm:ss",
  80: "[h]:mm:ss",
  81: "mmss.0"
}, Ot = /[dD]+|[mM]+|[yYeE]+|[Hh]+|[Ss]+/g;
function hf(e) {
  var a = typeof e == "number" ? ge[e] : e;
  return a = a.replace(Ot, "(\\d+)"), Ot.lastIndex = 0, new RegExp("^" + a + "$");
}
function xf(e, a, r) {
  var t = -1, n = -1, i = -1, f = -1, s = -1, c = -1;
  (a.match(Ot) || []).forEach(function(v, d) {
    var u = parseInt(r[d + 1], 10);
    switch (v.toLowerCase().charAt(0)) {
      case "y":
        t = u;
        break;
      case "d":
        i = u;
        break;
      case "h":
        f = u;
        break;
      case "s":
        c = u;
        break;
      case "m":
        f >= 0 ? s = u : n = u;
        break;
    }
  }), Ot.lastIndex = 0, c >= 0 && s == -1 && n >= 0 && (s = n, n = -1);
  var o = ("" + (t >= 0 ? t : (/* @__PURE__ */ new Date()).getFullYear())).slice(-4) + "-" + ("00" + (n >= 1 ? n : 1)).slice(-2) + "-" + ("00" + (i >= 1 ? i : 1)).slice(-2);
  o.length == 7 && (o = "0" + o), o.length == 8 && (o = "20" + o);
  var l = ("00" + (f >= 0 ? f : 0)).slice(-2) + ":" + ("00" + (s >= 0 ? s : 0)).slice(-2) + ":" + ("00" + (c >= 0 ? c : 0)).slice(-2);
  return f == -1 && s == -1 && c == -1 ? o : t == -1 && n == -1 && i == -1 ? l : o + "T" + l;
}
var df = {
  "d.m": "d\\.m"
  // Issue #2571 Google Sheets writes invalid format 'd.m', correct format is 'd"."m' or 'd\\.m'
};
function va(e, a) {
  return m0(df[e] || e, a);
}
var Z0 = /* @__PURE__ */ (function() {
  var e = {};
  e.version = "1.2.0";
  function a() {
    for (var I = 0, N = new Array(256), O = 0; O != 256; ++O)
      I = O, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, I = I & 1 ? -306674912 ^ I >>> 1 : I >>> 1, N[O] = I;
    return typeof Int32Array < "u" ? new Int32Array(N) : N;
  }
  var r = a();
  function t(I) {
    var N = 0, O = 0, B = 0, b = typeof Int32Array < "u" ? new Int32Array(4096) : new Array(4096);
    for (B = 0; B != 256; ++B) b[B] = I[B];
    for (B = 0; B != 256; ++B)
      for (O = I[B], N = 256 + B; N < 4096; N += 256) O = b[N] = O >>> 8 ^ I[O & 255];
    var G = [];
    for (B = 1; B != 16; ++B) G[B - 1] = typeof Int32Array < "u" && typeof b.subarray == "function" ? b.subarray(B * 256, B * 256 + 256) : b.slice(B * 256, B * 256 + 256);
    return G;
  }
  var n = t(r), i = n[0], f = n[1], s = n[2], c = n[3], o = n[4], l = n[5], v = n[6], d = n[7], u = n[8], p = n[9], _ = n[10], x = n[11], h = n[12], E = n[13], g = n[14];
  function y(I, N) {
    for (var O = N ^ -1, B = 0, b = I.length; B < b; ) O = O >>> 8 ^ r[(O ^ I.charCodeAt(B++)) & 255];
    return ~O;
  }
  function P(I, N) {
    for (var O = N ^ -1, B = I.length - 15, b = 0; b < B; ) O = g[I[b++] ^ O & 255] ^ E[I[b++] ^ O >> 8 & 255] ^ h[I[b++] ^ O >> 16 & 255] ^ x[I[b++] ^ O >>> 24] ^ _[I[b++]] ^ p[I[b++]] ^ u[I[b++]] ^ d[I[b++]] ^ v[I[b++]] ^ l[I[b++]] ^ o[I[b++]] ^ c[I[b++]] ^ s[I[b++]] ^ f[I[b++]] ^ i[I[b++]] ^ r[I[b++]];
    for (B += 15; b < B; ) O = O >>> 8 ^ r[(O ^ I[b++]) & 255];
    return ~O;
  }
  function M(I, N) {
    for (var O = N ^ -1, B = 0, b = I.length, G = 0, z = 0; B < b; )
      G = I.charCodeAt(B++), G < 128 ? O = O >>> 8 ^ r[(O ^ G) & 255] : G < 2048 ? (O = O >>> 8 ^ r[(O ^ (192 | G >> 6 & 31)) & 255], O = O >>> 8 ^ r[(O ^ (128 | G & 63)) & 255]) : G >= 55296 && G < 57344 ? (G = (G & 1023) + 64, z = I.charCodeAt(B++) & 1023, O = O >>> 8 ^ r[(O ^ (240 | G >> 8 & 7)) & 255], O = O >>> 8 ^ r[(O ^ (128 | G >> 2 & 63)) & 255], O = O >>> 8 ^ r[(O ^ (128 | z >> 6 & 15 | (G & 3) << 4)) & 255], O = O >>> 8 ^ r[(O ^ (128 | z & 63)) & 255]) : (O = O >>> 8 ^ r[(O ^ (224 | G >> 12 & 15)) & 255], O = O >>> 8 ^ r[(O ^ (128 | G >> 6 & 63)) & 255], O = O >>> 8 ^ r[(O ^ (128 | G & 63)) & 255]);
    return ~O;
  }
  return e.table = r, e.bstr = y, e.buf = P, e.str = M, e;
})(), Oe = /* @__PURE__ */ (function() {
  var a = (
    /*::(*/
    {}
  );
  a.version = "1.2.2";
  function r(m, A) {
    for (var k = m.split("/"), T = A.split("/"), F = 0, C = 0, H = Math.min(k.length, T.length); F < H; ++F) {
      if (C = k[F].length - T[F].length) return C;
      if (k[F] != T[F]) return k[F] < T[F] ? -1 : 1;
    }
    return k.length - T.length;
  }
  function t(m) {
    if (m.charAt(m.length - 1) == "/") return m.slice(0, -1).indexOf("/") === -1 ? m : t(m.slice(0, -1));
    var A = m.lastIndexOf("/");
    return A === -1 ? m : m.slice(0, A + 1);
  }
  function n(m) {
    if (m.charAt(m.length - 1) == "/") return n(m.slice(0, -1));
    var A = m.lastIndexOf("/");
    return A === -1 ? m : m.slice(A + 1);
  }
  function i(m, A) {
    typeof A == "string" && (A = new Date(A));
    var k = A.getHours();
    k = k << 6 | A.getMinutes(), k = k << 5 | A.getSeconds() >>> 1, m.write_shift(2, k);
    var T = A.getFullYear() - 1980;
    T = T << 4 | A.getMonth() + 1, T = T << 5 | A.getDate(), m.write_shift(2, T);
  }
  function f(m) {
    var A = m.read_shift(2) & 65535, k = m.read_shift(2) & 65535, T = /* @__PURE__ */ new Date(), F = k & 31;
    k >>>= 5;
    var C = k & 15;
    k >>>= 4, T.setMilliseconds(0), T.setFullYear(k + 1980), T.setMonth(C - 1), T.setDate(F);
    var H = A & 31;
    A >>>= 5;
    var K = A & 63;
    return A >>>= 6, T.setHours(A), T.setMinutes(K), T.setSeconds(H << 1), T;
  }
  function s(m) {
    rr(m, 0);
    for (var A = (
      /*::(*/
      {}
    ), k = 0; m.l <= m.length - 4; ) {
      var T = m.read_shift(2), F = m.read_shift(2), C = m.l + F, H = {};
      switch (T) {
        /* UNIX-style Timestamps */
        case 21589:
          k = m.read_shift(1), k & 1 && (H.mtime = m.read_shift(4)), F > 5 && (k & 2 && (H.atime = m.read_shift(4)), k & 4 && (H.ctime = m.read_shift(4))), H.mtime && (H.mt = new Date(H.mtime * 1e3));
          break;
        /* ZIP64 Extended Information Field */
        case 1:
          {
            var K = m.read_shift(4), U = m.read_shift(4);
            H.usz = U * Math.pow(2, 32) + K, K = m.read_shift(4), U = m.read_shift(4), H.csz = U * Math.pow(2, 32) + K;
          }
          break;
      }
      m.l = C, A[T] = H;
    }
    return A;
  }
  var c;
  function o() {
    return c || (c = vf);
  }
  function l(m, A) {
    if (m[0] == 80 && m[1] == 75) return U0(m, A);
    if ((m[0] | 32) == 109 && (m[1] | 32) == 105) return Is(m, A);
    if (m.length < 512) throw new Error("CFB file size " + m.length + " < 512");
    var k = 3, T = 512, F = 0, C = 0, H = 0, K = 0, U = 0, W = [], V = (
      /*::(*/
      m.slice(0, 512)
    );
    rr(V, 0);
    var Z = v(V);
    switch (k = Z[0], k) {
      case 3:
        T = 512;
        break;
      case 4:
        T = 4096;
        break;
      case 0:
        if (Z[1] == 0) return U0(m, A);
      /* falls through */
      default:
        throw new Error("Major Version: Expected 3 or 4 saw " + k);
    }
    T !== 512 && (V = /*::(*/
    m.slice(0, T), rr(
      V,
      28
      /* blob.l */
    ));
    var ee = m.slice(0, T);
    d(V, k);
    var oe = V.read_shift(4, "i");
    if (k === 3 && oe !== 0) throw new Error("# Directory Sectors: Expected 0 saw " + oe);
    V.l += 4, H = V.read_shift(4, "i"), V.l += 4, V.chk("00100000", "Mini Stream Cutoff Size: "), K = V.read_shift(4, "i"), F = V.read_shift(4, "i"), U = V.read_shift(4, "i"), C = V.read_shift(4, "i");
    for (var q = -1, ae = 0; ae < 109 && (q = V.read_shift(4, "i"), !(q < 0)); ++ae)
      W[ae] = q;
    var we = u(m, T);
    x(U, C, we, T, W);
    var Ve = E(we, H, W, T);
    H < Ve.length && (Ve[H].name = "!Directory"), F > 0 && K !== z && (Ve[K].name = "!MiniFAT"), Ve[W[0]].name = "!FAT", Ve.fat_addrs = W, Ve.ssz = T;
    var Ge = {}, lr = [], Ba = [], Ma = [];
    g(H, Ve, we, lr, F, Ge, Ba, K), p(Ba, Ma, lr), lr.shift();
    var Ua = {
      FileIndex: Ba,
      FullPaths: Ma
    };
    return A && A.raw && (Ua.raw = { header: ee, sectors: we }), Ua;
  }
  function v(m) {
    if (m[m.l] == 80 && m[m.l + 1] == 75) return [0, 0];
    m.chk(fe, "Header Signature: "), m.l += 16;
    var A = m.read_shift(2, "u");
    return [m.read_shift(2, "u"), A];
  }
  function d(m, A) {
    var k = 9;
    switch (m.l += 2, k = m.read_shift(2)) {
      case 9:
        if (A != 3) throw new Error("Sector Shift: Expected 9 saw " + k);
        break;
      case 12:
        if (A != 4) throw new Error("Sector Shift: Expected 12 saw " + k);
        break;
      default:
        throw new Error("Sector Shift: Expected 9 or 12 saw " + k);
    }
    m.chk("0600", "Mini Sector Shift: "), m.chk("000000000000", "Reserved: ");
  }
  function u(m, A) {
    for (var k = Math.ceil(m.length / A) - 1, T = [], F = 1; F < k; ++F) T[F - 1] = m.slice(F * A, (F + 1) * A);
    return T[k - 1] = m.slice(k * A), T;
  }
  function p(m, A, k) {
    for (var T = 0, F = 0, C = 0, H = 0, K = 0, U = k.length, W = [], V = []; T < U; ++T)
      W[T] = V[T] = T, A[T] = k[T];
    for (; K < V.length; ++K)
      T = V[K], F = m[T].L, C = m[T].R, H = m[T].C, W[T] === T && (F !== -1 && W[F] !== F && (W[T] = W[F]), C !== -1 && W[C] !== C && (W[T] = W[C])), H !== -1 && (W[H] = T), F !== -1 && T != W[T] && (W[F] = W[T], V.lastIndexOf(F) < K && V.push(F)), C !== -1 && T != W[T] && (W[C] = W[T], V.lastIndexOf(C) < K && V.push(C));
    for (T = 1; T < U; ++T) W[T] === T && (C !== -1 && W[C] !== C ? W[T] = W[C] : F !== -1 && W[F] !== F && (W[T] = W[F]));
    for (T = 1; T < U; ++T)
      if (m[T].type !== 0) {
        if (K = T, K != W[K]) do
          K = W[K], A[T] = A[K] + "/" + A[T];
        while (K !== 0 && W[K] !== -1 && K != W[K]);
        W[T] = -1;
      }
    for (A[0] += "/", T = 1; T < U; ++T)
      m[T].type !== 2 && (A[T] += "/");
  }
  function _(m, A, k) {
    for (var T = m.start, F = m.size, C = [], H = T; k && F > 0 && H >= 0; )
      C.push(A.slice(H * G, H * G + G)), F -= G, H = da(k, H * 4);
    return C.length === 0 ? Qe(0) : ta(C).slice(0, m.size);
  }
  function x(m, A, k, T, F) {
    var C = z;
    if (m === z) {
      if (A !== 0) throw new Error("DIFAT chain shorter than expected");
    } else if (m !== -1) {
      var H = k[m], K = (T >>> 2) - 1;
      if (!H) return;
      for (var U = 0; U < K && (C = da(H, U * 4)) !== z; ++U)
        F.push(C);
      A >= 1 && x(da(H, T - 4), A - 1, k, T, F);
    }
  }
  function h(m, A, k, T, F) {
    var C = [], H = [];
    F || (F = []);
    var K = T - 1, U = 0, W = 0;
    for (U = A; U >= 0; ) {
      F[U] = !0, C[C.length] = U, H.push(m[U]);
      var V = k[Math.floor(U * 4 / T)];
      if (W = U * 4 & K, T < 4 + W) throw new Error("FAT boundary crossed: " + U + " 4 " + T);
      if (!m[V]) break;
      U = da(m[V], W);
    }
    return { nodes: C, data: sn([H]) };
  }
  function E(m, A, k, T) {
    var F = m.length, C = [], H = [], K = [], U = [], W = T - 1, V = 0, Z = 0, ee = 0, oe = 0;
    for (V = 0; V < F; ++V)
      if (K = [], ee = V + A, ee >= F && (ee -= F), !H[ee]) {
        U = [];
        var q = [];
        for (Z = ee; Z >= 0; ) {
          q[Z] = !0, H[Z] = !0, K[K.length] = Z, U.push(m[Z]);
          var ae = k[Math.floor(Z * 4 / T)];
          if (oe = Z * 4 & W, T < 4 + oe) throw new Error("FAT boundary crossed: " + Z + " 4 " + T);
          if (!m[ae] || (Z = da(m[ae], oe), q[Z])) break;
        }
        C[ee] = { nodes: K, data: sn([U]) };
      }
    return C;
  }
  function g(m, A, k, T, F, C, H, K) {
    for (var U = 0, W = T.length ? 2 : 0, V = A[m].data, Z = 0, ee = 0, oe; Z < V.length; Z += 128) {
      var q = (
        /*::(*/
        V.slice(Z, Z + 128)
      );
      rr(q, 64), ee = q.read_shift(2), oe = w0(q, 0, ee - W), T.push(oe);
      var ae = {
        name: oe,
        type: q.read_shift(1),
        color: q.read_shift(1),
        L: q.read_shift(4, "i"),
        R: q.read_shift(4, "i"),
        C: q.read_shift(4, "i"),
        clsid: q.read_shift(16),
        state: q.read_shift(4, "i"),
        start: 0,
        size: 0
      }, we = q.read_shift(2) + q.read_shift(2) + q.read_shift(2) + q.read_shift(2);
      we !== 0 && (ae.ct = y(q, q.l - 8));
      var Ve = q.read_shift(2) + q.read_shift(2) + q.read_shift(2) + q.read_shift(2);
      Ve !== 0 && (ae.mt = y(q, q.l - 8)), ae.start = q.read_shift(4, "i"), ae.size = q.read_shift(4, "i"), ae.size < 0 && ae.start < 0 && (ae.size = ae.type = 0, ae.start = z, ae.name = ""), ae.type === 5 ? (U = ae.start, F > 0 && U !== z && (A[U].name = "!StreamData")) : ae.size >= 4096 ? (ae.storage = "fat", A[ae.start] === void 0 && (A[ae.start] = h(k, ae.start, A.fat_addrs, A.ssz)), A[ae.start].name = ae.name, ae.content = A[ae.start].data.slice(0, ae.size)) : (ae.storage = "minifat", ae.size < 0 ? ae.size = 0 : U !== z && ae.start !== z && A[U] && (ae.content = _(ae, A[U].data, (A[K] || {}).data))), ae.content && rr(ae.content, 0), C[oe] = ae, H.push(ae);
    }
  }
  function y(m, A) {
    return new Date((Dr(m, A + 4) / 1e7 * Math.pow(2, 32) + Dr(m, A) / 1e7 - 11644473600) * 1e3);
  }
  function P(m, A) {
    return o(), l(c.readFileSync(m), A);
  }
  function M(m, A) {
    var k = A && A.type;
    switch (k || Se && Buffer.isBuffer(m) && (k = "buffer"), k || "base64") {
      case "file":
        return P(m, A);
      case "base64":
        return l(yr(Or(m)), A);
      case "binary":
        return l(yr(m), A);
    }
    return l(
      /*::typeof blob == 'string' ? new Buffer(blob, 'utf-8') : */
      m,
      A
    );
  }
  function I(m, A) {
    var k = A || {}, T = k.root || "Root Entry";
    if (m.FullPaths || (m.FullPaths = []), m.FileIndex || (m.FileIndex = []), m.FullPaths.length !== m.FileIndex.length) throw new Error("inconsistent CFB structure");
    m.FullPaths.length === 0 && (m.FullPaths[0] = T + "/", m.FileIndex[0] = { name: T, type: 5 }), k.CLSID && (m.FileIndex[0].clsid = k.CLSID), N(m);
  }
  function N(m) {
    var A = "Sh33tJ5";
    if (!Oe.find(m, "/" + A)) {
      var k = Qe(4);
      k[0] = 55, k[1] = k[3] = 50, k[2] = 54, m.FileIndex.push({ name: A, type: 2, content: k, size: 4, L: 69, R: 69, C: 69 }), m.FullPaths.push(m.FullPaths[0] + A), O(m);
    }
  }
  function O(m, A) {
    I(m);
    for (var k = !1, T = !1, F = m.FullPaths.length - 1; F >= 0; --F) {
      var C = m.FileIndex[F];
      switch (C.type) {
        case 0:
          T ? k = !0 : (m.FileIndex.pop(), m.FullPaths.pop());
          break;
        case 1:
        case 2:
        case 5:
          T = !0, isNaN(C.R * C.L * C.C) && (k = !0), C.R > -1 && C.L > -1 && C.R == C.L && (k = !0);
          break;
        default:
          k = !0;
          break;
      }
    }
    if (!(!k && !A)) {
      var H = new Date(1987, 1, 19), K = 0, U = Object.create ? /* @__PURE__ */ Object.create(null) : {}, W = [];
      for (F = 0; F < m.FullPaths.length; ++F)
        U[m.FullPaths[F]] = !0, m.FileIndex[F].type !== 0 && W.push([m.FullPaths[F], m.FileIndex[F]]);
      for (F = 0; F < W.length; ++F) {
        var V = t(W[F][0]);
        for (T = U[V]; !T; ) {
          for (; t(V) && !U[t(V)]; ) V = t(V);
          W.push([V, {
            name: n(V).replace("/", ""),
            type: 1,
            clsid: he,
            ct: H,
            mt: H,
            content: null
          }]), U[V] = !0, V = t(W[F][0]), T = U[V];
        }
      }
      for (W.sort(function(oe, q) {
        return r(oe[0], q[0]);
      }), m.FullPaths = [], m.FileIndex = [], F = 0; F < W.length; ++F)
        m.FullPaths[F] = W[F][0], m.FileIndex[F] = W[F][1];
      for (F = 0; F < W.length; ++F) {
        var Z = m.FileIndex[F], ee = m.FullPaths[F];
        if (Z.name = n(ee).replace("/", ""), Z.L = Z.R = Z.C = -(Z.color = 1), Z.size = Z.content ? Z.content.length : 0, Z.start = 0, Z.clsid = Z.clsid || he, F === 0)
          Z.C = W.length > 1 ? 1 : -1, Z.size = 0, Z.type = 5;
        else if (ee.slice(-1) == "/") {
          for (K = F + 1; K < W.length && t(m.FullPaths[K]) != ee; ++K) ;
          for (Z.C = K >= W.length ? -1 : K, K = F + 1; K < W.length && t(m.FullPaths[K]) != t(ee); ++K) ;
          Z.R = K >= W.length ? -1 : K, Z.type = 1;
        } else
          t(m.FullPaths[F + 1] || "") == t(ee) && (Z.R = F + 1), Z.type = 2;
      }
    }
  }
  function B(m, A) {
    var k = A || {};
    if (k.fileType == "mad") return Os(m, k);
    switch (O(m), k.fileType) {
      case "zip":
        return Fs(m, k);
    }
    var T = (function(oe) {
      for (var q = 0, ae = 0, we = 0; we < oe.FileIndex.length; ++we) {
        var Ve = oe.FileIndex[we];
        if (Ve.content) {
          var Ge = Ve.content.length;
          Ge > 0 && (Ge < 4096 ? q += Ge + 63 >> 6 : ae += Ge + 511 >> 9);
        }
      }
      for (var lr = oe.FullPaths.length + 3 >> 2, Ba = q + 7 >> 3, Ma = q + 127 >> 7, Ua = Ba + ae + lr + Ma, ha = Ua + 127 >> 7, jt = ha <= 109 ? 0 : Math.ceil((ha - 109) / 127); Ua + ha + jt + 127 >> 7 > ha; ) jt = ++ha <= 109 ? 0 : Math.ceil((ha - 109) / 127);
      var jr = [1, jt, ha, Ma, lr, ae, q, 0];
      return oe.FileIndex[0].size = q << 6, jr[7] = (oe.FileIndex[0].start = jr[0] + jr[1] + jr[2] + jr[3] + jr[4] + jr[5]) + (jr[6] + 7 >> 3), jr;
    })(m), F = Qe(T[7] << 9), C = 0, H = 0;
    {
      for (C = 0; C < 8; ++C) F.write_shift(1, j[C]);
      for (C = 0; C < 8; ++C) F.write_shift(2, 0);
      for (F.write_shift(2, 62), F.write_shift(2, 3), F.write_shift(2, 65534), F.write_shift(2, 9), F.write_shift(2, 6), C = 0; C < 3; ++C) F.write_shift(2, 0);
      for (F.write_shift(4, 0), F.write_shift(4, T[2]), F.write_shift(4, T[0] + T[1] + T[2] + T[3] - 1), F.write_shift(4, 0), F.write_shift(4, 4096), F.write_shift(4, T[3] ? T[0] + T[1] + T[2] - 1 : z), F.write_shift(4, T[3]), F.write_shift(-4, T[1] ? T[0] - 1 : z), F.write_shift(4, T[1]), C = 0; C < 109; ++C) F.write_shift(-4, C < T[2] ? T[1] + C : -1);
    }
    if (T[1])
      for (H = 0; H < T[1]; ++H) {
        for (; C < 236 + H * 127; ++C) F.write_shift(-4, C < T[2] ? T[1] + C : -1);
        F.write_shift(-4, H === T[1] - 1 ? z : H + 1);
      }
    var K = function(oe) {
      for (H += oe; C < H - 1; ++C) F.write_shift(-4, C + 1);
      oe && (++C, F.write_shift(-4, z));
    };
    for (H = C = 0, H += T[1]; C < H; ++C) F.write_shift(-4, J.DIFSECT);
    for (H += T[2]; C < H; ++C) F.write_shift(-4, J.FATSECT);
    K(T[3]), K(T[4]);
    for (var U = 0, W = 0, V = m.FileIndex[0]; U < m.FileIndex.length; ++U)
      V = m.FileIndex[U], V.content && (W = V.content.length, !(W < 4096) && (V.start = H, K(W + 511 >> 9)));
    for (K(T[6] + 7 >> 3); F.l & 511; ) F.write_shift(-4, J.ENDOFCHAIN);
    for (H = C = 0, U = 0; U < m.FileIndex.length; ++U)
      V = m.FileIndex[U], V.content && (W = V.content.length, !(!W || W >= 4096) && (V.start = H, K(W + 63 >> 6)));
    for (; F.l & 511; ) F.write_shift(-4, J.ENDOFCHAIN);
    for (C = 0; C < T[4] << 2; ++C) {
      var Z = m.FullPaths[C];
      if (!Z || Z.length === 0) {
        for (U = 0; U < 17; ++U) F.write_shift(4, 0);
        for (U = 0; U < 3; ++U) F.write_shift(4, -1);
        for (U = 0; U < 12; ++U) F.write_shift(4, 0);
        continue;
      }
      V = m.FileIndex[C], C === 0 && (V.start = V.size ? V.start - 1 : z);
      var ee = C === 0 && k.root || V.name;
      if (ee.length > 31 && (console.error("Name " + ee + " will be truncated to " + ee.slice(0, 31)), ee = ee.slice(0, 31)), W = 2 * (ee.length + 1), F.write_shift(64, ee, "utf16le"), F.write_shift(2, W), F.write_shift(1, V.type), F.write_shift(1, V.color), F.write_shift(-4, V.L), F.write_shift(-4, V.R), F.write_shift(-4, V.C), V.clsid) F.write_shift(16, V.clsid, "hex");
      else for (U = 0; U < 4; ++U) F.write_shift(4, 0);
      F.write_shift(4, V.state || 0), F.write_shift(4, 0), F.write_shift(4, 0), F.write_shift(4, 0), F.write_shift(4, 0), F.write_shift(4, V.start), F.write_shift(4, V.size), F.write_shift(4, 0);
    }
    for (C = 1; C < m.FileIndex.length; ++C)
      if (V = m.FileIndex[C], V.size >= 4096)
        if (F.l = V.start + 1 << 9, Se && Buffer.isBuffer(V.content))
          V.content.copy(F, F.l, 0, V.size), F.l += V.size + 511 & -512;
        else {
          for (U = 0; U < V.size; ++U) F.write_shift(1, V.content[U]);
          for (; U & 511; ++U) F.write_shift(1, 0);
        }
    for (C = 1; C < m.FileIndex.length; ++C)
      if (V = m.FileIndex[C], V.size > 0 && V.size < 4096)
        if (Se && Buffer.isBuffer(V.content))
          V.content.copy(F, F.l, 0, V.size), F.l += V.size + 63 & -64;
        else {
          for (U = 0; U < V.size; ++U) F.write_shift(1, V.content[U]);
          for (; U & 63; ++U) F.write_shift(1, 0);
        }
    if (Se)
      F.l = F.length;
    else
      for (; F.l < F.length; ) F.write_shift(1, 0);
    return F;
  }
  function b(m, A) {
    var k = m.FullPaths.map(function(U) {
      return U.toUpperCase();
    }), T = k.map(function(U) {
      var W = U.split("/");
      return W[W.length - (U.slice(-1) == "/" ? 2 : 1)];
    }), F = !1;
    A.charCodeAt(0) === 47 ? (F = !0, A = k[0].slice(0, -1) + A) : F = A.indexOf("/") !== -1;
    var C = A.toUpperCase(), H = F === !0 ? k.indexOf(C) : T.indexOf(C);
    if (H !== -1) return m.FileIndex[H];
    var K = !C.match(Wa);
    for (C = C.replace(wr, ""), K && (C = C.replace(Wa, "!")), H = 0; H < k.length; ++H)
      if ((K ? k[H].replace(Wa, "!") : k[H]).replace(wr, "") == C || (K ? T[H].replace(Wa, "!") : T[H]).replace(wr, "") == C) return m.FileIndex[H];
    return null;
  }
  var G = 64, z = -2, fe = "d0cf11e0a1b11ae1", j = [208, 207, 17, 224, 161, 177, 26, 225], he = "00000000000000000000000000000000", J = {
    /* 2.1 Compund File Sector Numbers and Types */
    MAXREGSECT: -6,
    DIFSECT: -4,
    FATSECT: -3,
    ENDOFCHAIN: z,
    FREESECT: -1,
    /* 2.2 Compound File Header */
    HEADER_SIGNATURE: fe,
    HEADER_MINOR_VERSION: "3e00",
    MAXREGSID: -6,
    NOSTREAM: -1,
    HEADER_CLSID: he,
    /* 2.6.1 Compound File Directory Entry */
    EntryTypes: ["unknown", "storage", "stream", "lockbytes", "property", "root"]
  };
  function ne(m, A, k) {
    o();
    var T = B(m, k);
    c.writeFileSync(A, T);
  }
  function pe(m) {
    for (var A = new Array(m.length), k = 0; k < m.length; ++k) A[k] = String.fromCharCode(m[k]);
    return A.join("");
  }
  function X(m, A) {
    var k = B(m, A);
    switch (A && A.type || "buffer") {
      case "file":
        return o(), c.writeFileSync(A.filename, k), k;
      case "binary":
        return typeof k == "string" ? k : pe(k);
      case "base64":
        return V0(typeof k == "string" ? k : pe(k));
      case "buffer":
        if (Se) return Buffer.isBuffer(k) ? k : oa(k);
      /* falls through */
      case "array":
        return typeof k == "string" ? yr(k) : k;
    }
    return k;
  }
  var ke;
  function _e(m) {
    try {
      var A = m.InflateRaw, k = new A();
      if (k._processChunk(new Uint8Array([3, 0]), k._finishFlushFlag), k.bytesRead) ke = m;
      else throw new Error("zlib does not expose bytesRead");
    } catch (T) {
      console.error("cannot use native zlib: " + (T.message || T));
    }
  }
  function de(m, A) {
    if (!ke) return B0(m, A);
    var k = ke.InflateRaw, T = new k(), F = T._processChunk(m.slice(m.l), T._finishFlushFlag);
    return m.l += T.bytesRead, F;
  }
  function ce(m) {
    return ke ? ke.deflateRawSync(m) : Er(m);
  }
  var Te = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], me = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258], Fe = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
  function S(m) {
    var A = (m << 1 | m << 11) & 139536 | (m << 5 | m << 15) & 558144;
    return (A >> 16 | A >> 8 | A) & 255;
  }
  for (var L = typeof Uint8Array < "u", R = L ? new Uint8Array(256) : [], D = 0; D < 256; ++D) R[D] = S(D);
  function Y(m, A) {
    var k = R[m & 255];
    return A <= 8 ? k >>> 8 - A : (k = k << 8 | R[m >> 8 & 255], A <= 16 ? k >>> 16 - A : (k = k << 8 | R[m >> 16 & 255], k >>> 24 - A));
  }
  function w(m, A) {
    var k = A & 7, T = A >>> 3;
    return (m[T] | (k <= 6 ? 0 : m[T + 1] << 8)) >>> k & 3;
  }
  function te(m, A) {
    var k = A & 7, T = A >>> 3;
    return (m[T] | (k <= 5 ? 0 : m[T + 1] << 8)) >>> k & 7;
  }
  function ie(m, A) {
    var k = A & 7, T = A >>> 3;
    return (m[T] | (k <= 4 ? 0 : m[T + 1] << 8)) >>> k & 15;
  }
  function Q(m, A) {
    var k = A & 7, T = A >>> 3;
    return (m[T] | (k <= 3 ? 0 : m[T + 1] << 8)) >>> k & 31;
  }
  function ve(m, A) {
    var k = A & 7, T = A >>> 3;
    return (m[T] | (k <= 1 ? 0 : m[T + 1] << 8)) >>> k & 127;
  }
  function xe(m, A, k) {
    var T = A & 7, F = A >>> 3, C = (1 << k) - 1, H = m[F] >>> T;
    return k < 8 - T || (H |= m[F + 1] << 8 - T, k < 16 - T) || (H |= m[F + 2] << 16 - T, k < 24 - T) || (H |= m[F + 3] << 24 - T), H & C;
  }
  function Ee(m, A, k) {
    var T = A & 7, F = A >>> 3;
    return T <= 5 ? m[F] |= (k & 7) << T : (m[F] |= k << T & 255, m[F + 1] = (k & 7) >> 8 - T), A + 3;
  }
  function Le(m, A, k) {
    var T = A & 7, F = A >>> 3;
    return k = (k & 1) << T, m[F] |= k, A + 1;
  }
  function He(m, A, k) {
    var T = A & 7, F = A >>> 3;
    return k <<= T, m[F] |= k & 255, k >>>= 8, m[F + 1] = k, A + 8;
  }
  function Xe(m, A, k) {
    var T = A & 7, F = A >>> 3;
    return k <<= T, m[F] |= k & 255, k >>>= 8, m[F + 1] = k & 255, m[F + 2] = k >>> 8, A + 16;
  }
  function ue(m, A) {
    var k = m.length, T = 2 * k > A ? 2 * k : A + 5, F = 0;
    if (k >= A) return m;
    if (Se) {
      var C = G0(T);
      if (m.copy) m.copy(C);
      else for (; F < m.length; ++F) C[F] = m[F];
      return C;
    } else if (L) {
      var H = new Uint8Array(T);
      if (H.set) H.set(m);
      else for (; F < k; ++F) H[F] = m[F];
      return H;
    }
    return m.length = T, m;
  }
  function De(m) {
    for (var A = new Array(m), k = 0; k < m; ++k) A[k] = 0;
    return A;
  }
  function re(m, A, k) {
    var T = 1, F = 0, C = 0, H = 0, K = 0, U = m.length, W = L ? new Uint16Array(32) : De(32);
    for (C = 0; C < 32; ++C) W[C] = 0;
    for (C = U; C < k; ++C) m[C] = 0;
    U = m.length;
    var V = L ? new Uint16Array(U) : De(U);
    for (C = 0; C < U; ++C)
      W[F = m[C]]++, T < F && (T = F), V[C] = 0;
    for (W[0] = 0, C = 1; C <= T; ++C) W[C + 16] = K = K + W[C - 1] << 1;
    for (C = 0; C < U; ++C)
      K = m[C], K != 0 && (V[C] = W[K + 16]++);
    var Z = 0;
    for (C = 0; C < U; ++C)
      if (Z = m[C], Z != 0)
        for (K = Y(V[C], T) >> T - Z, H = (1 << T + 4 - Z) - 1; H >= 0; --H)
          A[K | H << Z] = Z & 15 | C << 4;
    return T;
  }
  var Sr = L ? new Uint16Array(512) : De(512), gr = L ? new Uint16Array(32) : De(32);
  if (!L) {
    for (var We = 0; We < 512; ++We) Sr[We] = 0;
    for (We = 0; We < 32; ++We) gr[We] = 0;
  }
  (function() {
    for (var m = [], A = 0; A < 32; A++) m.push(5);
    re(m, gr, 32);
    var k = [];
    for (A = 0; A <= 143; A++) k.push(8);
    for (; A <= 255; A++) k.push(9);
    for (; A <= 279; A++) k.push(7);
    for (; A <= 287; A++) k.push(8);
    re(k, Sr, 288);
  })();
  var Hr = /* @__PURE__ */ (function() {
    for (var A = L ? new Uint8Array(32768) : [], k = 0, T = 0; k < Fe.length - 1; ++k)
      for (; T < Fe[k + 1]; ++T) A[T] = k;
    for (; T < 32768; ++T) A[T] = 29;
    var F = L ? new Uint8Array(259) : [];
    for (k = 0, T = 0; k < me.length - 1; ++k)
      for (; T < me[k + 1]; ++T) F[T] = k;
    function C(K, U) {
      for (var W = 0; W < K.length; ) {
        var V = Math.min(65535, K.length - W), Z = W + V == K.length;
        for (U.write_shift(1, +Z), U.write_shift(2, V), U.write_shift(2, ~V & 65535); V-- > 0; ) U[U.l++] = K[W++];
      }
      return U.l;
    }
    function H(K, U) {
      for (var W = 0, V = 0, Z = L ? new Uint16Array(32768) : []; V < K.length; ) {
        var ee = (
          /* data.length - boff; */
          Math.min(65535, K.length - V)
        );
        if (ee < 10) {
          for (W = Ee(U, W, +(V + ee == K.length)), W & 7 && (W += 8 - (W & 7)), U.l = W / 8 | 0, U.write_shift(2, ee), U.write_shift(2, ~ee & 65535); ee-- > 0; ) U[U.l++] = K[V++];
          W = U.l * 8;
          continue;
        }
        W = Ee(U, W, +(V + ee == K.length) + 2);
        for (var oe = 0; ee-- > 0; ) {
          var q = K[V];
          oe = (oe << 5 ^ q) & 32767;
          var ae = -1, we = 0;
          if ((ae = Z[oe]) && (ae |= V & -32768, ae > V && (ae -= 32768), ae < V))
            for (; K[ae + we] == K[V + we] && we < 250; ) ++we;
          if (we > 2) {
            q = F[we], q <= 22 ? W = He(U, W, R[q + 1] >> 1) - 1 : (He(U, W, 3), W += 5, He(U, W, R[q - 23] >> 5), W += 3);
            var Ve = q < 8 ? 0 : q - 4 >> 2;
            Ve > 0 && (Xe(U, W, we - me[q]), W += Ve), q = A[V - ae], W = He(U, W, R[q] >> 3), W -= 3;
            var Ge = q < 4 ? 0 : q - 2 >> 1;
            Ge > 0 && (Xe(U, W, V - ae - Fe[q]), W += Ge);
            for (var lr = 0; lr < we; ++lr)
              Z[oe] = V & 32767, oe = (oe << 5 ^ K[V]) & 32767, ++V;
            ee -= we - 1;
          } else
            q <= 143 ? q = q + 48 : W = Le(U, W, 1), W = He(U, W, R[q]), Z[oe] = V & 32767, ++V;
        }
        W = He(U, W, 0) - 1;
      }
      return U.l = (W + 7) / 8 | 0, U.l;
    }
    return function(U, W) {
      return U.length < 8 ? C(U, W) : H(U, W);
    };
  })();
  function Er(m) {
    var A = Qe(50 + Math.floor(m.length * 1.1)), k = Hr(m, A);
    return A.slice(0, k);
  }
  var se = L ? new Uint16Array(32768) : De(32768), be = L ? new Uint16Array(32768) : De(32768), Ye = L ? new Uint16Array(128) : De(128), je = 1, Yr = 1;
  function ua(m, A) {
    var k = Q(m, A) + 257;
    A += 5;
    var T = Q(m, A) + 1;
    A += 5;
    var F = ie(m, A) + 4;
    A += 4;
    for (var C = 0, H = L ? new Uint8Array(19) : De(19), K = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], U = 1, W = L ? new Uint8Array(8) : De(8), V = L ? new Uint8Array(8) : De(8), Z = H.length, ee = 0; ee < F; ++ee)
      H[Te[ee]] = C = te(m, A), U < C && (U = C), W[C]++, A += 3;
    var oe = 0;
    for (W[0] = 0, ee = 1; ee <= U; ++ee) V[ee] = oe = oe + W[ee - 1] << 1;
    for (ee = 0; ee < Z; ++ee) (oe = H[ee]) != 0 && (K[ee] = V[oe]++);
    var q = 0;
    for (ee = 0; ee < Z; ++ee)
      if (q = H[ee], q != 0) {
        oe = R[K[ee]] >> 8 - q;
        for (var ae = (1 << 7 - q) - 1; ae >= 0; --ae) Ye[oe | ae << q] = q & 7 | ee << 3;
      }
    var we = [];
    for (U = 1; we.length < k + T; )
      switch (oe = Ye[ve(m, A)], A += oe & 7, oe >>>= 3) {
        case 16:
          for (C = 3 + w(m, A), A += 2, oe = we[we.length - 1]; C-- > 0; ) we.push(oe);
          break;
        case 17:
          for (C = 3 + te(m, A), A += 3; C-- > 0; ) we.push(0);
          break;
        case 18:
          for (C = 11 + ve(m, A), A += 7; C-- > 0; ) we.push(0);
          break;
        default:
          we.push(oe), U < oe && (U = oe);
          break;
      }
    var Ve = we.slice(0, k), Ge = we.slice(k);
    for (ee = k; ee < 286; ++ee) Ve[ee] = 0;
    for (ee = T; ee < 30; ++ee) Ge[ee] = 0;
    return je = re(Ve, se, 286), Yr = re(Ge, be, 30), A;
  }
  function pt(m, A) {
    if (m[0] == 3 && !(m[1] & 3))
      return [sa(A), 2];
    for (var k = 0, T = 0, F = G0(A || 1 << 18), C = 0, H = F.length >>> 0, K = 0, U = 0; (T & 1) == 0; ) {
      if (T = te(m, k), k += 3, T >>> 1)
        T >> 1 == 1 ? (K = 9, U = 5) : (k = ua(m, k), K = je, U = Yr);
      else {
        k & 7 && (k += 8 - (k & 7));
        var W = m[k >>> 3] | m[(k >>> 3) + 1] << 8;
        if (k += 32, W > 0)
          for (!A && H < C + W && (F = ue(F, C + W), H = F.length); W-- > 0; )
            F[C++] = m[k >>> 3], k += 8;
        continue;
      }
      for (; ; ) {
        !A && H < C + 32767 && (F = ue(F, C + 32767), H = F.length);
        var V = xe(m, k, K), Z = T >>> 1 == 1 ? Sr[V] : se[V];
        if (k += Z & 15, Z >>>= 4, (Z >>> 8 & 255) === 0) F[C++] = Z;
        else {
          if (Z == 256) break;
          Z -= 257;
          var ee = Z < 8 ? 0 : Z - 4 >> 2;
          ee > 5 && (ee = 0);
          var oe = C + me[Z];
          ee > 0 && (oe += xe(m, k, ee), k += ee), V = xe(m, k, U), Z = T >>> 1 == 1 ? gr[V] : be[V], k += Z & 15, Z >>>= 4;
          var q = Z < 4 ? 0 : Z - 2 >> 1, ae = Fe[Z];
          for (q > 0 && (ae += xe(m, k, q), k += q), !A && H < oe && (F = ue(F, oe + 100), H = F.length); C < oe; )
            F[C] = F[C - ae], ++C;
        }
      }
    }
    return A ? [F, k + 7 >>> 3] : [F.slice(0, C), k + 7 >>> 3];
  }
  function B0(m, A) {
    var k = m.slice(m.l || 0), T = pt(k, A);
    return m.l += T[1], T[0];
  }
  function M0(m, A) {
    if (m)
      typeof console < "u" && console.error(A);
    else throw new Error(A);
  }
  function U0(m, A) {
    var k = (
      /*::(*/
      m
    );
    rr(k, 0);
    var T = [], F = [], C = {
      FileIndex: T,
      FullPaths: F
    };
    I(C, { root: A.root });
    for (var H = k.length - 4; (k[H] != 80 || k[H + 1] != 75 || k[H + 2] != 5 || k[H + 3] != 6) && H >= 0; ) --H;
    k.l = H + 4, k.l += 4;
    var K = k.read_shift(2);
    k.l += 6;
    var U = k.read_shift(4);
    for (k.l = U, H = 0; H < K; ++H) {
      k.l += 20;
      var W = k.read_shift(4), V = k.read_shift(4), Z = k.read_shift(2), ee = k.read_shift(2), oe = k.read_shift(2);
      k.l += 8;
      var q = k.read_shift(4), ae = s(
        /*::(*/
        k.slice(k.l + Z, k.l + Z + ee)
        /*:: :any)*/
      );
      k.l += Z + ee + oe;
      var we = k.l;
      k.l = q + 4, ae && ae[1] && ((ae[1] || {}).usz && (V = ae[1].usz), (ae[1] || {}).csz && (W = ae[1].csz)), ws(k, W, V, C, ae), k.l = we;
    }
    return C;
  }
  function ws(m, A, k, T, F) {
    m.l += 2;
    var C = m.read_shift(2), H = m.read_shift(2), K = f(m);
    if (C & 8257) throw new Error("Unsupported ZIP encryption");
    for (var U = m.read_shift(4), W = m.read_shift(4), V = m.read_shift(4), Z = m.read_shift(2), ee = m.read_shift(2), oe = "", q = 0; q < Z; ++q) oe += String.fromCharCode(m[m.l++]);
    if (ee) {
      var ae = s(
        /*::(*/
        m.slice(m.l, m.l + ee)
        /*:: :any)*/
      );
      (ae[21589] || {}).mt && (K = ae[21589].mt), (ae[1] || {}).usz && (V = ae[1].usz), (ae[1] || {}).csz && (W = ae[1].csz), F && ((F[21589] || {}).mt && (K = F[21589].mt), (F[1] || {}).usz && (V = F[1].usz), (F[1] || {}).csz && (W = F[1].csz));
    }
    m.l += ee;
    var we = m.slice(m.l, m.l + W);
    switch (H) {
      case 8:
        we = de(m, V);
        break;
      case 0:
        m.l += W;
        break;
      // TODO: scan for magic number
      default:
        throw new Error("Unsupported ZIP Compression method " + H);
    }
    var Ve = !1;
    C & 8 && (U = m.read_shift(4), U == 134695760 && (U = m.read_shift(4), Ve = !0), W = m.read_shift(4), V = m.read_shift(4)), W != A && M0(Ve, "Bad compressed size: " + A + " != " + W), V != k && M0(Ve, "Bad uncompressed size: " + k + " != " + V), Yt(T, oe, we, { unsafe: !0, mt: K });
  }
  function Fs(m, A) {
    var k = A || {}, T = [], F = [], C = Qe(1), H = k.compression ? 8 : 0, K = 0, U = 0, W = 0, V = 0, Z = 0, ee = m.FullPaths[0], oe = ee, q = m.FileIndex[0], ae = [], we = 0;
    for (U = 1; U < m.FullPaths.length; ++U)
      if (oe = m.FullPaths[U].slice(ee.length), q = m.FileIndex[U], !(!q.size || !q.content || Array.isArray(q.content) && q.content.length == 0 || oe == "Sh33tJ5")) {
        var Ve = V, Ge = Qe(oe.length);
        for (W = 0; W < oe.length; ++W) Ge.write_shift(1, oe.charCodeAt(W) & 127);
        Ge = Ge.slice(0, Ge.l), ae[Z] = typeof q.content == "string" ? Z0.bstr(q.content, 0) : Z0.buf(
          /*::((*/
          q.content,
          0
        );
        var lr = typeof q.content == "string" ? yr(q.content) : q.content;
        H == 8 && (lr = ce(lr)), C = Qe(30), C.write_shift(4, 67324752), C.write_shift(2, 20), C.write_shift(2, K), C.write_shift(2, H), q.mt ? i(C, q.mt) : C.write_shift(4, 0), C.write_shift(-4, ae[Z]), C.write_shift(4, lr.length), C.write_shift(
          4,
          /*::(*/
          q.content.length
        ), C.write_shift(2, Ge.length), C.write_shift(2, 0), V += C.length, T.push(C), V += Ge.length, T.push(Ge), V += lr.length, T.push(lr), C = Qe(46), C.write_shift(4, 33639248), C.write_shift(2, 0), C.write_shift(2, 20), C.write_shift(2, K), C.write_shift(2, H), C.write_shift(4, 0), C.write_shift(-4, ae[Z]), C.write_shift(4, lr.length), C.write_shift(
          4,
          /*::(*/
          q.content.length
        ), C.write_shift(2, Ge.length), C.write_shift(2, 0), C.write_shift(2, 0), C.write_shift(2, 0), C.write_shift(2, 0), C.write_shift(4, 0), C.write_shift(4, Ve), we += C.l, F.push(C), we += Ge.length, F.push(Ge), ++Z;
      }
    return C = Qe(22), C.write_shift(4, 101010256), C.write_shift(2, 0), C.write_shift(2, 0), C.write_shift(2, Z), C.write_shift(2, Z), C.write_shift(4, we), C.write_shift(4, V), C.write_shift(2, 0), ta([ta(T), ta(F), C]);
  }
  var gt = {
    htm: "text/html",
    xml: "text/xml",
    gif: "image/gif",
    jpg: "image/jpeg",
    png: "image/png",
    mso: "application/x-mso",
    thmx: "application/vnd.ms-officetheme",
    sh33tj5: "application/octet-stream"
  };
  function As(m, A) {
    if (m.ctype) return m.ctype;
    var k = m.name || "", T = k.match(/\.([^\.]+)$/);
    return T && gt[T[1]] || A && (T = (k = A).match(/[\.\\]([^\.\\])+$/), T && gt[T[1]]) ? gt[T[1]] : "application/octet-stream";
  }
  function Ss(m) {
    for (var A = V0(m), k = [], T = 0; T < A.length; T += 76) k.push(A.slice(T, T + 76));
    return k.join(`\r
`) + `\r
`;
  }
  function Cs(m) {
    var A = m.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7E-\xFF=]/g, function(W) {
      var V = W.charCodeAt(0).toString(16).toUpperCase();
      return "=" + (V.length == 1 ? "0" + V : V);
    });
    A = A.replace(/ $/mg, "=20").replace(/\t$/mg, "=09"), A.charAt(0) == `
` && (A = "=0D" + A.slice(1)), A = A.replace(/\r(?!\n)/mg, "=0D").replace(/\n\n/mg, `
=0A`).replace(/([^\r\n])\n/mg, "$1=0A");
    for (var k = [], T = A.split(`\r
`), F = 0; F < T.length; ++F) {
      var C = T[F];
      if (C.length == 0) {
        k.push("");
        continue;
      }
      for (var H = 0; H < C.length; ) {
        var K = 76, U = C.slice(H, H + K);
        U.charAt(K - 1) == "=" ? K-- : U.charAt(K - 2) == "=" ? K -= 2 : U.charAt(K - 3) == "=" && (K -= 3), U = C.slice(H, H + K), H += K, H < C.length && (U += "="), k.push(U);
      }
    }
    return k.join(`\r
`);
  }
  function ys(m) {
    for (var A = [], k = 0; k < m.length; ++k) {
      for (var T = m[k]; k <= m.length && T.charAt(T.length - 1) == "="; ) T = T.slice(0, T.length - 1) + m[++k];
      A.push(T);
    }
    for (var F = 0; F < A.length; ++F) A[F] = A[F].replace(/[=][0-9A-Fa-f]{2}/g, function(C) {
      return String.fromCharCode(parseInt(C.slice(1), 16));
    });
    return yr(A.join(`\r
`));
  }
  function Ds(m, A, k) {
    for (var T = "", F = "", C = "", H, K = 0; K < 10; ++K) {
      var U = A[K];
      if (!U || U.match(/^\s*$/)) break;
      var W = U.match(/^([^:]*?):\s*([^\s].*)$/);
      if (W) switch (W[1].toLowerCase()) {
        case "content-location":
          T = W[2].trim();
          break;
        case "content-type":
          C = W[2].trim();
          break;
        case "content-transfer-encoding":
          F = W[2].trim();
          break;
      }
    }
    switch (++K, F.toLowerCase()) {
      case "base64":
        H = yr(Or(A.slice(K).join("")));
        break;
      case "quoted-printable":
        H = ys(A.slice(K));
        break;
      default:
        throw new Error("Unsupported Content-Transfer-Encoding " + F);
    }
    var V = Yt(m, T.slice(k.length), H, { unsafe: !0 });
    C && (V.ctype = C);
  }
  function Is(m, A) {
    if (pe(m.slice(0, 13)).toLowerCase() != "mime-version:") throw new Error("Unsupported MAD header");
    var k = A && A.root || "", T = (Se && Buffer.isBuffer(m) ? m.toString("binary") : pe(m)).split(`\r
`), F = 0, C = "";
    for (F = 0; F < T.length; ++F)
      if (C = T[F], !!/^Content-Location:/i.test(C) && (C = C.slice(C.indexOf("file")), k || (k = C.slice(0, C.lastIndexOf("/") + 1)), C.slice(0, k.length) != k))
        for (; k.length > 0 && (k = k.slice(0, k.length - 1), k = k.slice(0, k.lastIndexOf("/") + 1), C.slice(0, k.length) != k); )
          ;
    var H = (T[1] || "").match(/boundary="(.*?)"/);
    if (!H) throw new Error("MAD cannot find boundary");
    var K = "--" + (H[1] || ""), U = [], W = [], V = {
      FileIndex: U,
      FullPaths: W
    };
    I(V);
    var Z, ee = 0;
    for (F = 0; F < T.length; ++F) {
      var oe = T[F];
      oe !== K && oe !== K + "--" || (ee++ && Ds(V, T.slice(Z, F), k), Z = F);
    }
    return V;
  }
  function Os(m, A) {
    var k = A || {}, T = k.boundary || "SheetJS";
    T = "------=" + T;
    for (var F = [
      "MIME-Version: 1.0",
      'Content-Type: multipart/related; boundary="' + T.slice(2) + '"',
      "",
      "",
      ""
    ], C = m.FullPaths[0], H = C, K = m.FileIndex[0], U = 1; U < m.FullPaths.length; ++U)
      if (H = m.FullPaths[U].slice(C.length), K = m.FileIndex[U], !(!K.size || !K.content || H == "Sh33tJ5")) {
        H = H.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7E-\xFF]/g, function(we) {
          return "_x" + we.charCodeAt(0).toString(16) + "_";
        }).replace(/[\u0080-\uFFFF]/g, function(we) {
          return "_u" + we.charCodeAt(0).toString(16) + "_";
        });
        for (var W = K.content, V = Se && Buffer.isBuffer(W) ? W.toString("binary") : pe(W), Z = 0, ee = Math.min(1024, V.length), oe = 0, q = 0; q <= ee; ++q) (oe = V.charCodeAt(q)) >= 32 && oe < 128 && ++Z;
        var ae = Z >= ee * 4 / 5;
        F.push(T), F.push("Content-Location: " + (k.root || "file:///C:/SheetJS/") + H), F.push("Content-Transfer-Encoding: " + (ae ? "quoted-printable" : "base64")), F.push("Content-Type: " + As(K, H)), F.push(""), F.push(ae ? Cs(V) : Ss(V));
      }
    return F.push(T + `--\r
`), F.join(`\r
`);
  }
  function Rs(m) {
    var A = {};
    return I(A, m), A;
  }
  function Yt(m, A, k, T) {
    var F = T && T.unsafe;
    F || I(m);
    var C = !F && Oe.find(m, A);
    if (!C) {
      var H = m.FullPaths[0];
      A.slice(0, H.length) == H ? H = A : (H.slice(-1) != "/" && (H += "/"), H = (H + A).replace("//", "/")), C = { name: n(A), type: 2 }, m.FileIndex.push(C), m.FullPaths.push(H), F || Oe.utils.cfb_gc(m);
    }
    return C.content = k, C.size = k ? k.length : 0, T && (T.CLSID && (C.clsid = T.CLSID), T.mt && (C.mt = T.mt), T.ct && (C.ct = T.ct)), C;
  }
  function Ns(m, A) {
    I(m);
    var k = Oe.find(m, A);
    if (k) {
      for (var T = 0; T < m.FileIndex.length; ++T) if (m.FileIndex[T] == k)
        return m.FileIndex.splice(T, 1), m.FullPaths.splice(T, 1), !0;
    }
    return !1;
  }
  function Ps(m, A, k) {
    I(m);
    var T = Oe.find(m, A);
    if (T) {
      for (var F = 0; F < m.FileIndex.length; ++F) if (m.FileIndex[F] == T)
        return m.FileIndex[F].name = n(k), m.FullPaths[F] = k, !0;
    }
    return !1;
  }
  function bs(m) {
    O(m, !0);
  }
  return a.find = b, a.read = M, a.parse = l, a.write = X, a.writeFile = ne, a.utils = {
    cfb_new: Rs,
    cfb_add: Yt,
    cfb_del: Ns,
    cfb_mov: Ps,
    cfb_gc: bs,
    ReadShift: Xa,
    CheckField: wi,
    prep_blob: rr,
    bconcat: ta,
    use_zlib: _e,
    _deflateRaw: Er,
    _inflateRaw: B0,
    consts: J
  }, a;
})(), vf;
function pf(e) {
  if (typeof Deno < "u") return Deno.readFileSync(e);
  if (typeof $ < "u" && typeof File < "u" && typeof Folder < "u") try {
    var a = File(e);
    a.open("r"), a.encoding = "binary";
    var r = a.read();
    return a.close(), r;
  } catch (t) {
    if (!t.message || t.message.indexOf("onstruct") == -1) throw t;
  }
  throw new Error("Cannot access file " + e);
}
function Lr(e) {
  for (var a = Object.keys(e), r = [], t = 0; t < a.length; ++t) Object.prototype.hasOwnProperty.call(e, a[t]) && r.push(a[t]);
  return r;
}
function _0(e) {
  for (var a = [], r = Lr(e), t = 0; t !== r.length; ++t) a[e[r[t]]] = r[t];
  return a;
}
var ei = /* @__PURE__ */ Date.UTC(1899, 11, 30, 0, 0, 0), gf = /* @__PURE__ */ Date.UTC(1899, 11, 31, 0, 0, 0), mf = /* @__PURE__ */ Date.UTC(1904, 0, 1, 0, 0, 0);
function ar(e, a) {
  var r = /* @__PURE__ */ e.getTime(), t = (r - ei) / (1440 * 60 * 1e3);
  return a ? (t -= 1462, t < -1402 ? t - 1 : t) : t < 60 ? t - 1 : t;
}
function ia(e) {
  if (e >= 60 && e < 61) return e;
  var a = /* @__PURE__ */ new Date();
  return a.setTime((e > 60 ? e : e + 1) * 24 * 60 * 60 * 1e3 + ei), a;
}
function _f(e) {
  var a = 0, r = 0, t = !1, n = e.match(/P([0-9\.]+Y)?([0-9\.]+M)?([0-9\.]+D)?T([0-9\.]+H)?([0-9\.]+M)?([0-9\.]+S)?/);
  if (!n) throw new Error("|" + e + "| is not an ISO8601 Duration");
  for (var i = 1; i != n.length; ++i)
    if (n[i]) {
      switch (r = 1, i > 3 && (t = !0), n[i].slice(n[i].length - 1)) {
        case "Y":
          throw new Error("Unsupported ISO Duration Field: " + n[i].slice(n[i].length - 1));
        case "D":
          r *= 24;
        /* falls through */
        case "H":
          r *= 60;
        /* falls through */
        case "M":
          if (t) r *= 60;
          else throw new Error("Unsupported ISO Duration Field: M");
      }
      a += r * parseInt(n[i], 10);
    }
  return a;
}
var kf = /^(\d+):(\d+)(:\d+)?(\.\d+)?$/, Ef = /^(\d+)-(\d+)-(\d+)$/, ri = /^(\d+)-(\d+)-(\d+)[T ](\d+):(\d+)(:\d+)?(\.\d+)?$/;
function cr(e, a) {
  if (e instanceof Date) return e;
  var r = e.match(kf);
  if (r) return new Date((a ? mf : gf) + ((parseInt(r[1], 10) * 60 + parseInt(r[2], 10)) * 60 + (r[3] ? parseInt(r[3].slice(1), 10) : 0)) * 1e3 + (r[4] ? parseInt((r[4] + "000").slice(1, 4), 10) : 0));
  if (r = e.match(Ef), r) return new Date(Date.UTC(+r[1], +r[2] - 1, +r[3], 0, 0, 0, 0));
  if (r = e.match(ri), r) return new Date(Date.UTC(+r[1], +r[2] - 1, +r[3], +r[4], +r[5], r[6] && parseInt(r[6].slice(1), 10) || 0, r[7] && parseInt((r[7] + "0000").slice(1, 4), 10) || 0));
  var t = new Date(e);
  return t;
}
function ka(e, a) {
  if (Se && Buffer.isBuffer(e)) {
    if (a && rt) {
      if (e[0] == 255 && e[1] == 254) return Va(e.slice(2).toString("utf16le"));
      if (e[1] == 254 && e[2] == 255) return Va(Xn(e.slice(2).toString("binary")));
    }
    return e.toString("binary");
  }
  if (typeof TextDecoder < "u") try {
    if (a) {
      if (e[0] == 255 && e[1] == 254) return Va(new TextDecoder("utf-16le").decode(e.slice(2)));
      if (e[0] == 254 && e[1] == 255) return Va(new TextDecoder("utf-16be").decode(e.slice(2)));
    }
    var r = {
      "€": "",
      "‚": "",
      ƒ: "",
      "„": "",
      "…": "",
      "†": "",
      "‡": "",
      "ˆ": "",
      "‰": "",
      Š: "",
      "‹": "",
      Œ: "",
      Ž: "",
      "‘": "",
      "’": "",
      "“": "",
      "”": "",
      "•": "",
      "–": "",
      "—": "",
      "˜": "",
      "™": "",
      š: "",
      "›": "",
      œ: "",
      ž: "",
      Ÿ: ""
    };
    return Array.isArray(e) && (e = new Uint8Array(e)), new TextDecoder("latin1").decode(e).replace(/[€‚ƒ„…†‡ˆ‰Š‹ŒŽ‘’“”•–—˜™š›œžŸ]/g, function(i) {
      return r[i] || i;
    });
  } catch {
  }
  var t = [], n = 0;
  try {
    for (n = 0; n < e.length - 65536; n += 65536) t.push(String.fromCharCode.apply(0, e.slice(n, n + 65536)));
    t.push(String.fromCharCode.apply(0, e.slice(n)));
  } catch {
    try {
      for (; n < e.length - 16384; n += 16384) t.push(String.fromCharCode.apply(0, e.slice(n, n + 16384)));
      t.push(String.fromCharCode.apply(0, e.slice(n)));
    } catch {
      for (; n != e.length; ++n) t.push(String.fromCharCode(e[n]));
    }
  }
  return t.join("");
}
function er(e) {
  if (typeof JSON < "u" && !Array.isArray(e)) return JSON.parse(JSON.stringify(e));
  if (typeof e != "object" || e == null) return e;
  if (e instanceof Date) return new Date(e.getTime());
  var a = {};
  for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (a[r] = er(e[r]));
  return a;
}
function Ie(e, a) {
  for (var r = ""; r.length < a; ) r += e;
  return r;
}
function Ir(e) {
  var a = Number(e);
  if (!isNaN(a)) return isFinite(a) ? a : NaN;
  if (!/\d/.test(e)) return a;
  var r = 1, t = e.replace(/([\d]),([\d])/g, "$1$2").replace(/[$]/g, "").replace(/[%]/g, function() {
    return r *= 100, "";
  });
  return !isNaN(a = Number(t)) || (t = t.replace(/[(]([^()]*)[)]/, function(n, i) {
    return r = -r, i;
  }), !isNaN(a = Number(t))) ? a / r : a;
}
var Tf = /^(0?\d|1[0-2])(?:|:([0-5]?\d)(?:|(\.\d+)(?:|:([0-5]?\d))|:([0-5]?\d)(|\.\d+)))\s+([ap])m?$/, wf = /^([01]?\d|2[0-3])(?:|:([0-5]?\d)(?:|(\.\d+)(?:|:([0-5]?\d))|:([0-5]?\d)(|\.\d+)))$/, Ff = /^(\d+)-(\d+)-(\d+)[T ](\d+):(\d+)(:\d+)(\.\d+)?[Z]?$/, Af = (/* @__PURE__ */ new Date("6/9/69 00:00 UTC")).valueOf() == -177984e5;
function Sf(e) {
  return e[2] ? e[3] ? e[4] ? new Date(Date.UTC(1899, 11, 31, +e[1] % 12 + (e[7] == "p" ? 12 : 0), +e[2], +e[4], parseFloat(e[3]) * 1e3)) : new Date(Date.UTC(1899, 11, 31, e[7] == "p" ? 12 : 0, +e[1], +e[2], parseFloat(e[3]) * 1e3)) : e[5] ? new Date(Date.UTC(1899, 11, 31, +e[1] % 12 + (e[7] == "p" ? 12 : 0), +e[2], +e[5], e[6] ? parseFloat(e[6]) * 1e3 : 0)) : new Date(Date.UTC(1899, 11, 31, +e[1] % 12 + (e[7] == "p" ? 12 : 0), +e[2], 0, 0)) : new Date(Date.UTC(1899, 11, 31, +e[1] % 12 + (e[7] == "p" ? 12 : 0), 0, 0, 0));
}
function Cf(e) {
  return e[2] ? e[3] ? e[4] ? new Date(Date.UTC(1899, 11, 31, +e[1], +e[2], +e[4], parseFloat(e[3]) * 1e3)) : new Date(Date.UTC(1899, 11, 31, 0, +e[1], +e[2], parseFloat(e[3]) * 1e3)) : e[5] ? new Date(Date.UTC(1899, 11, 31, +e[1], +e[2], +e[5], e[6] ? parseFloat(e[6]) * 1e3 : 0)) : new Date(Date.UTC(1899, 11, 31, +e[1], +e[2], 0, 0)) : new Date(Date.UTC(1899, 11, 31, +e[1], 0, 0, 0));
}
var yf = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
function tt(e) {
  if (Ff.test(e)) return e.indexOf("Z") == -1 ? Ht(new Date(e)) : new Date(e);
  var a = e.toLowerCase(), r = a.replace(/\s+/g, " ").trim(), t = r.match(Tf);
  if (t) return Sf(t);
  if (t = r.match(wf), t) return Cf(t);
  if (t = r.match(ri), t) return new Date(Date.UTC(+t[1], +t[2] - 1, +t[3], +t[4], +t[5], t[6] && parseInt(t[6].slice(1), 10) || 0, t[7] && parseInt((t[7] + "0000").slice(1, 4), 10) || 0));
  var n = new Date(Af && e.indexOf("UTC") == -1 ? e + " UTC" : e), i = /* @__PURE__ */ new Date(NaN), f = n.getYear();
  n.getMonth();
  var s = n.getDate();
  if (isNaN(s)) return i;
  if (a.match(/jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec/)) {
    if (a = a.replace(/[^a-z]/g, "").replace(/([^a-z]|^)[ap]m?([^a-z]|$)/, ""), a.length > 3 && yf.indexOf(a) == -1) return i;
  } else if (a.replace(/[ap]m?/, "").match(/[a-z]/)) return i;
  return f < 0 || f > 8099 || e.match(/[^-0-9:,\/\\\ ]/) ? i : n;
}
var Df = /* @__PURE__ */ (function() {
  var e = "abacaba".split(/(:?b)/i).length == 5;
  return function(r, t, n) {
    if (e || typeof t == "string") return r.split(t);
    for (var i = r.split(t), f = [i[0]], s = 1; s < i.length; ++s)
      f.push(n), f.push(i[s]);
    return f;
  };
})();
function Ea(e) {
  return new Date(e.getUTCFullYear(), e.getUTCMonth(), e.getUTCDate(), e.getUTCHours(), e.getUTCMinutes(), e.getUTCSeconds(), e.getUTCMilliseconds());
}
function Ht(e) {
  return new Date(Date.UTC(e.getFullYear(), e.getMonth(), e.getDate(), e.getHours(), e.getMinutes(), e.getSeconds(), e.getMilliseconds()));
}
function k0(e) {
  var a = e.slice(0, 1024), r = a.indexOf("<!DOCTYPE");
  if (r == -1) return e;
  var t = e.match(/<[\w]/);
  return t ? e.slice(0, r) + e.slice(t.index) : e;
}
function E0(e, a, r) {
  for (var t = [], n = e.indexOf(a); n > -1; ) {
    var i = e.indexOf(r, n + a.length);
    if (i == -1) break;
    t.push(e.slice(n, i + r.length)), n = e.indexOf(a, i + r.length);
  }
  return t.length > 0 ? t : null;
}
function ot(e, a, r) {
  var t = [], n = 0, i = e.indexOf(a);
  if (i == -1) return e;
  for (; i > -1; ) {
    t.push(e.slice(n, i));
    var f = e.indexOf(r, i + a.length);
    if (f == -1) break;
    (i = e.indexOf(a, n = f + r.length)) == -1 && t.push(e.slice(n));
  }
  return t.join("");
}
var If = { " ": 1, "	": 1, "\r": 1, "\n": 1, ">": 1 };
function pa(e, a) {
  for (var r = e.indexOf("<" + a), t = a.length + 1, n = e.length; r >= 0 && r <= n - t && !If[e.charAt(r + t)]; ) r = e.indexOf("<" + a, r + 1);
  if (r === -1) return null;
  var i = e.indexOf(">", r + a.length);
  if (i === -1) return null;
  var f = "</" + a + ">", s = e.indexOf(f, i);
  return s == -1 ? null : [e.slice(r, s + f.length), e.slice(i + 1, s)];
}
var ir = /* @__PURE__ */ (function() {
  var e = {};
  return function(r, t) {
    var n = e[t];
    n || (e[t] = n = [
      new RegExp("<(?:\\w+:)?" + t + "\\b[^<>]*>", "g"),
      new RegExp("</(?:\\w+:)?" + t + ">", "g")
    ]), n[0].lastIndex = n[1].lastIndex = 0;
    var i = n[0].exec(r);
    if (!i) return null;
    var f = i.index, s = n[0].lastIndex;
    if (n[1].lastIndex = n[0].lastIndex, i = n[1].exec(r), !i) return null;
    var c = i.index, o = n[1].lastIndex;
    return [r.slice(f, o), r.slice(s, c)];
  };
})(), ai = /* @__PURE__ */ (function() {
  var e = {};
  return function(r, t) {
    var n = [], i = e[t];
    i || (e[t] = i = [
      new RegExp("<(?:\\w+:)?" + t + "\\b[^<>]*>", "g"),
      new RegExp("</(?:\\w+:)?" + t + ">", "g")
    ]), i[0].lastIndex = i[1].lastIndex = 0;
    for (var f; f = i[0].exec(r); ) {
      var s = f.index;
      if (i[1].lastIndex = i[0].lastIndex, f = i[1].exec(r), !f) return null;
      var c = i[1].lastIndex;
      n.push(r.slice(s, c)), i[0].lastIndex = i[1].lastIndex;
    }
    return n.length == 0 ? null : n;
  };
})(), Of = /* @__PURE__ */ (function() {
  var e = {};
  return function(r, t) {
    var n = [], i = e[t];
    i || (e[t] = i = [
      new RegExp("<(?:\\w+:)?" + t + "\\b[^<>]*>", "g"),
      new RegExp("</(?:\\w+:)?" + t + ">", "g")
    ]), i[0].lastIndex = i[1].lastIndex = 0;
    for (var f, s = 0, c = 0; f = i[0].exec(r); ) {
      if (s = f.index, n.push(r.slice(c, s)), c = s, i[1].lastIndex = i[0].lastIndex, f = i[1].exec(r), !f) return null;
      c = i[1].lastIndex, i[0].lastIndex = i[1].lastIndex;
    }
    return n.push(r.slice(c)), n.length == 0 ? "" : n.join("");
  };
})(), Rf = /* @__PURE__ */ (function() {
  var e = {};
  return function(r, t) {
    var n = [], i = e[t];
    i || (e[t] = i = [
      new RegExp("<" + t + "\\b[^<>]*>", "ig"),
      new RegExp("</" + t + ">", "ig")
    ]), i[0].lastIndex = i[1].lastIndex = 0;
    for (var f; f = i[0].exec(r); ) {
      var s = f.index;
      if (i[1].lastIndex = i[0].lastIndex, f = i[1].exec(r), !f) return null;
      var c = i[1].lastIndex;
      n.push(r.slice(s, c)), i[0].lastIndex = i[1].lastIndex;
    }
    return n.length == 0 ? null : n;
  };
})();
function ti(e) {
  return e ? e.content && e.type ? ka(e.content, !0) : e.data ? Ha(e.data) : e.asNodeBuffer && Se ? Ha(e.asNodeBuffer().toString("binary")) : e.asBinary ? Ha(e.asBinary()) : e._data && e._data.getContent ? Ha(ka(Array.prototype.slice.call(e._data.getContent(), 0))) : null : null;
}
function ni(e) {
  if (!e) return null;
  if (e.data) return H0(e.data);
  if (e.asNodeBuffer && Se) return e.asNodeBuffer();
  if (e._data && e._data.getContent) {
    var a = e._data.getContent();
    return typeof a == "string" ? H0(a) : Array.prototype.slice.call(a);
  }
  return e.content && e.type ? e.content : null;
}
function Nf(e) {
  return e && e.name.slice(-4) === ".bin" ? ni(e) : ti(e);
}
function Pr(e, a) {
  for (var r = e.FullPaths || Lr(e.files), t = a.toLowerCase().replace(/[\/]/g, "\\"), n = t.replace(/\\/g, "/"), i = 0; i < r.length; ++i) {
    var f = r[i].replace(/^Root Entry[\/]/, "").toLowerCase();
    if (t == f || n == f) return e.files ? e.files[r[i]] : e.FileIndex[i];
  }
  return null;
}
function T0(e, a) {
  var r = Pr(e, a);
  if (r == null) throw new Error("Cannot find file " + a + " in zip");
  return r;
}
function Ze(e, a, r) {
  if (!r) return Nf(T0(e, a));
  if (!a) return null;
  try {
    return Ze(e, a);
  } catch {
    return null;
  }
}
function kr(e, a, r) {
  if (!r) return ti(T0(e, a));
  if (!a) return null;
  try {
    return kr(e, a);
  } catch {
    return null;
  }
}
function Pf(e, a, r) {
  return ni(T0(e, a));
}
function q0(e) {
  for (var a = e.FullPaths || Lr(e.files), r = [], t = 0; t < a.length; ++t) a[t].slice(-1) != "/" && r.push(a[t].replace(/^Root Entry[\/]/, ""));
  return r.sort();
}
function bf(e, a, r) {
  if (e.FullPaths) {
    if (Array.isArray(r) && typeof r[0] == "string" && (r = r.join("")), typeof r == "string") {
      var t;
      return Se ? t = oa(r) : t = Hs(r), Oe.utils.cfb_add(e, a, t);
    }
    Oe.utils.cfb_add(e, a, r);
  } else e.file(a, r);
}
function ii(e, a) {
  switch (a.type) {
    case "base64":
      return Oe.read(e, { type: "base64" });
    case "binary":
      return Oe.read(e, { type: "binary" });
    case "buffer":
    case "array":
      return Oe.read(e, { type: "buffer" });
  }
  throw new Error("Unrecognized type " + a.type);
}
function Da(e, a) {
  if (e.charAt(0) == "/") return e.slice(1);
  var r = a.split("/");
  a.slice(-1) != "/" && r.pop();
  for (var t = e.split("/"); t.length !== 0; ) {
    var n = t.shift();
    n === ".." ? r.pop() : n !== "." && r.push(n);
  }
  return r.join("/");
}
var si = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r
`, fi = /\s([^"\s?>\/]+)\s*=\s*((?:")([^"]*)(?:")|(?:')([^']*)(?:')|([^'">\s]+))/g, Q0 = /<[\/\?]?[a-zA-Z0-9:_-]+(?:\s+[^"\s?<>\/]+\s*=\s*(?:"[^"]*"|'[^']*'|[^'"<>\s=]+))*\s*[\/\?]?>/mg, Lf = /<[^<>]*>/g, or = /* @__PURE__ */ si.match(Q0) ? Q0 : Lf, Bf = /<\w*:/, Mf = /<(\/?)\w+:/;
function le(e, a, r) {
  for (var t = {}, n = 0, i = 0; n !== e.length && !((i = e.charCodeAt(n)) === 32 || i === 10 || i === 13); ++n) ;
  if (a || (t[0] = e.slice(0, n)), n === e.length) return t;
  var f = e.match(fi), s = 0, c = "", o = 0, l = "", v = "", d = 1;
  if (f) for (o = 0; o != f.length; ++o) {
    for (v = f[o].slice(1), i = 0; i != v.length && v.charCodeAt(i) !== 61; ++i) ;
    for (l = v.slice(0, i).trim(); v.charCodeAt(i + 1) == 32; ) ++i;
    for (d = (n = v.charCodeAt(i + 1)) == 34 || n == 39 ? 1 : 0, c = v.slice(i + 1 + d, v.length - d), s = 0; s != l.length && l.charCodeAt(s) !== 58; ++s) ;
    if (s === l.length)
      l.indexOf("_") > 0 && (l = l.slice(0, l.indexOf("_"))), t[l] = c, t[l.toLowerCase()] = c;
    else {
      var u = (s === 5 && l.slice(0, 5) === "xmlns" ? "xmlns" : "") + l.slice(s + 1);
      if (t[u] && l.slice(s - 3, s) == "ext") continue;
      t[u] = c, t[u.toLowerCase()] = c;
    }
  }
  return t;
}
function Uf(e, a, r) {
  for (var t = {}, n = 0, i = 0; n !== e.length && !((i = e.charCodeAt(n)) === 32 || i === 10 || i === 13); ++n) ;
  if (n === e.length) return t;
  var f = e.match(fi), s = "", c = 0, o = "", l = "", v = 1;
  if (f) for (c = 0; c != f.length; ++c) {
    for (l = f[c].slice(1), i = 0; i != l.length && l.charCodeAt(i) !== 61; ++i) ;
    for (o = l.slice(0, i).trim(); l.charCodeAt(i + 1) == 32; ) ++i;
    v = (n = l.charCodeAt(i + 1)) == 34 || n == 39 ? 1 : 0, s = l.slice(i + 1 + v, l.length - v), o.indexOf("_") > 0 && (o = o.slice(0, o.indexOf("_"))), t[o] = s, t[o.toLowerCase()] = s;
  }
  return t;
}
function Mr(e) {
  return e.replace(Mf, "<$1");
}
var ci = {
  "&quot;": '"',
  "&apos;": "'",
  "&gt;": ">",
  "&lt;": "<",
  "&amp;": "&"
}, Hf = /* @__PURE__ */ _0(ci), Ce = /* @__PURE__ */ (function() {
  var e = /&(?:quot|apos|gt|lt|amp|#x?([\da-fA-F]+));/ig, a = /_x([\da-fA-F]{4})_/ig;
  function r(t) {
    var n = t + "", i = n.indexOf("<![CDATA[");
    if (i == -1) return n.replace(e, function(s, c) {
      return ci[s] || String.fromCharCode(parseInt(c, s.indexOf("x") > -1 ? 16 : 10)) || s;
    }).replace(a, function(s, c) {
      return String.fromCharCode(parseInt(c, 16));
    });
    var f = n.indexOf("]]>");
    return r(n.slice(0, i)) + n.slice(i + 9, f) + r(n.slice(f + 3));
  }
  return function(n, i) {
    var f = r(n);
    return i ? f.replace(/\r\n/g, `
`) : f;
  };
})(), Wf = /[&<>'"]/g, Vf = /[\u0000-\u001f]/g;
function Ga(e) {
  var a = e + "";
  return a.replace(Wf, function(r) {
    return Hf[r];
  }).replace(/\n/g, "<br/>").replace(Vf, function(r) {
    return "&#x" + ("000" + r.charCodeAt(0).toString(16)).slice(-4) + ";";
  });
}
var en = /* @__PURE__ */ (function() {
  var e = /&#(\d+);/g;
  function a(r, t) {
    return String.fromCharCode(parseInt(t, 10));
  }
  return function(t) {
    return t.replace(e, a);
  };
})();
function Be(e) {
  switch (e) {
    case 1:
    case !0:
    case "1":
    case "true":
      return !0;
    case 0:
    case !1:
    case "0":
    case "false":
      return !1;
  }
  return !1;
}
function Zt(e) {
  for (var a = "", r = 0, t = 0, n = 0, i = 0, f = 0, s = 0; r < e.length; ) {
    if (t = e.charCodeAt(r++), t < 128) {
      a += String.fromCharCode(t);
      continue;
    }
    if (n = e.charCodeAt(r++), t > 191 && t < 224) {
      f = (t & 31) << 6, f |= n & 63, a += String.fromCharCode(f);
      continue;
    }
    if (i = e.charCodeAt(r++), t < 240) {
      a += String.fromCharCode((t & 15) << 12 | (n & 63) << 6 | i & 63);
      continue;
    }
    f = e.charCodeAt(r++), s = ((t & 7) << 18 | (n & 63) << 12 | (i & 63) << 6 | f & 63) - 65536, a += String.fromCharCode(55296 + (s >>> 10 & 1023)), a += String.fromCharCode(56320 + (s & 1023));
  }
  return a;
}
function rn(e) {
  var a = sa(2 * e.length), r, t, n = 1, i = 0, f = 0, s;
  for (t = 0; t < e.length; t += n)
    n = 1, (s = e.charCodeAt(t)) < 128 ? r = s : s < 224 ? (r = (s & 31) * 64 + (e.charCodeAt(t + 1) & 63), n = 2) : s < 240 ? (r = (s & 15) * 4096 + (e.charCodeAt(t + 1) & 63) * 64 + (e.charCodeAt(t + 2) & 63), n = 3) : (n = 4, r = (s & 7) * 262144 + (e.charCodeAt(t + 1) & 63) * 4096 + (e.charCodeAt(t + 2) & 63) * 64 + (e.charCodeAt(t + 3) & 63), r -= 65536, f = 55296 + (r >>> 10 & 1023), r = 56320 + (r & 1023)), f !== 0 && (a[i++] = f & 255, a[i++] = f >>> 8, f = 0), a[i++] = r % 256, a[i++] = r >>> 8;
  return a.slice(0, i).toString("ucs2");
}
function an(e) {
  return oa(e, "binary").toString("utf8");
}
var _t = "foo bar bazâð£", Ue = Se && (/* @__PURE__ */ an(_t) == /* @__PURE__ */ Zt(_t) && an || /* @__PURE__ */ rn(_t) == /* @__PURE__ */ Zt(_t) && rn) || Zt, Va = Se ? function(e) {
  return oa(e, "utf8").toString("binary");
} : function(e) {
  for (var a = [], r = 0, t = 0, n = 0; r < e.length; )
    switch (t = e.charCodeAt(r++), !0) {
      case t < 128:
        a.push(String.fromCharCode(t));
        break;
      case t < 2048:
        a.push(String.fromCharCode(192 + (t >> 6))), a.push(String.fromCharCode(128 + (t & 63)));
        break;
      case (t >= 55296 && t < 57344):
        t -= 55296, n = e.charCodeAt(r++) - 56320 + (t << 10), a.push(String.fromCharCode(240 + (n >> 18 & 7))), a.push(String.fromCharCode(144 + (n >> 12 & 63))), a.push(String.fromCharCode(128 + (n >> 6 & 63))), a.push(String.fromCharCode(128 + (n & 63)));
        break;
      default:
        a.push(String.fromCharCode(224 + (t >> 12))), a.push(String.fromCharCode(128 + (t >> 6 & 63))), a.push(String.fromCharCode(128 + (t & 63)));
    }
  return a.join("");
}, oi = /* @__PURE__ */ (function() {
  var e = [
    ["nbsp", " "],
    ["middot", "·"],
    ["quot", '"'],
    ["apos", "'"],
    ["gt", ">"],
    ["lt", "<"],
    ["amp", "&"]
  ].map(function(a) {
    return [new RegExp("&" + a[0] + ";", "ig"), a[1]];
  });
  return function(r) {
    for (var t = r.replace(/^[\t\n\r ]+/, "").replace(/(^|[^\t\n\r ])[\t\n\r ]+$/, "$1").replace(/>\s+/g, ">").replace(/\b\s+</g, "<").replace(/[\t\n\r ]+/g, " ").replace(/<\s*[bB][rR]\s*\/?>/g, `
`).replace(/<[^<>]*>/g, ""), n = 0; n < e.length; ++n) t = t.replace(e[n][0], e[n][1]);
    return t;
  };
})(), Gf = /<\/?(?:vt:)?variant>/g, Xf = /<(?:vt:)([^<"'>]*)>([\s\S]*)</;
function tn(e, a) {
  var r = le(e), t = ai(e, r.baseType) || [], n = [];
  if (t.length != r.size) {
    if (a.WTF) throw new Error("unexpected vector length " + t.length + " != " + r.size);
    return n;
  }
  return t.forEach(function(i) {
    var f = i.replace(Gf, "").match(Xf);
    f && n.push({ v: Ue(f[2]), t: f[1] });
  }), n;
}
var zf = /(^\s|\s$|\n)/;
function $f(e) {
  return Lr(e).map(function(a) {
    return " " + a + '="' + e[a] + '"';
  }).join("");
}
function Kf(e, a, r) {
  return "<" + e + (r != null ? $f(r) : "") + (a != null ? (a.match(zf) ? ' xml:space="preserve"' : "") + ">" + a + "</" + e : "/") + ">";
}
function Wt(e) {
  if (Se && /*::typeof Buffer !== "undefined" && d != null && d instanceof Buffer &&*/
  Buffer.isBuffer(e)) return e.toString("utf8");
  if (typeof e == "string") return e;
  if (typeof Uint8Array < "u" && e instanceof Uint8Array) return Ue(ea(v0(e)));
  throw new Error("Bad input format: expected Buffer or string");
}
var qe = /<([\/]?)([^\s?><!\/:"]*:|)([^\s?<>:\/"]+)(?:\s+[^<>=?"'\s]+="[^"]*?")*\s*[\/]?>/mg, Yf = {
  CT: "http://schemas.openxmlformats.org/package/2006/content-types"
}, jf = [
  "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
  "http://purl.oclc.org/ooxml/spreadsheetml/main",
  "http://schemas.microsoft.com/office/excel/2006/main",
  "http://schemas.microsoft.com/office/excel/2006/2"
];
function Jf(e, a) {
  for (var r = 1 - 2 * (e[a + 7] >>> 7), t = ((e[a + 7] & 127) << 4) + (e[a + 6] >>> 4 & 15), n = e[a + 6] & 15, i = 5; i >= 0; --i) n = n * 256 + e[a + i];
  return t == 2047 ? n == 0 ? r * (1 / 0) : NaN : (t == 0 ? t = -1022 : (t -= 1023, n += Math.pow(2, 52)), r * Math.pow(2, t - 52) * n);
}
function Zf(e, a, r) {
  var t = (a < 0 || 1 / a == -1 / 0 ? 1 : 0) << 7, n = 0, i = 0, f = t ? -a : a;
  isFinite(f) ? f == 0 ? n = i = 0 : (n = Math.floor(Math.log(f) / Math.LN2), i = f * Math.pow(2, 52 - n), n <= -1023 && (!isFinite(i) || i < Math.pow(2, 52)) ? n = -1022 : (i -= Math.pow(2, 52), n += 1023)) : (n = 2047, i = isNaN(a) ? 26985 : 0);
  for (var s = 0; s <= 5; ++s, i /= 256) e[r + s] = i & 255;
  e[r + 6] = (n & 15) << 4 | i & 15, e[r + 7] = n >> 4 | t;
}
var nn = function(e) {
  for (var a = [], r = 10240, t = 0; t < e[0].length; ++t) if (e[0][t]) for (var n = 0, i = e[0][t].length; n < i; n += r) a.push.apply(a, e[0][t].slice(n, n + r));
  return a;
}, sn = Se ? function(e) {
  return e[0].length > 0 && Buffer.isBuffer(e[0][0]) ? Buffer.concat(e[0].map(function(a) {
    return Buffer.isBuffer(a) ? a : oa(a);
  })) : nn(e);
} : nn, fn = function(e, a, r) {
  for (var t = [], n = a; n < r; n += 2) t.push(String.fromCharCode(Zr(e, n)));
  return t.join("").replace(wr, "");
}, w0 = Se ? function(e, a, r) {
  return !Buffer.isBuffer(e) || !rt ? fn(e, a, r) : e.toString("utf16le", a, r).replace(wr, "");
} : fn, cn = function(e, a, r) {
  for (var t = [], n = a; n < a + r; ++n) t.push(("0" + e[n].toString(16)).slice(-2));
  return t.join("");
}, li = Se ? function(e, a, r) {
  return Buffer.isBuffer(e) ? e.toString("hex", a, a + r) : cn(e, a, r);
} : cn, on = function(e, a, r) {
  for (var t = [], n = a; n < r; n++) t.push(String.fromCharCode(ya(e, n)));
  return t.join("");
}, lt = Se ? function(a, r, t) {
  return Buffer.isBuffer(a) ? a.toString("utf8", r, t) : on(a, r, t);
} : on, ui = function(e, a) {
  var r = Dr(e, a);
  return r > 0 ? lt(e, a + 4, a + 4 + r - 1) : "";
}, hi = ui, xi = function(e, a) {
  var r = Dr(e, a);
  return r > 0 ? lt(e, a + 4, a + 4 + r - 1) : "";
}, di = xi, vi = function(e, a) {
  var r = 2 * Dr(e, a);
  return r > 0 ? lt(e, a + 4, a + 4 + r - 1) : "";
}, pi = vi, gi = function(a, r) {
  var t = Dr(a, r);
  return t > 0 ? w0(a, r + 4, r + 4 + t) : "";
}, mi = gi, _i = function(e, a) {
  var r = Dr(e, a);
  return r > 0 ? lt(e, a + 4, a + 4 + r) : "";
}, ki = _i, Ei = function(e, a) {
  return Jf(e, a);
}, Rt = Ei, Ti = function(a) {
  return Array.isArray(a) || typeof Uint8Array < "u" && a instanceof Uint8Array;
};
Se && (hi = function(a, r) {
  if (!Buffer.isBuffer(a)) return ui(a, r);
  var t = a.readUInt32LE(r);
  return t > 0 ? a.toString("utf8", r + 4, r + 4 + t - 1) : "";
}, di = function(a, r) {
  if (!Buffer.isBuffer(a)) return xi(a, r);
  var t = a.readUInt32LE(r);
  return t > 0 ? a.toString("utf8", r + 4, r + 4 + t - 1) : "";
}, pi = function(a, r) {
  if (!Buffer.isBuffer(a) || !rt) return vi(a, r);
  var t = 2 * a.readUInt32LE(r);
  return a.toString("utf16le", r + 4, r + 4 + t - 1);
}, mi = function(a, r) {
  if (!Buffer.isBuffer(a) || !rt) return gi(a, r);
  var t = a.readUInt32LE(r);
  return a.toString("utf16le", r + 4, r + 4 + t);
}, ki = function(a, r) {
  if (!Buffer.isBuffer(a)) return _i(a, r);
  var t = a.readUInt32LE(r);
  return a.toString("utf8", r + 4, r + 4 + t);
}, Rt = function(a, r) {
  return Buffer.isBuffer(a) ? a.readDoubleLE(r) : Ei(a, r);
}, Ti = function(a) {
  return Buffer.isBuffer(a) || Array.isArray(a) || typeof Uint8Array < "u" && a instanceof Uint8Array;
});
var ya = function(e, a) {
  return e[a];
}, Zr = function(e, a) {
  return e[a + 1] * 256 + e[a];
}, qf = function(e, a) {
  var r = e[a + 1] * 256 + e[a];
  return r < 32768 ? r : (65535 - r + 1) * -1;
}, Dr = function(e, a) {
  return e[a + 3] * (1 << 24) + (e[a + 2] << 16) + (e[a + 1] << 8) + e[a];
}, da = function(e, a) {
  return e[a + 3] << 24 | e[a + 2] << 16 | e[a + 1] << 8 | e[a];
}, Qf = function(e, a) {
  return e[a] << 24 | e[a + 1] << 16 | e[a + 2] << 8 | e[a + 3];
};
function Xa(e, a) {
  var r = "", t, n, i = [], f, s, c, o;
  switch (a) {
    case "dbcs":
      if (o = this.l, Se && Buffer.isBuffer(this) && rt) r = this.slice(this.l, this.l + 2 * e).toString("utf16le");
      else for (c = 0; c < e; ++c)
        r += String.fromCharCode(Zr(this, o)), o += 2;
      e *= 2;
      break;
    case "utf8":
      r = lt(this, this.l, this.l + e);
      break;
    case "utf16le":
      e *= 2, r = w0(this, this.l, this.l + e);
      break;
    case "wstr":
      return Xa.call(this, e, "dbcs");
    /* [MS-OLEDS] 2.1.4 LengthPrefixedAnsiString */
    case "lpstr-ansi":
      r = hi(this, this.l), e = 4 + Dr(this, this.l);
      break;
    case "lpstr-cp":
      r = di(this, this.l), e = 4 + Dr(this, this.l);
      break;
    /* [MS-OLEDS] 2.1.5 LengthPrefixedUnicodeString */
    case "lpwstr":
      r = pi(this, this.l), e = 4 + 2 * Dr(this, this.l);
      break;
    /* [MS-OFFCRYPTO] 2.1.2 Length-Prefixed Padded Unicode String (UNICODE-LP-P4) */
    case "lpp4":
      e = 4 + Dr(this, this.l), r = mi(this, this.l), e & 2 && (e += 2);
      break;
    /* [MS-OFFCRYPTO] 2.1.3 Length-Prefixed UTF-8 String (UTF-8-LP-P4) */
    case "8lpp4":
      e = 4 + Dr(this, this.l), r = ki(this, this.l), e & 3 && (e += 4 - (e & 3));
      break;
    case "cstr":
      for (e = 0, r = ""; (f = ya(this, this.l + e++)) !== 0; ) i.push(mt(f));
      r = i.join("");
      break;
    case "_wstr":
      for (e = 0, r = ""; (f = Zr(this, this.l + e)) !== 0; )
        i.push(mt(f)), e += 2;
      e += 2, r = i.join("");
      break;
    /* sbcs and dbcs support continue records in the SST way TODO codepages */
    case "dbcs-cont":
      for (r = "", o = this.l, c = 0; c < e; ++c) {
        if (this.lens && this.lens.indexOf(o) !== -1)
          return f = ya(this, o), this.l = o + 1, s = Xa.call(this, e - c, f ? "dbcs-cont" : "sbcs-cont"), i.join("") + s;
        i.push(mt(Zr(this, o))), o += 2;
      }
      r = i.join(""), e *= 2;
      break;
    case "cpstr":
    /* falls through */
    case "sbcs-cont":
      for (r = "", o = this.l, c = 0; c != e; ++c) {
        if (this.lens && this.lens.indexOf(o) !== -1)
          return f = ya(this, o), this.l = o + 1, s = Xa.call(this, e - c, f ? "dbcs-cont" : "sbcs-cont"), i.join("") + s;
        i.push(mt(ya(this, o))), o += 1;
      }
      r = i.join("");
      break;
    default:
      switch (e) {
        case 1:
          return t = ya(this, this.l), this.l++, t;
        case 2:
          return t = (a === "i" ? qf : Zr)(this, this.l), this.l += 2, t;
        case 4:
        case -4:
          return a === "i" || (this[this.l + 3] & 128) === 0 ? (t = (e > 0 ? da : Qf)(this, this.l), this.l += 4, t) : (n = Dr(this, this.l), this.l += 4, n);
        case 8:
        case -8:
          if (a === "f")
            return e == 8 ? n = Rt(this, this.l) : n = Rt([this[this.l + 7], this[this.l + 6], this[this.l + 5], this[this.l + 4], this[this.l + 3], this[this.l + 2], this[this.l + 1], this[this.l + 0]], 0), this.l += 8, n;
          e = 8;
        /* falls through */
        case 16:
          r = li(this, this.l, e);
          break;
      }
  }
  return this.l += e, r;
}
var ec = function(e, a, r) {
  e[r] = a & 255, e[r + 1] = a >>> 8 & 255, e[r + 2] = a >>> 16 & 255, e[r + 3] = a >>> 24 & 255;
}, rc = function(e, a, r) {
  e[r] = a & 255, e[r + 1] = a >> 8 & 255, e[r + 2] = a >> 16 & 255, e[r + 3] = a >> 24 & 255;
}, ac = function(e, a, r) {
  e[r] = a & 255, e[r + 1] = a >>> 8 & 255;
};
function tc(e, a, r) {
  var t = 0, n = 0;
  if (r === "dbcs") {
    for (n = 0; n != a.length; ++n) ac(this, a.charCodeAt(n), this.l + 2 * n);
    t = 2 * a.length;
  } else if (r === "sbcs" || r == "cpstr") {
    for (a = a.replace(/[^\x00-\x7F]/g, "_"), n = 0; n != a.length; ++n) this[this.l + n] = a.charCodeAt(n) & 255;
    t = a.length;
  } else if (r === "hex") {
    for (; n < e; ++n)
      this[this.l++] = parseInt(a.slice(2 * n, 2 * n + 2), 16) || 0;
    return this;
  } else if (r === "utf16le") {
    var i = Math.min(this.l + e, this.length);
    for (n = 0; n < Math.min(a.length, e); ++n) {
      var f = a.charCodeAt(n);
      this[this.l++] = f & 255, this[this.l++] = f >> 8;
    }
    for (; this.l < i; ) this[this.l++] = 0;
    return this;
  } else switch (e) {
    case 1:
      t = 1, this[this.l] = a & 255;
      break;
    case 2:
      t = 2, this[this.l] = a & 255, a >>>= 8, this[this.l + 1] = a & 255;
      break;
    case 3:
      t = 3, this[this.l] = a & 255, a >>>= 8, this[this.l + 1] = a & 255, a >>>= 8, this[this.l + 2] = a & 255;
      break;
    case 4:
      t = 4, ec(this, a, this.l);
      break;
    case 8:
      if (t = 8, r === "f") {
        Zf(this, a, this.l);
        break;
      }
    /* falls through */
    case 16:
      break;
    case -4:
      t = 4, rc(this, a, this.l);
      break;
  }
  return this.l += t, this;
}
function wi(e, a) {
  var r = li(this, this.l, e.length >> 1);
  if (r !== e) throw new Error(a + "Expected " + e + " saw " + r);
  this.l += e.length >> 1;
}
function rr(e, a) {
  e.l = a, e.read_shift = /*::(*/
  Xa, e.chk = wi, e.write_shift = tc;
}
function pr(e, a) {
  e.l += a;
}
function Qe(e) {
  var a = sa(e);
  return rr(a, 0), a;
}
function ra(e, a, r) {
  if (e) {
    var t, n, i;
    rr(e, e.l || 0);
    for (var f = e.length, s = 0, c = 0; e.l < f; ) {
      s = e.read_shift(1), s & 128 && (s = (s & 127) + ((e.read_shift(1) & 127) << 7));
      var o = Mt[s] || Mt[65535];
      for (t = e.read_shift(1), i = t & 127, n = 1; n < 4 && t & 128; ++n) i += ((t = e.read_shift(1)) & 127) << 7 * n;
      c = e.l + i;
      var l = o.f && o.f(e, i, r);
      if (e.l = c, a(l, o, s)) return;
    }
  }
}
function s0() {
  var e = [], a = Se ? 16384 : 2048;
  Se && Qe(a).copy;
  var r = function(l) {
    var v = Qe(l);
    return rr(v, 0), v;
  }, t = r(a), n = function() {
    t && (t.l && (t.length > t.l && (t = t.slice(0, t.l), t.l = t.length), t.length > 0 && e.push(t)), t = null);
  }, i = function(l) {
    return t && l < t.length - t.l ? t : (n(), t = r(Math.max(l + 1, a)));
  }, f = function() {
    return n(), ta(e);
  }, s = function() {
    return n(), e;
  }, c = function(l) {
    n(), t = l, t.l == null && (t.l = t.length), i(a);
  };
  return { next: i, push: c, end: f, _bufs: e, end2: s };
}
function za(e, a, r) {
  var t = er(e);
  if (a.s ? (t.cRel && (t.c += a.s.c), t.rRel && (t.r += a.s.r)) : (t.cRel && (t.c += a.c), t.rRel && (t.r += a.r)), !r || r.biff < 12) {
    for (; t.c >= 256; ) t.c -= 256;
    for (; t.r >= 65536; ) t.r -= 65536;
  }
  return t;
}
function ln(e, a, r) {
  var t = er(e);
  return t.s = za(t.s, a.s, r), t.e = za(t.e, a.s, r), t;
}
function $a(e, a) {
  if (e.cRel && e.c < 0)
    for (e = er(e); e.c < 0; ) e.c += a > 8 ? 16384 : 256;
  if (e.rRel && e.r < 0)
    for (e = er(e); e.r < 0; ) e.r += a > 8 ? 1048576 : a > 5 ? 65536 : 16384;
  var r = Ne(e);
  return !e.cRel && e.cRel != null && (r = sc(r)), !e.rRel && e.rRel != null && (r = nc(r)), r;
}
function qt(e, a) {
  return e.s.r == 0 && !e.s.rRel && e.e.r == (a.biff >= 12 ? 1048575 : a.biff >= 8 ? 65536 : 16384) && !e.e.rRel ? (e.s.cRel ? "" : "$") + Pe(e.s.c) + ":" + (e.e.cRel ? "" : "$") + Pe(e.e.c) : e.s.c == 0 && !e.s.cRel && e.e.c == (a.biff >= 12 ? 16383 : 255) && !e.e.cRel ? (e.s.rRel ? "" : "$") + Me(e.s.r) + ":" + (e.e.rRel ? "" : "$") + Me(e.e.r) : $a(e.s, a.biff) + ":" + $a(e.e, a.biff);
}
function F0(e) {
  return parseInt(ic(e), 10) - 1;
}
function Me(e) {
  return "" + (e + 1);
}
function nc(e) {
  return e.replace(/([A-Z]|^)(\d+)$/, "$1$$$2");
}
function ic(e) {
  return e.replace(/\$(\d+)$/, "$1");
}
function A0(e) {
  for (var a = fc(e), r = 0, t = 0; t !== a.length; ++t) r = 26 * r + a.charCodeAt(t) - 64;
  return r - 1;
}
function Pe(e) {
  if (e < 0) throw new Error("invalid column " + e);
  var a = "";
  for (++e; e; e = Math.floor((e - 1) / 26)) a = String.fromCharCode((e - 1) % 26 + 65) + a;
  return a;
}
function sc(e) {
  return e.replace(/^([A-Z])/, "$$$1");
}
function fc(e) {
  return e.replace(/^\$([A-Z])/, "$1");
}
function cc(e) {
  return e.replace(/(\$?[A-Z]*)(\$?\d*)/, "$1,$2").split(",");
}
function dr(e) {
  for (var a = 0, r = 0, t = 0; t < e.length; ++t) {
    var n = e.charCodeAt(t);
    n >= 48 && n <= 57 ? a = 10 * a + (n - 48) : n >= 65 && n <= 90 && (r = 26 * r + (n - 64));
  }
  return { c: r - 1, r: a - 1 };
}
function Ne(e) {
  for (var a = e.c + 1, r = ""; a; a = (a - 1) / 26 | 0) r = String.fromCharCode((a - 1) % 26 + 65) + r;
  return r + (e.r + 1);
}
function wa(e) {
  var a = e.indexOf(":");
  return a == -1 ? { s: dr(e), e: dr(e) } : { s: dr(e.slice(0, a)), e: dr(e.slice(a + 1)) };
}
function ye(e, a) {
  return typeof a > "u" || typeof a == "number" ? ye(e.s, e.e) : (typeof e != "string" && (e = Ne(e)), typeof a != "string" && (a = Ne(a)), e == a ? e : e + ":" + a);
}
function oc(e, a) {
  if (!e && !(a && a.biff <= 5 && a.biff >= 2)) throw new Error("empty sheet name");
  return /[^\w\u4E00-\u9FFF\u3040-\u30FF]/.test(e) ? "'" + e.replace(/'/g, "''") + "'" : e;
}
function Ke(e) {
  var a = { s: { c: 0, r: 0 }, e: { c: 0, r: 0 } }, r = 0, t = 0, n = 0, i = e.length;
  for (r = 0; t < i && !((n = e.charCodeAt(t) - 64) < 1 || n > 26); ++t)
    r = 26 * r + n;
  for (a.s.c = --r, r = 0; t < i && !((n = e.charCodeAt(t) - 48) < 0 || n > 9); ++t)
    r = 10 * r + n;
  if (a.s.r = --r, t === i || n != 10)
    return a.e.c = a.s.c, a.e.r = a.s.r, a;
  for (++t, r = 0; t != i && !((n = e.charCodeAt(t) - 64) < 1 || n > 26); ++t)
    r = 26 * r + n;
  for (a.e.c = --r, r = 0; t != i && !((n = e.charCodeAt(t) - 48) < 0 || n > 9); ++t)
    r = 10 * r + n;
  return a.e.r = --r, a;
}
function un(e, a) {
  var r = e.t == "d" && a instanceof Date;
  if (e.z != null) try {
    return e.w = Fr(e.z, r ? ar(a) : a);
  } catch {
  }
  try {
    return e.w = Fr((e.XF || {}).numFmtId || (r ? 14 : 0), r ? ar(a) : a);
  } catch {
    return "" + a;
  }
}
function fa(e, a, r) {
  return e == null || e.t == null || e.t == "z" ? "" : e.w !== void 0 ? e.w : (e.t == "d" && !e.z && r && r.dateNF && (e.z = r.dateNF), e.t == "e" ? Ar[e.v] || e.v : a == null ? un(e, e.v) : un(e, a));
}
function la(e, a) {
  var r = a && a.sheet ? a.sheet : "Sheet1", t = {};
  return t[r] = e, { SheetNames: [r], Sheets: t };
}
function lc(e) {
  var a = {}, r = e || {};
  return r.dense && (a["!data"] = []), a;
}
function Fi(e, a, r) {
  var t = r || {}, n = e ? e["!data"] != null : t.dense, i = e || (n ? { "!data": [] } : {});
  n && !i["!data"] && (i["!data"] = []);
  var f = 0, s = 0;
  if (i && t.origin != null)
    if (typeof t.origin == "number") f = t.origin;
    else {
      var c = typeof t.origin == "string" ? dr(t.origin) : t.origin;
      f = c.r, s = c.c;
    }
  var o = { s: { c: 1e7, r: 1e7 }, e: { c: 0, r: 0 } };
  if (i["!ref"]) {
    var l = Ke(i["!ref"]);
    o.s.c = l.s.c, o.s.r = l.s.r, o.e.c = Math.max(o.e.c, l.e.c), o.e.r = Math.max(o.e.r, l.e.r), f == -1 && (o.e.r = f = i["!ref"] ? l.e.r + 1 : 0);
  } else
    o.s.c = o.e.c = o.s.r = o.e.r = 0;
  for (var v = [], d = !1, u = 0; u != a.length; ++u)
    if (a[u]) {
      if (!Array.isArray(a[u])) throw new Error("aoa_to_sheet expects an array of arrays");
      var p = f + u;
      n && (i["!data"][p] || (i["!data"][p] = []), v = i["!data"][p]);
      for (var _ = a[u], x = 0; x != _.length; ++x)
        if (!(typeof _[x] > "u")) {
          var h = { v: _[x], t: "" }, E = s + x;
          if (o.s.r > p && (o.s.r = p), o.s.c > E && (o.s.c = E), o.e.r < p && (o.e.r = p), o.e.c < E && (o.e.c = E), d = !0, _[x] && typeof _[x] == "object" && !Array.isArray(_[x]) && !(_[x] instanceof Date)) h = _[x];
          else if (Array.isArray(h.v) && (h.f = _[x][1], h.v = h.v[0]), h.v === null)
            if (h.f) h.t = "n";
            else if (t.nullError)
              h.t = "e", h.v = 0;
            else if (t.sheetStubs) h.t = "z";
            else continue;
          else typeof h.v == "number" ? isFinite(h.v) ? h.t = "n" : isNaN(h.v) ? (h.t = "e", h.v = 15) : (h.t = "e", h.v = 7) : typeof h.v == "boolean" ? h.t = "b" : h.v instanceof Date ? (h.z = t.dateNF || ge[14], t.UTC || (h.v = Ht(h.v)), t.cellDates ? (h.t = "d", h.w = Fr(h.z, ar(h.v, t.date1904))) : (h.t = "n", h.v = ar(h.v, t.date1904), h.w = Fr(h.z, h.v))) : h.t = "s";
          if (n)
            v[E] && v[E].z && (h.z = v[E].z), v[E] = h;
          else {
            var g = Pe(E) + (p + 1);
            i[g] && i[g].z && (h.z = i[g].z), i[g] = h;
          }
        }
    }
  return d && o.s.c < 104e5 && (i["!ref"] = ye(o)), i;
}
function La(e, a) {
  return Fi(null, e, a);
}
function uc(e) {
  return e.read_shift(4, "i");
}
function vr(e) {
  var a = e.read_shift(4);
  return a === 0 ? "" : e.read_shift(a, "dbcs");
}
function hc(e) {
  return { ich: e.read_shift(2), ifnt: e.read_shift(2) };
}
function S0(e, a) {
  var r = e.l, t = e.read_shift(1), n = vr(e), i = [], f = { t: n, h: n };
  if ((t & 1) !== 0) {
    for (var s = e.read_shift(4), c = 0; c != s; ++c) i.push(hc(e));
    f.r = i;
  } else f.r = [{ ich: 0, ifnt: 0 }];
  return e.l = r + a, f;
}
var xc = S0;
function Ur(e) {
  var a = e.read_shift(4), r = e.read_shift(2);
  return r += e.read_shift(1) << 16, e.l++, { c: a, iStyleRef: r };
}
function Fa(e) {
  var a = e.read_shift(2);
  return a += e.read_shift(1) << 16, e.l++, { c: -1, iStyleRef: a };
}
var dc = vr;
function Vt(e) {
  var a = e.read_shift(4);
  return a === 0 || a === 4294967295 ? "" : e.read_shift(a, "dbcs");
}
var vc = vr, f0 = Vt;
function Gt(e) {
  var a = e.slice(e.l, e.l + 4), r = a[0] & 1, t = a[0] & 2;
  e.l += 4;
  var n = t === 0 ? Rt([0, 0, 0, 0, a[0] & 252, a[1], a[2], a[3]], 0) : da(a, 0) >> 2;
  return r ? n / 100 : n;
}
function Ai(e) {
  var a = { s: {}, e: {} };
  return a.s.r = e.read_shift(4), a.e.r = e.read_shift(4), a.s.c = e.read_shift(4), a.e.c = e.read_shift(4), a;
}
var Aa = Ai;
function xr(e) {
  if (e.length - e.l < 8) throw "XLS Xnum Buffer underflow";
  return e.read_shift(8, "f");
}
function pc(e) {
  var a = {}, r = e.read_shift(1), t = r >>> 1, n = e.read_shift(1), i = e.read_shift(2, "i"), f = e.read_shift(1), s = e.read_shift(1), c = e.read_shift(1);
  switch (e.l++, t) {
    case 0:
      a.auto = 1;
      break;
    case 1:
      a.index = n;
      var o = ga[n];
      o && (a.rgb = it(o));
      break;
    case 2:
      a.rgb = it([f, s, c]);
      break;
    case 3:
      a.theme = n;
      break;
  }
  return i != 0 && (a.tint = i > 0 ? i / 32767 : i / 32768), a;
}
function gc(e) {
  var a = e.read_shift(1);
  e.l++;
  var r = {
    fBold: a & 1,
    fItalic: a & 2,
    fUnderline: a & 4,
    fStrikeout: a & 8,
    fOutline: a & 16,
    fShadow: a & 32,
    fCondense: a & 64,
    fExtend: a & 128
  };
  return r;
}
function Si(e, a) {
  var r = { 2: "BITMAP", 3: "METAFILEPICT", 8: "DIB", 14: "ENHMETAFILE" }, t = e.read_shift(4);
  switch (t) {
    case 0:
      return "";
    case 4294967295:
    case 4294967294:
      return r[e.read_shift(4)] || "";
  }
  if (t > 400) throw new Error("Unsupported Clipboard: " + t.toString(16));
  return e.l -= 4, e.read_shift(0, a == 1 ? "lpstr" : "lpwstr");
}
function mc(e) {
  return Si(e, 1);
}
function _c(e) {
  return Si(e, 2);
}
var C0 = 2, Tr = 3, kt = 11, hn = 12, Nt = 19, Et = 64, kc = 65, Ec = 71, Tc = 4108, wc = 4126, tr = 80, Ci = 81, Fc = [tr, Ci], Ac = {
  1: { n: "CodePage", t: C0 },
  2: { n: "Category", t: tr },
  3: { n: "PresentationFormat", t: tr },
  4: { n: "ByteCount", t: Tr },
  5: { n: "LineCount", t: Tr },
  6: { n: "ParagraphCount", t: Tr },
  7: { n: "SlideCount", t: Tr },
  8: { n: "NoteCount", t: Tr },
  9: { n: "HiddenCount", t: Tr },
  10: { n: "MultimediaClipCount", t: Tr },
  11: { n: "ScaleCrop", t: kt },
  12: {
    n: "HeadingPairs",
    t: Tc
    /* VT_VECTOR | VT_VARIANT */
  },
  13: {
    n: "TitlesOfParts",
    t: wc
    /* VT_VECTOR | VT_LPSTR */
  },
  14: { n: "Manager", t: tr },
  15: { n: "Company", t: tr },
  16: { n: "LinksUpToDate", t: kt },
  17: { n: "CharacterCount", t: Tr },
  19: { n: "SharedDoc", t: kt },
  22: { n: "HyperlinksChanged", t: kt },
  23: { n: "AppVersion", t: Tr, p: "version" },
  24: { n: "DigSig", t: kc },
  26: { n: "ContentType", t: tr },
  27: { n: "ContentStatus", t: tr },
  28: { n: "Language", t: tr },
  29: { n: "Version", t: tr },
  255: {},
  /* [MS-OLEPS] 2.18 */
  2147483648: { n: "Locale", t: Nt },
  2147483651: { n: "Behavior", t: Nt },
  1919054434: {}
}, Sc = {
  1: { n: "CodePage", t: C0 },
  2: { n: "Title", t: tr },
  3: { n: "Subject", t: tr },
  4: { n: "Author", t: tr },
  5: { n: "Keywords", t: tr },
  6: { n: "Comments", t: tr },
  7: { n: "Template", t: tr },
  8: { n: "LastAuthor", t: tr },
  9: { n: "RevNumber", t: tr },
  10: { n: "EditTime", t: Et },
  11: { n: "LastPrinted", t: Et },
  12: { n: "CreatedDate", t: Et },
  13: { n: "ModifiedDate", t: Et },
  14: { n: "PageCount", t: Tr },
  15: { n: "WordCount", t: Tr },
  16: { n: "CharCount", t: Tr },
  17: { n: "Thumbnail", t: Ec },
  18: { n: "Application", t: tr },
  19: { n: "DocSecurity", t: Tr },
  255: {},
  /* [MS-OLEPS] 2.18 */
  2147483648: { n: "Locale", t: Nt },
  2147483651: { n: "Behavior", t: Nt },
  1919054434: {}
}, xn = {
  1: "US",
  // United States
  2: "CA",
  // Canada
  3: "",
  // Latin America (except Brazil)
  7: "RU",
  // Russia
  20: "EG",
  // Egypt
  30: "GR",
  // Greece
  31: "NL",
  // Netherlands
  32: "BE",
  // Belgium
  33: "FR",
  // France
  34: "ES",
  // Spain
  36: "HU",
  // Hungary
  39: "IT",
  // Italy
  41: "CH",
  // Switzerland
  43: "AT",
  // Austria
  44: "GB",
  // United Kingdom
  45: "DK",
  // Denmark
  46: "SE",
  // Sweden
  47: "NO",
  // Norway
  48: "PL",
  // Poland
  49: "DE",
  // Germany
  52: "MX",
  // Mexico
  55: "BR",
  // Brazil
  61: "AU",
  // Australia
  64: "NZ",
  // New Zealand
  66: "TH",
  // Thailand
  81: "JP",
  // Japan
  82: "KR",
  // Korea
  84: "VN",
  // Viet Nam
  86: "CN",
  // China
  90: "TR",
  // Turkey
  105: "JS",
  // Ramastan
  213: "DZ",
  // Algeria
  216: "MA",
  // Morocco
  218: "LY",
  // Libya
  351: "PT",
  // Portugal
  354: "IS",
  // Iceland
  358: "FI",
  // Finland
  420: "CZ",
  // Czech Republic
  886: "TW",
  // Taiwan
  961: "LB",
  // Lebanon
  962: "JO",
  // Jordan
  963: "SY",
  // Syria
  964: "IQ",
  // Iraq
  965: "KW",
  // Kuwait
  966: "SA",
  // Saudi Arabia
  971: "AE",
  // United Arab Emirates
  972: "IL",
  // Israel
  974: "QA",
  // Qatar
  981: "IR",
  // Iran
  65535: "US"
  // United States
}, Cc = [
  null,
  "solid",
  "mediumGray",
  "darkGray",
  "lightGray",
  "darkHorizontal",
  "darkVertical",
  "darkDown",
  "darkUp",
  "darkGrid",
  "darkTrellis",
  "lightHorizontal",
  "lightVertical",
  "lightDown",
  "lightUp",
  "lightGrid",
  "lightTrellis",
  "gray125",
  "gray0625"
];
function yc(e) {
  return e.map(function(a) {
    return [a >> 16 & 255, a >> 8 & 255, a & 255];
  });
}
var Dc = /* @__PURE__ */ yc([
  /* Color Constants */
  0,
  16777215,
  16711680,
  65280,
  255,
  16776960,
  16711935,
  65535,
  /* Overridable Defaults */
  0,
  16777215,
  16711680,
  65280,
  255,
  16776960,
  16711935,
  65535,
  8388608,
  32768,
  128,
  8421376,
  8388736,
  32896,
  12632256,
  8421504,
  10066431,
  10040166,
  16777164,
  13434879,
  6684774,
  16744576,
  26316,
  13421823,
  128,
  16711935,
  16776960,
  65535,
  8388736,
  8388608,
  32896,
  255,
  52479,
  13434879,
  13434828,
  16777113,
  10079487,
  16751052,
  13408767,
  16764057,
  3368703,
  3394764,
  10079232,
  16763904,
  16750848,
  16737792,
  6710937,
  9868950,
  13158,
  3381606,
  13056,
  3355392,
  10040064,
  10040166,
  3355545,
  3355443,
  /* Other entries to appease BIFF8/12 */
  0,
  /* 0x40 icvForeground ?? */
  16777215,
  /* 0x41 icvBackground ?? */
  0,
  /* 0x42 icvFrame ?? */
  0,
  /* 0x43 icv3D ?? */
  0,
  /* 0x44 icv3DText ?? */
  0,
  /* 0x45 icv3DHilite ?? */
  0,
  /* 0x46 icv3DShadow ?? */
  0,
  /* 0x47 icvHilite ?? */
  0,
  /* 0x48 icvCtlText ?? */
  0,
  /* 0x49 icvCtlScrl ?? */
  0,
  /* 0x4A icvCtlInv ?? */
  0,
  /* 0x4B icvCtlBody ?? */
  0,
  /* 0x4C icvCtlFrame ?? */
  0,
  /* 0x4D icvCtlFore ?? */
  0,
  /* 0x4E icvCtlBack ?? */
  0,
  /* 0x4F icvCtlNeutral */
  0,
  /* 0x50 icvInfoBk ?? */
  0
  /* 0x51 icvInfoText ?? */
]), ga = /* @__PURE__ */ er(Dc), Ar = {
  0: "#NULL!",
  7: "#DIV/0!",
  15: "#VALUE!",
  23: "#REF!",
  29: "#NAME?",
  36: "#NUM!",
  42: "#N/A",
  43: "#GETTING_DATA",
  255: "#WTF?"
}, sr = {
  "#NULL!": 0,
  "#DIV/0!": 7,
  "#VALUE!": 15,
  "#REF!": 23,
  "#NAME?": 29,
  "#NUM!": 36,
  "#N/A": 42,
  "#GETTING_DATA": 43,
  "#WTF?": 255
}, yi = [
  "_xlnm.Consolidate_Area",
  "_xlnm.Auto_Open",
  "_xlnm.Auto_Close",
  "_xlnm.Extract",
  "_xlnm.Database",
  "_xlnm.Criteria",
  "_xlnm.Print_Area",
  "_xlnm.Print_Titles",
  "_xlnm.Recorder",
  "_xlnm.Data_Form",
  "_xlnm.Auto_Activate",
  "_xlnm.Auto_Deactivate",
  "_xlnm.Sheet_Title",
  "_xlnm._FilterDatabase"
], dn = {
  /* Workbook */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml": "workbooks",
  "application/vnd.ms-excel.sheet.macroEnabled.main+xml": "workbooks",
  "application/vnd.ms-excel.sheet.binary.macroEnabled.main": "workbooks",
  "application/vnd.ms-excel.addin.macroEnabled.main+xml": "workbooks",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.template.main+xml": "workbooks",
  /* Worksheet */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml": "sheets",
  "application/vnd.ms-excel.worksheet": "sheets",
  "application/vnd.ms-excel.binIndexWs": "TODO",
  /* Binary Index */
  /* Chartsheet */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.chartsheet+xml": "charts",
  "application/vnd.ms-excel.chartsheet": "charts",
  /* Macrosheet */
  "application/vnd.ms-excel.macrosheet+xml": "macros",
  "application/vnd.ms-excel.macrosheet": "macros",
  "application/vnd.ms-excel.intlmacrosheet": "TODO",
  "application/vnd.ms-excel.binIndexMs": "TODO",
  /* Binary Index */
  /* Dialogsheet */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.dialogsheet+xml": "dialogs",
  "application/vnd.ms-excel.dialogsheet": "dialogs",
  /* Shared Strings */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml": "strs",
  "application/vnd.ms-excel.sharedStrings": "strs",
  /* Styles */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml": "styles",
  "application/vnd.ms-excel.styles": "styles",
  /* File Properties */
  "application/vnd.openxmlformats-package.core-properties+xml": "coreprops",
  "application/vnd.openxmlformats-officedocument.custom-properties+xml": "custprops",
  "application/vnd.openxmlformats-officedocument.extended-properties+xml": "extprops",
  /* Custom Data Properties */
  "application/vnd.openxmlformats-officedocument.customXmlProperties+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.customProperty": "TODO",
  /* Comments */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml": "comments",
  "application/vnd.ms-excel.comments": "comments",
  "application/vnd.ms-excel.threadedcomments+xml": "threadedcomments",
  "application/vnd.ms-excel.person+xml": "people",
  /* Metadata (Stock/Geography and Dynamic Array) */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheetMetadata+xml": "metadata",
  "application/vnd.ms-excel.sheetMetadata": "metadata",
  /* PivotTable */
  "application/vnd.ms-excel.pivotTable": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotTable+xml": "TODO",
  /* Chart Objects */
  "application/vnd.openxmlformats-officedocument.drawingml.chart+xml": "TODO",
  /* Chart Colors */
  "application/vnd.ms-office.chartcolorstyle+xml": "TODO",
  /* Chart Style */
  "application/vnd.ms-office.chartstyle+xml": "TODO",
  /* Chart Advanced */
  "application/vnd.ms-office.chartex+xml": "TODO",
  /* Calculation Chain */
  "application/vnd.ms-excel.calcChain": "calcchains",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.calcChain+xml": "calcchains",
  /* Printer Settings */
  "application/vnd.openxmlformats-officedocument.spreadsheetml.printerSettings": "TODO",
  /* ActiveX */
  "application/vnd.ms-office.activeX": "TODO",
  "application/vnd.ms-office.activeX+xml": "TODO",
  /* Custom Toolbars */
  "application/vnd.ms-excel.attachedToolbars": "TODO",
  /* External Data Connections */
  "application/vnd.ms-excel.connections": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.connections+xml": "TODO",
  /* External Links */
  "application/vnd.ms-excel.externalLink": "links",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.externalLink+xml": "links",
  /* PivotCache */
  "application/vnd.ms-excel.pivotCacheDefinition": "TODO",
  "application/vnd.ms-excel.pivotCacheRecords": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotCacheDefinition+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotCacheRecords+xml": "TODO",
  /* Query Table */
  "application/vnd.ms-excel.queryTable": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.queryTable+xml": "TODO",
  /* Shared Workbook */
  "application/vnd.ms-excel.userNames": "TODO",
  "application/vnd.ms-excel.revisionHeaders": "TODO",
  "application/vnd.ms-excel.revisionLog": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionHeaders+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionLog+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.userNames+xml": "TODO",
  /* Single Cell Table */
  "application/vnd.ms-excel.tableSingleCells": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.tableSingleCells+xml": "TODO",
  /* Slicer */
  "application/vnd.ms-excel.slicer": "TODO",
  "application/vnd.ms-excel.slicerCache": "TODO",
  "application/vnd.ms-excel.slicer+xml": "TODO",
  "application/vnd.ms-excel.slicerCache+xml": "TODO",
  /* Sort Map */
  "application/vnd.ms-excel.wsSortMap": "TODO",
  /* Table */
  "application/vnd.ms-excel.table": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml": "TODO",
  /* Themes */
  "application/vnd.openxmlformats-officedocument.theme+xml": "themes",
  /* Theme Override */
  "application/vnd.openxmlformats-officedocument.themeOverride+xml": "TODO",
  /* Timeline */
  "application/vnd.ms-excel.Timeline+xml": "TODO",
  /* verify */
  "application/vnd.ms-excel.TimelineCache+xml": "TODO",
  /* verify */
  /* VBA */
  "application/vnd.ms-office.vbaProject": "vba",
  "application/vnd.ms-office.vbaProjectSignature": "TODO",
  /* Volatile Dependencies */
  "application/vnd.ms-office.volatileDependencies": "TODO",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.volatileDependencies+xml": "TODO",
  /* Control Properties */
  "application/vnd.ms-excel.controlproperties+xml": "TODO",
  /* Data Model */
  "application/vnd.openxmlformats-officedocument.model+data": "TODO",
  /* Survey */
  "application/vnd.ms-excel.Survey+xml": "TODO",
  /* Drawing */
  "application/vnd.openxmlformats-officedocument.drawing+xml": "drawings",
  "application/vnd.openxmlformats-officedocument.drawingml.chartshapes+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.drawingml.diagramColors+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.drawingml.diagramData+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.drawingml.diagramLayout+xml": "TODO",
  "application/vnd.openxmlformats-officedocument.drawingml.diagramStyle+xml": "TODO",
  /* VML */
  "application/vnd.openxmlformats-officedocument.vmlDrawing": "TODO",
  "application/vnd.openxmlformats-package.relationships+xml": "rels",
  "application/vnd.openxmlformats-officedocument.oleObject": "TODO",
  /* Image */
  "image/png": "TODO",
  sheet: "js"
};
function Ic() {
  return {
    workbooks: [],
    sheets: [],
    charts: [],
    dialogs: [],
    macros: [],
    rels: [],
    strs: [],
    comments: [],
    threadedcomments: [],
    links: [],
    coreprops: [],
    extprops: [],
    custprops: [],
    themes: [],
    styles: [],
    calcchains: [],
    vba: [],
    drawings: [],
    metadata: [],
    people: [],
    TODO: [],
    xmlns: ""
  };
}
function Oc(e) {
  var a = Ic();
  if (!e || !e.match) return a;
  var r = {};
  if ((e.match(or) || []).forEach(function(t) {
    var n = le(t);
    switch (n[0].replace(Bf, "<")) {
      case "<?xml":
        break;
      case "<Types":
        a.xmlns = n["xmlns" + (n[0].match(/<(\w+):/) || ["", ""])[1]];
        break;
      case "<Default":
        r[n.Extension.toLowerCase()] = n.ContentType;
        break;
      case "<Override":
        a[dn[n.ContentType]] !== void 0 && a[dn[n.ContentType]].push(n.PartName);
        break;
    }
  }), a.xmlns !== Yf.CT) throw new Error("Unknown Namespace: " + a.xmlns);
  return a.calcchain = a.calcchains.length > 0 ? a.calcchains[0] : "", a.sst = a.strs.length > 0 ? a.strs[0] : "", a.style = a.styles.length > 0 ? a.styles[0] : "", a.defaults = r, delete a.calcchains, a;
}
var Ia = {
  WB: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument",
  SHEET: "http://sheetjs.openxmlformats.org/officeDocument/2006/relationships/officeDocument",
  HLINK: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
  VML: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/vmlDrawing",
  XPATH: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/externalLinkPath",
  XMISS: "http://schemas.microsoft.com/office/2006/relationships/xlExternalLinkPath/xlPathMissing",
  XLINK: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/externalLink",
  CXML: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml",
  CXMLP: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXmlProps",
  CMNT: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments",
  CORE_PROPS: "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties",
  EXT_PROPS: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties",
  CUST_PROPS: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties",
  SST: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings",
  STY: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles",
  THEME: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme",
  CHART: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart",
  CHARTEX: "http://schemas.microsoft.com/office/2014/relationships/chartEx",
  CS: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/chartsheet",
  WS: [
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet",
    "http://purl.oclc.org/ooxml/officeDocument/relationships/worksheet"
  ],
  DS: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/dialogsheet",
  MS: "http://schemas.microsoft.com/office/2006/relationships/xlMacrosheet",
  IMG: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
  DRAW: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing",
  XLMETA: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sheetMetadata",
  TCMNT: "http://schemas.microsoft.com/office/2017/10/relationships/threadedComment",
  PEOPLE: "http://schemas.microsoft.com/office/2017/10/relationships/person",
  CONN: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/connections",
  VBA: "http://schemas.microsoft.com/office/2006/relationships/vbaProject"
};
function c0(e) {
  var a = e.lastIndexOf("/");
  return e.slice(0, a + 1) + "_rels/" + e.slice(a + 1) + ".rels";
}
function Ka(e, a) {
  var r = { "!id": {} };
  if (!e) return r;
  a.charAt(0) !== "/" && (a = "/" + a);
  var t = {};
  return (e.match(or) || []).forEach(function(n) {
    var i = le(n);
    if (i[0] === "<Relationship") {
      var f = {};
      f.Type = i.Type, f.Target = Ce(i.Target), f.Id = i.Id, i.TargetMode && (f.TargetMode = i.TargetMode);
      var s = i.TargetMode === "External" ? i.Target : Da(i.Target, a);
      r[s] = f, t[i.Id] = f;
    }
  }), r["!id"] = t, r;
}
var Rc = "application/vnd.oasis.opendocument.spreadsheet";
function Nc(e, a) {
  for (var r = Wt(e), t, n; t = qe.exec(r); )
    switch (t[3]) {
      case "manifest":
        break;
      case "file-entry":
        if (n = le(t[0], !1), n.path == "/" && n.type !== Rc)
          throw new Error("This OpenDocument is not a spreadsheet");
        break;
      case "encryption-data":
      case "algorithm":
      case "start-key-generation":
      case "key-derivation":
        throw new Error("Unsupported ODS Encryption");
      default:
        if (a && a.WTF)
          throw t;
    }
}
var vn = [
  ["cp:category", "Category"],
  ["cp:contentStatus", "ContentStatus"],
  ["cp:keywords", "Keywords"],
  ["cp:lastModifiedBy", "LastAuthor"],
  ["cp:lastPrinted", "LastPrinted"],
  ["cp:revision", "RevNumber"],
  ["cp:version", "Version"],
  ["dc:creator", "Author"],
  ["dc:description", "Comments"],
  ["dc:identifier", "Identifier"],
  ["dc:language", "Language"],
  ["dc:subject", "Subject"],
  ["dc:title", "Title"],
  ["dcterms:created", "CreatedDate", "date"],
  ["dcterms:modified", "ModifiedDate", "date"]
];
function Di(e) {
  var a = {};
  e = Ue(e);
  for (var r = 0; r < vn.length; ++r) {
    var t = vn[r], n = pa(e, t[0]);
    n != null && n.length > 0 && (a[t[1]] = Ce(n[1])), t[2] === "date" && a[t[1]] && (a[t[1]] = cr(a[t[1]]));
  }
  return a;
}
var Pc = [
  ["Application", "Application", "string"],
  ["AppVersion", "AppVersion", "string"],
  ["Company", "Company", "string"],
  ["DocSecurity", "DocSecurity", "string"],
  ["Manager", "Manager", "string"],
  ["HyperlinksChanged", "HyperlinksChanged", "bool"],
  ["SharedDoc", "SharedDoc", "bool"],
  ["LinksUpToDate", "LinksUpToDate", "bool"],
  ["ScaleCrop", "ScaleCrop", "bool"],
  ["HeadingPairs", "HeadingPairs", "raw"],
  ["TitlesOfParts", "TitlesOfParts", "raw"]
];
function Ii(e, a, r, t) {
  var n = [];
  if (typeof e == "string") n = tn(e, t);
  else for (var i = 0; i < e.length; ++i) n = n.concat(e[i].map(function(l) {
    return { v: l };
  }));
  var f = typeof a == "string" ? tn(a, t).map(function(l) {
    return l.v;
  }) : a, s = 0, c = 0;
  if (f.length > 0) for (var o = 0; o !== n.length; o += 2) {
    switch (c = +n[o + 1].v, n[o].v) {
      case "Worksheets":
      case "工作表":
      case "Листы":
      case "أوراق العمل":
      case "ワークシート":
      case "גליונות עבודה":
      case "Arbeitsblätter":
      case "Çalışma Sayfaları":
      case "Feuilles de calcul":
      case "Fogli di lavoro":
      case "Folhas de cálculo":
      case "Planilhas":
      case "Regneark":
      case "Hojas de cálculo":
      case "Werkbladen":
        r.Worksheets = c, r.SheetNames = f.slice(s, s + c);
        break;
      case "Named Ranges":
      case "Rangos con nombre":
      case "名前付き一覧":
      case "Benannte Bereiche":
      case "Navngivne områder":
        r.NamedRanges = c, r.DefinedNames = f.slice(s, s + c);
        break;
      case "Charts":
      case "Diagramme":
        r.Chartsheets = c, r.ChartNames = f.slice(s, s + c);
        break;
    }
    s += c;
  }
}
function bc(e, a, r) {
  var t = {};
  return a || (a = {}), e = Ue(e), Pc.forEach(function(n) {
    var i = (ir(e, n[0]) || [])[1];
    switch (n[2]) {
      case "string":
        i && (a[n[1]] = Ce(i));
        break;
      case "bool":
        a[n[1]] = i === "true";
        break;
      case "raw":
        var f = pa(e, n[0]);
        f && f.length > 0 && (t[n[1]] = f[1]);
        break;
    }
  }), t.HeadingPairs && t.TitlesOfParts && Ii(t.HeadingPairs, t.TitlesOfParts, a, r), a;
}
var Lc = /<[^<>]+>[^<]*/g;
function Bc(e, a) {
  var r = {}, t = "", n = e.match(Lc);
  if (n) for (var i = 0; i != n.length; ++i) {
    var f = n[i], s = le(f);
    switch (Mr(s[0])) {
      case "<?xml":
        break;
      case "<Properties":
        break;
      case "<property":
        t = Ce(s.name);
        break;
      case "</property>":
        t = null;
        break;
      default:
        if (f.indexOf("<vt:") === 0) {
          var c = f.split(">"), o = c[0].slice(4), l = c[1];
          switch (o) {
            case "lpstr":
            case "bstr":
            case "lpwstr":
              r[t] = Ce(l);
              break;
            case "bool":
              r[t] = Be(l);
              break;
            case "i1":
            case "i2":
            case "i4":
            case "i8":
            case "int":
            case "uint":
              r[t] = parseInt(l, 10);
              break;
            case "r4":
            case "r8":
            case "decimal":
              r[t] = parseFloat(l);
              break;
            case "filetime":
            case "date":
              r[t] = cr(l);
              break;
            case "cy":
            case "error":
              r[t] = Ce(l);
              break;
            default:
              if (o.slice(-1) == "/") break;
              a.WTF && typeof console < "u" && console.warn("Unexpected", f, o, c);
          }
        } else if (f.slice(0, 2) !== "</") {
          if (a.WTF) throw new Error(f);
        }
    }
  }
  return r;
}
var Mc = {
  Title: "Title",
  Subject: "Subject",
  Author: "Author",
  Keywords: "Keywords",
  Comments: "Description",
  LastAuthor: "LastAuthor",
  RevNumber: "Revision",
  Application: "AppName",
  /* TotalTime: 'TotalTime', */
  LastPrinted: "LastPrinted",
  CreatedDate: "Created",
  ModifiedDate: "LastSaved",
  /* Pages */
  /* Words */
  /* Characters */
  Category: "Category",
  /* PresentationFormat */
  Manager: "Manager",
  Company: "Company",
  /* Guid */
  /* HyperlinkBase */
  /* Bytes */
  /* Lines */
  /* Paragraphs */
  /* CharactersWithSpaces */
  AppVersion: "Version",
  ContentStatus: "ContentStatus",
  /* NOTE: missing from schema */
  Identifier: "Identifier",
  /* NOTE: missing from schema */
  Language: "Language"
  /* NOTE: missing from schema */
}, Qt;
function Uc(e, a, r) {
  Qt || (Qt = _0(Mc)), a = Qt[a] || a, e[a] = r;
}
function y0(e) {
  var a = e.read_shift(4), r = e.read_shift(4);
  return new Date((r / 1e7 * Math.pow(2, 32) + a / 1e7 - 11644473600) * 1e3).toISOString().replace(/\.000/, "");
}
function Hc(e, a, r) {
  var t = e.l, n = e.read_shift(0, "lpstr-cp");
  if (r) for (; e.l - t & 3; ) ++e.l;
  return n;
}
function Wc(e, a, r) {
  var t = e.read_shift(0, "lpwstr");
  return t;
}
function Oi(e, a, r) {
  return a === 31 ? Wc(e) : Hc(e, a, r);
}
function Ya(e, a, r) {
  return Oi(e, a, r === !1 ? 0 : 4);
}
function Vc(e, a) {
  if (!a) throw new Error("VtUnalignedString must have positive length");
  return Oi(e, a, 0);
}
function Gc(e) {
  for (var a = e.read_shift(4), r = [], t = 0; t != a; ++t) {
    var n = e.l;
    r[t] = e.read_shift(0, "lpwstr").replace(wr, ""), e.l - n & 2 && (e.l += 2);
  }
  return r;
}
function Xc(e) {
  for (var a = e.read_shift(4), r = [], t = 0; t != a; ++t) r[t] = e.read_shift(0, "lpstr-cp").replace(wr, "");
  return r;
}
function zc(e) {
  var a = e.l, r = Pt(e, Ci);
  e[e.l] == 0 && e[e.l + 1] == 0 && e.l - a & 2 && (e.l += 2);
  var t = Pt(e, Tr);
  return [r, t];
}
function $c(e) {
  for (var a = e.read_shift(4), r = [], t = 0; t < a / 2; ++t) r.push(zc(e));
  return r;
}
function pn(e, a) {
  for (var r = e.read_shift(4), t = {}, n = 0; n != r; ++n) {
    var i = e.read_shift(4), f = e.read_shift(4);
    t[i] = e.read_shift(f, a === 1200 ? "utf16le" : "utf8").replace(wr, "").replace(Wa, "!"), a === 1200 && f % 2 && (e.l += 2);
  }
  return e.l & 3 && (e.l = e.l >> 3 << 2), t;
}
function Ri(e) {
  var a = e.read_shift(4), r = e.slice(e.l, e.l + a);
  return e.l += a, (a & 3) > 0 && (e.l += 4 - (a & 3) & 3), r;
}
function Kc(e) {
  var a = {};
  return a.Size = e.read_shift(4), e.l += a.Size + 3 - (a.Size - 1) % 4, a;
}
function Pt(e, a, r) {
  var t = e.read_shift(2), n, i = r || {};
  if (e.l += 2, a !== hn && t !== a && Fc.indexOf(a) === -1 && !((a & 65534) == 4126 && (t & 65534) == 4126))
    throw new Error("Expected type " + a + " saw " + t);
  switch (a === hn ? t : a) {
    case 2:
      return n = e.read_shift(2, "i"), i.raw || (e.l += 2), n;
    case 3:
      return n = e.read_shift(4, "i"), n;
    case 11:
      return e.read_shift(4) !== 0;
    case 19:
      return n = e.read_shift(4), n;
    case 30:
      e.l += 4, val = Ya(e, e[e.l - 4]).replace(/(^|[^\u0000])\u0000+$/, "$1");
      break;
    case 31:
      e.l += 4, val = Ya(e, e[e.l - 4]).replace(/(^|[^\u0000])\u0000+$/, "$1");
      break;
    case 64:
      return y0(e);
    case 65:
      return Ri(e);
    case 71:
      return Kc(e);
    case 80:
      return Ya(e, t, !i.raw).replace(wr, "");
    case 81:
      return Vc(
        e,
        t
        /*, 4*/
      ).replace(wr, "");
    case 4108:
      return $c(e);
    case 4126:
    case 4127:
      return t == 4127 ? Gc(e) : Xc(e);
    default:
      throw new Error("TypedPropertyValue unrecognized type " + a + " " + t);
  }
}
function gn(e, a) {
  var r = e.l, t = e.read_shift(4), n = e.read_shift(4), i = [], f = 0, s = 0, c = -1, o = {};
  for (f = 0; f != n; ++f) {
    var l = e.read_shift(4), v = e.read_shift(4);
    i[f] = [l, v + r];
  }
  i.sort(function(E, g) {
    return E[1] - g[1];
  });
  var d = {};
  for (f = 0; f != n; ++f) {
    if (e.l !== i[f][1]) {
      var u = !0;
      if (f > 0 && a) switch (a[i[f - 1][0]].t) {
        case 2:
          e.l + 2 === i[f][1] && (e.l += 2, u = !1);
          break;
        case 80:
          e.l <= i[f][1] && (e.l = i[f][1], u = !1);
          break;
        case 4108:
          e.l <= i[f][1] && (e.l = i[f][1], u = !1);
          break;
      }
      if ((!a || f == 0) && e.l <= i[f][1] && (u = !1, e.l = i[f][1]), u) throw new Error("Read Error: Expected address " + i[f][1] + " at " + e.l + " :" + f);
    }
    if (a) {
      if (i[f][0] == 0 && i.length > f + 1 && i[f][1] == i[f + 1][1]) continue;
      var p = a[i[f][0]];
      if (d[p.n] = Pt(e, p.t, { raw: !0 }), p.p === "version" && (d[p.n] = String(d[p.n] >> 16) + "." + ("0000" + String(d[p.n] & 65535)).slice(-4)), p.n == "CodePage") switch (d[p.n]) {
        case 0:
          d[p.n] = 1252;
        /* falls through */
        case 874:
        case 932:
        case 936:
        case 949:
        case 950:
        case 1250:
        case 1251:
        case 1253:
        case 1254:
        case 1255:
        case 1256:
        case 1257:
        case 1258:
        case 1e4:
        case 1200:
        case 1201:
        case 1252:
        case 65e3:
        case -536:
        case 65001:
        case -535:
          Vr(s = d[p.n] >>> 0 & 65535);
          break;
        default:
          throw new Error("Unsupported CodePage: " + d[p.n]);
      }
    } else if (i[f][0] === 1) {
      if (s = d.CodePage = Pt(e, C0), Vr(s), c !== -1) {
        var _ = e.l;
        e.l = i[c][1], o = pn(e, s), e.l = _;
      }
    } else if (i[f][0] === 0) {
      if (s === 0) {
        c = f, e.l = i[f + 1][1];
        continue;
      }
      o = pn(e, s);
    } else {
      var x = o[i[f][0]], h;
      switch (e[e.l]) {
        case 65:
          e.l += 4, h = Ri(e);
          break;
        case 30:
          e.l += 4, h = Ya(e, e[e.l - 4]).replace(/(^|[^\u0000])\u0000+$/, "$1");
          break;
        case 31:
          e.l += 4, h = Ya(e, e[e.l - 4]).replace(/(^|[^\u0000])\u0000+$/, "$1");
          break;
        case 3:
          e.l += 4, h = e.read_shift(4, "i");
          break;
        case 19:
          e.l += 4, h = e.read_shift(4);
          break;
        case 5:
          e.l += 4, h = e.read_shift(8, "f");
          break;
        case 11:
          e.l += 4, h = $e(e, 4);
          break;
        case 64:
          e.l += 4, h = cr(y0(e));
          break;
        default:
          throw new Error("unparsed value: " + e[e.l]);
      }
      d[x] = h;
    }
  }
  return e.l = r + t, d;
}
function mn(e, a, r) {
  var t = e.content;
  if (!t) return {};
  rr(t, 0);
  var n, i, f, s, c = 0;
  t.chk("feff", "Byte Order: "), t.read_shift(2);
  var o = t.read_shift(4), l = t.read_shift(16);
  if (l !== Oe.utils.consts.HEADER_CLSID && l !== r) throw new Error("Bad PropertySet CLSID " + l);
  if (n = t.read_shift(4), n !== 1 && n !== 2) throw new Error("Unrecognized #Sets: " + n);
  if (i = t.read_shift(16), s = t.read_shift(4), n === 1 && s !== t.l) throw new Error("Length mismatch: " + s + " !== " + t.l);
  n === 2 && (f = t.read_shift(16), c = t.read_shift(4));
  var v = gn(t, a), d = { SystemIdentifier: o };
  for (var u in v) d[u] = v[u];
  if (d.FMTID = i, n === 1) return d;
  if (c - t.l == 2 && (t.l += 2), t.l !== c) throw new Error("Length mismatch 2: " + t.l + " !== " + c);
  var p;
  try {
    p = gn(t, null);
  } catch {
  }
  for (u in p) d[u] = p[u];
  return d.FMTID = [i, f], d;
}
function aa(e, a) {
  return e.read_shift(a), null;
}
function Yc(e, a, r) {
  for (var t = [], n = e.l + a; e.l < n; ) t.push(r(e, n - e.l));
  if (n !== e.l) throw new Error("Slurp error");
  return t;
}
function $e(e, a) {
  return e.read_shift(a) === 1;
}
function ze(e) {
  return e.read_shift(2, "u");
}
function Ni(e, a) {
  return Yc(e, a, ze);
}
function Pi(e) {
  var a = e.read_shift(1), r = e.read_shift(1);
  return r === 1 ? a : a === 1;
}
function Pa(e, a, r) {
  var t = e.read_shift(r && r.biff >= 12 ? 2 : 1), n = "sbcs-cont", i = br;
  if (r && r.biff >= 8 && (br = 1200), !r || r.biff == 8) {
    var f = e.read_shift(1);
    f && (n = "dbcs-cont");
  } else r.biff == 12 && (n = "wstr");
  r.biff >= 2 && r.biff <= 5 && (n = "cpstr");
  var s = t ? e.read_shift(t, n) : "";
  return br = i, s;
}
function jc(e) {
  var a = br;
  br = 1200;
  var r = e.read_shift(2), t = e.read_shift(1), n = t & 4, i = t & 8, f = 1 + (t & 1), s = 0, c, o = {};
  i && (s = e.read_shift(2)), n && (c = e.read_shift(4));
  var l = f == 2 ? "dbcs-cont" : "sbcs-cont", v = r === 0 ? "" : e.read_shift(r, l);
  return i && (e.l += 4 * s), n && (e.l += c), o.t = v, i || (o.raw = "<t>" + o.t + "</t>", o.r = o.t), br = a, o;
}
function Ta(e, a, r) {
  var t;
  if (r) {
    if (r.biff >= 2 && r.biff <= 5) return e.read_shift(a, "cpstr");
    if (r.biff >= 12) return e.read_shift(a, "dbcs-cont");
  }
  var n = e.read_shift(1);
  return n === 0 ? t = e.read_shift(a, "sbcs-cont") : t = e.read_shift(a, "dbcs-cont"), t;
}
function ut(e, a, r) {
  var t = e.read_shift(r && r.biff == 2 ? 1 : 2);
  return t === 0 ? (e.l++, "") : Ta(e, t, r);
}
function Sa(e, a, r) {
  if (r.biff > 5) return ut(e, a, r);
  var t = e.read_shift(1);
  return t === 0 ? (e.l++, "") : e.read_shift(t, r.biff <= 4 || !e.lens ? "cpstr" : "sbcs-cont");
}
function Jc(e) {
  var a = e.read_shift(1);
  e.l++;
  var r = e.read_shift(2);
  return e.l += 2, [a, r];
}
function Zc(e) {
  var a = e.read_shift(4), r = e.l, t = !1;
  a > 24 && (e.l += a - 24, e.read_shift(16) === "795881f43b1d7f48af2c825dc4852763" && (t = !0), e.l = r);
  var n = e.read_shift((t ? a - 24 : a) >> 1, "utf16le").replace(wr, "");
  return t && (e.l += 24), n;
}
function qc(e) {
  for (var a = e.read_shift(2), r = ""; a-- > 0; ) r += "../";
  var t = e.read_shift(0, "lpstr-ansi");
  if (e.l += 2, e.read_shift(2) != 57005) throw new Error("Bad FileMoniker");
  var n = e.read_shift(4);
  if (n === 0) return r + t.replace(/\\/g, "/");
  var i = e.read_shift(4);
  if (e.read_shift(2) != 3) throw new Error("Bad FileMoniker");
  var f = e.read_shift(i >> 1, "utf16le").replace(wr, "");
  return r + f;
}
function Qc(e, a) {
  var r = e.read_shift(16);
  switch (r) {
    case "e0c9ea79f9bace118c8200aa004ba90b":
      return Zc(e);
    case "0303000000000000c000000000000046":
      return qc(e);
    default:
      throw new Error("Unsupported Moniker " + r);
  }
}
function Tt(e) {
  var a = e.read_shift(4), r = a > 0 ? e.read_shift(a, "utf16le").replace(wr, "") : "";
  return r;
}
function eo(e, a) {
  var r = e.l + a, t = e.read_shift(4);
  if (t !== 2) throw new Error("Unrecognized streamVersion: " + t);
  var n = e.read_shift(2);
  e.l += 2;
  var i, f, s, c, o = "", l, v;
  n & 16 && (i = Tt(e, r - e.l)), n & 128 && (f = Tt(e, r - e.l)), (n & 257) === 257 && (s = Tt(e, r - e.l)), (n & 257) === 1 && (c = Qc(e, r - e.l)), n & 8 && (o = Tt(e, r - e.l)), n & 32 && (l = e.read_shift(16)), n & 64 && (v = y0(
    e
    /*, 8*/
  )), e.l = r;
  var d = f || s || c || "";
  d && o && (d += "#" + o), d || (d = "#" + o), n & 2 && d.charAt(0) == "/" && d.charAt(1) != "/" && (d = "file://" + d);
  var u = { Target: d };
  return l && (u.guid = l), v && (u.time = v), i && (u.Tooltip = i), u;
}
function bi(e) {
  var a = e.read_shift(1), r = e.read_shift(1), t = e.read_shift(1), n = e.read_shift(1);
  return [a, r, t, n];
}
function Li(e, a) {
  var r = bi(e);
  return r[3] = 0, r;
}
function Xr(e, a, r) {
  var t = e.read_shift(2), n = e.read_shift(2), i = { r: t, c: n, ixfe: 0 };
  if (r && r.biff == 2 || a == 7) {
    var f = e.read_shift(1);
    i.ixfe = f & 63, e.l += 2;
  } else i.ixfe = e.read_shift(2);
  return i;
}
function ro(e) {
  var a = e.read_shift(2), r = e.read_shift(2);
  return e.l += 8, { type: a, flags: r };
}
function ao(e, a, r) {
  return a === 0 ? "" : Sa(e, a, r);
}
function to(e, a, r) {
  var t = r.biff > 8 ? 4 : 2, n = e.read_shift(t), i = e.read_shift(t, "i"), f = e.read_shift(t, "i");
  return [n, i, f];
}
function Bi(e) {
  var a = e.read_shift(2), r = Gt(e);
  return [a, r];
}
function no(e, a, r) {
  e.l += 4, a -= 4;
  var t = e.l + a, n = Pa(e, a, r), i = e.read_shift(2);
  if (t -= e.l, i !== t) throw new Error("Malformed AddinUdf: padding = " + t + " != " + i);
  return e.l += i, n;
}
function Xt(e) {
  var a = e.read_shift(2), r = e.read_shift(2), t = e.read_shift(2), n = e.read_shift(2);
  return { s: { c: t, r: a }, e: { c: n, r } };
}
function Mi(e) {
  var a = e.read_shift(2), r = e.read_shift(2), t = e.read_shift(1), n = e.read_shift(1);
  return { s: { c: t, r: a }, e: { c: n, r } };
}
var io = Mi;
function Ui(e) {
  e.l += 4;
  var a = e.read_shift(2), r = e.read_shift(2), t = e.read_shift(2);
  return e.l += 12, [r, a, t];
}
function so(e) {
  var a = {};
  return e.l += 4, e.l += 16, a.fSharedNote = e.read_shift(2), e.l += 4, a;
}
function fo(e) {
  var a = {};
  return e.l += 4, e.cf = e.read_shift(2), a;
}
function ur(e) {
  e.l += 2, e.l += e.read_shift(2);
}
var co = {
  0: ur,
  /* FtEnd */
  4: ur,
  /* FtMacro */
  5: ur,
  /* FtButton */
  6: ur,
  /* FtGmo */
  7: fo,
  /* FtCf */
  8: ur,
  /* FtPioGrbit */
  9: ur,
  /* FtPictFmla */
  10: ur,
  /* FtCbls */
  11: ur,
  /* FtRbo */
  12: ur,
  /* FtSbs */
  13: so,
  /* FtNts */
  14: ur,
  /* FtSbsFmla */
  15: ur,
  /* FtGboData */
  16: ur,
  /* FtEdoData */
  17: ur,
  /* FtRboData */
  18: ur,
  /* FtCblsData */
  19: ur,
  /* FtLbsData */
  20: ur,
  /* FtCblsFmla */
  21: Ui
};
function oo(e, a) {
  for (var r = e.l + a, t = []; e.l < r; ) {
    var n = e.read_shift(2);
    e.l -= 2;
    try {
      t[n] = co[n](e, r - e.l);
    } catch {
      return e.l = r, t;
    }
  }
  return e.l != r && (e.l = r), t;
}
function wt(e, a) {
  var r = { BIFFVer: 0, dt: 0 };
  switch (r.BIFFVer = e.read_shift(2), a -= 2, a >= 2 && (r.dt = e.read_shift(2), e.l -= 2), r.BIFFVer) {
    case 1536:
    /* BIFF8 */
    case 1280:
    /* BIFF5 */
    case 1024:
    /* BIFF4 */
    case 768:
    /* BIFF3 */
    case 512:
    /* BIFF2 */
    case 2:
    case 7:
      break;
    default:
      if (a > 6) throw new Error("Unexpected BIFF Ver " + r.BIFFVer);
  }
  return e.read_shift(a), r;
}
function lo(e, a) {
  return a === 0 || e.read_shift(2), 1200;
}
function uo(e, a, r) {
  if (r.enc)
    return e.l += a, "";
  var t = e.l, n = Sa(e, 0, r);
  return e.read_shift(a + t - e.l), n;
}
function ho(e, a, r) {
  var t = r && r.biff == 8 || a == 2 ? e.read_shift(2) : (e.l += a, 0);
  return { fDialog: t & 16, fBelow: t & 64, fRight: t & 128 };
}
function xo(e, a, r) {
  var t = "";
  if (r.biff == 4)
    return t = Pa(e, 0, r), t.length === 0 && (t = "Sheet1"), { name: t };
  var n = e.read_shift(4), i = e.read_shift(1) & 3, f = e.read_shift(1);
  switch (f) {
    case 0:
      f = "Worksheet";
      break;
    case 1:
      f = "Macrosheet";
      break;
    case 2:
      f = "Chartsheet";
      break;
    case 6:
      f = "VBAModule";
      break;
  }
  return t = Pa(e, 0, r), t.length === 0 && (t = "Sheet1"), { pos: n, hs: i, dt: f, name: t };
}
function vo(e, a) {
  for (var r = e.l + a, t = e.read_shift(4), n = e.read_shift(4), i = [], f = 0; f != n && e.l < r; ++f)
    i.push(jc(e));
  return i.Count = t, i.Unique = n, i;
}
function po(e, a) {
  var r = {};
  return r.dsst = e.read_shift(2), e.l += a - 2, r;
}
function go(e) {
  var a = {};
  a.r = e.read_shift(2), a.c = e.read_shift(2), a.cnt = e.read_shift(2) - a.c;
  var r = e.read_shift(2);
  e.l += 4;
  var t = e.read_shift(1);
  return e.l += 3, t & 7 && (a.level = t & 7), t & 32 && (a.hidden = !0), t & 64 && (a.hpt = r / 20), a;
}
function mo(e) {
  var a = ro(e);
  if (a.type != 2211) throw new Error("Invalid Future Record " + a.type);
  var r = e.read_shift(4);
  return r !== 0;
}
function _o(e) {
  return e.read_shift(2), e.read_shift(4);
}
function _n(e, a, r) {
  var t = 0;
  r && r.biff == 2 || (t = e.read_shift(2));
  var n = e.read_shift(2);
  r && r.biff == 2 && (t = 1 - (n >> 15), n &= 32767);
  var i = { Unsynced: t & 1, DyZero: (t & 2) >> 1, ExAsc: (t & 4) >> 2, ExDsc: (t & 8) >> 3 };
  return [i, n];
}
function ko(e) {
  var a = e.read_shift(2), r = e.read_shift(2), t = e.read_shift(2), n = e.read_shift(2), i = e.read_shift(2), f = e.read_shift(2), s = e.read_shift(2), c = e.read_shift(2), o = e.read_shift(2);
  return {
    Pos: [a, r],
    Dim: [t, n],
    Flags: i,
    CurTab: f,
    FirstTab: s,
    Selected: c,
    TabRatio: o
  };
}
function Eo(e, a, r) {
  if (r && r.biff >= 2 && r.biff < 5) return {};
  var t = e.read_shift(2);
  return { RTL: t & 64 };
}
function To() {
}
function wo(e, a, r) {
  var t = {
    dyHeight: e.read_shift(2),
    fl: e.read_shift(2)
  };
  switch (r && r.biff || 8) {
    case 2:
      break;
    case 3:
    case 4:
      e.l += 2;
      break;
    default:
      e.l += 10;
      break;
  }
  return t.name = Pa(e, 0, r), t;
}
function Fo(e, a, r) {
  var t = Xr(e, a, r);
  return t.isst = e.read_shift(4), t;
}
function Ao(e, a, r) {
  r.biffguess && r.biff == 2 && (r.biff = 5);
  var t = e.l + a, n = Xr(e, a, r), i = ut(e, t - e.l, r);
  return n.val = i, n;
}
function So(e, a, r) {
  var t = e.read_shift(2), n = Sa(e, 0, r);
  return [t, n];
}
var Co = Sa;
function kn(e, a, r) {
  var t = e.l + a, n = r.biff == 8 || !r.biff ? 4 : 2, i = e.read_shift(n), f = e.read_shift(n), s = e.read_shift(2), c = e.read_shift(2);
  return e.l = t, { s: { r: i, c: s }, e: { r: f, c } };
}
function yo(e) {
  var a = e.read_shift(2), r = e.read_shift(2), t = Bi(e);
  return { r: a, c: r, ixfe: t[0], rknum: t[1] };
}
function Do(e, a) {
  for (var r = e.l + a - 2, t = e.read_shift(2), n = e.read_shift(2), i = []; e.l < r; ) i.push(Bi(e));
  if (e.l !== r) throw new Error("MulRK read error");
  var f = e.read_shift(2);
  if (i.length != f - n + 1) throw new Error("MulRK length mismatch");
  return { r: t, c: n, C: f, rkrec: i };
}
function Io(e, a) {
  for (var r = e.l + a - 2, t = e.read_shift(2), n = e.read_shift(2), i = []; e.l < r; ) i.push(e.read_shift(2));
  if (e.l !== r) throw new Error("MulBlank read error");
  var f = e.read_shift(2);
  if (i.length != f - n + 1) throw new Error("MulBlank length mismatch");
  return { r: t, c: n, C: f, ixfe: i };
}
function Oo(e, a, r, t) {
  var n = {}, i = e.read_shift(4), f = e.read_shift(4), s = e.read_shift(4), c = e.read_shift(2);
  return n.patternType = Cc[s >> 26], t.cellStyles && (n.alc = i & 7, n.fWrap = i >> 3 & 1, n.alcV = i >> 4 & 7, n.fJustLast = i >> 7 & 1, n.trot = i >> 8 & 255, n.cIndent = i >> 16 & 15, n.fShrinkToFit = i >> 20 & 1, n.iReadOrder = i >> 22 & 2, n.fAtrNum = i >> 26 & 1, n.fAtrFnt = i >> 27 & 1, n.fAtrAlc = i >> 28 & 1, n.fAtrBdr = i >> 29 & 1, n.fAtrPat = i >> 30 & 1, n.fAtrProt = i >> 31 & 1, n.dgLeft = f & 15, n.dgRight = f >> 4 & 15, n.dgTop = f >> 8 & 15, n.dgBottom = f >> 12 & 15, n.icvLeft = f >> 16 & 127, n.icvRight = f >> 23 & 127, n.grbitDiag = f >> 30 & 3, n.icvTop = s & 127, n.icvBottom = s >> 7 & 127, n.icvDiag = s >> 14 & 127, n.dgDiag = s >> 21 & 15, n.icvFore = c & 127, n.icvBack = c >> 7 & 127, n.fsxButton = c >> 14 & 1), n;
}
function Ro(e, a, r) {
  var t = {};
  return t.ifnt = e.read_shift(2), t.numFmtId = e.read_shift(2), t.flags = e.read_shift(2), t.fStyle = t.flags >> 2 & 1, a -= 6, t.data = Oo(e, a, t.fStyle, r), t;
}
function No(e) {
  var a = {};
  return a.ifnt = e.read_shift(1), e.l++, a.flags = e.read_shift(1), a.numFmtId = a.flags & 63, a.flags >>= 6, a.fStyle = 0, a.data = {}, a;
}
function Po(e) {
  var a = {};
  return a.ifnt = e.read_shift(1), a.numFmtId = e.read_shift(1), a.flags = e.read_shift(2), a.fStyle = a.flags >> 2 & 1, a.data = {}, a;
}
function bo(e) {
  var a = {};
  return a.ifnt = e.read_shift(1), a.numFmtId = e.read_shift(1), a.flags = e.read_shift(2), a.fStyle = a.flags >> 2 & 1, a.data = {}, a;
}
function Lo(e) {
  e.l += 4;
  var a = [e.read_shift(2), e.read_shift(2)];
  if (a[0] !== 0 && a[0]--, a[1] !== 0 && a[1]--, a[0] > 7 || a[1] > 7) throw new Error("Bad Gutters: " + a.join("|"));
  return a;
}
function Bo(e, a, r) {
  var t = Xr(e, 6, r), n = Pi(e);
  return t.val = n, t.t = n === !0 || n === !1 ? "b" : "e", t;
}
function Mo(e, a, r) {
  r.biffguess && r.biff == 2 && (r.biff = 5);
  var t = Xr(e, 6, r), n = xr(e);
  return t.val = n, t;
}
var En = ao;
function Uo(e, a, r) {
  var t = e.l + a, n = e.read_shift(2), i = e.read_shift(2);
  if (r.sbcch = i, i == 1025 || i == 14849) return [i, n];
  if (i < 1 || i > 255) throw new Error("Unexpected SupBook type: " + i);
  for (var f = Ta(e, i), s = []; t > e.l; ) s.push(ut(e));
  return [i, n, f, s];
}
function Tn(e, a, r) {
  var t = e.read_shift(2), n, i = {
    fBuiltIn: t & 1,
    fWantAdvise: t >>> 1 & 1,
    fWantPict: t >>> 2 & 1,
    fOle: t >>> 3 & 1,
    fOleLink: t >>> 4 & 1,
    cf: t >>> 5 & 1023,
    fIcon: t >>> 15 & 1
  };
  return r.sbcch === 14849 && (n = no(e, a - 2, r)), i.body = n || e.read_shift(a - 2), typeof n == "string" && (i.Name = n), i;
}
function wn(e, a, r) {
  var t = e.l + a, n = e.read_shift(2), i = e.read_shift(1), f = e.read_shift(1), s = e.read_shift(r && r.biff == 2 ? 1 : 2), c = 0;
  (!r || r.biff >= 5) && (r.biff != 5 && (e.l += 2), c = e.read_shift(2), r.biff == 5 && (e.l += 2), e.l += 4);
  var o = Ta(e, f, r);
  n & 32 && (o = yi[o.charCodeAt(0)]);
  var l = t - e.l;
  r && r.biff == 2 && --l;
  var v = t == e.l || s === 0 || !(l > 0) ? [] : dh(e, l, r, s);
  return {
    chKey: i,
    Name: o,
    itab: c,
    rgce: v
  };
}
function Hi(e, a, r) {
  if (r.biff < 8 || !(r.biff > 8) && a == e[e.l] + (e[e.l + 1] == 3 ? 1 : 0) + 1) return Fn(e, a, r);
  for (var t = [], n = e.l + a, i = e.read_shift(r.biff > 8 ? 4 : 2); i-- !== 0; ) t.push(to(e, r.biff > 8 ? 12 : 6, r));
  if (e.l != n) throw new Error("Bad ExternSheet: " + e.l + " != " + n);
  return t;
}
function Fn(e, a, r) {
  e[e.l + 1] == 3 && e[e.l]++;
  var t = Pa(e, a, r);
  return t.charCodeAt(0) == 3 ? t.slice(1) : t;
}
function Ho(e, a, r) {
  if (r.biff < 8) {
    e.l += a;
    return;
  }
  var t = e.read_shift(2), n = e.read_shift(2), i = Ta(e, t, r), f = Ta(e, n, r);
  return [i, f];
}
function Wo(e, a, r) {
  var t = Mi(e);
  e.l++;
  var n = e.read_shift(1);
  return a -= 8, [vh(e, a, r), n, t];
}
function An(e, a, r) {
  var t = io(e);
  switch (r.biff) {
    case 2:
      e.l++, a -= 7;
      break;
    case 3:
    case 4:
      e.l += 2, a -= 8;
      break;
    default:
      e.l += 6, a -= 12;
  }
  return [t, hh(e, a, r)];
}
function Vo(e) {
  var a = e.read_shift(4) !== 0, r = e.read_shift(4) !== 0, t = e.read_shift(4);
  return [a, r, t];
}
function Go(e, a, r) {
  var t = e.read_shift(2), n = e.read_shift(2), i = e.read_shift(2), f = e.read_shift(2), s = Sa(e, 0, r);
  return [{ r: t, c: n }, s, f, i];
}
function Xo(e, a, r) {
  if (r && r.biff < 8) {
    var t = e.read_shift(2), n = e.read_shift(2);
    if (t == 65535 || t == -1) return;
    var i = e.read_shift(2), f = e.read_shift(Math.min(i, 2048), "cpstr");
    return [{ r: t, c: n }, f];
  }
  return Go(e, a, r);
}
function zo(e, a) {
  for (var r = [], t = e.read_shift(2); t--; ) r.push(Xt(e));
  return r;
}
function $o(e, a, r) {
  if (r && r.biff < 8) return Yo(e, a, r);
  var t = Ui(e), n = oo(e, a - 22, t[1]);
  return { cmo: t, ft: n };
}
var Ko = {
  8: function(e, a) {
    var r = e.l + a;
    e.l += 10;
    var t = e.read_shift(2);
    e.l += 4, e.l += 2, e.l += 2, e.l += 2, e.l += 4;
    var n = e.read_shift(1);
    return e.l += n, e.l = r, { fmt: t };
  }
};
function Yo(e, a, r) {
  e.l += 4;
  var t = e.read_shift(2), n = e.read_shift(2), i = e.read_shift(2);
  e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 6, a -= 36;
  var f = [];
  return f.push((Ko[t] || pr)(e, a, r)), { cmo: [n, t, i], ft: f };
}
function jo(e, a, r) {
  var t = e.l, n = "";
  try {
    e.l += 4;
    var i = (r.lastobj || { cmo: [0, 0] }).cmo[1], f;
    [0, 5, 7, 11, 12, 14].indexOf(i) == -1 ? e.l += 6 : f = Jc(e, 6, r);
    var s = e.read_shift(2);
    e.read_shift(2), ze(e, 2);
    var c = e.read_shift(2);
    e.l += c;
    for (var o = 1; o < e.lens.length - 1; ++o) {
      if (e.l - t != e.lens[o]) throw new Error("TxO: bad continue record");
      var l = e[e.l], v = Ta(e, e.lens[o + 1] - e.lens[o] - 1);
      if (n += v, n.length >= (l ? s : 2 * s)) break;
    }
    if (n.length !== s && n.length !== s * 2)
      throw new Error("cchText: " + s + " != " + n.length);
    return e.l = t + a, { t: n };
  } catch {
    return e.l = t + a, { t: n };
  }
}
function Jo(e, a) {
  var r = Xt(e);
  e.l += 16;
  var t = eo(e, a - 24);
  return [r, t];
}
function Zo(e, a) {
  e.read_shift(2);
  var r = Xt(e), t = e.read_shift((a - 10) / 2, "dbcs-cont");
  return t = t.replace(wr, ""), [r, t];
}
function qo(e) {
  var a = [0, 0], r;
  return r = e.read_shift(2), a[0] = xn[r] || r, r = e.read_shift(2), a[1] = xn[r] || r, a;
}
function Qo(e) {
  for (var a = e.read_shift(2), r = []; a-- > 0; ) r.push(Li(e));
  return r;
}
function el(e) {
  for (var a = e.read_shift(2), r = []; a-- > 0; ) r.push(Li(e));
  return r;
}
function rl(e) {
  e.l += 2;
  var a = { cxfs: 0, crc: 0 };
  return a.cxfs = e.read_shift(2), a.crc = e.read_shift(4), a;
}
function Wi(e, a, r) {
  if (!r.cellStyles) return pr(e, a);
  var t = r && r.biff >= 12 ? 4 : 2, n = e.read_shift(t), i = e.read_shift(t), f = e.read_shift(t), s = e.read_shift(t), c = e.read_shift(2);
  t == 2 && (e.l += 2);
  var o = { s: n, e: i, w: f, ixfe: s, flags: c };
  return (r.biff >= 5 || !r.biff) && (o.level = c >> 8 & 7), o;
}
function al(e, a) {
  var r = {};
  return a < 32 || (e.l += 16, r.header = xr(e), r.footer = xr(e), e.l += 2), r;
}
function tl(e, a, r) {
  var t = { area: !1 };
  if (r.biff != 5)
    return e.l += a, t;
  var n = e.read_shift(1);
  return e.l += 3, n & 16 && (t.area = !0), t;
}
var nl = Xr, il = Ni, sl = ut;
function fl(e) {
  var a = e.read_shift(2), r = e.read_shift(2), t = e.read_shift(4), n = { fmt: a, env: r, len: t, data: e.slice(e.l, e.l + t) };
  return e.l += t, n;
}
function cl(e, a, r) {
  r.biffguess && r.biff == 5 && (r.biff = 2);
  var t = Xr(e, 7, r), n = Sa(e, a - 7, r);
  return t.t = "str", t.val = n, t;
}
function ol(e, a, r) {
  var t = Xr(e, 7, r), n = xr(e);
  return t.t = "n", t.val = n, t;
}
function ll(e, a, r) {
  var t = Xr(e, 7, r), n = e.read_shift(2);
  return t.t = "n", t.val = n, t;
}
function ul(e) {
  var a = e.read_shift(1);
  return a === 0 ? (e.l++, "") : e.read_shift(a, "sbcs-cont");
}
function hl(e, a, r) {
  var t = e.l + 7, n = Xr(e, 6, r);
  e.l = t;
  var i = Pi(e);
  return n.val = i, n.t = i === !0 || i === !1 ? "b" : "e", n;
}
function xl(e, a) {
  e.l += 6, e.l += 2, e.l += 1, e.l += 3, e.l += 1, e.l += a - 13;
}
function dl(e, a, r) {
  var t = e.l + a, n = Xr(e, 6, r), i = e.read_shift(2), f = Ta(e, i, r);
  return e.l = t, n.t = "str", n.val = f, n;
}
function vl(e) {
  var a = e.read_shift(4), r = e.read_shift(1), t = e.read_shift(r, "sbcs");
  return t.length === 0 && (t = "Sheet1"), { flags: a, name: t };
}
var pl = [2, 3, 48, 49, 131, 139, 140, 245], Sn = /* @__PURE__ */ (function() {
  var e = {
    /* Code Pages Supported by Visual FoxPro */
    1: 437,
    2: 850,
    3: 1252,
    4: 1e4,
    100: 852,
    101: 866,
    102: 865,
    103: 861,
    104: 895,
    105: 620,
    106: 737,
    107: 857,
    120: 950,
    121: 949,
    122: 936,
    123: 932,
    124: 874,
    125: 1255,
    126: 1256,
    150: 10007,
    151: 10029,
    152: 10006,
    200: 1250,
    201: 1251,
    202: 1254,
    203: 1253,
    /* shapefile DBF extension */
    0: 20127,
    8: 865,
    9: 437,
    10: 850,
    11: 437,
    13: 437,
    14: 850,
    15: 437,
    16: 850,
    17: 437,
    18: 850,
    19: 932,
    20: 850,
    21: 437,
    22: 850,
    23: 865,
    24: 437,
    25: 437,
    26: 850,
    27: 437,
    28: 863,
    29: 850,
    31: 852,
    34: 852,
    35: 852,
    36: 860,
    37: 850,
    38: 866,
    55: 850,
    64: 852,
    77: 936,
    78: 949,
    79: 950,
    80: 874,
    87: 1252,
    88: 1252,
    89: 1252,
    108: 863,
    134: 737,
    135: 852,
    136: 857,
    204: 1257,
    255: 16969
  }, a = _0({
    1: 437,
    2: 850,
    3: 1252,
    4: 1e4,
    100: 852,
    101: 866,
    102: 865,
    103: 861,
    104: 895,
    105: 620,
    106: 737,
    107: 857,
    120: 950,
    121: 949,
    122: 936,
    123: 932,
    124: 874,
    125: 1255,
    126: 1256,
    150: 10007,
    151: 10029,
    152: 10006,
    200: 1250,
    201: 1251,
    202: 1254,
    203: 1253,
    0: 20127
  });
  function r(s, c) {
    var o = [], l = sa(1);
    switch (c.type) {
      case "base64":
        l = yr(Or(s));
        break;
      case "binary":
        l = yr(s);
        break;
      case "buffer":
      case "array":
        l = s;
        break;
    }
    rr(l, 0);
    var v = l.read_shift(1), d = !!(v & 136), u = !1, p = !1;
    switch (v) {
      case 2:
        break;
      // dBASE II
      case 3:
        break;
      // dBASE III
      case 48:
        u = !0, d = !0;
        break;
      // VFP
      case 49:
        u = !0, d = !0;
        break;
      // VFP with autoincrement
      // 0x43 dBASE IV SQL table files
      // 0x63 dBASE IV SQL system files
      case 131:
        break;
      // dBASE III with memo
      case 139:
        break;
      // dBASE IV with memo
      case 140:
        p = !0;
        break;
      // dBASE Level 7 with memo
      // case 0xCB dBASE IV SQL table files with memo
      case 245:
        break;
      // FoxPro 2.x with memo
      // case 0xFB FoxBASE
      default:
        throw new Error("DBF Unsupported Version: " + v.toString(16));
    }
    var _ = 0, x = 521;
    v == 2 && (_ = l.read_shift(2)), l.l += 3, v != 2 && (_ = l.read_shift(4)), _ > 1048576 && (_ = 1e6), v != 2 && (x = l.read_shift(2));
    var h = l.read_shift(2);
    c.codepage, v != 2 && (l.l += 16, l.read_shift(1), l[l.l] !== 0 && e[l[l.l]], l.l += 1, l.l += 2), p && (l.l += 36);
    for (var E = [], g = {}, y = Math.min(l.length, v == 2 ? 521 : x - 10 - (u ? 264 : 0)), P = p ? 32 : 11; l.l < y && l[l.l] != 13; )
      switch (g = {}, g.name = ea(l.slice(l.l, l.l + P)).replace(/[\u0000\r\n][\S\s]*$/g, ""), l.l += P, g.type = String.fromCharCode(l.read_shift(1)), v != 2 && !p && (g.offset = l.read_shift(4)), g.len = l.read_shift(1), v == 2 && (g.offset = l.read_shift(2)), g.dec = l.read_shift(1), g.name.length && E.push(g), v != 2 && (l.l += p ? 13 : 14), g.type) {
        case "B":
          (!u || g.len != 8) && c.WTF && console.log("Skipping " + g.name + ":" + g.type);
          break;
        case "G":
        // General (FoxPro and dBASE L7)
        case "P":
          c.WTF && console.log("Skipping " + g.name + ":" + g.type);
          break;
        case "+":
        // Autoincrement (dBASE L7 only)
        case "0":
        // _NullFlags (VFP only)
        case "@":
        // Timestamp (dBASE L7 only)
        case "C":
        // Character (dBASE II)
        case "D":
        // Date (dBASE III)
        case "F":
        // Float (dBASE IV)
        case "I":
        // Long (VFP and dBASE L7)
        case "L":
        // Logical (dBASE II)
        case "M":
        // Memo (dBASE III)
        case "N":
        // Number (dBASE II)
        case "O":
        // Double (dBASE L7 only)
        case "T":
        // Datetime (VFP only)
        case "Y":
          break;
        default:
          throw new Error("Unknown Field Type: " + g.type);
      }
    if (l[l.l] !== 13 && (l.l = x - 1), l.read_shift(1) !== 13) throw new Error("DBF Terminator not found " + l.l + " " + l[l.l]);
    l.l = x;
    var M = 0, I = 0;
    for (o[0] = [], I = 0; I != E.length; ++I) o[0][I] = E[I].name;
    for (; _-- > 0; ) {
      if (l[l.l] === 42) {
        l.l += h;
        continue;
      }
      for (++l.l, o[++M] = [], I = 0, I = 0; I != E.length; ++I) {
        var N = l.slice(l.l, l.l + E[I].len);
        l.l += E[I].len, rr(N, 0);
        var O = ea(N);
        switch (E[I].type) {
          case "C":
            O.trim().length && (o[M][I] = O.replace(/([^\s])\s+$/, "$1"));
            break;
          case "D":
            O.length === 8 ? (o[M][I] = new Date(Date.UTC(+O.slice(0, 4), +O.slice(4, 6) - 1, +O.slice(6, 8), 0, 0, 0, 0)), c && c.UTC || (o[M][I] = Ea(o[M][I]))) : o[M][I] = O;
            break;
          case "F":
            o[M][I] = parseFloat(O.trim());
            break;
          case "+":
          case "I":
            o[M][I] = p ? N.read_shift(-4, "i") ^ 2147483648 : N.read_shift(4, "i");
            break;
          case "L":
            switch (O.trim().toUpperCase()) {
              case "Y":
              case "T":
                o[M][I] = !0;
                break;
              case "N":
              case "F":
                o[M][I] = !1;
                break;
              case "":
              case "\0":
              case "?":
                break;
              default:
                throw new Error("DBF Unrecognized L:|" + O + "|");
            }
            break;
          case "M":
            if (!d) throw new Error("DBF Unexpected MEMO for type " + v.toString(16));
            o[M][I] = "##MEMO##" + (p ? parseInt(O.trim(), 10) : N.read_shift(4));
            break;
          case "N":
            O = O.replace(/\u0000/g, "").trim(), O && O != "." && (o[M][I] = +O || 0);
            break;
          case "@":
            o[M][I] = new Date(N.read_shift(-8, "f") - 621356832e5);
            break;
          case "T":
            {
              var B = N.read_shift(4), b = N.read_shift(4);
              if (B == 0 && b == 0) break;
              o[M][I] = new Date((B - 2440588) * 864e5 + b), c && c.UTC || (o[M][I] = Ea(o[M][I]));
            }
            break;
          case "Y":
            o[M][I] = N.read_shift(4, "i") / 1e4 + N.read_shift(4, "i") / 1e4 * Math.pow(2, 32);
            break;
          case "O":
            o[M][I] = -N.read_shift(-8, "f");
            break;
          case "B":
            if (u && E[I].len == 8) {
              o[M][I] = N.read_shift(8, "f");
              break;
            }
          /* falls through */
          case "G":
          case "P":
            N.l += E[I].len;
            break;
          case "0":
            if (E[I].name === "_NullFlags") break;
          /* falls through */
          default:
            throw new Error("DBF Unsupported data type " + E[I].type);
        }
      }
    }
    if (v != 2 && l.l < l.length && l[l.l++] != 26) throw new Error("DBF EOF Marker missing " + (l.l - 1) + " of " + l.length + " " + l[l.l - 1].toString(16));
    return c && c.sheetRows && (o = o.slice(0, c.sheetRows)), c.DBF = E, o;
  }
  function t(s, c) {
    var o = c || {};
    o.dateNF || (o.dateNF = "yyyymmdd");
    var l = La(r(s, o), o);
    return l["!cols"] = o.DBF.map(function(v) {
      return {
        wch: v.len,
        DBF: v
      };
    }), delete o.DBF, l;
  }
  function n(s, c) {
    try {
      var o = la(t(s, c), c);
      return o.bookType = "dbf", o;
    } catch (l) {
      if (c && c.WTF) throw l;
    }
    return { SheetNames: [], Sheets: {} };
  }
  var i = { B: 8, C: 250, L: 1, D: 8, "?": 0, "": 0 };
  function f(s, c) {
    if (!s["!ref"]) throw new Error("Cannot export empty sheet to DBF");
    var o = c || {}, l = br;
    if (+o.codepage >= 0 && Vr(+o.codepage), o.type == "string") throw new Error("Cannot write DBF to JS string");
    var v = s0(), d = h0(s, { header: 1, raw: !0, cellDates: !0 }), u = d[0], p = d.slice(1), _ = s["!cols"] || [], x = 0, h = 0, E = 0, g = 1;
    for (x = 0; x < u.length; ++x) {
      if (((_[x] || {}).DBF || {}).name) {
        u[x] = _[x].DBF.name, ++E;
        continue;
      }
      if (u[x] != null) {
        if (++E, typeof u[x] == "number" && (u[x] = u[x].toString(10)), typeof u[x] != "string") throw new Error("DBF Invalid column name " + u[x] + " |" + typeof u[x] + "|");
        if (u.indexOf(u[x]) !== x) {
          for (h = 0; h < 1024; ++h)
            if (u.indexOf(u[x] + "_" + h) == -1) {
              u[x] += "_" + h;
              break;
            }
        }
      }
    }
    var y = Ke(s["!ref"]), P = [], M = [], I = [];
    for (x = 0; x <= y.e.c - y.s.c; ++x) {
      var N = "", O = "", B = 0, b = [];
      for (h = 0; h < p.length; ++h)
        p[h][x] != null && b.push(p[h][x]);
      if (b.length == 0 || u[x] == null) {
        P[x] = "?";
        continue;
      }
      for (h = 0; h < b.length; ++h) {
        switch (typeof b[h]) {
          /* TODO: check if L2 compat is desired */
          case "number":
            O = "B";
            break;
          case "string":
            O = "C";
            break;
          case "boolean":
            O = "L";
            break;
          case "object":
            O = b[h] instanceof Date ? "D" : "C";
            break;
          default:
            O = "C";
        }
        B = Math.max(B, String(b[h]).length), N = N && N != O ? "C" : O;
      }
      B > 250 && (B = 250), O = ((_[x] || {}).DBF || {}).type, O == "C" && _[x].DBF.len > B && (B = _[x].DBF.len), N == "B" && O == "N" && (N = "N", I[x] = _[x].DBF.dec, B = _[x].DBF.len), M[x] = N == "C" || O == "N" ? B : i[N] || 0, g += M[x], P[x] = N;
    }
    var G = v.next(32);
    for (G.write_shift(4, 318902576), G.write_shift(4, p.length), G.write_shift(2, 296 + 32 * E), G.write_shift(2, g), x = 0; x < 4; ++x) G.write_shift(4, 0);
    var z = +a[
      /*::String(*/
      br
      /*::)*/
    ] || 3;
    for (G.write_shift(4, 0 | z << 8), e[z] != +o.codepage && (o.codepage && console.error("DBF Unsupported codepage " + br + ", using 1252"), br = 1252), x = 0, h = 0; x < u.length; ++x)
      if (u[x] != null) {
        var fe = v.next(32), j = (u[x].slice(-10) + "\0\0\0\0\0\0\0\0\0\0\0").slice(0, 11);
        fe.write_shift(1, j, "sbcs"), fe.write_shift(1, P[x] == "?" ? "C" : P[x], "sbcs"), fe.write_shift(4, h), fe.write_shift(1, M[x] || i[P[x]] || 0), fe.write_shift(1, I[x] || 0), fe.write_shift(1, 2), fe.write_shift(4, 0), fe.write_shift(1, 0), fe.write_shift(4, 0), fe.write_shift(4, 0), h += M[x] || i[P[x]] || 0;
      }
    var he = v.next(264);
    for (he.write_shift(4, 13), x = 0; x < 65; ++x) he.write_shift(4, 0);
    for (x = 0; x < p.length; ++x) {
      var J = v.next(g);
      for (J.write_shift(1, 0), h = 0; h < u.length; ++h)
        if (u[h] != null)
          switch (P[h]) {
            case "L":
              J.write_shift(1, p[x][h] == null ? 63 : p[x][h] ? 84 : 70);
              break;
            case "B":
              J.write_shift(8, p[x][h] || 0, "f");
              break;
            case "N":
              var ne = "0";
              for (typeof p[x][h] == "number" && (ne = p[x][h].toFixed(I[h] || 0)), ne.length > M[h] && (ne = ne.slice(0, M[h])), E = 0; E < M[h] - ne.length; ++E) J.write_shift(1, 32);
              J.write_shift(1, ne, "sbcs");
              break;
            case "D":
              p[x][h] ? (J.write_shift(4, ("0000" + p[x][h].getFullYear()).slice(-4), "sbcs"), J.write_shift(2, ("00" + (p[x][h].getMonth() + 1)).slice(-2), "sbcs"), J.write_shift(2, ("00" + p[x][h].getDate()).slice(-2), "sbcs")) : J.write_shift(8, "00000000", "sbcs");
              break;
            case "C":
              var pe = J.l, X = String(p[x][h] != null ? p[x][h] : "").slice(0, M[h]);
              for (J.write_shift(1, X, "cpstr"), pe += M[h] - J.l, E = 0; E < pe; ++E) J.write_shift(1, 32);
              break;
          }
    }
    return br = l, v.next(1).write_shift(1, 26), v.end();
  }
  return {
    to_workbook: n,
    to_sheet: t,
    from_sheet: f
  };
})(), gl = /* @__PURE__ */ (function() {
  var e = {
    AA: "À",
    BA: "Á",
    CA: "Â",
    DA: 195,
    HA: "Ä",
    JA: 197,
    AE: "È",
    BE: "É",
    CE: "Ê",
    HE: "Ë",
    AI: "Ì",
    BI: "Í",
    CI: "Î",
    HI: "Ï",
    AO: "Ò",
    BO: "Ó",
    CO: "Ô",
    DO: 213,
    HO: "Ö",
    AU: "Ù",
    BU: "Ú",
    CU: "Û",
    HU: "Ü",
    Aa: "à",
    Ba: "á",
    Ca: "â",
    Da: 227,
    Ha: "ä",
    Ja: 229,
    Ae: "è",
    Be: "é",
    Ce: "ê",
    He: "ë",
    Ai: "ì",
    Bi: "í",
    Ci: "î",
    Hi: "ï",
    Ao: "ò",
    Bo: "ó",
    Co: "ô",
    Do: 245,
    Ho: "ö",
    Au: "ù",
    Bu: "ú",
    Cu: "û",
    Hu: "ü",
    KC: "Ç",
    Kc: "ç",
    q: "æ",
    z: "œ",
    a: "Æ",
    j: "Œ",
    DN: 209,
    Dn: 241,
    Hy: 255,
    S: 169,
    c: 170,
    R: 174,
    "B ": 180,
    0: 176,
    1: 177,
    2: 178,
    3: 179,
    5: 181,
    6: 182,
    7: 183,
    Q: 185,
    k: 186,
    b: 208,
    i: 216,
    l: 222,
    s: 240,
    y: 248,
    "!": 161,
    '"': 162,
    "#": 163,
    "(": 164,
    "%": 165,
    "'": 167,
    "H ": 168,
    "+": 171,
    ";": 187,
    "<": 188,
    "=": 189,
    ">": 190,
    "?": 191,
    "{": 223
  }, a = new RegExp("\x1BN(" + Lr(e).join("|").replace(/\|\|\|/, "|\\||").replace(/([?()+])/g, "\\$1").replace("{", "\\{") + "|\\|)", "gm");
  try {
    a = new RegExp("\x1BN(" + Lr(e).join("|").replace(/\|\|\|/, "|\\||").replace(/([?()+])/g, "\\$1") + "|\\|)", "gm");
  } catch {
  }
  var r = function(u, p) {
    var _ = e[p];
    return typeof _ == "number" ? W0(_) : _;
  }, t = function(u, p, _) {
    var x = p.charCodeAt(0) - 32 << 4 | _.charCodeAt(0) - 48;
    return x == 59 ? u : W0(x);
  };
  e["|"] = 254;
  var n = function(u) {
    return u.replace(/\n/g, "\x1B :").replace(/\r/g, "\x1B =");
  };
  function i(u, p) {
    switch (p.type) {
      case "base64":
        return f(Or(u), p);
      case "binary":
        return f(u, p);
      case "buffer":
        return f(Se && Buffer.isBuffer(u) ? u.toString("binary") : ea(u), p);
      case "array":
        return f(ka(u), p);
    }
    throw new Error("Unrecognized type " + p.type);
  }
  function f(u, p) {
    var _ = u.split(/[\n\r]+/), x = -1, h = -1, E = 0, g = 0, y = [], P = [], M = null, I = {}, N = [], O = [], B = [], b = 0, G, z = { Workbook: { WBProps: {}, Names: [] } };
    for (+p.codepage >= 0 && Vr(+p.codepage); E !== _.length; ++E) {
      b = 0;
      var fe = _[E].trim().replace(/\x1B([\x20-\x2F])([\x30-\x3F])/g, t).replace(a, r), j = fe.replace(/;;/g, "\0").split(";").map(function(D) {
        return D.replace(/\u0000/g, ";");
      }), he = j[0], J;
      if (fe.length > 0) switch (he) {
        case "ID":
          break;
        /* header */
        case "E":
          break;
        /* EOF */
        case "B":
          break;
        /* dimensions */
        case "O":
          for (g = 1; g < j.length; ++g) switch (j[g].charAt(0)) {
            case "V":
              {
                var ne = parseInt(j[g].slice(1), 10);
                ne >= 1 && ne <= 4 && (z.Workbook.WBProps.date1904 = !0);
              }
              break;
          }
          break;
        case "W":
          break;
        /* window */
        case "P":
          switch (j[1].charAt(0)) {
            case "P":
              P.push(fe.slice(3).replace(/;;/g, ";"));
              break;
          }
          break;
        case "NN":
          {
            var pe = { Sheet: 0 };
            for (g = 1; g < j.length; ++g) switch (j[g].charAt(0)) {
              case "N":
                pe.Name = j[g].slice(1);
                break;
              case "E":
                pe.Ref = (p && p.sheet || "Sheet1") + "!" + ma(j[g].slice(1));
                break;
            }
            z.Workbook.Names.push(pe);
          }
          break;
        // case 'NE': // ??
        // case 'NU': // ??
        case "C":
          var X = !1, ke = !1, _e = !1, de = !1, ce = -1, Te = -1, me = "", Fe = "z", S = "";
          for (g = 1; g < j.length; ++g) switch (j[g].charAt(0)) {
            case "A":
              S = j[g].slice(1);
              break;
            // TODO: comment
            case "X":
              h = parseInt(j[g].slice(1), 10) - 1, ke = !0;
              break;
            case "Y":
              for (x = parseInt(j[g].slice(1), 10) - 1, ke || (h = 0), G = y.length; G <= x; ++G) y[G] = [];
              break;
            case "K":
              J = j[g].slice(1), J.charAt(0) === '"' ? (J = J.slice(1, J.length - 1), Fe = "s") : J === "TRUE" || J === "FALSE" ? (J = J === "TRUE", Fe = "b") : J.charAt(0) == "#" && sr[J] != null ? (Fe = "e", J = sr[J]) : isNaN(Ir(J)) || (J = Ir(J), Fe = "n", M !== null && Br(M) && p.cellDates && (J = ia(z.Workbook.WBProps.date1904 ? J + 1462 : J), Fe = typeof J == "number" ? "n" : "d")), X = !0;
              break;
            case "E":
              de = !0, me = ma(j[g].slice(1), { r: x, c: h });
              break;
            case "S":
              _e = !0;
              break;
            case "G":
              break;
            // unknown
            case "R":
              ce = parseInt(j[g].slice(1), 10) - 1;
              break;
            case "C":
              Te = parseInt(j[g].slice(1), 10) - 1;
              break;
            // case 'P': // ??
            // case 'D': // ??
            default:
              if (p && p.WTF) throw new Error("SYLK bad record " + fe);
          }
          if (X && (y[x][h] ? (y[x][h].t = Fe, y[x][h].v = J) : y[x][h] = { t: Fe, v: J }, M && (y[x][h].z = M), p.cellText !== !1 && M && (y[x][h].w = Fr(y[x][h].z, y[x][h].v, { date1904: z.Workbook.WBProps.date1904 })), M = null), _e) {
            if (de) throw new Error("SYLK shared formula cannot have own formula");
            var L = ce > -1 && y[ce][Te];
            if (!L || !L[1]) throw new Error("SYLK shared formula cannot find base");
            me = Ji(L[1], { r: x - ce, c: h - Te });
          }
          me && (y[x][h] ? y[x][h].f = me : y[x][h] = { t: "n", f: me }), S && (y[x][h] || (y[x][h] = { t: "z" }), y[x][h].c = [{ a: "SheetJSYLK", t: S }]);
          break;
        case "F":
          var R = 0;
          for (g = 1; g < j.length; ++g) switch (j[g].charAt(0)) {
            case "X":
              h = parseInt(j[g].slice(1), 10) - 1, ++R;
              break;
            case "Y":
              for (x = parseInt(j[g].slice(1), 10) - 1, G = y.length; G <= x; ++G) y[G] = [];
              break;
            case "M":
              b = parseInt(j[g].slice(1), 10) / 20;
              break;
            case "F":
              break;
            /* ??? */
            case "G":
              break;
            /* hide grid */
            case "P":
              M = P[parseInt(j[g].slice(1), 10)];
              break;
            case "S":
              break;
            /* cell style */
            case "D":
              break;
            /* column */
            case "N":
              break;
            /* font */
            case "W":
              for (B = j[g].slice(1).split(" "), G = parseInt(B[0], 10); G <= parseInt(B[1], 10); ++G)
                b = parseInt(B[2], 10), O[G - 1] = b === 0 ? { hidden: !0 } : { wch: b };
              break;
            case "C":
              h = parseInt(j[g].slice(1), 10) - 1, O[h] || (O[h] = {});
              break;
            case "R":
              x = parseInt(j[g].slice(1), 10) - 1, N[x] || (N[x] = {}), b > 0 ? (N[x].hpt = b, N[x].hpx = st(b)) : b === 0 && (N[x].hidden = !0);
              break;
            // case 'K': // ??
            // case 'E': // ??
            default:
              if (p && p.WTF) throw new Error("SYLK bad record " + fe);
          }
          R < 1 && (M = null);
          break;
        default:
          if (p && p.WTF) throw new Error("SYLK bad record " + fe);
      }
    }
    return N.length > 0 && (I["!rows"] = N), O.length > 0 && (I["!cols"] = O), O.forEach(function(D) {
      ba(D);
    }), p && p.sheetRows && (y = y.slice(0, p.sheetRows)), [y, I, z];
  }
  function s(u, p) {
    var _ = i(u, p), x = _[0], h = _[1], E = _[2], g = er(p);
    g.date1904 = (((E || {}).Workbook || {}).WBProps || {}).date1904;
    var y = La(x, g);
    Lr(h).forEach(function(M) {
      y[M] = h[M];
    });
    var P = la(y, p);
    return Lr(E).forEach(function(M) {
      P[M] = E[M];
    }), P.bookType = "sylk", P;
  }
  function c(u, p, _, x, h, E) {
    var g = "C;Y" + (_ + 1) + ";X" + (x + 1) + ";K";
    switch (u.t) {
      case "n":
        g += isFinite(u.v) ? u.v || 0 : Ar[isNaN(u.v) ? 36 : 7], u.f && !u.F && (g += ";E" + Z1(u.f, { r: _, c: x }));
        break;
      case "b":
        g += u.v ? "TRUE" : "FALSE";
        break;
      case "e":
        g += u.w || Ar[u.v] || u.v;
        break;
      case "d":
        g += ar(cr(u.v, E), E);
        break;
      case "s":
        g += '"' + (u.v == null ? "" : String(u.v)).replace(/"/g, "").replace(/;/g, ";;") + '"';
        break;
    }
    return g;
  }
  function o(u, p, _) {
    var x = "C;Y" + (p + 1) + ";X" + (_ + 1) + ";A";
    return x += n(u.map(function(h) {
      return h.t;
    }).join("")), x;
  }
  function l(u, p) {
    p.forEach(function(_, x) {
      var h = "F;W" + (x + 1) + " " + (x + 1) + " ";
      _.hidden ? h += "0" : (typeof _.width == "number" && !_.wpx && (_.wpx = Lt(_.width)), typeof _.wpx == "number" && !_.wch && (_.wch = Bt(_.wpx)), typeof _.wch == "number" && (h += Math.round(_.wch))), h.charAt(h.length - 1) != " " && u.push(h);
    });
  }
  function v(u, p) {
    p.forEach(function(_, x) {
      var h = "F;";
      _.hidden ? h += "M0;" : _.hpt ? h += "M" + 20 * _.hpt + ";" : _.hpx && (h += "M" + 20 * Yi(_.hpx) + ";"), h.length > 2 && u.push(h + "R" + (x + 1));
    });
  }
  function d(u, p, _) {
    p || (p = {}), p._formats = ["General"];
    var x = ["ID;PSheetJS;N;E"], h = [], E = Ke(u["!ref"] || "A1"), g, y = u["!data"] != null, P = `\r
`, M = (((_ || {}).Workbook || {}).WBProps || {}).date1904, I = "General";
    x.push("P;PGeneral");
    var N = E.s.r, O = E.s.c, B = [];
    if (u["!ref"]) {
      for (N = E.s.r; N <= E.e.r; ++N)
        if (!(y && !u["!data"][N])) {
          for (B = [], O = E.s.c; O <= E.e.c; ++O)
            g = y ? u["!data"][N][O] : u[Pe(O) + Me(N)], !(!g || !g.c) && B.push(o(g.c, N, O));
          B.length && h.push(B.join(P));
        }
    }
    if (u["!ref"]) {
      for (N = E.s.r; N <= E.e.r; ++N)
        if (!(y && !u["!data"][N])) {
          for (B = [], O = E.s.c; O <= E.e.c; ++O)
            if (g = y ? u["!data"][N][O] : u[Pe(O) + Me(N)], !(!g || g.v == null && (!g.f || g.F))) {
              if ((g.z || (g.t == "d" ? ge[14] : "General")) != I) {
                var b = p._formats.indexOf(g.z);
                b == -1 && (p._formats.push(g.z), b = p._formats.length - 1, x.push("P;P" + g.z.replace(/;/g, ";;"))), B.push("F;P" + b + ";Y" + (N + 1) + ";X" + (O + 1));
              }
              B.push(c(g, u, N, O, p, M));
            }
          h.push(B.join(P));
        }
    }
    return x.push("F;P0;DG0G8;M255"), u["!cols"] && l(x, u["!cols"]), u["!rows"] && v(x, u["!rows"]), u["!ref"] && x.push("B;Y" + (E.e.r - E.s.r + 1) + ";X" + (E.e.c - E.s.c + 1) + ";D" + [E.s.c, E.s.r, E.e.c, E.e.r].join(" ")), x.push("O;L;D;B" + (M ? ";V4" : "") + ";K47;G100 0.001"), delete p._formats, x.join(P) + P + h.join(P) + P + "E" + P;
  }
  return {
    to_workbook: s,
    from_sheet: d
  };
})(), ml = /* @__PURE__ */ (function() {
  function e(s, c) {
    switch (c.type) {
      case "base64":
        return a(Or(s), c);
      case "binary":
        return a(s, c);
      case "buffer":
        return a(Se && Buffer.isBuffer(s) ? s.toString("binary") : ea(s), c);
      case "array":
        return a(ka(s), c);
    }
    throw new Error("Unrecognized type " + c.type);
  }
  function a(s, c) {
    for (var o = s.split(`
`), l = -1, v = -1, d = 0, u = []; d !== o.length; ++d) {
      if (o[d].trim() === "BOT") {
        u[++l] = [], v = 0;
        continue;
      }
      if (!(l < 0)) {
        var p = o[d].trim().split(","), _ = p[0], x = p[1];
        ++d;
        for (var h = o[d] || ""; (h.match(/["]/g) || []).length & 1 && d < o.length - 1; ) h += `
` + o[++d];
        switch (h = h.trim(), +_) {
          case -1:
            if (h === "BOT") {
              u[++l] = [], v = 0;
              continue;
            } else if (h !== "EOD") throw new Error("Unrecognized DIF special command " + h);
            break;
          case 0:
            h === "TRUE" ? u[l][v] = !0 : h === "FALSE" ? u[l][v] = !1 : isNaN(Ir(x)) ? isNaN(tt(x).getDate()) ? u[l][v] = x : (u[l][v] = cr(x), c && c.UTC || (u[l][v] = Ea(u[l][v]))) : u[l][v] = Ir(x), ++v;
            break;
          case 1:
            h = h.slice(1, h.length - 1), h = h.replace(/""/g, '"'), h && h.match(/^=".*"$/) && (h = h.slice(2, -1)), u[l][v++] = h !== "" ? h : null;
            break;
        }
        if (h === "EOD") break;
      }
    }
    return c && c.sheetRows && (u = u.slice(0, c.sheetRows)), u;
  }
  function r(s, c) {
    return La(e(s, c), c);
  }
  function t(s, c) {
    var o = la(r(s, c), c);
    return o.bookType = "dif", o;
  }
  function n(s, c) {
    return "0," + String(s) + `\r
` + c;
  }
  function i(s) {
    return `1,0\r
"` + s.replace(/"/g, '""') + '"';
  }
  function f(s) {
    if (!s["!ref"]) throw new Error("Cannot export empty sheet to DIF");
    for (var c = Ke(s["!ref"]), o = s["!data"] != null, l = [
      `TABLE\r
0,1\r
"sheetjs"\r
`,
      `VECTORS\r
0,` + (c.e.r - c.s.r + 1) + `\r
""\r
`,
      `TUPLES\r
0,` + (c.e.c - c.s.c + 1) + `\r
""\r
`,
      `DATA\r
0,0\r
""\r
`
    ], v = c.s.r; v <= c.e.r; ++v) {
      for (var d = o ? s["!data"][v] : [], u = `-1,0\r
BOT\r
`, p = c.s.c; p <= c.e.c; ++p) {
        var _ = o ? d && d[p] : s[Ne({ r: v, c: p })];
        if (_ == null) {
          u += `1,0\r
""\r
`;
          continue;
        }
        switch (_.t) {
          case "n":
            _.w != null ? u += "0," + _.w + `\r
V` : _.v != null ? u += n(_.v, "V") : _.f != null && !_.F ? u += i("=" + _.f) : u += `1,0\r
""`;
            break;
          case "b":
            u += _.v ? n(1, "TRUE") : n(0, "FALSE");
            break;
          case "s":
            u += i(isNaN(+_.v) ? _.v : '="' + _.v + '"');
            break;
          case "d":
            _.w || (_.w = Fr(_.z || ge[14], ar(cr(_.v)))), u += n(_.w, "V");
            break;
          default:
            u += `1,0\r
""`;
        }
        u += `\r
`;
      }
      l.push(u);
    }
    return l.join("") + `-1,0\r
EOD`;
  }
  return {
    to_workbook: t,
    to_sheet: r,
    from_sheet: f
  };
})(), _l = /* @__PURE__ */ (function() {
  function e(v) {
    return v.replace(/\\b/g, "\\").replace(/\\c/g, ":").replace(/\\n/g, `
`);
  }
  function a(v) {
    return v.replace(/\\/g, "\\b").replace(/:/g, "\\c").replace(/\n/g, "\\n");
  }
  function r(v, d) {
    for (var u = v.split(`
`), p = -1, _ = -1, x = 0, h = []; x !== u.length; ++x) {
      var E = u[x].trim().split(":");
      if (E[0] === "cell") {
        var g = dr(E[1]);
        if (h.length <= g.r) for (p = h.length; p <= g.r; ++p) h[p] || (h[p] = []);
        switch (p = g.r, _ = g.c, E[2]) {
          case "t":
            h[p][_] = e(E[3]);
            break;
          case "v":
            h[p][_] = +E[3];
            break;
          case "vtf":
            var y = E[E.length - 1];
          /* falls through */
          case "vtc":
            switch (E[3]) {
              case "nl":
                h[p][_] = !!+E[4];
                break;
              default:
                h[p][_] = E[E.length - 1].charAt(0) == "#" ? { t: "e", v: sr[E[E.length - 1]] } : +E[4];
                break;
            }
            E[2] == "vtf" && (h[p][_] = [h[p][_], y]);
        }
      }
    }
    return d && d.sheetRows && (h = h.slice(0, d.sheetRows)), h;
  }
  function t(v, d) {
    return La(r(v, d), d);
  }
  function n(v, d) {
    return la(t(v, d), d);
  }
  var i = [
    "socialcalc:version:1.5",
    "MIME-Version: 1.0",
    "Content-Type: multipart/mixed; boundary=SocialCalcSpreadsheetControlSave"
  ].join(`
`), f = [
    "--SocialCalcSpreadsheetControlSave",
    "Content-type: text/plain; charset=UTF-8"
  ].join(`
`) + `
`, s = [
    "# SocialCalc Spreadsheet Control Save",
    "part:sheet"
  ].join(`
`), c = "--SocialCalcSpreadsheetControlSave--";
  function o(v) {
    if (!v || !v["!ref"]) return "";
    for (var d = [], u = [], p, _ = "", x = wa(v["!ref"]), h = v["!data"] != null, E = x.s.r; E <= x.e.r; ++E)
      for (var g = x.s.c; g <= x.e.c; ++g)
        if (_ = Ne({ r: E, c: g }), p = h ? (v["!data"][E] || [])[g] : v[_], !(!p || p.v == null || p.t === "z")) {
          switch (u = ["cell", _, "t"], p.t) {
            case "s":
              u.push(a(p.v));
              break;
            case "b":
              u[2] = "vt" + (p.f ? "f" : "c"), u[3] = "nl", u[4] = p.v ? "1" : "0", u[5] = a(p.f || (p.v ? "TRUE" : "FALSE"));
              break;
            case "d":
              var y = ar(cr(p.v));
              u[2] = "vtc", u[3] = "nd", u[4] = "" + y, u[5] = p.w || Fr(p.z || ge[14], y);
              break;
            case "n":
              isFinite(p.v) ? p.f ? (u[2] = "vtf", u[3] = "n", u[4] = p.v, u[5] = a(p.f)) : (u[2] = "v", u[3] = p.v) : (u[2] = "vt" + (p.f ? "f" : "c"), u[3] = "e" + Ar[isNaN(p.v) ? 36 : 7], u[4] = "0", u[5] = p.f || u[3].slice(1), u[6] = "e", u[7] = u[3].slice(1));
              break;
            case "e":
              continue;
          }
          d.push(u.join(":"));
        }
    return d.push("sheet:c:" + (x.e.c - x.s.c + 1) + ":r:" + (x.e.r - x.s.r + 1) + ":tvf:1"), d.push("valueformat:1:text-wiki"), d.join(`
`);
  }
  function l(v) {
    return [i, f, s, f, o(v), c].join(`
`);
  }
  return {
    to_workbook: n,
    to_sheet: t,
    from_sheet: l
  };
})(), nt = /* @__PURE__ */ (function() {
  function e(l, v, d, u, p) {
    p.raw ? v[d][u] = l : l === "" || (l === "TRUE" ? v[d][u] = !0 : l === "FALSE" ? v[d][u] = !1 : isNaN(Ir(l)) ? isNaN(tt(l).getDate()) ? l.charCodeAt(0) == 35 && sr[l] != null ? v[d][u] = { t: "e", v: sr[l], w: l } : v[d][u] = l : v[d][u] = cr(l) : v[d][u] = Ir(l));
  }
  function a(l, v) {
    var d = v || {}, u = [];
    if (!l || l.length === 0) return u;
    for (var p = l.split(/[\r\n]/), _ = p.length - 1; _ >= 0 && p[_].length === 0; ) --_;
    for (var x = 10, h = 0, E = 0; E <= _; ++E)
      h = p[E].indexOf(" "), h == -1 ? h = p[E].length : h++, x = Math.max(x, h);
    for (E = 0; E <= _; ++E) {
      u[E] = [];
      var g = 0;
      for (e(p[E].slice(0, x).trim(), u, E, g, d), g = 1; g <= (p[E].length - x) / 10 + 1; ++g)
        e(p[E].slice(x + (g - 1) * 10, x + g * 10).trim(), u, E, g, d);
    }
    return d.sheetRows && (u = u.slice(0, d.sheetRows)), u;
  }
  var r = {
    44: ",",
    9: "	",
    59: ";",
    124: "|"
  }, t = {
    44: 3,
    9: 2,
    59: 1,
    124: 0
  };
  function n(l) {
    for (var v = {}, d = !1, u = 0, p = 0; u < l.length; ++u)
      (p = l.charCodeAt(u)) == 34 ? d = !d : !d && p in r && (v[p] = (v[p] || 0) + 1);
    p = [];
    for (u in v) Object.prototype.hasOwnProperty.call(v, u) && p.push([v[u], u]);
    if (!p.length) {
      v = t;
      for (u in v) Object.prototype.hasOwnProperty.call(v, u) && p.push([v[u], u]);
    }
    return p.sort(function(_, x) {
      return _[0] - x[0] || t[_[1]] - t[x[1]];
    }), r[p.pop()[1]] || 44;
  }
  function i(l, v) {
    var d = v || {}, u = "", p = {};
    d.dense && (p["!data"] = []);
    var _ = { s: { c: 0, r: 0 }, e: { c: 0, r: 0 } };
    l.slice(0, 4) == "sep=" ? l.charCodeAt(5) == 13 && l.charCodeAt(6) == 10 ? (u = l.charAt(4), l = l.slice(7)) : l.charCodeAt(5) == 13 || l.charCodeAt(5) == 10 ? (u = l.charAt(4), l = l.slice(6)) : u = n(l.slice(0, 1024)) : d && d.FS ? u = d.FS : u = n(l.slice(0, 1024));
    var x = 0, h = 0, E = 0, g = 0, y = 0, P = u.charCodeAt(0), M = !1, I = 0, N = l.charCodeAt(0), O = d.dateNF != null ? hf(d.dateNF) : null;
    function B() {
      var b = l.slice(g, y);
      b.slice(-1) == "\r" && (b = b.slice(0, -1));
      var G = {};
      if (b.charAt(0) == '"' && b.charAt(b.length - 1) == '"' && (b = b.slice(1, -1).replace(/""/g, '"')), d.cellText !== !1 && (G.w = b), b.length === 0) G.t = "z";
      else if (d.raw)
        G.t = "s", G.v = b;
      else if (b.trim().length === 0)
        G.t = "s", G.v = b;
      else if (b.charCodeAt(0) == 61)
        b.charCodeAt(1) == 34 && b.charCodeAt(b.length - 1) == 34 ? (G.t = "s", G.v = b.slice(2, -1).replace(/""/g, '"')) : q1(b) ? (G.t = "s", G.f = b.slice(1), G.v = b) : (G.t = "s", G.v = b);
      else if (b == "TRUE")
        G.t = "b", G.v = !0;
      else if (b == "FALSE")
        G.t = "b", G.v = !1;
      else if (!isNaN(E = Ir(b)))
        G.t = "n", G.v = E;
      else if (!isNaN((E = tt(b)).getDate()) || O && b.match(O)) {
        if (G.z = d.dateNF || ge[14], O && b.match(O)) {
          var z = xf(b, d.dateNF, b.match(O) || []);
          E = cr(z), d && d.UTC === !1 && (E = Ea(E));
        } else d && d.UTC === !1 ? E = Ea(E) : d.cellText !== !1 && d.dateNF && (G.w = Fr(G.z, E));
        d.cellDates ? (G.t = "d", G.v = E) : (G.t = "n", G.v = ar(E)), d.cellNF || delete G.z;
      } else b.charCodeAt(0) == 35 && sr[b] != null ? (G.t = "e", G.w = b, G.v = sr[b]) : (G.t = "s", G.v = b);
      if (G.t == "z" || (d.dense ? (p["!data"][x] || (p["!data"][x] = []), p["!data"][x][h] = G) : p[Ne({ c: h, r: x })] = G), g = y + 1, N = l.charCodeAt(g), _.e.c < h && (_.e.c = h), _.e.r < x && (_.e.r = x), I == P) ++h;
      else if (h = 0, ++x, d.sheetRows && d.sheetRows <= x) return !0;
    }
    e: for (; y < l.length; ++y) switch (I = l.charCodeAt(y)) {
      case 34:
        N === 34 && (M = !M);
        break;
      case 13:
        if (M) break;
        l.charCodeAt(y + 1) == 10 && ++y;
      /* falls through */
      case P:
      case 10:
        if (!M && B()) break e;
        break;
    }
    return y - g > 0 && B(), p["!ref"] = ye(_), p;
  }
  function f(l, v) {
    return !(v && v.PRN) || v.FS || l.slice(0, 4) == "sep=" || l.indexOf("	") >= 0 || l.indexOf(",") >= 0 || l.indexOf(";") >= 0 ? i(l, v) : La(a(l, v), v);
  }
  function s(l, v) {
    var d = "", u = v.type == "string" ? [0, 0, 0, 0] : b0(l, v);
    switch (v.type) {
      case "base64":
        d = Or(l);
        break;
      case "binary":
        d = l;
        break;
      case "buffer":
        v.codepage == 65001 ? d = l.toString("utf8") : (v.codepage, d = Se && Buffer.isBuffer(l) ? l.toString("binary") : ea(l));
        break;
      case "array":
        d = ka(l);
        break;
      case "string":
        d = l;
        break;
      default:
        throw new Error("Unrecognized type " + v.type);
    }
    return u[0] == 239 && u[1] == 187 && u[2] == 191 ? d = Ue(d.slice(3)) : v.type != "string" && v.type != "buffer" && v.codepage == 65001 ? d = Ue(d) : v.type == "binary", d.slice(0, 19) == "socialcalc:version:" ? _l.to_sheet(v.type == "string" ? d : Ue(d), v) : f(d, v);
  }
  function c(l, v) {
    return la(s(l, v), v);
  }
  function o(l) {
    var v = [];
    if (!l["!ref"]) return "";
    for (var d = Ke(l["!ref"]), u, p = l["!data"] != null, _ = d.s.r; _ <= d.e.r; ++_) {
      for (var x = [], h = d.s.c; h <= d.e.c; ++h) {
        var E = Ne({ r: _, c: h });
        if (u = p ? (l["!data"][_] || [])[h] : l[E], !u || u.v == null) {
          x.push("          ");
          continue;
        }
        for (var g = (u.w || (fa(u), u.w) || "").slice(0, 10); g.length < 10; ) g += " ";
        x.push(g + (h === 0 ? " " : ""));
      }
      v.push(x.join(""));
    }
    return v.join(`
`);
  }
  return {
    to_workbook: c,
    to_sheet: s,
    from_sheet: o
  };
})();
function kl(e, a) {
  var r = a || {}, t = !!r.WTF;
  r.WTF = !0;
  try {
    var n = gl.to_workbook(e, r);
    return r.WTF = t, n;
  } catch (i) {
    if (r.WTF = t, i.message.indexOf("SYLK bad record ID") == -1 && t) throw i;
    return nt.to_workbook(e, a);
  }
}
var ja = /* @__PURE__ */ (function() {
  function e(S, L, R) {
    if (S) {
      rr(S, S.l || 0);
      for (var D = R.Enum || de; S.l < S.length; ) {
        var Y = S.read_shift(2), w = D[Y] || D[65535], te = S.read_shift(2), ie = S.l + te, Q = w.f && w.f(S, te, R);
        if (S.l = ie, L(Q, w, Y)) return;
      }
    }
  }
  function a(S, L) {
    switch (L.type) {
      case "base64":
        return t(yr(Or(S)), L);
      case "binary":
        return t(yr(S), L);
      case "buffer":
      case "array":
        return t(S, L);
    }
    throw "Unsupported type " + L.type;
  }
  var r = [
    "mmmm",
    "dd-mmm-yyyy",
    "dd-mmm",
    "mmm-yyyy",
    "@",
    // "text"?
    "mm/dd",
    "hh:mm:ss AM/PM",
    // 7
    "hh:mm AM/PM",
    "mm/dd/yyyy",
    "mm/dd",
    "hh:mm:ss",
    "hh:mm"
    // 12
  ];
  function t(S, L) {
    if (!S) return S;
    var R = L || {}, D = {}, Y = "Sheet1", w = "", te = 0, ie = {}, Q = [], ve = [], xe = [];
    R.dense && (xe = D["!data"] = []);
    var Ee = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }, Le = R.sheetRows || 0, He = {};
    if (S[4] == 81 && S[5] == 80 && S[6] == 87) return Fe(S, L);
    if (S[2] == 0 && (S[3] == 8 || S[3] == 9) && S.length >= 16 && S[14] == 5 && S[15] === 108)
      throw new Error("Unsupported Works 3 for Mac file");
    if (S[2] == 2)
      R.Enum = de, e(S, function(re, Sr, gr) {
        switch (gr) {
          case 0:
            R.vers = re, re >= 4096 && (R.qpro = !0);
            break;
          case 255:
            R.vers = re, R.works = !0;
            break;
          case 6:
            Ee = re;
            break;
          /* RANGE */
          case 204:
            re && (w = re);
            break;
          /* SHEETNAMECS */
          case 222:
            w = re;
            break;
          /* SHEETNAMELP */
          case 15:
          /* LABEL */
          case 51:
            (!R.qpro && !R.works || gr == 51) && re[1].v.charCodeAt(0) < 48 && (re[1].v = re[1].v.slice(1)), (R.works || R.works2) && (re[1].v = re[1].v.replace(/\r\n/g, `
`));
          /* falls through */
          case 13:
          /* INTEGER */
          case 14:
          /* NUMBER */
          case 16:
            (re[2] & 112) == 112 && (re[2] & 15) > 1 && (re[2] & 15) < 15 && (re[1].z = R.dateNF || r[(re[2] & 15) - 1] || ge[14], R.cellDates && (re[1].v = ia(re[1].v), re[1].t = typeof re[1].v == "number" ? "n" : "d")), R.qpro && re[3] > te && (D["!ref"] = ye(Ee), ie[Y] = D, Q.push(Y), D = {}, R.dense && (xe = D["!data"] = []), Ee = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }, te = re[3], Y = w || "Sheet" + (te + 1), w = "");
            var We = R.dense ? (xe[re[0].r] || [])[re[0].c] : D[Ne(re[0])];
            if (We) {
              We.t = re[1].t, We.v = re[1].v, re[1].z != null && (We.z = re[1].z), re[1].f != null && (We.f = re[1].f), He = We;
              break;
            }
            R.dense ? (xe[re[0].r] || (xe[re[0].r] = []), xe[re[0].r][re[0].c] = re[1]) : D[Ne(re[0])] = re[1], He = re[1];
            break;
          case 21509:
            R.works2 = !0;
            break;
          case 21506:
            re == 5281 && (He.z = "hh:mm:ss", R.cellDates && He.t == "n" && (He.v = ia(He.v), He.t = typeof He.v == "number" ? "n" : "d"));
            break;
        }
      }, R);
    else if (S[2] == 26 || S[2] == 14)
      R.Enum = ce, S[2] == 14 && (R.qpro = !0, S.l = 0), e(S, function(re, Sr, gr) {
        switch (gr) {
          case 204:
            Y = re;
            break;
          /* SHEETNAMECS */
          case 22:
            re[1].v.charCodeAt(0) < 48 && (re[1].v = re[1].v.slice(1)), re[1].v = re[1].v.replace(/\x0F./g, function(We) {
              return String.fromCharCode(We.charCodeAt(1) - 32);
            }).replace(/\r\n/g, `
`);
          /* falls through */
          case 23:
          /* NUMBER17 */
          case 24:
          /* NUMBER18 */
          case 25:
          /* FORMULA19 */
          case 37:
          /* NUMBER25 */
          case 39:
          /* NUMBER27 */
          case 40:
            if (re[3] > te && (D["!ref"] = ye(Ee), ie[Y] = D, Q.push(Y), D = {}, R.dense && (xe = D["!data"] = []), Ee = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }, te = re[3], Y = "Sheet" + (te + 1)), Le > 0 && re[0].r >= Le) break;
            R.dense ? (xe[re[0].r] || (xe[re[0].r] = []), xe[re[0].r][re[0].c] = re[1]) : D[Ne(re[0])] = re[1], Ee.e.c < re[0].c && (Ee.e.c = re[0].c), Ee.e.r < re[0].r && (Ee.e.r = re[0].r);
            break;
          case 27:
            re[14e3] && (ve[re[14e3][0]] = re[14e3][1]);
            break;
          case 1537:
            ve[re[0]] = re[1], re[0] == te && (Y = re[1]);
            break;
        }
      }, R);
    else throw new Error("Unrecognized LOTUS BOF " + S[2]);
    if (D["!ref"] = ye(Ee), ie[w || Y] = D, Q.push(w || Y), !ve.length) return { SheetNames: Q, Sheets: ie };
    for (var Xe = {}, ue = [], De = 0; De < ve.length; ++De) ie[Q[De]] ? (ue.push(ve[De] || Q[De]), Xe[ve[De]] = ie[ve[De]] || ie[Q[De]]) : (ue.push(ve[De]), Xe[ve[De]] = { "!ref": "A1" });
    return { SheetNames: ue, Sheets: Xe };
  }
  function n(S, L) {
    var R = L || {};
    if (+R.codepage >= 0 && Vr(+R.codepage), R.type == "string") throw new Error("Cannot write WK1 to JS string");
    var D = s0();
    if (!S["!ref"]) throw new Error("Cannot export empty sheet to WK1");
    var Y = Ke(S["!ref"]), w = S["!data"] != null, te = [];
    Cr(D, 0, f(1030)), Cr(D, 6, o(Y));
    for (var ie = Math.min(Y.e.r, 8191), Q = Y.s.c; Q <= Y.e.c; ++Q) te[Q] = Pe(Q);
    for (var ve = Y.s.r; ve <= ie; ++ve) {
      var xe = Me(ve);
      for (Q = Y.s.c; Q <= Y.e.c; ++Q) {
        var Ee = w ? (S["!data"][ve] || [])[Q] : S[te[Q] + xe];
        if (!(!Ee || Ee.t == "z"))
          switch (Ee.t) {
            case "n":
              (Ee.v | 0) == Ee.v && Ee.v >= -32768 && Ee.v <= 32767 ? Cr(D, 13, x(ve, Q, Ee)) : Cr(D, 14, E(ve, Q, Ee));
              break;
            case "d":
              var Le = ar(Ee.v);
              (Le | 0) == Le && Le >= -32768 && Le <= 32767 ? Cr(D, 13, x(ve, Q, { v: Le, z: Ee.z || ge[14] })) : Cr(D, 14, E(ve, Q, { v: Le, z: Ee.z || ge[14] }));
              break;
            default:
              var He = fa(Ee);
              Cr(D, 15, u(ve, Q, He.slice(0, 239)));
          }
      }
    }
    return Cr(D, 1), D.end();
  }
  function i(S, L) {
    var R = L || {};
    if (+R.codepage >= 0 && Vr(+R.codepage), R.type == "string") throw new Error("Cannot write WK3 to JS string");
    var D = s0();
    Cr(D, 0, s(S));
    for (var Y = 0, w = 0; Y < S.SheetNames.length; ++Y) (S.Sheets[S.SheetNames[Y]] || {})["!ref"] && Cr(D, 27, _e(S.SheetNames[Y], w++));
    var te = 0;
    for (Y = 0; Y < S.SheetNames.length; ++Y) {
      var ie = S.Sheets[S.SheetNames[Y]];
      if (!(!ie || !ie["!ref"])) {
        for (var Q = Ke(ie["!ref"]), ve = ie["!data"] != null, xe = [], Ee = Math.min(Q.e.r, 8191), Le = Q.s.r; Le <= Ee; ++Le)
          for (var He = Me(Le), Xe = Q.s.c; Xe <= Q.e.c; ++Xe) {
            Le === Q.s.r && (xe[Xe] = Pe(Xe));
            var ue = xe[Xe] + He, De = ve ? (ie["!data"][Le] || [])[Xe] : ie[ue];
            if (!(!De || De.t == "z"))
              if (De.t == "n")
                Cr(D, 23, z(Le, Xe, te, De.v));
              else {
                var re = fa(De);
                Cr(D, 22, B(Le, Xe, te, re.slice(0, 239)));
              }
          }
        ++te;
      }
    }
    return Cr(D, 1), D.end();
  }
  function f(S) {
    var L = Qe(2);
    return L.write_shift(2, S), L;
  }
  function s(S) {
    var L = Qe(26);
    L.write_shift(2, 4096), L.write_shift(2, 4), L.write_shift(4, 0);
    for (var R = 0, D = 0, Y = 0, w = 0; w < S.SheetNames.length; ++w) {
      var te = S.SheetNames[w], ie = S.Sheets[te];
      if (!(!ie || !ie["!ref"])) {
        ++Y;
        var Q = wa(ie["!ref"]);
        R < Q.e.r && (R = Q.e.r), D < Q.e.c && (D = Q.e.c);
      }
    }
    return R > 8191 && (R = 8191), L.write_shift(2, R), L.write_shift(1, Y), L.write_shift(1, D), L.write_shift(2, 0), L.write_shift(2, 0), L.write_shift(1, 1), L.write_shift(1, 2), L.write_shift(4, 0), L.write_shift(4, 0), L;
  }
  function c(S, L, R) {
    var D = { s: { c: 0, r: 0 }, e: { c: 0, r: 0 } };
    return L == 8 && R.qpro ? (D.s.c = S.read_shift(1), S.l++, D.s.r = S.read_shift(2), D.e.c = S.read_shift(1), S.l++, D.e.r = S.read_shift(2), D) : (D.s.c = S.read_shift(2), D.s.r = S.read_shift(2), L == 12 && R.qpro && (S.l += 2), D.e.c = S.read_shift(2), D.e.r = S.read_shift(2), L == 12 && R.qpro && (S.l += 2), D.s.c == 65535 && (D.s.c = D.e.c = D.s.r = D.e.r = 0), D);
  }
  function o(S) {
    var L = Qe(8);
    return L.write_shift(2, S.s.c), L.write_shift(2, S.s.r), L.write_shift(2, S.e.c), L.write_shift(2, S.e.r), L;
  }
  function l(S, L, R) {
    var D = [{ c: 0, r: 0 }, { t: "n", v: 0 }, 0, 0];
    return R.qpro && R.vers != 20768 ? (D[0].c = S.read_shift(1), D[3] = S.read_shift(1), D[0].r = S.read_shift(2), S.l += 2) : R.works ? (D[0].c = S.read_shift(2), D[0].r = S.read_shift(2), D[2] = S.read_shift(2)) : (D[2] = S.read_shift(1), D[0].c = S.read_shift(2), D[0].r = S.read_shift(2)), D;
  }
  function v(S) {
    return S.z && Br(S.z) ? 240 | (r.indexOf(S.z) + 1 || 2) : 255;
  }
  function d(S, L, R) {
    var D = S.l + L, Y = l(S, L, R);
    if (Y[1].t = "s", (R.vers & 65534) == 20768) {
      S.l++;
      var w = S.read_shift(1);
      return Y[1].v = S.read_shift(w, "utf8"), Y;
    }
    return R.qpro && S.l++, Y[1].v = S.read_shift(D - S.l, "cstr"), Y;
  }
  function u(S, L, R) {
    var D = Qe(7 + R.length);
    D.write_shift(1, 255), D.write_shift(2, L), D.write_shift(2, S), D.write_shift(1, 39);
    for (var Y = 0; Y < D.length; ++Y) {
      var w = R.charCodeAt(Y);
      D.write_shift(1, w >= 128 ? 95 : w);
    }
    return D.write_shift(1, 0), D;
  }
  function p(S, L, R) {
    var D = S.l + L, Y = l(S, L, R);
    if (Y[1].t = "s", R.vers == 20768) {
      var w = S.read_shift(1);
      return Y[1].v = S.read_shift(w, "utf8"), Y;
    }
    return Y[1].v = S.read_shift(D - S.l, "cstr"), Y;
  }
  function _(S, L, R) {
    var D = l(S, L, R);
    return D[1].v = S.read_shift(2, "i"), D;
  }
  function x(S, L, R) {
    var D = Qe(7);
    return D.write_shift(1, v(R)), D.write_shift(2, L), D.write_shift(2, S), D.write_shift(2, R.v, "i"), D;
  }
  function h(S, L, R) {
    var D = l(S, L, R);
    return D[1].v = S.read_shift(8, "f"), D;
  }
  function E(S, L, R) {
    var D = Qe(13);
    return D.write_shift(1, v(R)), D.write_shift(2, L), D.write_shift(2, S), D.write_shift(8, R.v, "f"), D;
  }
  function g(S, L, R) {
    var D = S.l + L, Y = l(S, L, R);
    if (Y[1].v = S.read_shift(8, "f"), R.qpro) S.l = D;
    else {
      var w = S.read_shift(2);
      I(S.slice(S.l, S.l + w), Y), S.l += w;
    }
    return Y;
  }
  function y(S, L, R) {
    var D = L & 32768;
    return L &= -32769, L = (D ? S : 0) + (L >= 8192 ? L - 16384 : L), (D ? "" : "$") + (R ? Pe(L) : Me(L));
  }
  var P = {
    31: ["NA", 0],
    // 0x20: ["ERR", 0],
    33: ["ABS", 1],
    34: ["TRUNC", 1],
    35: ["SQRT", 1],
    36: ["LOG", 1],
    37: ["LN", 1],
    38: ["PI", 0],
    39: ["SIN", 1],
    40: ["COS", 1],
    41: ["TAN", 1],
    42: ["ATAN2", 2],
    43: ["ATAN", 1],
    44: ["ASIN", 1],
    45: ["ACOS", 1],
    46: ["EXP", 1],
    47: ["MOD", 2],
    // 0x30
    49: ["ISNA", 1],
    50: ["ISERR", 1],
    51: ["FALSE", 0],
    52: ["TRUE", 0],
    53: ["RAND", 0],
    54: ["DATE", 3],
    // 0x37 NOW
    // 0x38 PMT
    // 0x39 PV
    // 0x3A FV
    // 0x3B IF
    // 0x3C DAY
    // 0x3D MONTH
    // 0x3E YEAR
    63: ["ROUND", 2],
    64: ["TIME", 3],
    // 0x41 HOUR
    // 0x42 MINUTE
    // 0x43 SECOND
    68: ["ISNUMBER", 1],
    69: ["ISTEXT", 1],
    70: ["LEN", 1],
    71: ["VALUE", 1],
    // 0x48: ["FIXED", ?? 1],
    73: ["MID", 3],
    74: ["CHAR", 1],
    // 0x4B
    // 0x4C FIND
    // 0x4D DATEVALUE
    // 0x4E TIMEVALUE
    // 0x4F CELL
    80: ["SUM", 69],
    81: ["AVERAGEA", 69],
    82: ["COUNTA", 69],
    83: ["MINA", 69],
    84: ["MAXA", 69],
    // 0x55 VLOOKUP
    // 0x56 NPV
    // 0x57 VAR
    // 0x58 STD
    // 0x59 IRR
    // 0x5A HLOOKUP
    // 0x5B DSUM
    // 0x5C DAVERAGE
    // 0x5D DCOUNTA
    // 0x5E DMIN
    // 0x5F DMAX
    // 0x60 DVARP
    // 0x61 DSTDEVP
    // 0x62 INDEX
    // 0x63 COLS
    // 0x64 ROWS
    // 0x65 REPEAT
    102: ["UPPER", 1],
    103: ["LOWER", 1],
    // 0x68 LEFT
    // 0x69 RIGHT
    // 0x6A REPLACE
    107: ["PROPER", 1],
    // 0x6C CELL
    109: ["TRIM", 1],
    // 0x6E CLEAN
    111: ["T", 1]
    // 0x70 V
  }, M = [
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    // eslint-disable-line no-mixed-spaces-and-tabs
    "",
    "+",
    "-",
    "*",
    "/",
    "^",
    "=",
    "<>",
    // eslint-disable-line no-mixed-spaces-and-tabs
    "<=",
    ">=",
    "<",
    ">",
    "",
    "",
    "",
    "",
    // eslint-disable-line no-mixed-spaces-and-tabs
    "&",
    "",
    "",
    "",
    "",
    "",
    "",
    ""
    // eslint-disable-line no-mixed-spaces-and-tabs
  ];
  function I(S, L) {
    rr(S, 0);
    for (var R = [], D = 0, Y = "", w = "", te = "", ie = ""; S.l < S.length; ) {
      var Q = S[S.l++];
      switch (Q) {
        case 0:
          R.push(S.read_shift(8, "f"));
          break;
        case 1:
          w = y(L[0].c, S.read_shift(2), !0), Y = y(L[0].r, S.read_shift(2), !1), R.push(w + Y);
          break;
        case 2:
          {
            var ve = y(L[0].c, S.read_shift(2), !0), xe = y(L[0].r, S.read_shift(2), !1);
            w = y(L[0].c, S.read_shift(2), !0), Y = y(L[0].r, S.read_shift(2), !1), R.push(ve + xe + ":" + w + Y);
          }
          break;
        case 3:
          if (S.l < S.length) {
            console.error("WK1 premature formula end");
            return;
          }
          break;
        case 4:
          R.push("(" + R.pop() + ")");
          break;
        case 5:
          R.push(S.read_shift(2));
          break;
        case 6:
          {
            for (var Ee = ""; Q = S[S.l++]; ) Ee += String.fromCharCode(Q);
            R.push('"' + Ee.replace(/"/g, '""') + '"');
          }
          break;
        case 8:
          R.push("-" + R.pop());
          break;
        case 23:
          R.push("+" + R.pop());
          break;
        case 22:
          R.push("NOT(" + R.pop() + ")");
          break;
        case 20:
        case 21:
          ie = R.pop(), te = R.pop(), R.push(["AND", "OR"][Q - 20] + "(" + te + "," + ie + ")");
          break;
        default:
          if (Q < 32 && M[Q])
            ie = R.pop(), te = R.pop(), R.push(te + M[Q] + ie);
          else if (P[Q]) {
            if (D = P[Q][1], D == 69 && (D = S[S.l++]), D > R.length) {
              console.error("WK1 bad formula parse 0x" + Q.toString(16) + ":|" + R.join("|") + "|");
              return;
            }
            var Le = R.slice(-D);
            R.length -= D, R.push(P[Q][0] + "(" + Le.join(",") + ")");
          } else return Q <= 7 ? console.error("WK1 invalid opcode " + Q.toString(16)) : Q <= 24 ? console.error("WK1 unsupported op " + Q.toString(16)) : Q <= 30 ? console.error("WK1 invalid opcode " + Q.toString(16)) : Q <= 115 ? console.error("WK1 unsupported function opcode " + Q.toString(16)) : console.error("WK1 unrecognized opcode " + Q.toString(16));
      }
    }
    R.length == 1 ? L[1].f = "" + R[0] : console.error("WK1 bad formula parse |" + R.join("|") + "|");
  }
  function N(S) {
    var L = [{ c: 0, r: 0 }, { t: "n", v: 0 }, 0];
    return L[0].r = S.read_shift(2), L[3] = S[S.l++], L[0].c = S[S.l++], L;
  }
  function O(S, L) {
    var R = N(S);
    return R[1].t = "s", R[1].v = S.read_shift(L - 4, "cstr"), R;
  }
  function B(S, L, R, D) {
    var Y = Qe(6 + D.length);
    Y.write_shift(2, S), Y.write_shift(1, R), Y.write_shift(1, L), Y.write_shift(1, 39);
    for (var w = 0; w < D.length; ++w) {
      var te = D.charCodeAt(w);
      Y.write_shift(1, te >= 128 ? 95 : te);
    }
    return Y.write_shift(1, 0), Y;
  }
  function b(S, L) {
    var R = N(S);
    R[1].v = S.read_shift(2);
    var D = R[1].v >> 1;
    if (R[1].v & 1)
      switch (D & 7) {
        case 0:
          D = (D >> 3) * 5e3;
          break;
        case 1:
          D = (D >> 3) * 500;
          break;
        case 2:
          D = (D >> 3) / 20;
          break;
        case 3:
          D = (D >> 3) / 200;
          break;
        case 4:
          D = (D >> 3) / 2e3;
          break;
        case 5:
          D = (D >> 3) / 2e4;
          break;
        case 6:
          D = (D >> 3) / 16;
          break;
        case 7:
          D = (D >> 3) / 64;
          break;
      }
    return R[1].v = D, R;
  }
  function G(S, L) {
    var R = N(S), D = S.read_shift(4), Y = S.read_shift(4), w = S.read_shift(2);
    if (w == 65535)
      return D === 0 && Y === 3221225472 ? (R[1].t = "e", R[1].v = 15) : D === 0 && Y === 3489660928 ? (R[1].t = "e", R[1].v = 42) : R[1].v = 0, R;
    var te = w & 32768;
    return w = (w & 32767) - 16446, R[1].v = (1 - te * 2) * (Y * Math.pow(2, w + 32) + D * Math.pow(2, w)), R;
  }
  function z(S, L, R, D) {
    var Y = Qe(14);
    if (Y.write_shift(2, S), Y.write_shift(1, R), Y.write_shift(1, L), D == 0)
      return Y.write_shift(4, 0), Y.write_shift(4, 0), Y.write_shift(2, 65535), Y;
    var w = 0, te = 0, ie = 0, Q = 0;
    return D < 0 && (w = 1, D = -D), te = Math.log2(D) | 0, D /= Math.pow(2, te - 31), Q = D >>> 0, (Q & 2147483648) == 0 && (D /= 2, ++te, Q = D >>> 0), D -= Q, Q |= 2147483648, Q >>>= 0, D *= Math.pow(2, 32), ie = D >>> 0, Y.write_shift(4, ie), Y.write_shift(4, Q), te += 16383 + (w ? 32768 : 0), Y.write_shift(2, te), Y;
  }
  function fe(S, L) {
    var R = G(S);
    return S.l += L - 14, R;
  }
  function j(S, L) {
    var R = N(S), D = S.read_shift(4);
    return R[1].v = D >> 6, R;
  }
  function he(S, L) {
    var R = N(S), D = S.read_shift(8, "f");
    return R[1].v = D, R;
  }
  function J(S, L) {
    var R = he(S);
    return S.l += L - 12, R;
  }
  function ne(S, L) {
    return S[S.l + L - 1] == 0 ? S.read_shift(L, "cstr") : "";
  }
  function pe(S, L) {
    var R = S[S.l++];
    R > L - 1 && (R = L - 1);
    for (var D = ""; D.length < R; ) D += String.fromCharCode(S[S.l++]);
    return D;
  }
  function X(S, L, R) {
    if (!(!R.qpro || L < 21)) {
      var D = S.read_shift(1);
      S.l += 17, S.l += 1, S.l += 2;
      var Y = S.read_shift(L - 21, "cstr");
      return [D, Y];
    }
  }
  function ke(S, L) {
    for (var R = {}, D = S.l + L; S.l < D; ) {
      var Y = S.read_shift(2);
      if (Y == 14e3) {
        for (R[Y] = [0, ""], R[Y][0] = S.read_shift(2); S[S.l]; )
          R[Y][1] += String.fromCharCode(S[S.l]), S.l++;
        S.l++;
      }
    }
    return R;
  }
  function _e(S, L) {
    var R = Qe(5 + S.length);
    R.write_shift(2, 14e3), R.write_shift(2, L);
    for (var D = 0; D < S.length; ++D) {
      var Y = S.charCodeAt(D);
      R[R.l++] = Y > 127 ? 95 : Y;
    }
    return R[R.l++] = 0, R;
  }
  var de = {
    0: { n: "BOF", f: ze },
    1: { n: "EOF" },
    2: { n: "CALCMODE" },
    3: { n: "CALCORDER" },
    4: { n: "SPLIT" },
    5: { n: "SYNC" },
    6: { n: "RANGE", f: c },
    7: { n: "WINDOW1" },
    8: { n: "COLW1" },
    9: { n: "WINTWO" },
    10: { n: "COLW2" },
    11: { n: "NAME" },
    12: { n: "BLANK" },
    13: { n: "INTEGER", f: _ },
    14: { n: "NUMBER", f: h },
    15: { n: "LABEL", f: d },
    16: { n: "FORMULA", f: g },
    24: { n: "TABLE" },
    25: { n: "ORANGE" },
    26: { n: "PRANGE" },
    27: { n: "SRANGE" },
    28: { n: "FRANGE" },
    29: { n: "KRANGE1" },
    32: { n: "HRANGE" },
    35: { n: "KRANGE2" },
    36: { n: "PROTEC" },
    37: { n: "FOOTER" },
    38: { n: "HEADER" },
    39: { n: "SETUP" },
    40: { n: "MARGINS" },
    41: { n: "LABELFMT" },
    42: { n: "TITLES" },
    43: { n: "SHEETJS" },
    45: { n: "GRAPH" },
    46: { n: "NGRAPH" },
    47: { n: "CALCCOUNT" },
    48: { n: "UNFORMATTED" },
    49: { n: "CURSORW12" },
    50: { n: "WINDOW" },
    51: { n: "STRING", f: p },
    55: { n: "PASSWORD" },
    56: { n: "LOCKED" },
    60: { n: "QUERY" },
    61: { n: "QUERYNAME" },
    62: { n: "PRINT" },
    63: { n: "PRINTNAME" },
    64: { n: "GRAPH2" },
    65: { n: "GRAPHNAME" },
    66: { n: "ZOOM" },
    67: { n: "SYMSPLIT" },
    68: { n: "NSROWS" },
    69: { n: "NSCOLS" },
    70: { n: "RULER" },
    71: { n: "NNAME" },
    72: { n: "ACOMM" },
    73: { n: "AMACRO" },
    74: { n: "PARSE" },
    // 0x0064
    102: { n: "PRANGES??" },
    103: { n: "RRANGES??" },
    104: { n: "FNAME??" },
    105: { n: "MRANGES??" },
    // 0x0096
    // 0x0099
    // 0x009A
    // 0x009B
    // 0x009C
    // 0x00C0
    // 0x00C7
    // 0x00C9
    204: { n: "SHEETNAMECS", f: ne },
    // 0x00CD
    222: { n: "SHEETNAMELP", f: pe },
    255: { n: "BOF", f: ze },
    21506: { n: "WKSNF", f: ze },
    65535: { n: "" }
  }, ce = {
    0: { n: "BOF" },
    1: { n: "EOF" },
    2: { n: "PASSWORD" },
    3: { n: "CALCSET" },
    4: { n: "WINDOWSET" },
    5: { n: "SHEETCELLPTR" },
    6: { n: "SHEETLAYOUT" },
    7: { n: "COLUMNWIDTH" },
    8: { n: "HIDDENCOLUMN" },
    9: { n: "USERRANGE" },
    10: { n: "SYSTEMRANGE" },
    11: { n: "ZEROFORCE" },
    12: { n: "SORTKEYDIR" },
    13: { n: "FILESEAL" },
    14: { n: "DATAFILLNUMS" },
    15: { n: "PRINTMAIN" },
    16: { n: "PRINTSTRING" },
    17: { n: "GRAPHMAIN" },
    18: { n: "GRAPHSTRING" },
    19: { n: "??" },
    20: { n: "ERRCELL" },
    21: { n: "NACELL" },
    22: { n: "LABEL16", f: O },
    23: { n: "NUMBER17", f: G },
    24: { n: "NUMBER18", f: b },
    25: { n: "FORMULA19", f: fe },
    26: { n: "FORMULA1A" },
    27: { n: "XFORMAT", f: ke },
    28: { n: "DTLABELMISC" },
    29: { n: "DTLABELCELL" },
    30: { n: "GRAPHWINDOW" },
    31: { n: "CPA" },
    32: { n: "LPLAUTO" },
    33: { n: "QUERY" },
    34: { n: "HIDDENSHEET" },
    35: { n: "??" },
    37: { n: "NUMBER25", f: j },
    38: { n: "??" },
    39: { n: "NUMBER27", f: he },
    40: { n: "FORMULA28", f: J },
    142: { n: "??" },
    147: { n: "??" },
    150: { n: "??" },
    151: { n: "??" },
    152: { n: "??" },
    153: { n: "??" },
    154: { n: "??" },
    155: { n: "??" },
    156: { n: "??" },
    163: { n: "??" },
    174: { n: "??" },
    175: { n: "??" },
    176: { n: "??" },
    177: { n: "??" },
    184: { n: "??" },
    185: { n: "??" },
    186: { n: "??" },
    187: { n: "??" },
    188: { n: "??" },
    195: { n: "??" },
    201: { n: "??" },
    204: { n: "SHEETNAMECS", f: ne },
    205: { n: "??" },
    206: { n: "??" },
    207: { n: "??" },
    208: { n: "??" },
    256: { n: "??" },
    259: { n: "??" },
    260: { n: "??" },
    261: { n: "??" },
    262: { n: "??" },
    263: { n: "??" },
    265: { n: "??" },
    266: { n: "??" },
    267: { n: "??" },
    268: { n: "??" },
    270: { n: "??" },
    271: { n: "??" },
    384: { n: "??" },
    389: { n: "??" },
    390: { n: "??" },
    393: { n: "??" },
    396: { n: "??" },
    512: { n: "??" },
    514: { n: "??" },
    513: { n: "??" },
    516: { n: "??" },
    517: { n: "??" },
    640: { n: "??" },
    641: { n: "??" },
    642: { n: "??" },
    643: { n: "??" },
    644: { n: "??" },
    645: { n: "??" },
    646: { n: "??" },
    647: { n: "??" },
    648: { n: "??" },
    658: { n: "??" },
    659: { n: "??" },
    660: { n: "??" },
    661: { n: "??" },
    662: { n: "??" },
    665: { n: "??" },
    666: { n: "??" },
    768: { n: "??" },
    772: { n: "??" },
    1537: { n: "SHEETINFOQP", f: X },
    1600: { n: "??" },
    1602: { n: "??" },
    1793: { n: "??" },
    1794: { n: "??" },
    1795: { n: "??" },
    1796: { n: "??" },
    1920: { n: "??" },
    2048: { n: "??" },
    2049: { n: "??" },
    2052: { n: "??" },
    2688: { n: "??" },
    10998: { n: "??" },
    12849: { n: "??" },
    28233: { n: "??" },
    28484: { n: "??" },
    65535: { n: "" }
  }, Te = {
    5: "dd-mmm-yy",
    6: "dd-mmm",
    7: "mmm-yy",
    8: "mm/dd/yy",
    // Long Date Intl
    10: "hh:mm:ss AM/PM",
    11: "hh:mm AM/PM",
    14: "dd-mmm-yyyy",
    15: "mmm-yyyy",
    /* It is suspected that the the low nybble specifies decimal places */
    34: "0.00",
    50: "0.00;[Red]0.00",
    66: "0.00;(0.00)",
    82: "0.00;[Red](0.00)",
    162: '"$"#,##0.00;\\("$"#,##0.00\\)',
    288: "0%",
    304: "0E+00",
    320: "# ?/?"
  };
  function me(S) {
    var L = S.read_shift(2), R = S.read_shift(1);
    if (R != 0) throw "unsupported QPW string type " + R.toString(16);
    return S.read_shift(L, "sbcs-cont");
  }
  function Fe(S, L) {
    rr(S, 0);
    var R = L || {}, D = {};
    R.dense && (D["!data"] = []);
    var Y = [], w = "", te = { s: { r: -1, c: -1 }, e: { r: -1, c: -1 } }, ie = 0, Q = 0, ve = 0, xe = 0, Ee = { SheetNames: [], Sheets: {} }, Le = [];
    e: for (; S.l < S.length; ) {
      var He = S.read_shift(2), Xe = S.read_shift(2), ue = S.slice(S.l, S.l + Xe);
      switch (rr(ue, 0), He) {
        case 1:
          if (ue.read_shift(4) != 962023505) throw "Bad QPW9 BOF!";
          break;
        case 2:
          break e;
        case 8:
          break;
        // TODO: this is tied to custom number formats
        case 10:
          for (var De = ue.read_shift(4), re = (ue.length - ue.l) / De | 0, Sr = 0; Sr < De; ++Sr) {
            var gr = ue.l + re, We = {};
            ue.l += 2, We.numFmtId = ue.read_shift(2), Te[We.numFmtId] && (We.z = Te[We.numFmtId]), ue.l = gr, Le.push(We);
          }
          break;
        /* TODO: The behavior here should be consistent with Numbers: QP Notebook ~ .TN.SheetArchive, QP Sheet ~ .TST.TableModelArchive */
        case 1025:
          break;
        case 1026:
          break;
        case 1031:
          for (ue.l += 12; ue.l < ue.length; )
            ie = ue.read_shift(2), Q = ue.read_shift(1), Y.push(ue.read_shift(ie, "cstr"));
          break;
        case 1032:
          break;
        case 1537:
          {
            var Hr = ue.read_shift(2);
            D = {}, R.dense && (D["!data"] = []), te.s.c = ue.read_shift(2), te.e.c = ue.read_shift(2), te.s.r = ue.read_shift(4), te.e.r = ue.read_shift(4), ue.l += 4, ue.l + 2 < ue.length && (ie = ue.read_shift(2), Q = ue.read_shift(1), w = ie == 0 ? "" : ue.read_shift(ie, "cstr")), w || (w = Pe(Hr));
          }
          break;
        case 1538:
          {
            if (te.s.c > 255 || te.s.r > 999999) break;
            te.e.c < te.s.c && (te.e.c = te.s.c), te.e.r < te.s.r && (te.e.r = te.s.r), D["!ref"] = ye(te), vt(Ee, D, w);
          }
          break;
        case 2561:
          ve = ue.read_shift(2), te.e.c < ve && (te.e.c = ve), te.s.c > ve && (te.s.c = ve), xe = ue.read_shift(4), te.s.r > xe && (te.s.r = xe), xe = ue.read_shift(4), te.e.r < xe && (te.e.r = xe);
          break;
        case 3073:
          {
            xe = ue.read_shift(4), ie = ue.read_shift(4), te.s.r > xe && (te.s.r = xe), te.e.r < xe + ie - 1 && (te.e.r = xe + ie - 1);
            for (var Er = Pe(ve); ue.l < ue.length; ) {
              var se = { t: "z" }, be = ue.read_shift(1), Ye = -1;
              be & 128 && (Ye = ue.read_shift(2));
              var je = be & 64 ? ue.read_shift(2) - 1 : 0;
              switch (be & 31) {
                case 0:
                  break;
                case 1:
                  break;
                case 2:
                  se = { t: "n", v: ue.read_shift(2) };
                  break;
                case 3:
                  se = { t: "n", v: ue.read_shift(2, "i") };
                  break;
                case 4:
                  se = { t: "n", v: Gt(ue) };
                  break;
                case 5:
                  se = { t: "n", v: ue.read_shift(8, "f") };
                  break;
                case 7:
                  se = { t: "s", v: Y[Q = ue.read_shift(4) - 1] };
                  break;
                case 8:
                  se = { t: "n", v: ue.read_shift(8, "f") }, ue.l += 2, ue.l += 4, isNaN(se.v) && (se = { t: "e", v: 15 });
                  break;
                default:
                  throw "Unrecognized QPW cell type " + (be & 31);
              }
              Ye != -1 && (Le[Ye - 1] || {}).z && (se.z = Le[Ye - 1].z);
              var Yr = 0;
              if (be & 32) switch (be & 31) {
                case 2:
                  Yr = ue.read_shift(2);
                  break;
                case 3:
                  Yr = ue.read_shift(2, "i");
                  break;
                case 7:
                  Yr = ue.read_shift(2);
                  break;
                default:
                  throw "Unsupported delta for QPW cell type " + (be & 31);
              }
              if (!(!R.sheetStubs && se.t == "z")) {
                var ua = er(se);
                se.t == "n" && se.z && Br(se.z) && R.cellDates && (ua.v = ia(se.v), ua.t = typeof ua.v == "number" ? "n" : "d"), D["!data"] != null ? (D["!data"][xe] || (D["!data"][xe] = []), D["!data"][xe][ve] = ua) : D[Er + Me(xe)] = ua;
              }
              for (++xe, --ie; je-- > 0 && ie >= 0; ) {
                if (be & 32) switch (be & 31) {
                  case 2:
                    se = { t: "n", v: se.v + Yr & 65535 };
                    break;
                  case 3:
                    se = { t: "n", v: se.v + Yr & 65535 }, se.v > 32767 && (se.v -= 65536);
                    break;
                  case 7:
                    se = { t: "s", v: Y[Q = Q + Yr >>> 0] };
                    break;
                  default:
                    throw "Cannot apply delta for QPW cell type " + (be & 31);
                }
                else switch (be & 31) {
                  case 1:
                    se = { t: "z" };
                    break;
                  case 2:
                    se = { t: "n", v: ue.read_shift(2) };
                    break;
                  case 7:
                    se = { t: "s", v: Y[Q = ue.read_shift(4) - 1] };
                    break;
                  default:
                    throw "Cannot apply repeat for QPW cell type " + (be & 31);
                }
                !R.sheetStubs && se.t == "z" || (D["!data"] != null ? (D["!data"][xe] || (D["!data"][xe] = []), D["!data"][xe][ve] = se) : D[Er + Me(xe)] = se), ++xe, --ie;
              }
            }
          }
          break;
        case 3074:
          {
            ve = ue.read_shift(2), xe = ue.read_shift(4);
            var pt = me(ue);
            D["!data"] != null ? (D["!data"][xe] || (D["!data"][xe] = []), D["!data"][xe][ve] = { t: "s", v: pt }) : D[Pe(ve) + Me(xe)] = { t: "s", v: pt };
          }
          break;
      }
      S.l += Xe;
    }
    return Ee;
  }
  return {
    sheet_to_wk1: n,
    book_to_wk3: i,
    to_workbook: a
  };
})();
function El(e) {
  var a = {}, r = e.match(or), t = 0, n = !1;
  if (r) for (; t != r.length; ++t) {
    var i = le(r[t]);
    switch (i[0].replace(/<\w*:/g, "<")) {
      /* 18.8.12 condense CT_BooleanProperty */
      /* ** not required . */
      case "<condense":
        break;
      /* 18.8.17 extend CT_BooleanProperty */
      /* ** not required . */
      case "<extend":
        break;
      /* 18.8.36 shadow CT_BooleanProperty */
      /* ** not required . */
      case "<shadow":
        if (!i.val) break;
      /* falls through */
      case "<shadow>":
      case "<shadow/>":
        a.shadow = 1;
        break;
      case "</shadow>":
        break;
      /* 18.4.1 charset CT_IntProperty TODO */
      case "<charset":
        if (i.val == "1") break;
        a.cp = x0[parseInt(i.val, 10)];
        break;
      /* 18.4.2 outline CT_BooleanProperty TODO */
      case "<outline":
        if (!i.val) break;
      /* falls through */
      case "<outline>":
      case "<outline/>":
        a.outline = 1;
        break;
      case "</outline>":
        break;
      /* 18.4.5 rFont CT_FontName */
      case "<rFont":
        a.name = i.val;
        break;
      /* 18.4.11 sz CT_FontSize */
      case "<sz":
        a.sz = i.val;
        break;
      /* 18.4.10 strike CT_BooleanProperty */
      case "<strike":
        if (!i.val) break;
      /* falls through */
      case "<strike>":
      case "<strike/>":
        a.strike = 1;
        break;
      case "</strike>":
        break;
      /* 18.4.13 u CT_UnderlineProperty */
      case "<u":
        if (!i.val) break;
        switch (i.val) {
          case "double":
            a.uval = "double";
            break;
          case "singleAccounting":
            a.uval = "single-accounting";
            break;
          case "doubleAccounting":
            a.uval = "double-accounting";
            break;
        }
      /* falls through */
      case "<u>":
      case "<u/>":
        a.u = 1;
        break;
      case "</u>":
        break;
      /* 18.8.2 b */
      case "<b":
        if (i.val == "0") break;
      /* falls through */
      case "<b>":
      case "<b/>":
        a.b = 1;
        break;
      case "</b>":
        break;
      /* 18.8.26 i */
      case "<i":
        if (i.val == "0") break;
      /* falls through */
      case "<i>":
      case "<i/>":
        a.i = 1;
        break;
      case "</i>":
        break;
      /* 18.3.1.15 color CT_Color TODO: tint, theme, auto, indexed */
      case "<color":
        i.rgb && (a.color = i.rgb.slice(2, 8));
        break;
      case "<color>":
      case "<color/>":
      case "</color>":
        break;
      /* 18.8.18 family ST_FontFamily */
      case "<family":
        a.family = i.val;
        break;
      case "<family>":
      case "<family/>":
      case "</family>":
        break;
      /* 18.4.14 vertAlign CT_VerticalAlignFontProperty TODO */
      case "<vertAlign":
        a.valign = i.val;
        break;
      case "<vertAlign>":
      case "<vertAlign/>":
      case "</vertAlign>":
        break;
      /* 18.8.35 scheme CT_FontScheme TODO */
      case "<scheme":
        break;
      case "<scheme>":
      case "<scheme/>":
      case "</scheme>":
        break;
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
        break;
      case "<ext":
        n = !0;
        break;
      case "</ext>":
        n = !1;
        break;
      default:
        if (i[0].charCodeAt(1) !== 47 && !n) throw new Error("Unrecognized rich format " + i[0]);
    }
  }
  return a;
}
var Tl = /* @__PURE__ */ (function() {
  function e(t) {
    var n = ir(t, "t");
    if (!n) return { t: "s", v: "" };
    var i = { t: "s", v: Ce(n[1]) }, f = ir(t, "rPr");
    return f && (i.s = El(f[1])), i;
  }
  var a = /<(?:\w+:)?r>/g, r = /<\/(?:\w+:)?r>/;
  return function(n) {
    return n.replace(a, "").split(r).map(e).filter(function(i) {
      return i.v;
    });
  };
})(), wl = /* @__PURE__ */ (function() {
  var a = /(\r\n|\n)/g;
  function r(n, i, f) {
    var s = [];
    n.u && s.push("text-decoration: underline;"), n.uval && s.push("text-underline-style:" + n.uval + ";"), n.sz && s.push("font-size:" + n.sz + "pt;"), n.outline && s.push("text-effect: outline;"), n.shadow && s.push("text-shadow: auto;"), i.push('<span style="' + s.join("") + '">'), n.b && (i.push("<b>"), f.push("</b>")), n.i && (i.push("<i>"), f.push("</i>")), n.strike && (i.push("<s>"), f.push("</s>"));
    var c = n.valign || "";
    return c == "superscript" || c == "super" ? c = "sup" : c == "subscript" && (c = "sub"), c != "" && (i.push("<" + c + ">"), f.push("</" + c + ">")), f.push("</span>"), n;
  }
  function t(n) {
    var i = [[], n.v, []];
    return n.v ? (n.s && r(n.s, i[0], i[2]), i[0].join("") + i[1].replace(a, "<br/>") + i[2].join("")) : "";
  }
  return function(i) {
    return i.map(t).join("");
  };
})(), Fl = /<(?:\w+:)?t\b[^<>]*>([^<]*)<\/(?:\w+:)?t>/g, Al = /<(?:\w+:)?r\b[^<>]*>/;
function D0(e, a) {
  var r = a ? a.cellHTML : !0, t = {};
  return e ? (e.match(/^\s*<(?:\w+:)?t[^>]*>/) ? (t.t = Ce(Ue(e.slice(e.indexOf(">") + 1).split(/<\/(?:\w+:)?t>/)[0] || ""), !0), t.r = Ue(e), r && (t.h = Ga(t.t))) : (
    /*y = */
    e.match(Al) && (t.r = Ue(e), t.t = Ce(Ue((Of(e, "rPh").match(Fl) || []).join("").replace(or, "")), !0), r && (t.h = wl(Tl(t.r))))
  ), t) : { t: "" };
}
var Sl = /<(?:\w+:)?(?:si|sstItem)>/g, Cl = /<\/(?:\w+:)?(?:si|sstItem)>/;
function yl(e, a) {
  var r = [], t = "";
  if (!e) return r;
  var n = ir(e, "sst");
  if (n) {
    t = n[1].replace(Sl, "").split(Cl);
    for (var i = 0; i != t.length; ++i) {
      var f = D0(t[i].trim(), a);
      f != null && (r[r.length] = f);
    }
    n = le(n[0].slice(0, n[0].indexOf(">"))), r.Count = n.count, r.Unique = n.uniqueCount;
  }
  return r;
}
function Dl(e) {
  return [e.read_shift(4), e.read_shift(4)];
}
function Il(e, a) {
  var r = [], t = !1;
  return ra(e, function(i, f, s) {
    switch (s) {
      case 159:
        r.Count = i[0], r.Unique = i[1];
        break;
      case 19:
        r.push(i);
        break;
      case 160:
        return !0;
      case 35:
        t = !0;
        break;
      case 36:
        t = !1;
        break;
      default:
        if (f.T, !t || a.WTF) throw new Error("Unexpected record 0x" + s.toString(16));
    }
  }), r;
}
function Vi(e) {
  for (var a = [], r = e.split(""), t = 0; t < r.length; ++t) a[t] = r[t].charCodeAt(0);
  return a;
}
function Qr(e, a) {
  var r = {};
  return r.Major = e.read_shift(2), r.Minor = e.read_shift(2), a >= 4 && (e.l += a - 4), r;
}
function Ol(e) {
  var a = {};
  return a.id = e.read_shift(0, "lpp4"), a.R = Qr(e, 4), a.U = Qr(e, 4), a.W = Qr(e, 4), a;
}
function Rl(e) {
  for (var a = e.read_shift(4), r = e.l + a - 4, t = {}, n = e.read_shift(4), i = []; n-- > 0; ) i.push({ t: e.read_shift(4), v: e.read_shift(0, "lpp4") });
  if (t.name = e.read_shift(0, "lpp4"), t.comps = i, e.l != r) throw new Error("Bad DataSpaceMapEntry: " + e.l + " != " + r);
  return t;
}
function Nl(e) {
  var a = [];
  e.l += 4;
  for (var r = e.read_shift(4); r-- > 0; ) a.push(Rl(e));
  return a;
}
function Pl(e) {
  var a = [];
  e.l += 4;
  for (var r = e.read_shift(4); r-- > 0; ) a.push(e.read_shift(0, "lpp4"));
  return a;
}
function bl(e) {
  var a = {};
  return e.read_shift(4), e.l += 4, a.id = e.read_shift(0, "lpp4"), a.name = e.read_shift(0, "lpp4"), a.R = Qr(e, 4), a.U = Qr(e, 4), a.W = Qr(e, 4), a;
}
function Ll(e) {
  var a = bl(e);
  if (a.ename = e.read_shift(0, "8lpp4"), a.blksz = e.read_shift(4), a.cmode = e.read_shift(4), e.read_shift(4) != 4) throw new Error("Bad !Primary record");
  return a;
}
function Gi(e, a) {
  var r = e.l + a, t = {};
  t.Flags = e.read_shift(4) & 63, e.l += 4, t.AlgID = e.read_shift(4);
  var n = !1;
  switch (t.AlgID) {
    case 26126:
    case 26127:
    case 26128:
      n = t.Flags == 36;
      break;
    case 26625:
      n = t.Flags == 4;
      break;
    case 0:
      n = t.Flags == 16 || t.Flags == 4 || t.Flags == 36;
      break;
    default:
      throw "Unrecognized encryption algorithm: " + t.AlgID;
  }
  if (!n) throw new Error("Encryption Flags/AlgID mismatch");
  return t.AlgIDHash = e.read_shift(4), t.KeySize = e.read_shift(4), t.ProviderType = e.read_shift(4), e.l += 8, t.CSPName = e.read_shift(r - e.l >> 1, "utf16le"), e.l = r, t;
}
function Xi(e, a) {
  var r = {}, t = e.l + a;
  return e.l += 4, r.Salt = e.slice(e.l, e.l + 16), e.l += 16, r.Verifier = e.slice(e.l, e.l + 16), e.l += 16, e.read_shift(4), r.VerifierHash = e.slice(e.l, t), e.l = t, r;
}
function Bl(e) {
  var a = Qr(e);
  switch (a.Minor) {
    case 2:
      return [a.Minor, Ml(e)];
    case 3:
      return [a.Minor, Ul()];
    case 4:
      return [a.Minor, Hl(e)];
  }
  throw new Error("ECMA-376 Encrypted file unrecognized Version: " + a.Minor);
}
function Ml(e) {
  var a = e.read_shift(4);
  if ((a & 63) != 36) throw new Error("EncryptionInfo mismatch");
  var r = e.read_shift(4), t = Gi(e, r), n = Xi(e, e.length - e.l);
  return { t: "Std", h: t, v: n };
}
function Ul() {
  throw new Error("File is password-protected: ECMA-376 Extensible");
}
function Hl(e) {
  var a = ["saltSize", "blockSize", "keyBits", "hashSize", "cipherAlgorithm", "cipherChaining", "hashAlgorithm", "saltValue"];
  e.l += 4;
  var r = e.read_shift(e.length - e.l, "utf8"), t = {};
  return r.replace(or, function(i) {
    var f = le(i);
    switch (Mr(f[0])) {
      case "<?xml":
        break;
      case "<encryption":
      case "</encryption>":
        break;
      case "<keyData":
        a.forEach(function(s) {
          t[s] = f[s];
        });
        break;
      case "<dataIntegrity":
        t.encryptedHmacKey = f.encryptedHmacKey, t.encryptedHmacValue = f.encryptedHmacValue;
        break;
      case "<keyEncryptors>":
      case "<keyEncryptors":
        t.encs = [];
        break;
      case "</keyEncryptors>":
        break;
      case "<keyEncryptor":
        t.uri = f.uri;
        break;
      case "</keyEncryptor>":
        break;
      case "<encryptedKey":
        t.encs.push(f);
        break;
      default:
        throw f[0];
    }
  }), t;
}
function Wl(e, a) {
  var r = {}, t = r.EncryptionVersionInfo = Qr(e, 4);
  if (a -= 4, t.Minor != 2) throw new Error("unrecognized minor version code: " + t.Minor);
  if (t.Major > 4 || t.Major < 2) throw new Error("unrecognized major version code: " + t.Major);
  r.Flags = e.read_shift(4), a -= 4;
  var n = e.read_shift(4);
  return a -= 4, r.EncryptionHeader = Gi(e, n), a -= n, r.EncryptionVerifier = Xi(e, a), r;
}
function Vl(e) {
  var a = {}, r = a.EncryptionVersionInfo = Qr(e, 4);
  if (r.Major != 1 || r.Minor != 1) throw "unrecognized version code " + r.Major + " : " + r.Minor;
  return a.Salt = e.read_shift(16), a.EncryptedVerifier = e.read_shift(16), a.EncryptedVerifierHash = e.read_shift(16), a;
}
function Gl(e) {
  var a = 0, r, t = Vi(e), n = t.length + 1, i, f, s, c, o;
  for (r = sa(n), r[0] = t.length, i = 1; i != n; ++i) r[i] = t[i - 1];
  for (i = n - 1; i >= 0; --i)
    f = r[i], s = (a & 16384) === 0 ? 0 : 1, c = a << 1 & 32767, o = s | c, a = o ^ f;
  return a ^ 52811;
}
var zi = /* @__PURE__ */ (function() {
  var e = [187, 255, 255, 186, 255, 255, 185, 128, 0, 190, 15, 0, 191, 15, 0], a = [57840, 7439, 52380, 33984, 4364, 3600, 61902, 12606, 6258, 57657, 54287, 34041, 10252, 43370, 20163], r = [44796, 19929, 39858, 10053, 20106, 40212, 10761, 31585, 63170, 64933, 60267, 50935, 40399, 11199, 17763, 35526, 1453, 2906, 5812, 11624, 23248, 885, 1770, 3540, 7080, 14160, 28320, 56640, 55369, 41139, 20807, 41614, 21821, 43642, 17621, 28485, 56970, 44341, 19019, 38038, 14605, 29210, 60195, 50791, 40175, 10751, 21502, 43004, 24537, 18387, 36774, 3949, 7898, 15796, 31592, 63184, 47201, 24803, 49606, 37805, 14203, 28406, 56812, 17824, 35648, 1697, 3394, 6788, 13576, 27152, 43601, 17539, 35078, 557, 1114, 2228, 4456, 30388, 60776, 51953, 34243, 7079, 14158, 28316, 14128, 28256, 56512, 43425, 17251, 34502, 7597, 13105, 26210, 52420, 35241, 883, 1766, 3532, 4129, 8258, 16516, 33032, 4657, 9314, 18628], t = function(f) {
    return (f / 2 | f * 128) & 255;
  }, n = function(f, s) {
    return t(f ^ s);
  }, i = function(f) {
    for (var s = a[f.length - 1], c = 104, o = f.length - 1; o >= 0; --o)
      for (var l = f[o], v = 0; v != 7; ++v)
        l & 64 && (s ^= r[c]), l *= 2, --c;
    return s;
  };
  return function(f) {
    for (var s = Vi(f), c = i(s), o = s.length, l = sa(16), v = 0; v != 16; ++v) l[v] = 0;
    var d, u, p;
    for ((o & 1) === 1 && (d = c >> 8, l[o] = n(e[0], d), --o, d = c & 255, u = s[s.length - 1], l[o] = n(u, d)); o > 0; )
      --o, d = c >> 8, l[o] = n(s[o], d), --o, d = c & 255, l[o] = n(s[o], d);
    for (o = 15, p = 15 - s.length; p > 0; )
      d = c >> 8, l[o] = n(e[p], d), --o, --p, d = c & 255, l[o] = n(s[o], d), --o, --p;
    return l;
  };
})(), Xl = function(e, a, r, t, n) {
  n || (n = a), t || (t = zi(e));
  var i, f;
  for (i = 0; i != a.length; ++i)
    f = a[i], f ^= t[r], f = (f >> 5 | f << 3) & 255, n[i] = f, ++r;
  return [n, r, t];
}, zl = function(e) {
  var a = 0, r = zi(e);
  return function(t) {
    var n = Xl("", t, a, r);
    return a = n[1], n[0];
  };
};
function $l(e, a, r, t) {
  var n = { key: ze(e), verificationBytes: ze(e) };
  return r.password && (n.verifier = Gl(r.password)), t.valid = n.verificationBytes === n.verifier, t.valid && (t.insitu = zl(r.password)), n;
}
function Kl(e, a, r) {
  var t = r || {};
  return t.Info = e.read_shift(2), e.l -= 2, t.Info === 1 ? t.Data = Vl(e) : t.Data = Wl(e, a), t;
}
function Yl(e, a, r) {
  var t = { Type: r.biff >= 8 ? e.read_shift(2) : 0 };
  return t.Type ? Kl(e, a - 2, t) : $l(e, r.biff >= 8 ? a : a - 2, r, t), t;
}
function jl(e, a) {
  switch (a.type) {
    case "base64":
      return Ft(Or(e), a);
    case "binary":
      return Ft(e, a);
    case "buffer":
      return Ft(Se && Buffer.isBuffer(e) ? e.toString("binary") : ea(e), a);
    case "array":
      return Ft(ka(e), a);
  }
  throw new Error("Unrecognized type " + a.type);
}
function Ft(e, a) {
  var r = a || {}, t = {}, n = r.dense;
  n && (t["!data"] = []);
  var i = E0(e, "\\trowd", "\\row");
  if (!i)
    throw new Error("RTF missing table");
  var f = { s: { c: 0, r: 0 }, e: { c: 0, r: i.length - 1 } }, s = [];
  return i.forEach(function(c, o) {
    n && (s = t["!data"][o] = []);
    for (var l = /\\[\w\-]+\b/g, v = 0, d, u = -1, p = []; (d = l.exec(c)) != null; ) {
      var _ = c.slice(v, l.lastIndex - d[0].length);
      switch (_.charCodeAt(0) == 32 && (_ = _.slice(1)), _.length && p.push(_), d[0]) {
        case "\\cell":
          if (++u, p.length) {
            var x = { v: p.join(""), t: "s" };
            x.v == "TRUE" || x.v == "FALSE" ? (x.v = x.v == "TRUE", x.t = "b") : isNaN(Ir(x.v)) ? sr[x.v] != null && (x.t = "e", x.w = x.v, x.v = sr[x.v]) : (x.t = "n", r.cellText !== !1 && (x.w = x.v), x.v = Ir(x.v)), n ? s[u] = x : t[Ne({ r: o, c: u })] = x;
          }
          p = [];
          break;
        case "\\par":
          p.push(`
`);
          break;
      }
      v = l.lastIndex;
    }
    u > f.e.c && (f.e.c = u);
  }), t["!ref"] = ye(f), t;
}
function Jl(e, a) {
  var r = la(jl(e, a), a);
  return r.bookType = "rtf", r;
}
function Zl(e) {
  var a = e.slice(e[0] === "#" ? 1 : 0).slice(0, 6);
  return [parseInt(a.slice(0, 2), 16), parseInt(a.slice(2, 4), 16), parseInt(a.slice(4, 6), 16)];
}
function it(e) {
  for (var a = 0, r = 1; a != 3; ++a) r = r * 256 + (e[a] > 255 ? 255 : e[a] < 0 ? 0 : e[a]);
  return r.toString(16).toUpperCase().slice(1);
}
function ql(e) {
  var a = e[0] / 255, r = e[1] / 255, t = e[2] / 255, n = Math.max(a, r, t), i = Math.min(a, r, t), f = n - i;
  if (f === 0) return [0, 0, a];
  var s = 0, c = 0, o = n + i;
  switch (c = f / (o > 1 ? 2 - o : o), n) {
    case a:
      s = ((r - t) / f + 6) % 6;
      break;
    case r:
      s = (t - a) / f + 2;
      break;
    case t:
      s = (a - r) / f + 4;
      break;
  }
  return [s / 6, c, o / 2];
}
function Ql(e) {
  var a = e[0], r = e[1], t = e[2], n = r * 2 * (t < 0.5 ? t : 1 - t), i = t - n / 2, f = [i, i, i], s = 6 * a, c;
  if (r !== 0) switch (s | 0) {
    case 0:
    case 6:
      c = n * s, f[0] += n, f[1] += c;
      break;
    case 1:
      c = n * (2 - s), f[0] += c, f[1] += n;
      break;
    case 2:
      c = n * (s - 2), f[1] += n, f[2] += c;
      break;
    case 3:
      c = n * (4 - s), f[1] += c, f[2] += n;
      break;
    case 4:
      c = n * (s - 4), f[2] += n, f[0] += c;
      break;
    case 5:
      c = n * (6 - s), f[2] += c, f[0] += n;
      break;
  }
  for (var o = 0; o != 3; ++o) f[o] = Math.round(f[o] * 255);
  return f;
}
function bt(e, a) {
  if (a === 0) return e;
  var r = ql(Zl(e));
  return a < 0 ? r[2] = r[2] * (1 + a) : r[2] = 1 - (1 - r[2]) * (1 - a), it(Ql(r));
}
var $i = 6, e1 = 15, r1 = 1, _r = $i;
function Lt(e) {
  return Math.floor((e + Math.round(128 / _r) / 256) * _r);
}
function Bt(e) {
  return Math.floor((e - 5) / _r * 100 + 0.5) / 100;
}
function o0(e) {
  return Math.round((e * _r + 5) / _r * 256) / 256;
}
function e0(e) {
  return o0(Bt(Lt(e)));
}
function I0(e) {
  var a = Math.abs(e - e0(e)), r = _r;
  if (a > 5e-3) for (_r = r1; _r < e1; ++_r) Math.abs(e - e0(e)) <= a && (a = Math.abs(e - e0(e)), r = _r);
  _r = r;
}
function ba(e) {
  e.width ? (e.wpx = Lt(e.width), e.wch = Bt(e.wpx), e.MDW = _r) : e.wpx ? (e.wch = Bt(e.wpx), e.width = o0(e.wch), e.MDW = _r) : typeof e.wch == "number" && (e.width = o0(e.wch), e.wpx = Lt(e.width), e.MDW = _r), e.customWidth && delete e.customWidth;
}
var a1 = 96, Ki = a1;
function Yi(e) {
  return e * 96 / Ki;
}
function st(e) {
  return e * Ki / 96;
}
var t1 = {
  None: "none",
  Solid: "solid",
  Gray50: "mediumGray",
  Gray75: "darkGray",
  Gray25: "lightGray",
  HorzStripe: "darkHorizontal",
  VertStripe: "darkVertical",
  ReverseDiagStripe: "darkDown",
  DiagStripe: "darkUp",
  DiagCross: "darkGrid",
  ThickDiagCross: "darkTrellis",
  ThinHorzStripe: "lightHorizontal",
  ThinVertStripe: "lightVertical",
  ThinReverseDiagStripe: "lightDown",
  ThinHorzCross: "lightGrid"
};
function n1(e, a, r, t) {
  a.Borders = [];
  var n = {}, i = !1;
  (e.match(or) || []).forEach(function(f) {
    var s = le(f);
    switch (Mr(s[0])) {
      case "<borders":
      case "<borders>":
      case "</borders>":
        break;
      /* 18.8.4 border CT_Border */
      case "<border":
      case "<border>":
      case "<border/>":
        n = /*::(*/
        {}, s.diagonalUp && (n.diagonalUp = Be(s.diagonalUp)), s.diagonalDown && (n.diagonalDown = Be(s.diagonalDown)), a.Borders.push(n);
        break;
      case "</border>":
        break;
      /* note: not in spec, appears to be CT_BorderPr */
      case "<left/>":
        break;
      case "<left":
      case "<left>":
        break;
      case "</left>":
        break;
      /* note: not in spec, appears to be CT_BorderPr */
      case "<right/>":
        break;
      case "<right":
      case "<right>":
        break;
      case "</right>":
        break;
      /* 18.8.43 top CT_BorderPr */
      case "<top/>":
        break;
      case "<top":
      case "<top>":
        break;
      case "</top>":
        break;
      /* 18.8.6 bottom CT_BorderPr */
      case "<bottom/>":
        break;
      case "<bottom":
      case "<bottom>":
        break;
      case "</bottom>":
        break;
      /* 18.8.13 diagonal CT_BorderPr */
      case "<diagonal":
      case "<diagonal>":
      case "<diagonal/>":
        break;
      case "</diagonal>":
        break;
      /* 18.8.25 horizontal CT_BorderPr */
      case "<horizontal":
      case "<horizontal>":
      case "<horizontal/>":
        break;
      case "</horizontal>":
        break;
      /* 18.8.44 vertical CT_BorderPr */
      case "<vertical":
      case "<vertical>":
      case "<vertical/>":
        break;
      case "</vertical>":
        break;
      /* 18.8.37 start CT_BorderPr */
      case "<start":
      case "<start>":
      case "<start/>":
        break;
      case "</start>":
        break;
      /* 18.8.16 end CT_BorderPr */
      case "<end":
      case "<end>":
      case "<end/>":
        break;
      case "</end>":
        break;
      /* 18.8.? color CT_Color */
      case "<color":
      case "<color>":
        break;
      case "<color/>":
      case "</color>":
        break;
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
        break;
      case "<ext":
        i = !0;
        break;
      case "</ext>":
        i = !1;
        break;
      default:
        if (t && t.WTF && !i)
          throw new Error("unrecognized " + s[0] + " in borders");
    }
  });
}
function i1(e, a, r, t) {
  a.Fills = [];
  var n = {}, i = !1;
  (e.match(or) || []).forEach(function(f) {
    var s = le(f);
    switch (Mr(s[0])) {
      case "<fills":
      case "<fills>":
      case "</fills>":
        break;
      /* 18.8.20 fill CT_Fill */
      case "<fill>":
      case "<fill":
      case "<fill/>":
        n = {}, a.Fills.push(n);
        break;
      case "</fill>":
        break;
      /* 18.8.24 gradientFill CT_GradientFill */
      case "<gradientFill>":
        break;
      case "<gradientFill":
      case "</gradientFill>":
        a.Fills.push(n), n = {};
        break;
      /* 18.8.32 patternFill CT_PatternFill */
      case "<patternFill":
      case "<patternFill>":
        s.patternType && (n.patternType = s.patternType);
        break;
      case "<patternFill/>":
      case "</patternFill>":
        break;
      /* 18.8.3 bgColor CT_Color */
      case "<bgColor":
        n.bgColor || (n.bgColor = {}), s.indexed && (n.bgColor.indexed = parseInt(s.indexed, 10)), s.theme && (n.bgColor.theme = parseInt(s.theme, 10)), s.tint && (n.bgColor.tint = parseFloat(s.tint)), s.rgb && (n.bgColor.rgb = s.rgb.slice(-6));
        break;
      case "<bgColor/>":
      case "</bgColor>":
        break;
      /* 18.8.19 fgColor CT_Color */
      case "<fgColor":
        n.fgColor || (n.fgColor = {}), s.theme && (n.fgColor.theme = parseInt(s.theme, 10)), s.tint && (n.fgColor.tint = parseFloat(s.tint)), s.rgb != null && (n.fgColor.rgb = s.rgb.slice(-6));
        break;
      case "<fgColor/>":
      case "</fgColor>":
        break;
      /* 18.8.38 stop CT_GradientStop */
      case "<stop":
      case "<stop/>":
        break;
      case "</stop>":
        break;
      /* 18.8.? color CT_Color */
      case "<color":
      case "<color/>":
        break;
      case "</color>":
        break;
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
        break;
      case "<ext":
        i = !0;
        break;
      case "</ext>":
        i = !1;
        break;
      default:
        if (t && t.WTF && !i)
          throw new Error("unrecognized " + s[0] + " in fills");
    }
  });
}
function s1(e, a, r, t) {
  a.Fonts = [];
  var n = {}, i = !1;
  (e.match(or) || []).forEach(function(f) {
    var s = le(f);
    switch (Mr(s[0])) {
      case "<fonts":
      case "<fonts>":
      case "</fonts>":
        break;
      /* 18.8.22 font CT_Font */
      case "<font":
      case "<font>":
        break;
      case "</font>":
      case "<font/>":
        a.Fonts.push(n), n = {};
        break;
      /* 18.8.29 name CT_FontName */
      case "<name":
        s.val && (n.name = Ue(s.val));
        break;
      case "<name/>":
      case "</name>":
        break;
      /* 18.8.2  b CT_BooleanProperty */
      case "<b":
        n.bold = s.val ? Be(s.val) : 1;
        break;
      case "<b/>":
        n.bold = 1;
        break;
      case "</b>":
      case "</b":
        break;
      /* 18.8.26 i CT_BooleanProperty */
      case "<i":
        n.italic = s.val ? Be(s.val) : 1;
        break;
      case "<i/>":
        n.italic = 1;
        break;
      case "</i>":
      case "</i":
        break;
      /* 18.4.13 u CT_UnderlineProperty */
      case "<u":
        switch (s.val) {
          case "none":
            n.underline = 0;
            break;
          case "single":
            n.underline = 1;
            break;
          case "double":
            n.underline = 2;
            break;
          case "singleAccounting":
            n.underline = 33;
            break;
          case "doubleAccounting":
            n.underline = 34;
            break;
        }
        break;
      case "<u/>":
        n.underline = 1;
        break;
      case "</u>":
      case "</u":
        break;
      /* 18.4.10 strike CT_BooleanProperty */
      case "<strike":
        n.strike = s.val ? Be(s.val) : 1;
        break;
      case "<strike/>":
        n.strike = 1;
        break;
      case "</strike>":
      case "</strike":
        break;
      /* 18.4.2  outline CT_BooleanProperty */
      case "<outline":
        n.outline = s.val ? Be(s.val) : 1;
        break;
      case "<outline/>":
        n.outline = 1;
        break;
      case "</outline>":
      case "</outline":
        break;
      /* 18.8.36 shadow CT_BooleanProperty */
      case "<shadow":
        n.shadow = s.val ? Be(s.val) : 1;
        break;
      case "<shadow/>":
        n.shadow = 1;
        break;
      case "</shadow>":
      case "</shadow":
        break;
      /* 18.8.12 condense CT_BooleanProperty */
      case "<condense":
        n.condense = s.val ? Be(s.val) : 1;
        break;
      case "<condense/>":
        n.condense = 1;
        break;
      case "</condense>":
      case "</condense":
        break;
      /* 18.8.17 extend CT_BooleanProperty */
      case "<extend":
        n.extend = s.val ? Be(s.val) : 1;
        break;
      case "<extend/>":
        n.extend = 1;
        break;
      case "</extend>":
      case "</extend":
        break;
      /* 18.4.11 sz CT_FontSize */
      case "<sz":
        s.val && (n.sz = +s.val);
        break;
      case "<sz/>":
      case "</sz>":
      case "</sz":
        break;
      /* 18.4.14 vertAlign CT_VerticalAlignFontProperty */
      case "<vertAlign":
        s.val && (n.vertAlign = s.val);
        break;
      case "<vertAlign/>":
      case "</vertAlign>":
      case "</vertAlign":
        break;
      /* 18.8.18 family CT_FontFamily */
      case "<family":
        s.val && (n.family = parseInt(s.val, 10));
        break;
      case "<family/>":
      case "</family>":
      case "</family":
        break;
      /* 18.8.35 scheme CT_FontScheme */
      case "<scheme":
        s.val && (n.scheme = s.val);
        break;
      case "<scheme/>":
      case "</scheme>":
      case "</scheme":
        break;
      /* 18.4.1 charset CT_IntProperty */
      case "<charset":
        if (s.val == "1") break;
        s.codepage = x0[parseInt(s.val, 10)];
        break;
      case "<charset/>":
      case "</charset>":
      case "</charset":
        break;
      /* 18.?.? color CT_Color */
      case "<color":
        if (n.color || (n.color = {}), s.auto && (n.color.auto = Be(s.auto)), s.rgb) n.color.rgb = s.rgb.slice(-6);
        else if (s.indexed) {
          n.color.index = parseInt(s.indexed, 10);
          var c = ga[n.color.index];
          n.color.index == 81 && (c = ga[1]), c || (c = ga[1]), n.color.rgb = c[0].toString(16) + c[1].toString(16) + c[2].toString(16);
        } else s.theme && (n.color.theme = parseInt(s.theme, 10), s.tint && (n.color.tint = parseFloat(s.tint)), s.theme && r.themeElements && r.themeElements.clrScheme && (n.color.rgb = bt(r.themeElements.clrScheme[n.color.theme].rgb, n.color.tint || 0)));
        break;
      case "<color/>":
      case "</color>":
      case "</color":
        break;
      /* note: sometimes mc:AlternateContent appears bare */
      case "<AlternateContent":
        i = !0;
        break;
      case "</AlternateContent>":
      case "</AlternateContent":
        i = !1;
        break;
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
        break;
      case "<ext":
        i = !0;
        break;
      case "</ext>":
        i = !1;
        break;
      default:
        if (t && t.WTF && !i)
          throw new Error("unrecognized " + s[0] + " in fonts");
    }
  });
}
function f1(e, a, r) {
  a.NumberFmt = [];
  for (var t = Lr(ge), n = 0; n < t.length; ++n) a.NumberFmt[t[n]] = ge[t[n]];
  var i = e.match(or);
  if (i)
    for (n = 0; n < i.length; ++n) {
      var f = le(i[n]);
      switch (Mr(f[0])) {
        case "<numFmts":
        case "</numFmts>":
        case "<numFmts/>":
        case "<numFmts>":
          break;
        case "<numFmt":
          {
            var s = Ce(Ue(f.formatCode)), c = parseInt(f.numFmtId, 10);
            if (a.NumberFmt[c] = s, c > 0) {
              if (c > 392) {
                for (c = 392; c > 60 && a.NumberFmt[c] != null; --c) ;
                a.NumberFmt[c] = s;
              }
              va(s, c);
            }
          }
          break;
        case "</numFmt>":
          break;
        default:
          if (r.WTF) throw new Error("unrecognized " + f[0] + " in numFmts");
      }
    }
}
var At = ["numFmtId", "fillId", "fontId", "borderId", "xfId"], St = ["applyAlignment", "applyBorder", "applyFill", "applyFont", "applyNumberFormat", "applyProtection", "pivotButton", "quotePrefix"];
function c1(e, a, r) {
  a.CellXf = [];
  var t, n = !1;
  (e.match(or) || []).forEach(function(i) {
    var f = le(i), s = 0;
    switch (Mr(f[0])) {
      case "<cellXfs":
      case "<cellXfs>":
      case "<cellXfs/>":
      case "</cellXfs>":
        break;
      /* 18.8.45 xf CT_Xf */
      case "<xf":
      case "<xf/>":
      case "<xf>":
        for (t = f, delete t[0], s = 0; s < At.length; ++s) t[At[s]] && (t[At[s]] = parseInt(t[At[s]], 10));
        for (s = 0; s < St.length; ++s) t[St[s]] && (t[St[s]] = Be(t[St[s]]));
        if (a.NumberFmt && t.numFmtId > 392) {
          for (s = 392; s > 60; --s) if (a.NumberFmt[t.numFmtId] == a.NumberFmt[s]) {
            t.numFmtId = s;
            break;
          }
        }
        a.CellXf.push(t);
        break;
      case "</xf>":
        break;
      /* 18.8.1 alignment CT_CellAlignment */
      case "<alignment":
      case "<alignment/>":
      case "<alignment>":
        var c = {};
        f.vertical && (c.vertical = f.vertical), f.horizontal && (c.horizontal = f.horizontal), f.textRotation != null && (c.textRotation = f.textRotation), f.indent && (c.indent = f.indent), f.wrapText && (c.wrapText = Be(f.wrapText)), t.alignment = c;
        break;
      case "</alignment>":
        break;
      /* 18.8.33 protection CT_CellProtection */
      case "<protection":
      case "<protection>":
        break;
      case "</protection>":
      case "<protection/>":
        break;
      /* note: sometimes mc:AlternateContent appears bare */
      case "<AlternateContent":
      case "<AlternateContent>":
        n = !0;
        break;
      case "</AlternateContent>":
        n = !1;
        break;
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
        break;
      case "<ext":
        n = !0;
        break;
      case "</ext>":
        n = !1;
        break;
      default:
        if (r && r.WTF && !n)
          throw new Error("unrecognized " + f[0] + " in cellXfs");
    }
  });
}
var o1 = /* @__PURE__ */ (function() {
  return function(r, t, n) {
    var i = {};
    if (!r) return i;
    r = k0(ot(r, "<!--", "-->"));
    var f;
    return (f = ir(r, "numFmts")) && f1(f[0], i, n), (f = ir(r, "fonts")) && s1(f[0], i, t, n), (f = ir(r, "fills")) && i1(f[0], i, t, n), (f = ir(r, "borders")) && n1(f[0], i, t, n), (f = ir(r, "cellXfs")) && c1(f[0], i, n), i;
  };
})();
function l1(e, a) {
  var r = e.read_shift(2), t = vr(e);
  return [r, t];
}
function u1(e, a, r) {
  var t = {};
  t.sz = e.read_shift(2) / 20;
  var n = gc(e);
  n.fItalic && (t.italic = 1), n.fCondense && (t.condense = 1), n.fExtend && (t.extend = 1), n.fShadow && (t.shadow = 1), n.fOutline && (t.outline = 1), n.fStrikeout && (t.strike = 1);
  var i = e.read_shift(2);
  switch (i === 700 && (t.bold = 1), e.read_shift(2)) {
    /* case 0: out.vertAlign = "baseline"; break; */
    case 1:
      t.vertAlign = "superscript";
      break;
    case 2:
      t.vertAlign = "subscript";
      break;
  }
  var f = e.read_shift(1);
  f != 0 && (t.underline = f);
  var s = e.read_shift(1);
  s > 0 && (t.family = s);
  var c = e.read_shift(1);
  switch (c > 0 && (t.charset = c), e.l++, t.color = pc(e), e.read_shift(1)) {
    /* case 0: out.scheme = "none": break; */
    case 1:
      t.scheme = "major";
      break;
    case 2:
      t.scheme = "minor";
      break;
  }
  return t.name = vr(e), t;
}
var h1 = pr;
function x1(e, a) {
  var r = e.l + a, t = e.read_shift(2), n = e.read_shift(2);
  return e.l = r, { ixfe: t, numFmtId: n };
}
var d1 = pr;
function v1(e, a, r) {
  var t = {};
  t.NumberFmt = [];
  for (var n in ge) t.NumberFmt[n] = ge[n];
  t.CellXf = [], t.Fonts = [];
  var i = [], f = !1;
  return ra(e, function(c, o, l) {
    switch (l) {
      case 44:
        t.NumberFmt[c[0]] = c[1], va(c[1], c[0]);
        break;
      case 43:
        t.Fonts.push(c), c.color.theme != null && a && a.themeElements && a.themeElements.clrScheme && (c.color.rgb = bt(a.themeElements.clrScheme[c.color.theme].rgb, c.color.tint || 0));
        break;
      case 1025:
        break;
      case 45:
        break;
      case 46:
        break;
      case 47:
        i[i.length - 1] == 617 && t.CellXf.push(c);
        break;
      case 48:
      /* BrtStyle */
      case 507:
      /* BrtDXF */
      case 572:
      /* BrtMRUColor */
      case 475:
        break;
      case 1171:
      /* BrtDXF14 */
      case 2102:
      /* BrtDXF15 */
      case 1130:
      /* BrtSlicerStyleElement */
      case 512:
      /* BrtTableStyleElement */
      case 2095:
      /* BrtTimelineStyleElement */
      case 3072:
        break;
      case 35:
        f = !0;
        break;
      case 36:
        f = !1;
        break;
      case 37:
        i.push(l), f = !0;
        break;
      case 38:
        i.pop(), f = !1;
        break;
      default:
        if (o.T > 0) i.push(l);
        else if (o.T < 0) i.pop();
        else if (!f || r.WTF && i[i.length - 1] != 37) throw new Error("Unexpected record 0x" + l.toString(16));
    }
  }), t;
}
var p1 = [
  "</a:lt1>",
  "</a:dk1>",
  "</a:lt2>",
  "</a:dk2>",
  "</a:accent1>",
  "</a:accent2>",
  "</a:accent3>",
  "</a:accent4>",
  "</a:accent5>",
  "</a:accent6>",
  "</a:hlink>",
  "</a:folHlink>"
];
function g1(e, a, r) {
  a.themeElements.clrScheme = [];
  var t = {};
  (e[0].match(or) || []).forEach(function(n) {
    var i = le(n);
    switch (i[0]) {
      /* 20.1.6.2 clrScheme (Color Scheme) CT_ColorScheme */
      case "<a:clrScheme":
      case "</a:clrScheme>":
        break;
      /* 20.1.2.3.32 srgbClr CT_SRgbColor */
      case "<a:srgbClr":
        t.rgb = i.val;
        break;
      case "</a:srgbClr>":
        break;
      /* 20.1.2.3.33 sysClr CT_SystemColor */
      case "<a:sysClr":
        t.rgb = i.lastClr;
        break;
      case "</a:sysClr>":
        break;
      /* 20.1.4.1.1 accent1 (Accent 1) */
      /* 20.1.4.1.2 accent2 (Accent 2) */
      /* 20.1.4.1.3 accent3 (Accent 3) */
      /* 20.1.4.1.4 accent4 (Accent 4) */
      /* 20.1.4.1.5 accent5 (Accent 5) */
      /* 20.1.4.1.6 accent6 (Accent 6) */
      /* 20.1.4.1.9 dk1 (Dark 1) */
      /* 20.1.4.1.10 dk2 (Dark 2) */
      /* 20.1.4.1.15 folHlink (Followed Hyperlink) */
      /* 20.1.4.1.19 hlink (Hyperlink) */
      /* 20.1.4.1.22 lt1 (Light 1) */
      /* 20.1.4.1.23 lt2 (Light 2) */
      case "</a:dk1>":
      case "</a:lt1>":
      case "<a:dk1>":
      case "<a:lt1>":
      case "<a:dk2>":
      case "</a:dk2>":
      case "<a:lt2>":
      case "</a:lt2>":
      case "<a:accent1>":
      case "</a:accent1>":
      case "<a:accent2>":
      case "</a:accent2>":
      case "<a:accent3>":
      case "</a:accent3>":
      case "<a:accent4>":
      case "</a:accent4>":
      case "<a:accent5>":
      case "</a:accent5>":
      case "<a:accent6>":
      case "</a:accent6>":
      case "<a:hlink>":
      case "</a:hlink>":
      case "<a:folHlink>":
      case "</a:folHlink>":
        i[0].charAt(1) === "/" ? (a.themeElements.clrScheme[p1.indexOf(i[0])] = t, t = {}) : t.name = i[0].slice(3, i[0].length - 1);
        break;
      default:
        if (r && r.WTF) throw new Error("Unrecognized " + i[0] + " in clrScheme");
    }
  });
}
function m1(e, a, r) {
  a.themeElements = {};
  var t;
  if (!(t = pa(e, "a:clrScheme"))) throw new Error("clrScheme not found in themeElements");
  if (g1(t, a, r), !(t = pa(e, "a:fontScheme"))) throw new Error("fontScheme not found in themeElements");
  if (!(t = pa(e, "a:fmtScheme"))) throw new Error("fmtScheme not found in themeElements");
}
function ji(e, a) {
  (!e || e.length === 0) && (e = _1());
  var r, t = {};
  if (!(r = pa(e, "a:themeElements"))) throw new Error("themeElements not found in theme");
  return m1(r[0], t, a), t.raw = e, t;
}
function _1(e, a) {
  var r = [si];
  return r[r.length] = '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Office Theme">', r[r.length] = "<a:themeElements>", r[r.length] = '<a:clrScheme name="Office">', r[r.length] = '<a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1>', r[r.length] = '<a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1>', r[r.length] = '<a:dk2><a:srgbClr val="1F497D"/></a:dk2>', r[r.length] = '<a:lt2><a:srgbClr val="EEECE1"/></a:lt2>', r[r.length] = '<a:accent1><a:srgbClr val="4F81BD"/></a:accent1>', r[r.length] = '<a:accent2><a:srgbClr val="C0504D"/></a:accent2>', r[r.length] = '<a:accent3><a:srgbClr val="9BBB59"/></a:accent3>', r[r.length] = '<a:accent4><a:srgbClr val="8064A2"/></a:accent4>', r[r.length] = '<a:accent5><a:srgbClr val="4BACC6"/></a:accent5>', r[r.length] = '<a:accent6><a:srgbClr val="F79646"/></a:accent6>', r[r.length] = '<a:hlink><a:srgbClr val="0000FF"/></a:hlink>', r[r.length] = '<a:folHlink><a:srgbClr val="800080"/></a:folHlink>', r[r.length] = "</a:clrScheme>", r[r.length] = '<a:fontScheme name="Office">', r[r.length] = "<a:majorFont>", r[r.length] = '<a:latin typeface="Cambria"/>', r[r.length] = '<a:ea typeface=""/>', r[r.length] = '<a:cs typeface=""/>', r[r.length] = '<a:font script="Jpan" typeface="ＭＳ Ｐゴシック"/>', r[r.length] = '<a:font script="Hang" typeface="맑은 고딕"/>', r[r.length] = '<a:font script="Hans" typeface="宋体"/>', r[r.length] = '<a:font script="Hant" typeface="新細明體"/>', r[r.length] = '<a:font script="Arab" typeface="Times New Roman"/>', r[r.length] = '<a:font script="Hebr" typeface="Times New Roman"/>', r[r.length] = '<a:font script="Thai" typeface="Tahoma"/>', r[r.length] = '<a:font script="Ethi" typeface="Nyala"/>', r[r.length] = '<a:font script="Beng" typeface="Vrinda"/>', r[r.length] = '<a:font script="Gujr" typeface="Shruti"/>', r[r.length] = '<a:font script="Khmr" typeface="MoolBoran"/>', r[r.length] = '<a:font script="Knda" typeface="Tunga"/>', r[r.length] = '<a:font script="Guru" typeface="Raavi"/>', r[r.length] = '<a:font script="Cans" typeface="Euphemia"/>', r[r.length] = '<a:font script="Cher" typeface="Plantagenet Cherokee"/>', r[r.length] = '<a:font script="Yiii" typeface="Microsoft Yi Baiti"/>', r[r.length] = '<a:font script="Tibt" typeface="Microsoft Himalaya"/>', r[r.length] = '<a:font script="Thaa" typeface="MV Boli"/>', r[r.length] = '<a:font script="Deva" typeface="Mangal"/>', r[r.length] = '<a:font script="Telu" typeface="Gautami"/>', r[r.length] = '<a:font script="Taml" typeface="Latha"/>', r[r.length] = '<a:font script="Syrc" typeface="Estrangelo Edessa"/>', r[r.length] = '<a:font script="Orya" typeface="Kalinga"/>', r[r.length] = '<a:font script="Mlym" typeface="Kartika"/>', r[r.length] = '<a:font script="Laoo" typeface="DokChampa"/>', r[r.length] = '<a:font script="Sinh" typeface="Iskoola Pota"/>', r[r.length] = '<a:font script="Mong" typeface="Mongolian Baiti"/>', r[r.length] = '<a:font script="Viet" typeface="Times New Roman"/>', r[r.length] = '<a:font script="Uigh" typeface="Microsoft Uighur"/>', r[r.length] = '<a:font script="Geor" typeface="Sylfaen"/>', r[r.length] = "</a:majorFont>", r[r.length] = "<a:minorFont>", r[r.length] = '<a:latin typeface="Calibri"/>', r[r.length] = '<a:ea typeface=""/>', r[r.length] = '<a:cs typeface=""/>', r[r.length] = '<a:font script="Jpan" typeface="ＭＳ Ｐゴシック"/>', r[r.length] = '<a:font script="Hang" typeface="맑은 고딕"/>', r[r.length] = '<a:font script="Hans" typeface="宋体"/>', r[r.length] = '<a:font script="Hant" typeface="新細明體"/>', r[r.length] = '<a:font script="Arab" typeface="Arial"/>', r[r.length] = '<a:font script="Hebr" typeface="Arial"/>', r[r.length] = '<a:font script="Thai" typeface="Tahoma"/>', r[r.length] = '<a:font script="Ethi" typeface="Nyala"/>', r[r.length] = '<a:font script="Beng" typeface="Vrinda"/>', r[r.length] = '<a:font script="Gujr" typeface="Shruti"/>', r[r.length] = '<a:font script="Khmr" typeface="DaunPenh"/>', r[r.length] = '<a:font script="Knda" typeface="Tunga"/>', r[r.length] = '<a:font script="Guru" typeface="Raavi"/>', r[r.length] = '<a:font script="Cans" typeface="Euphemia"/>', r[r.length] = '<a:font script="Cher" typeface="Plantagenet Cherokee"/>', r[r.length] = '<a:font script="Yiii" typeface="Microsoft Yi Baiti"/>', r[r.length] = '<a:font script="Tibt" typeface="Microsoft Himalaya"/>', r[r.length] = '<a:font script="Thaa" typeface="MV Boli"/>', r[r.length] = '<a:font script="Deva" typeface="Mangal"/>', r[r.length] = '<a:font script="Telu" typeface="Gautami"/>', r[r.length] = '<a:font script="Taml" typeface="Latha"/>', r[r.length] = '<a:font script="Syrc" typeface="Estrangelo Edessa"/>', r[r.length] = '<a:font script="Orya" typeface="Kalinga"/>', r[r.length] = '<a:font script="Mlym" typeface="Kartika"/>', r[r.length] = '<a:font script="Laoo" typeface="DokChampa"/>', r[r.length] = '<a:font script="Sinh" typeface="Iskoola Pota"/>', r[r.length] = '<a:font script="Mong" typeface="Mongolian Baiti"/>', r[r.length] = '<a:font script="Viet" typeface="Arial"/>', r[r.length] = '<a:font script="Uigh" typeface="Microsoft Uighur"/>', r[r.length] = '<a:font script="Geor" typeface="Sylfaen"/>', r[r.length] = "</a:minorFont>", r[r.length] = "</a:fontScheme>", r[r.length] = '<a:fmtScheme name="Office">', r[r.length] = "<a:fillStyleLst>", r[r.length] = '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>', r[r.length] = '<a:gradFill rotWithShape="1">', r[r.length] = "<a:gsLst>", r[r.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="50000"/><a:satMod val="300000"/></a:schemeClr></a:gs>', r[r.length] = '<a:gs pos="35000"><a:schemeClr val="phClr"><a:tint val="37000"/><a:satMod val="300000"/></a:schemeClr></a:gs>', r[r.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:tint val="15000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', r[r.length] = "</a:gsLst>", r[r.length] = '<a:lin ang="16200000" scaled="1"/>', r[r.length] = "</a:gradFill>", r[r.length] = '<a:gradFill rotWithShape="1">', r[r.length] = "<a:gsLst>", r[r.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="100000"/><a:shade val="100000"/><a:satMod val="130000"/></a:schemeClr></a:gs>', r[r.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:tint val="50000"/><a:shade val="100000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', r[r.length] = "</a:gsLst>", r[r.length] = '<a:lin ang="16200000" scaled="0"/>', r[r.length] = "</a:gradFill>", r[r.length] = "</a:fillStyleLst>", r[r.length] = "<a:lnStyleLst>", r[r.length] = '<a:ln w="9525" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"><a:shade val="95000"/><a:satMod val="105000"/></a:schemeClr></a:solidFill><a:prstDash val="solid"/></a:ln>', r[r.length] = '<a:ln w="25400" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>', r[r.length] = '<a:ln w="38100" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>', r[r.length] = "</a:lnStyleLst>", r[r.length] = "<a:effectStyleLst>", r[r.length] = "<a:effectStyle>", r[r.length] = "<a:effectLst>", r[r.length] = '<a:outerShdw blurRad="40000" dist="20000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="38000"/></a:srgbClr></a:outerShdw>', r[r.length] = "</a:effectLst>", r[r.length] = "</a:effectStyle>", r[r.length] = "<a:effectStyle>", r[r.length] = "<a:effectLst>", r[r.length] = '<a:outerShdw blurRad="40000" dist="23000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="35000"/></a:srgbClr></a:outerShdw>', r[r.length] = "</a:effectLst>", r[r.length] = "</a:effectStyle>", r[r.length] = "<a:effectStyle>", r[r.length] = "<a:effectLst>", r[r.length] = '<a:outerShdw blurRad="40000" dist="23000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="35000"/></a:srgbClr></a:outerShdw>', r[r.length] = "</a:effectLst>", r[r.length] = '<a:scene3d><a:camera prst="orthographicFront"><a:rot lat="0" lon="0" rev="0"/></a:camera><a:lightRig rig="threePt" dir="t"><a:rot lat="0" lon="0" rev="1200000"/></a:lightRig></a:scene3d>', r[r.length] = '<a:sp3d><a:bevelT w="63500" h="25400"/></a:sp3d>', r[r.length] = "</a:effectStyle>", r[r.length] = "</a:effectStyleLst>", r[r.length] = "<a:bgFillStyleLst>", r[r.length] = '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>', r[r.length] = '<a:gradFill rotWithShape="1">', r[r.length] = "<a:gsLst>", r[r.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="40000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', r[r.length] = '<a:gs pos="40000"><a:schemeClr val="phClr"><a:tint val="45000"/><a:shade val="99000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', r[r.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="20000"/><a:satMod val="255000"/></a:schemeClr></a:gs>', r[r.length] = "</a:gsLst>", r[r.length] = '<a:path path="circle"><a:fillToRect l="50000" t="-80000" r="50000" b="180000"/></a:path>', r[r.length] = "</a:gradFill>", r[r.length] = '<a:gradFill rotWithShape="1">', r[r.length] = "<a:gsLst>", r[r.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="80000"/><a:satMod val="300000"/></a:schemeClr></a:gs>', r[r.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="30000"/><a:satMod val="200000"/></a:schemeClr></a:gs>', r[r.length] = "</a:gsLst>", r[r.length] = '<a:path path="circle"><a:fillToRect l="50000" t="50000" r="50000" b="50000"/></a:path>', r[r.length] = "</a:gradFill>", r[r.length] = "</a:bgFillStyleLst>", r[r.length] = "</a:fmtScheme>", r[r.length] = "</a:themeElements>", r[r.length] = "<a:objectDefaults>", r[r.length] = "<a:spDef>", r[r.length] = '<a:spPr/><a:bodyPr/><a:lstStyle/><a:style><a:lnRef idx="1"><a:schemeClr val="accent1"/></a:lnRef><a:fillRef idx="3"><a:schemeClr val="accent1"/></a:fillRef><a:effectRef idx="2"><a:schemeClr val="accent1"/></a:effectRef><a:fontRef idx="minor"><a:schemeClr val="lt1"/></a:fontRef></a:style>', r[r.length] = "</a:spDef>", r[r.length] = "<a:lnDef>", r[r.length] = '<a:spPr/><a:bodyPr/><a:lstStyle/><a:style><a:lnRef idx="2"><a:schemeClr val="accent1"/></a:lnRef><a:fillRef idx="0"><a:schemeClr val="accent1"/></a:fillRef><a:effectRef idx="1"><a:schemeClr val="accent1"/></a:effectRef><a:fontRef idx="minor"><a:schemeClr val="tx1"/></a:fontRef></a:style>', r[r.length] = "</a:lnDef>", r[r.length] = "</a:objectDefaults>", r[r.length] = "<a:extraClrSchemeLst/>", r[r.length] = "</a:theme>", r.join("");
}
function k1(e, a, r) {
  var t = e.l + a, n = e.read_shift(4);
  if (n !== 124226) {
    if (!r.cellStyles) {
      e.l = t;
      return;
    }
    var i = e.slice(e.l);
    e.l = t;
    var f;
    try {
      f = ii(i, { type: "array" });
    } catch {
      return;
    }
    var s = kr(f, "theme/theme/theme1.xml", !0);
    if (s)
      return ji(s, r);
  }
}
function E1(e) {
  return e.read_shift(4);
}
function T1(e) {
  var a = {};
  switch (a.xclrType = e.read_shift(2), a.nTintShade = e.read_shift(2), a.xclrType) {
    case 0:
      e.l += 4;
      break;
    case 1:
      a.xclrValue = w1(e, 4);
      break;
    case 2:
      a.xclrValue = bi(e);
      break;
    case 3:
      a.xclrValue = E1(e);
      break;
    case 4:
      e.l += 4;
      break;
  }
  return e.l += 8, a;
}
function w1(e, a) {
  return pr(e, a);
}
function F1(e, a) {
  return pr(e, a);
}
function A1(e) {
  var a = e.read_shift(2), r = e.read_shift(2) - 4, t = [a];
  switch (a) {
    case 4:
    case 5:
    case 7:
    case 8:
    case 9:
    case 10:
    case 11:
    case 13:
      t[1] = T1(e);
      break;
    case 6:
      t[1] = F1(e, r);
      break;
    case 14:
    case 15:
      t[1] = e.read_shift(r === 1 ? 1 : 2);
      break;
    default:
      throw new Error("Unrecognized ExtProp type: " + a + " " + r);
  }
  return t;
}
function S1(e, a) {
  var r = e.l + a;
  e.l += 2;
  var t = e.read_shift(2);
  e.l += 2;
  for (var n = e.read_shift(2), i = []; n-- > 0; ) i.push(A1(e, r - e.l));
  return { ixfe: t, ext: i };
}
function C1(e, a) {
  a.forEach(function(r) {
    r[0];
  });
}
function y1(e, a) {
  return {
    flags: e.read_shift(4),
    version: e.read_shift(4),
    name: vr(e)
  };
}
function D1(e) {
  for (var a = [], r = e.read_shift(4); r-- > 0; )
    a.push([e.read_shift(4), e.read_shift(4)]);
  return a;
}
function I1(e) {
  return e.l += 4, e.read_shift(4) != 0;
}
function O1(e, a, r) {
  var t = { Types: [], Cell: [], Value: [] }, n = r || {}, i = [], f = !1, s = 2;
  return ra(e, function(c, o, l) {
    switch (l) {
      case 335:
        t.Types.push({ name: c.name });
        break;
      case 51:
        c.forEach(function(v) {
          s == 1 ? t.Cell.push({ type: t.Types[v[0] - 1].name, index: v[1] }) : s == 0 && t.Value.push({ type: t.Types[v[0] - 1].name, index: v[1] });
        });
        break;
      case 337:
        s = c ? 1 : 0;
        break;
      case 338:
        s = 2;
        break;
      case 35:
        i.push(l), f = !0;
        break;
      case 36:
        i.pop(), f = !1;
        break;
      default:
        if (!o.T) {
          if (!f || n.WTF && i[i.length - 1] != 35)
            throw new Error("Unexpected record 0x" + l.toString(16));
        }
    }
  }), t;
}
function R1(e, a, r) {
  var t = { Types: [], Cell: [], Value: [] };
  if (!e)
    return t;
  var n = !1, i = 2, f;
  return e.replace(or, function(s) {
    var c = le(s);
    switch (Mr(c[0])) {
      case "<?xml":
        break;
      case "<metadata":
      case "</metadata>":
        break;
      case "<metadataTypes":
      case "</metadataTypes>":
        break;
      case "<metadataType":
        t.Types.push({ name: c.name });
        break;
      case "</metadataType>":
        break;
      case "<futureMetadata":
        for (var o = 0; o < t.Types.length; ++o)
          t.Types[o].name == c.name && (f = t.Types[o]);
        break;
      case "</futureMetadata>":
        break;
      case "<bk>":
        break;
      case "</bk>":
        break;
      case "<rc":
        i == 1 ? t.Cell.push({ type: t.Types[c.t - 1].name, index: +c.v }) : i == 0 && t.Value.push({ type: t.Types[c.t - 1].name, index: +c.v });
        break;
      case "</rc>":
        break;
      case "<cellMetadata":
        i = 1;
        break;
      case "</cellMetadata>":
        i = 2;
        break;
      case "<valueMetadata":
        i = 0;
        break;
      case "</valueMetadata>":
        i = 2;
        break;
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
      case "<extLst/>":
        break;
      case "<ext":
        n = !0;
        break;
      case "</ext>":
        n = !1;
        break;
      case "<rvb":
        if (!f)
          break;
        f.offsets || (f.offsets = []), f.offsets.push(+c.i);
        break;
      default:
        if (!n && r?.WTF)
          throw new Error("unrecognized " + c[0] + " in metadata");
    }
    return s;
  }), t;
}
function N1(e) {
  var a = [];
  if (!e) return a;
  var r = 1;
  return (e.match(or) || []).forEach(function(t) {
    var n = le(t);
    switch (n[0]) {
      case "<?xml":
        break;
      /* 18.6.2  calcChain CT_CalcChain 1 */
      case "<calcChain":
      case "<calcChain>":
      case "</calcChain>":
        break;
      /* 18.6.1  c CT_CalcCell 1 */
      case "<c":
        delete n[0], n.i ? r = n.i : n.i = r, a.push(n);
        break;
    }
  }), a;
}
function P1(e) {
  var a = {};
  a.i = e.read_shift(4);
  var r = {};
  r.r = e.read_shift(4), r.c = e.read_shift(4), a.r = Ne(r);
  var t = e.read_shift(1);
  return t & 2 && (a.l = "1"), t & 8 && (a.a = "1"), a;
}
function b1(e, a, r) {
  var t = [];
  return ra(e, function(i, f, s) {
    switch (s) {
      case 63:
        t.push(i);
        break;
      default:
        if (!f.T) throw new Error("Unexpected record 0x" + s.toString(16));
    }
  }), t;
}
function L1(e, a, r, t) {
  if (!e) return e;
  var n = t || {}, i = !1;
  ra(e, function(s, c, o) {
    switch (o) {
      case 359:
      /* 'BrtSupTabs' */
      case 363:
      /* 'BrtExternTableStart' */
      case 364:
      /* 'BrtExternTableEnd' */
      case 366:
      /* 'BrtExternRowHdr' */
      case 367:
      /* 'BrtExternCellBlank' */
      case 368:
      /* 'BrtExternCellReal' */
      case 369:
      /* 'BrtExternCellBool' */
      case 370:
      /* 'BrtExternCellError' */
      case 371:
      /* 'BrtExternCellString' */
      case 472:
      /* 'BrtExternValueMeta' */
      case 577:
      /* 'BrtSupNameStart' */
      case 578:
      /* 'BrtSupNameValueStart' */
      case 579:
      /* 'BrtSupNameValueEnd' */
      case 580:
      /* 'BrtSupNameNum' */
      case 581:
      /* 'BrtSupNameErr' */
      case 582:
      /* 'BrtSupNameSt' */
      case 583:
      /* 'BrtSupNameNil' */
      case 584:
      /* 'BrtSupNameBool' */
      case 585:
      /* 'BrtSupNameFmla' */
      case 586:
      /* 'BrtSupNameBits' */
      case 587:
        break;
      case 35:
        i = !0;
        break;
      case 36:
        i = !1;
        break;
      default:
        if (!c.T) {
          if (!i || n.WTF) throw new Error("Unexpected record 0x" + o.toString(16));
        }
    }
  }, n);
}
function B1(e, a) {
  if (!e) return "??";
  var r = (e.match(/<c:chart [^<>]*r:id="([^<>"]*)"/) || ["", ""])[1];
  return a["!id"][r].Target;
}
function M1(e, a, r) {
  var t = 0;
  (ai(e, "shape") || []).forEach(function(n) {
    var i = "", f = !0, s = -1, c = -1, o = -1;
    switch (n.replace(or, function(v, d) {
      var u = le(v);
      switch (Mr(u[0])) {
        case "<ClientData":
          u.ObjectType && (i = u.ObjectType);
          break;
        case "<Visible":
        case "<Visible/>":
          f = !1;
          break;
        case "<Row":
        case "<Row>":
          s = d + v.length;
          break;
        case "</Row>":
          c = +n.slice(s, d).trim();
          break;
        case "<Column":
        case "<Column>":
          s = d + v.length;
          break;
        case "</Column>":
          o = +n.slice(s, d).trim();
          break;
      }
      return "";
    }), i) {
      case "Note":
        var l = ct(a, c >= 0 && o >= 0 ? Ne({ r: c, c: o }) : r[t].ref);
        l.c && (l.c.hidden = f), ++t;
        break;
    }
  });
}
function Cn(e, a, r, t) {
  var n = e["!data"] != null, i;
  a.forEach(function(f) {
    var s = dr(f.ref);
    if (!(s.r < 0 || s.c < 0)) {
      if (n ? (e["!data"][s.r] || (e["!data"][s.r] = []), i = e["!data"][s.r][s.c]) : i = e[f.ref], !i) {
        i = { t: "z" }, n ? e["!data"][s.r][s.c] = i : e[f.ref] = i;
        var c = Ke(e["!ref"] || "BDWGO1000001:A1");
        c.s.r > s.r && (c.s.r = s.r), c.e.r < s.r && (c.e.r = s.r), c.s.c > s.c && (c.s.c = s.c), c.e.c < s.c && (c.e.c = s.c);
        var o = ye(c);
        e["!ref"] = o;
      }
      i.c || (i.c = []);
      var l = { a: f.author, t: f.t, r: f.r, T: r };
      f.h && (l.h = f.h);
      for (var v = i.c.length - 1; v >= 0; --v) {
        if (!r && i.c[v].T) return;
        r && !i.c[v].T && i.c.splice(v, 1);
      }
      if (r && t) {
        for (v = 0; v < t.length; ++v)
          if (l.a == t[v].id) {
            l.a = t[v].name || l.a;
            break;
          }
      }
      i.c.push(l);
    }
  });
}
function U1(e, a) {
  if (e.match(/<(?:\w+:)?comments *\/>/)) return [];
  var r = [], t = [], n = ir(e, "authors");
  n && n[1] && n[1].split(/<\/\w*:?author>/).forEach(function(f) {
    if (!(f === "" || f.trim() === "")) {
      var s = f.match(/<(?:\w+:)?author[^<>]*>(.*)/);
      s && r.push(s[1]);
    }
  });
  var i = ir(e, "commentList");
  return i && i[1] && i[1].split(/<\/\w*:?comment>/).forEach(function(f) {
    if (!(f === "" || f.trim() === "")) {
      var s = f.match(/<(?:\w+:)?comment[^<>]*>/);
      if (s) {
        var c = le(s[0]), o = { author: c.authorId && r[c.authorId] || "sheetjsghost", ref: c.ref, guid: c.guid }, l = dr(c.ref);
        if (!(a.sheetRows && a.sheetRows <= l.r)) {
          var v = ir(f, "text"), d = !!v && !!v[1] && D0(v[1]) || { r: "", t: "", h: "" };
          o.r = d.r, d.r == "<t></t>" && (d.t = d.h = ""), o.t = (d.t || "").replace(/\r\n/g, `
`).replace(/\r/g, `
`), a.cellHTML && (o.h = d.h), t.push(o);
        }
      }
    }
  }), t;
}
function H1(e, a) {
  var r = [], t = !1, n = {}, i = 0;
  return e.replace(or, function(s, c) {
    var o = le(s);
    switch (Mr(o[0])) {
      case "<?xml":
        break;
      /* 2.6.207 ThreadedComments CT_ThreadedComments */
      case "<ThreadedComments":
        break;
      case "</ThreadedComments>":
        break;
      /* 2.6.205 threadedComment CT_ThreadedComment */
      case "<threadedComment":
        n = { author: o.personId, guid: o.id, ref: o.ref, T: 1 };
        break;
      case "</threadedComment>":
        n.t != null && r.push(n);
        break;
      case "<text>":
      case "<text":
        i = c + s.length;
        break;
      case "</text>":
        n.t = e.slice(i, c).replace(/\r\n/g, `
`).replace(/\r/g, `
`);
        break;
      /* 2.6.206 mentions CT_ThreadedCommentMentions TODO */
      case "<mentions":
      case "<mentions>":
        t = !0;
        break;
      case "</mentions>":
        t = !1;
        break;
      /* 2.6.202 mention CT_Mention TODO */
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
      case "<extLst/>":
        break;
      /* 18.2.7  ext CT_Extension + */
      case "<ext":
        t = !0;
        break;
      case "</ext>":
        t = !1;
        break;
      default:
        if (!t && a.WTF) throw new Error("unrecognized " + o[0] + " in threaded comments");
    }
    return s;
  }), r;
}
function W1(e, a) {
  var r = [], t = !1;
  return e.replace(or, function(i) {
    var f = le(i);
    switch (Mr(f[0])) {
      case "<?xml":
        break;
      /* 2.4.85 personList CT_PersonList */
      case "<personList":
        break;
      case "</personList>":
        break;
      /* 2.6.203 person CT_Person TODO: providers */
      case "<person":
        r.push({ name: f.displayname, id: f.id });
        break;
      case "</person>":
        break;
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
      case "<extLst/>":
        break;
      /* 18.2.7  ext CT_Extension + */
      case "<ext":
        t = !0;
        break;
      case "</ext>":
        t = !1;
        break;
      default:
        if (!t && a.WTF) throw new Error("unrecognized " + f[0] + " in threaded comments");
    }
    return i;
  }), r;
}
function V1(e) {
  var a = {};
  a.iauthor = e.read_shift(4);
  var r = Aa(e);
  return a.rfx = r.s, a.ref = Ne(r.s), e.l += 16, a;
}
var G1 = vr;
function X1(e, a) {
  var r = [], t = [], n = {}, i = !1;
  return ra(e, function(s, c, o) {
    switch (o) {
      case 632:
        t.push(s);
        break;
      case 635:
        n = s;
        break;
      case 637:
        n.t = s.t, n.h = s.h, n.r = s.r;
        break;
      case 636:
        if (n.author = t[n.iauthor], delete n.iauthor, a.sheetRows && n.rfx && a.sheetRows <= n.rfx.r) break;
        n.t || (n.t = ""), delete n.rfx, r.push(n);
        break;
      case 3072:
        break;
      case 35:
        i = !0;
        break;
      case 36:
        i = !1;
        break;
      case 37:
        break;
      case 38:
        break;
      default:
        if (!c.T) {
          if (!i || a.WTF) throw new Error("Unexpected record 0x" + o.toString(16));
        }
    }
  }), r;
}
var z1 = "application/vnd.ms-office.vbaProject";
function $1(e) {
  var a = Oe.utils.cfb_new({ root: "R" });
  return e.FullPaths.forEach(function(r, t) {
    if (!(r.slice(-1) === "/" || !r.match(/_VBA_PROJECT_CUR/))) {
      var n = r.replace(/^[^\/]*/, "R").replace(/\/_VBA_PROJECT_CUR\u0000*/, "");
      Oe.utils.cfb_add(a, n, e.FileIndex[t].content);
    }
  }), Oe.write(a);
}
function K1() {
  return { "!type": "dialog" };
}
function Y1() {
  return { "!type": "dialog" };
}
function j1() {
  return { "!type": "macro" };
}
function J1() {
  return { "!type": "macro" };
}
var ma = /* @__PURE__ */ (function() {
  var e = /(^|[^A-Za-z_])R(\[?-?\d+\]|[1-9]\d*|)C(\[?-?\d+\]|[1-9]\d*|)(?![A-Za-z0-9_])/g, a = { r: 0, c: 0 };
  function r(t, n, i, f) {
    var s = !1, c = !1;
    i.length == 0 ? c = !0 : i.charAt(0) == "[" && (c = !0, i = i.slice(1, -1)), f.length == 0 ? s = !0 : f.charAt(0) == "[" && (s = !0, f = f.slice(1, -1));
    var o = i.length > 0 ? parseInt(i, 10) | 0 : 0, l = f.length > 0 ? parseInt(f, 10) | 0 : 0;
    return s ? l += a.c : --l, c ? o += a.r : --o, n + (s ? "" : "$") + Pe(l) + (c ? "" : "$") + Me(o);
  }
  return function(n, i) {
    return a = i, n.replace(e, r);
  };
})(), O0 = /(^|[^._A-Z0-9])(\$?)([A-Z]{1,2}|[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D])(\$?)(\d{1,7})(?![_.\(A-Za-z0-9])/g;
try {
  O0 = /(^|[^._A-Z0-9])([$]?)([A-Z]{1,2}|[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D])([$]?)(10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5})(?![_.\(A-Za-z0-9])/g;
} catch {
}
var Z1 = /* @__PURE__ */ (function() {
  return function(a, r) {
    return a.replace(O0, function(t, n, i, f, s, c) {
      var o = A0(f) - (i ? 0 : r.c), l = F0(c) - (s ? 0 : r.r), v = s == "$" ? l + 1 : l == 0 ? "" : "[" + l + "]", d = i == "$" ? o + 1 : o == 0 ? "" : "[" + o + "]";
      return n + "R" + v + "C" + d;
    });
  };
})();
function Ji(e, a) {
  return e.replace(O0, function(r, t, n, i, f, s) {
    return t + (n == "$" ? n + i : Pe(A0(i) + a.c)) + (f == "$" ? f + s : Me(F0(s) + a.r));
  });
}
function yn(e, a, r) {
  var t = wa(a), n = t.s, i = dr(r), f = { r: i.r - n.r, c: i.c - n.c };
  return Ji(e, f);
}
function q1(e) {
  return e.length != 1;
}
function Dn(e) {
  return e.replace(/_xlfn\./g, "");
}
function Je(e) {
  e.l += 1;
}
function ca(e, a) {
  var r = e.read_shift(2);
  return [r & 16383, r >> 14 & 1, r >> 15 & 1];
}
function Zi(e, a, r) {
  var t = 2;
  if (r) {
    if (r.biff >= 2 && r.biff <= 5) return qi(e);
    r.biff == 12 && (t = 4);
  }
  var n = e.read_shift(t), i = e.read_shift(t), f = ca(e), s = ca(e);
  return { s: { r: n, c: f[0], cRel: f[1], rRel: f[2] }, e: { r: i, c: s[0], cRel: s[1], rRel: s[2] } };
}
function qi(e) {
  var a = ca(e), r = ca(e), t = e.read_shift(1), n = e.read_shift(1);
  return { s: { r: a[0], c: t, cRel: a[1], rRel: a[2] }, e: { r: r[0], c: n, cRel: r[1], rRel: r[2] } };
}
function Q1(e, a, r) {
  if (r.biff < 8) return qi(e);
  var t = e.read_shift(r.biff == 12 ? 4 : 2), n = e.read_shift(r.biff == 12 ? 4 : 2), i = ca(e), f = ca(e);
  return { s: { r: t, c: i[0], cRel: i[1], rRel: i[2] }, e: { r: n, c: f[0], cRel: f[1], rRel: f[2] } };
}
function Qi(e, a, r) {
  if (r && r.biff >= 2 && r.biff <= 5) return eu(e);
  var t = e.read_shift(r && r.biff == 12 ? 4 : 2), n = ca(e);
  return { r: t, c: n[0], cRel: n[1], rRel: n[2] };
}
function eu(e) {
  var a = ca(e), r = e.read_shift(1);
  return { r: a[0], c: r, cRel: a[1], rRel: a[2] };
}
function ru(e) {
  var a = e.read_shift(2), r = e.read_shift(2);
  return { r: a, c: r & 255, fQuoted: !!(r & 16384), cRel: r >> 15, rRel: r >> 15 };
}
function au(e, a, r) {
  var t = r && r.biff ? r.biff : 8;
  if (t >= 2 && t <= 5) return tu(e);
  var n = e.read_shift(t >= 12 ? 4 : 2), i = e.read_shift(2), f = (i & 16384) >> 14, s = (i & 32768) >> 15;
  if (i &= 16383, s == 1) for (; n > 524287; ) n -= 1048576;
  if (f == 1) for (; i > 8191; ) i = i - 16384;
  return { r: n, c: i, cRel: f, rRel: s };
}
function tu(e) {
  var a = e.read_shift(2), r = e.read_shift(1), t = (a & 32768) >> 15, n = (a & 16384) >> 14;
  return a &= 16383, t == 1 && a >= 8192 && (a = a - 16384), n == 1 && r >= 128 && (r = r - 256), { r: a, c: r, cRel: n, rRel: t };
}
function nu(e, a, r) {
  var t = (e[e.l++] & 96) >> 5, n = Zi(e, r.biff >= 2 && r.biff <= 5 ? 6 : 8, r);
  return [t, n];
}
function iu(e, a, r) {
  var t = (e[e.l++] & 96) >> 5, n = e.read_shift(2, "i"), i = 8;
  if (r) switch (r.biff) {
    case 5:
      e.l += 12, i = 6;
      break;
    case 12:
      i = 12;
      break;
  }
  var f = Zi(e, i, r);
  return [t, n, f];
}
function su(e, a, r) {
  var t = (e[e.l++] & 96) >> 5;
  return e.l += r && r.biff > 8 ? 12 : r.biff < 8 ? 6 : 8, [t];
}
function fu(e, a, r) {
  var t = (e[e.l++] & 96) >> 5, n = e.read_shift(2), i = 8;
  if (r) switch (r.biff) {
    case 5:
      e.l += 12, i = 6;
      break;
    case 12:
      i = 12;
      break;
  }
  return e.l += i, [t, n];
}
function cu(e, a, r) {
  var t = (e[e.l++] & 96) >> 5, n = Q1(e, a - 1, r);
  return [t, n];
}
function ou(e, a, r) {
  var t = (e[e.l++] & 96) >> 5;
  return e.l += r.biff == 2 ? 6 : r.biff == 12 ? 14 : 7, [t];
}
function In(e) {
  var a = e[e.l + 1] & 1, r = 1;
  return e.l += 4, [a, r];
}
function lu(e, a, r) {
  e.l += 2;
  for (var t = e.read_shift(r && r.biff == 2 ? 1 : 2), n = [], i = 0; i <= t; ++i) n.push(e.read_shift(r && r.biff == 2 ? 1 : 2));
  return n;
}
function uu(e, a, r) {
  var t = e[e.l + 1] & 255 ? 1 : 0;
  return e.l += 2, [t, e.read_shift(r && r.biff == 2 ? 1 : 2)];
}
function hu(e, a, r) {
  var t = e[e.l + 1] & 255 ? 1 : 0;
  return e.l += 2, [t, e.read_shift(r && r.biff == 2 ? 1 : 2)];
}
function xu(e) {
  var a = e[e.l + 1] & 255 ? 1 : 0;
  return e.l += 2, [a, e.read_shift(2)];
}
function du(e, a, r) {
  var t = e[e.l + 1] & 255 ? 1 : 0;
  return e.l += r && r.biff == 2 ? 3 : 4, [t];
}
function es(e) {
  var a = e.read_shift(1), r = e.read_shift(1);
  return [a, r];
}
function vu(e) {
  return e.read_shift(2), es(e);
}
function pu(e) {
  return e.read_shift(2), es(e);
}
function gu(e, a, r) {
  var t = (e[e.l] & 96) >> 5;
  e.l += 1;
  var n = Qi(e, 0, r);
  return [t, n];
}
function mu(e, a, r) {
  var t = (e[e.l] & 96) >> 5;
  e.l += 1;
  var n = au(e, 0, r);
  return [t, n];
}
function _u(e, a, r) {
  var t = (e[e.l] & 96) >> 5;
  e.l += 1;
  var n = e.read_shift(2);
  r && r.biff == 5 && (e.l += 12);
  var i = Qi(e, 0, r);
  return [t, n, i];
}
function ku(e, a, r) {
  var t = (e[e.l] & 96) >> 5;
  e.l += 1;
  var n = e.read_shift(r && r.biff <= 3 ? 1 : 2);
  return [Eh[n], ts[n], t];
}
function Eu(e, a, r) {
  var t = e[e.l++], n = e.read_shift(1), i = r && r.biff <= 3 ? [t == 88 ? -1 : 0, e.read_shift(1)] : Tu(e);
  return [n, (i[0] === 0 ? ts : kh)[i[1]]];
}
function Tu(e) {
  return [e[e.l + 1] >> 7, e.read_shift(2) & 32767];
}
function wu(e, a, r) {
  e.l += r && r.biff == 2 ? 3 : 4;
}
function Fu(e, a, r) {
  if (e.l++, r && r.biff == 12) return [e.read_shift(4, "i"), 0];
  var t = e.read_shift(2), n = e.read_shift(r && r.biff == 2 ? 1 : 2);
  return [t, n];
}
function Au(e) {
  return e.l++, Ar[e.read_shift(1)];
}
function Su(e) {
  return e.l++, e.read_shift(2);
}
function Cu(e) {
  return e.l++, e.read_shift(1) !== 0;
}
function yu(e) {
  return e.l++, xr(e);
}
function Du(e, a, r) {
  return e.l++, Pa(e, a - 1, r);
}
function Iu(e, a) {
  var r = [e.read_shift(1)];
  if (a == 12) switch (r[0]) {
    case 2:
      r[0] = 4;
      break;
    /* SerBool */
    case 4:
      r[0] = 16;
      break;
    /* SerErr */
    case 0:
      r[0] = 1;
      break;
    /* SerNum */
    case 1:
      r[0] = 2;
      break;
  }
  switch (r[0]) {
    case 4:
      r[1] = $e(e, 1) ? "TRUE" : "FALSE", a != 12 && (e.l += 7);
      break;
    case 37:
    /* appears to be an alias */
    case 16:
      r[1] = Ar[e[e.l]], e.l += a == 12 ? 4 : 8;
      break;
    case 0:
      e.l += 8;
      break;
    case 1:
      r[1] = xr(e);
      break;
    case 2:
      r[1] = Sa(e, 0, { biff: a > 0 && a < 8 ? 2 : a });
      break;
    default:
      throw new Error("Bad SerAr: " + r[0]);
  }
  return r;
}
function Ou(e, a, r) {
  for (var t = e.read_shift(r.biff == 12 ? 4 : 2), n = [], i = 0; i != t; ++i) n.push((r.biff == 12 ? Aa : Xt)(e));
  return n;
}
function Ru(e, a, r) {
  var t = 0, n = 0;
  r.biff == 12 ? (t = e.read_shift(4), n = e.read_shift(4)) : (n = 1 + e.read_shift(1), t = 1 + e.read_shift(2)), r.biff >= 2 && r.biff < 8 && (--t, --n == 0 && (n = 256));
  for (var i = 0, f = []; i != t && (f[i] = []); ++i)
    for (var s = 0; s != n; ++s) f[i][s] = Iu(e, r.biff);
  return f;
}
function Nu(e, a, r) {
  var t = e.read_shift(1) >>> 5 & 3, n = !r || r.biff >= 8 ? 4 : 2, i = e.read_shift(n);
  switch (r.biff) {
    case 2:
      e.l += 5;
      break;
    case 3:
    case 4:
      e.l += 8;
      break;
    case 5:
      e.l += 12;
      break;
  }
  return [t, 0, i];
}
function Pu(e, a, r) {
  if (r.biff == 5) return bu(e);
  var t = e.read_shift(1) >>> 5 & 3, n = e.read_shift(2), i = e.read_shift(4);
  return [t, n, i];
}
function bu(e) {
  var a = e.read_shift(1) >>> 5 & 3, r = e.read_shift(2, "i");
  e.l += 8;
  var t = e.read_shift(2);
  return e.l += 12, [a, r, t];
}
function Lu(e, a, r) {
  var t = e.read_shift(1) >>> 5 & 3;
  e.l += r && r.biff == 2 ? 3 : 4;
  var n = e.read_shift(r && r.biff == 2 ? 1 : 2);
  return [t, n];
}
function Bu(e, a, r) {
  var t = e.read_shift(1) >>> 5 & 3, n = e.read_shift(r && r.biff == 2 ? 1 : 2);
  return [t, n];
}
function Mu(e, a, r) {
  var t = e.read_shift(1) >>> 5 & 3;
  return e.l += 4, r.biff < 8 && e.l--, r.biff == 12 && (e.l += 2), [t];
}
function Uu(e, a, r) {
  var t = (e[e.l++] & 96) >> 5, n = e.read_shift(2), i = 4;
  if (r) switch (r.biff) {
    case 5:
      i = 15;
      break;
    case 12:
      i = 6;
      break;
  }
  return e.l += i, [t, n];
}
var Hu = pr, Wu = pr, Vu = pr;
function ht(e, a, r) {
  return e.l += 2, [ru(e)];
}
function R0(e) {
  return e.l += 6, [];
}
var Gu = ht, Xu = R0, zu = R0, $u = ht;
function rs(e) {
  return e.l += 2, [ze(e), e.read_shift(2) & 1];
}
var Ku = ht, Yu = rs, ju = R0, Ju = ht, Zu = ht, qu = [
  "Data",
  "All",
  "Headers",
  "??",
  "?Data2",
  "??",
  "?DataHeaders",
  "??",
  "Totals",
  "??",
  "??",
  "??",
  "?DataTotals",
  "??",
  "??",
  "??",
  "?Current"
];
function Qu(e) {
  e.l += 2;
  var a = e.read_shift(2), r = e.read_shift(2), t = e.read_shift(4), n = e.read_shift(2), i = e.read_shift(2), f = qu[r >> 2 & 31];
  return { ixti: a, coltype: r & 3, rt: f, idx: t, c: n, C: i };
}
function eh(e) {
  return e.l += 2, [e.read_shift(4)];
}
function rh(e, a, r) {
  return e.l += 5, e.l += 2, e.l += r.biff == 2 ? 1 : 4, ["PTGSHEET"];
}
function ah(e, a, r) {
  return e.l += r.biff == 2 ? 4 : 5, ["PTGENDSHEET"];
}
function th(e) {
  var a = e.read_shift(1) >>> 5 & 3, r = e.read_shift(2);
  return [a, r];
}
function nh(e) {
  var a = e.read_shift(1) >>> 5 & 3, r = e.read_shift(2);
  return [a, r];
}
function ih(e) {
  return e.l += 4, [0, 0];
}
var On = {
  1: { n: "PtgExp", f: Fu },
  2: { n: "PtgTbl", f: Vu },
  3: { n: "PtgAdd", f: Je },
  4: { n: "PtgSub", f: Je },
  5: { n: "PtgMul", f: Je },
  6: { n: "PtgDiv", f: Je },
  7: { n: "PtgPower", f: Je },
  8: { n: "PtgConcat", f: Je },
  9: { n: "PtgLt", f: Je },
  10: { n: "PtgLe", f: Je },
  11: { n: "PtgEq", f: Je },
  12: { n: "PtgGe", f: Je },
  13: { n: "PtgGt", f: Je },
  14: { n: "PtgNe", f: Je },
  15: { n: "PtgIsect", f: Je },
  16: { n: "PtgUnion", f: Je },
  17: { n: "PtgRange", f: Je },
  18: { n: "PtgUplus", f: Je },
  19: { n: "PtgUminus", f: Je },
  20: { n: "PtgPercent", f: Je },
  21: { n: "PtgParen", f: Je },
  22: { n: "PtgMissArg", f: Je },
  23: { n: "PtgStr", f: Du },
  26: { n: "PtgSheet", f: rh },
  27: { n: "PtgEndSheet", f: ah },
  28: { n: "PtgErr", f: Au },
  29: { n: "PtgBool", f: Cu },
  30: { n: "PtgInt", f: Su },
  31: { n: "PtgNum", f: yu },
  32: { n: "PtgArray", f: ou },
  33: { n: "PtgFunc", f: ku },
  34: { n: "PtgFuncVar", f: Eu },
  35: { n: "PtgName", f: Nu },
  36: { n: "PtgRef", f: gu },
  37: { n: "PtgArea", f: nu },
  38: { n: "PtgMemArea", f: Lu },
  39: { n: "PtgMemErr", f: Hu },
  40: { n: "PtgMemNoMem", f: Wu },
  41: { n: "PtgMemFunc", f: Bu },
  42: { n: "PtgRefErr", f: Mu },
  43: { n: "PtgAreaErr", f: su },
  44: { n: "PtgRefN", f: mu },
  45: { n: "PtgAreaN", f: cu },
  46: { n: "PtgMemAreaN", f: th },
  47: { n: "PtgMemNoMemN", f: nh },
  57: { n: "PtgNameX", f: Pu },
  58: { n: "PtgRef3d", f: _u },
  59: { n: "PtgArea3d", f: iu },
  60: { n: "PtgRefErr3d", f: Uu },
  61: { n: "PtgAreaErr3d", f: fu },
  255: {}
}, sh = {
  64: 32,
  96: 32,
  65: 33,
  97: 33,
  66: 34,
  98: 34,
  67: 35,
  99: 35,
  68: 36,
  100: 36,
  69: 37,
  101: 37,
  70: 38,
  102: 38,
  71: 39,
  103: 39,
  72: 40,
  104: 40,
  73: 41,
  105: 41,
  74: 42,
  106: 42,
  75: 43,
  107: 43,
  76: 44,
  108: 44,
  77: 45,
  109: 45,
  78: 46,
  110: 46,
  79: 47,
  111: 47,
  88: 34,
  120: 34,
  89: 57,
  121: 57,
  90: 58,
  122: 58,
  91: 59,
  123: 59,
  92: 60,
  124: 60,
  93: 61,
  125: 61
}, fh = {
  1: { n: "PtgElfLel", f: rs },
  2: { n: "PtgElfRw", f: Ju },
  3: { n: "PtgElfCol", f: Gu },
  6: { n: "PtgElfRwV", f: Zu },
  7: { n: "PtgElfColV", f: $u },
  10: { n: "PtgElfRadical", f: Ku },
  11: { n: "PtgElfRadicalS", f: ju },
  13: { n: "PtgElfColS", f: Xu },
  15: { n: "PtgElfColSV", f: zu },
  16: { n: "PtgElfRadicalLel", f: Yu },
  25: { n: "PtgList", f: Qu },
  29: { n: "PtgSxName", f: eh },
  255: {}
}, ch = {
  0: { n: "PtgAttrNoop", f: ih },
  1: { n: "PtgAttrSemi", f: du },
  2: { n: "PtgAttrIf", f: hu },
  4: { n: "PtgAttrChoose", f: lu },
  8: { n: "PtgAttrGoto", f: uu },
  16: { n: "PtgAttrSum", f: wu },
  32: { n: "PtgAttrBaxcel", f: In },
  33: { n: "PtgAttrBaxcel", f: In },
  64: { n: "PtgAttrSpace", f: vu },
  65: { n: "PtgAttrSpaceSemi", f: pu },
  128: { n: "PtgAttrIfError", f: xu },
  255: {}
};
function xt(e, a, r, t) {
  if (t.biff < 8) return pr(e, a);
  for (var n = e.l + a, i = [], f = 0; f !== r.length; ++f)
    switch (r[f][0]) {
      case "PtgArray":
        r[f][1] = Ru(e, 0, t), i.push(r[f][1]);
        break;
      case "PtgMemArea":
        r[f][2] = Ou(e, r[f][1], t), i.push(r[f][2]);
        break;
      case "PtgExp":
        t && t.biff == 12 && (r[f][1][1] = e.read_shift(4), i.push(r[f][1]));
        break;
      case "PtgList":
      /* TODO: PtgList -> PtgExtraList */
      case "PtgElfRadicalS":
      /* TODO: PtgElfRadicalS -> PtgExtraElf */
      case "PtgElfColS":
      /* TODO: PtgElfColS -> PtgExtraElf */
      case "PtgElfColSV":
        throw "Unsupported " + r[f][0];
    }
  return a = n - e.l, a !== 0 && i.push(pr(e, a)), i;
}
function dt(e, a, r) {
  for (var t = e.l + a, n, i, f = []; t != e.l; )
    a = t - e.l, i = e[e.l], n = On[i] || On[sh[i]], (i === 24 || i === 25) && (n = (i === 24 ? fh : ch)[e[e.l + 1]]), !n || !n.f ? pr(e, a) : f.push([n.n, n.f(e, a, r)]);
  return f;
}
function oh(e) {
  for (var a = [], r = 0; r < e.length; ++r) {
    for (var t = e[r], n = [], i = 0; i < t.length; ++i) {
      var f = t[i];
      if (f) switch (f[0]) {
        // TODO: handle embedded quotes
        case 2:
          n.push('"' + f[1].replace(/"/g, '""') + '"');
          break;
        default:
          n.push(f[1]);
      }
      else n.push("");
    }
    a.push(n.join(","));
  }
  return a.join(";");
}
var lh = {
  PtgAdd: "+",
  PtgConcat: "&",
  PtgDiv: "/",
  PtgEq: "=",
  PtgGe: ">=",
  PtgGt: ">",
  PtgLe: "<=",
  PtgLt: "<",
  PtgMul: "*",
  PtgNe: "<>",
  PtgPower: "^",
  PtgSub: "-"
};
function uh(e, a) {
  var r = e.lastIndexOf("!"), t = a.lastIndexOf("!");
  return r == -1 && t == -1 ? e + ":" + a : r > 0 && t > 0 && e.slice(0, r).toLowerCase() == a.slice(0, t).toLowerCase() ? e + ":" + a.slice(t + 1) : (console.error("Cannot hydrate range", e, a), e + ":" + a);
}
function as(e, a, r) {
  if (!e) return "SH33TJSERR0";
  if (r.biff > 8 && (!e.XTI || !e.XTI[a])) return e.SheetNames[a];
  if (!e.XTI) return "SH33TJSERR6";
  var t = e.XTI[a];
  if (r.biff < 8)
    return a > 1e4 && (a -= 65536), a < 0 && (a = -a), a == 0 ? "" : e.XTI[a - 1];
  if (!t) return "SH33TJSERR1";
  var n = "";
  if (r.biff > 8) switch (e[t[0]][0]) {
    case 357:
      return n = t[1] == -1 ? "#REF" : e.SheetNames[t[1]], t[1] == t[2] ? n : n + ":" + e.SheetNames[t[2]];
    case 358:
      return r.SID != null ? e.SheetNames[r.SID] : "SH33TJSSAME" + e[t[0]][0];
    case 355:
    /* 'BrtSupBookSrc' */
    /* falls through */
    default:
      return "SH33TJSSRC" + e[t[0]][0];
  }
  switch (e[t[0]][0][0]) {
    case 1025:
      return n = t[1] == -1 ? "#REF" : e.SheetNames[t[1]] || "SH33TJSERR3", t[1] == t[2] ? n : n + ":" + e.SheetNames[t[2]];
    case 14849:
      return e[t[0]].slice(1).map(function(i) {
        return i.Name;
      }).join(";;");
    //return "SH33TJSERR8";
    default:
      return e[t[0]][0][3] ? (n = t[1] == -1 ? "#REF" : e[t[0]][0][3][t[1]] || "SH33TJSERR4", t[1] == t[2] ? n : n + ":" + e[t[0]][0][3][t[2]]) : "SH33TJSERR2";
  }
}
function Rn(e, a, r) {
  var t = as(e, a, r);
  return t == "#REF" ? t : oc(t, r);
}
function hr(e, a, r, t, n) {
  var i = n && n.biff || 8, f = (
    /*range != null ? range :*/
    { s: { c: 0, r: 0 } }
  ), s = [], c, o, l, v = 0, d = 0, u, p = "";
  if (!e[0] || !e[0][0]) return "";
  for (var _ = -1, x = "", h = 0, E = e[0].length; h < E; ++h) {
    var g = e[0][h];
    switch (g[0]) {
      case "PtgUminus":
        s.push("-" + s.pop());
        break;
      case "PtgUplus":
        s.push("+" + s.pop());
        break;
      case "PtgPercent":
        s.push(s.pop() + "%");
        break;
      case "PtgAdd":
      /* [MS-XLS] 2.5.198.26 */
      case "PtgConcat":
      /* [MS-XLS] 2.5.198.43 */
      case "PtgDiv":
      /* [MS-XLS] 2.5.198.45 */
      case "PtgEq":
      /* [MS-XLS] 2.5.198.56 */
      case "PtgGe":
      /* [MS-XLS] 2.5.198.64 */
      case "PtgGt":
      /* [MS-XLS] 2.5.198.65 */
      case "PtgLe":
      /* [MS-XLS] 2.5.198.68 */
      case "PtgLt":
      /* [MS-XLS] 2.5.198.69 */
      case "PtgMul":
      /* [MS-XLS] 2.5.198.75 */
      case "PtgNe":
      /* [MS-XLS] 2.5.198.78 */
      case "PtgPower":
      /* [MS-XLS] 2.5.198.82 */
      case "PtgSub":
        if (c = s.pop(), o = s.pop(), _ >= 0) {
          switch (e[0][_][1][0]) {
            case 0:
              x = Ie(" ", e[0][_][1][1]);
              break;
            case 1:
              x = Ie("\r", e[0][_][1][1]);
              break;
            default:
              if (x = "", n.WTF) throw new Error("Unexpected PtgAttrSpaceType " + e[0][_][1][0]);
          }
          o = o + x, _ = -1;
        }
        s.push(o + lh[g[0]] + c);
        break;
      case "PtgIsect":
        c = s.pop(), o = s.pop(), s.push(o + " " + c);
        break;
      case "PtgUnion":
        c = s.pop(), o = s.pop(), s.push(o + "," + c);
        break;
      case "PtgRange":
        c = s.pop(), o = s.pop(), s.push(uh(o, c));
        break;
      case "PtgAttrChoose":
        break;
      case "PtgAttrGoto":
        break;
      case "PtgAttrIf":
        break;
      case "PtgAttrIfError":
        break;
      case "PtgRef":
        l = za(g[1][1], f, n), s.push($a(l, i));
        break;
      case "PtgRefN":
        l = r ? za(g[1][1], r, n) : g[1][1], s.push($a(l, i));
        break;
      case "PtgRef3d":
        v = /*::Number(*/
        g[1][1], l = za(g[1][2], f, n), p = Rn(t, v, n), s.push(p + "!" + $a(l, i));
        break;
      case "PtgFunc":
      /* [MS-XLS] 2.5.198.62 */
      case "PtgFuncVar":
        var y = g[1][0], P = g[1][1];
        y || (y = 0), y &= 127;
        var M = y == 0 ? [] : s.slice(-y);
        s.length -= y, P === "User" && (P = M.shift()), s.push(P + "(" + M.join(",") + ")");
        break;
      case "PtgBool":
        s.push(g[1] ? "TRUE" : "FALSE");
        break;
      case "PtgInt":
        s.push(
          /*::String(*/
          g[1]
          /*::)*/
        );
        break;
      case "PtgNum":
        s.push(String(g[1]));
        break;
      case "PtgStr":
        s.push('"' + g[1].replace(/"/g, '""') + '"');
        break;
      case "PtgErr":
        s.push(
          /*::String(*/
          g[1]
          /*::)*/
        );
        break;
      case "PtgAreaN":
        u = ln(g[1][1], r ? { s: r } : f, n), s.push(qt(u, n));
        break;
      case "PtgArea":
        u = ln(g[1][1], f, n), s.push(qt(u, n));
        break;
      case "PtgArea3d":
        v = /*::Number(*/
        g[1][1], u = g[1][2], p = Rn(t, v, n), s.push(p + "!" + qt(u, n));
        break;
      case "PtgAttrSum":
        s.push("SUM(" + s.pop() + ")");
        break;
      case "PtgAttrBaxcel":
      /* [MS-XLS] 2.5.198.33 */
      case "PtgAttrSemi":
        break;
      case "PtgName":
        d = g[1][2];
        var I = (t.names || [])[d - 1] || (t[0] || [])[d], N = I ? I.Name : "SH33TJSNAME" + String(d);
        N && N.slice(0, 6) == "_xlfn." && !n.xlfn && (N = N.slice(6)), s.push(N);
        break;
      case "PtgNameX":
        var O = g[1][1];
        d = g[1][2];
        var B;
        if (n.biff <= 5)
          O < 0 && (O = -O), t[O] && (B = t[O][d]);
        else {
          var b = "";
          if (((t[O] || [])[0] || [])[0] == 14849 || (((t[O] || [])[0] || [])[0] == 1025 ? t[O][d] && t[O][d].itab > 0 && (b = t.SheetNames[t[O][d].itab - 1] + "!") : b = t.SheetNames[d - 1] + "!"), t[O] && t[O][d]) b += t[O][d].Name;
          else if (t[0] && t[0][d]) b += t[0][d].Name;
          else {
            var G = (as(t, O, n) || "").split(";;");
            G[d - 1] ? b = G[d - 1] : b += "SH33TJSERRX";
          }
          s.push(b);
          break;
        }
        B || (B = { Name: "SH33TJSERRY" }), s.push(B.Name);
        break;
      case "PtgParen":
        var z = "(", fe = ")";
        if (_ >= 0) {
          switch (x = "", e[0][_][1][0]) {
            // $FlowIgnore
            case 2:
              z = Ie(" ", e[0][_][1][1]) + z;
              break;
            // $FlowIgnore
            case 3:
              z = Ie("\r", e[0][_][1][1]) + z;
              break;
            // $FlowIgnore
            case 4:
              fe = Ie(" ", e[0][_][1][1]) + fe;
              break;
            // $FlowIgnore
            case 5:
              fe = Ie("\r", e[0][_][1][1]) + fe;
              break;
            default:
              if (n.WTF) throw new Error("Unexpected PtgAttrSpaceType " + e[0][_][1][0]);
          }
          _ = -1;
        }
        s.push(z + s.pop() + fe);
        break;
      case "PtgRefErr":
        s.push("#REF!");
        break;
      case "PtgRefErr3d":
        s.push("#REF!");
        break;
      case "PtgExp":
        l = { c: g[1][1], r: g[1][0] };
        var j = { c: r.c, r: r.r };
        if (t.sharedf[Ne(l)]) {
          var he = t.sharedf[Ne(l)];
          s.push(hr(he, f, j, t, n));
        } else {
          var J = !1;
          for (c = 0; c != t.arrayf.length; ++c)
            if (o = t.arrayf[c], !(l.c < o[0].s.c || l.c > o[0].e.c) && !(l.r < o[0].s.r || l.r > o[0].e.r)) {
              s.push(hr(o[1], f, j, t, n)), J = !0;
              break;
            }
          J || s.push(
            /*::String(*/
            g[1]
            /*::)*/
          );
        }
        break;
      case "PtgArray":
        s.push("{" + oh(
          /*::(*/
          g[1]
          /*:: :any)*/
        ) + "}");
        break;
      case "PtgMemArea":
        break;
      case "PtgAttrSpace":
      /* [MS-XLS] 2.5.198.38 */
      case "PtgAttrSpaceSemi":
        _ = h;
        break;
      case "PtgTbl":
        break;
      case "PtgMemErr":
        break;
      case "PtgMissArg":
        s.push("");
        break;
      case "PtgAreaErr":
        s.push("#REF!");
        break;
      case "PtgAreaErr3d":
        s.push("#REF!");
        break;
      case "PtgList":
        s.push("Table" + g[1].idx + "[#" + g[1].rt + "]");
        break;
      case "PtgMemAreaN":
      case "PtgMemNoMemN":
      case "PtgAttrNoop":
      case "PtgSheet":
      case "PtgEndSheet":
        break;
      case "PtgMemFunc":
        break;
      case "PtgMemNoMem":
        break;
      case "PtgElfCol":
      /* [MS-XLS] 2.5.198.46 */
      case "PtgElfColS":
      /* [MS-XLS] 2.5.198.47 */
      case "PtgElfColSV":
      /* [MS-XLS] 2.5.198.48 */
      case "PtgElfColV":
      /* [MS-XLS] 2.5.198.49 */
      case "PtgElfLel":
      /* [MS-XLS] 2.5.198.50 */
      case "PtgElfRadical":
      /* [MS-XLS] 2.5.198.51 */
      case "PtgElfRadicalLel":
      /* [MS-XLS] 2.5.198.52 */
      case "PtgElfRadicalS":
      /* [MS-XLS] 2.5.198.53 */
      case "PtgElfRw":
      /* [MS-XLS] 2.5.198.54 */
      case "PtgElfRwV":
        throw new Error("Unsupported ELFs");
      case "PtgSxName":
        throw new Error("Unrecognized Formula Token: " + String(g));
      default:
        throw new Error("Unrecognized Formula Token: " + String(g));
    }
    var ne = ["PtgAttrSpace", "PtgAttrSpaceSemi", "PtgAttrGoto"];
    if (n.biff != 3 && _ >= 0 && ne.indexOf(e[0][h][0]) == -1) {
      g = e[0][_];
      var pe = !0;
      switch (g[1][0]) {
        /* note: some bad XLSB files omit the PtgParen */
        case 4:
          pe = !1;
        /* falls through */
        case 0:
          x = Ie(" ", g[1][1]);
          break;
        case 5:
          pe = !1;
        /* falls through */
        case 1:
          x = Ie("\r", g[1][1]);
          break;
        default:
          if (x = "", n.WTF) throw new Error("Unexpected PtgAttrSpaceType " + g[1][0]);
      }
      s.push((pe ? x : "") + s.pop() + (pe ? "" : x)), _ = -1;
    }
  }
  if (s.length > 1 && n.WTF) throw new Error("bad formula stack");
  return s[0] == "TRUE" ? !0 : s[0] == "FALSE" ? !1 : s[0];
}
function hh(e, a, r) {
  var t = e.l + a, n = r.biff == 2 ? 1 : 2, i, f = e.read_shift(n);
  if (f == 65535) return [[], pr(e, a - 2)];
  var s = dt(e, f, r);
  return a !== f + n && (i = xt(e, a - f - n, s, r)), e.l = t, [s, i];
}
function xh(e, a, r) {
  var t = e.l + a, n = r.biff == 2 ? 1 : 2, i, f = e.read_shift(n);
  if (f == 65535) return [[], pr(e, a - 2)];
  var s = dt(e, f, r);
  return a !== f + n && (i = xt(e, a - f - n, s, r)), e.l = t, [s, i];
}
function dh(e, a, r, t) {
  var n = e.l + a, i = dt(e, t, r), f;
  return n !== e.l && (f = xt(e, n - e.l, i, r)), [i, f];
}
function vh(e, a, r) {
  var t = e.l + a, n, i = e.read_shift(2), f = dt(e, i, r);
  return i == 65535 ? [[], pr(e, a - 2)] : (a !== i + 2 && (n = xt(e, t - i - 2, f, r)), [f, n]);
}
function ph(e) {
  var a;
  if (Zr(e, e.l + 6) !== 65535) return [xr(e), "n"];
  switch (e[e.l]) {
    case 0:
      return e.l += 8, ["String", "s"];
    case 1:
      return a = e[e.l + 2] === 1, e.l += 8, [a, "b"];
    case 2:
      return a = e[e.l + 2], e.l += 8, [a, "e"];
    case 3:
      return e.l += 8, ["", "s"];
  }
  return [];
}
function r0(e, a, r) {
  var t = e.l + a, n = Xr(e, 6, r), i = ph(e), f = e.read_shift(1);
  r.biff != 2 && (e.read_shift(1), r.biff >= 5 && e.read_shift(4));
  var s = xh(e, t - e.l, r);
  return { cell: n, val: i[0], formula: s, shared: f >> 3 & 1, tt: i[1] };
}
function zt(e, a, r) {
  var t = e.read_shift(4), n = dt(e, t, r), i = e.read_shift(4), f = i > 0 ? xt(e, i, n, r) : null;
  return [n, f];
}
var gh = zt, $t = zt, mh = zt, _h = zt, kh = {
  0: "BEEP",
  1: "OPEN",
  2: "OPEN.LINKS",
  3: "CLOSE.ALL",
  4: "SAVE",
  5: "SAVE.AS",
  6: "FILE.DELETE",
  7: "PAGE.SETUP",
  8: "PRINT",
  9: "PRINTER.SETUP",
  10: "QUIT",
  11: "NEW.WINDOW",
  12: "ARRANGE.ALL",
  13: "WINDOW.SIZE",
  14: "WINDOW.MOVE",
  15: "FULL",
  16: "CLOSE",
  17: "RUN",
  22: "SET.PRINT.AREA",
  23: "SET.PRINT.TITLES",
  24: "SET.PAGE.BREAK",
  25: "REMOVE.PAGE.BREAK",
  26: "FONT",
  27: "DISPLAY",
  28: "PROTECT.DOCUMENT",
  29: "PRECISION",
  30: "A1.R1C1",
  31: "CALCULATE.NOW",
  32: "CALCULATION",
  34: "DATA.FIND",
  35: "EXTRACT",
  36: "DATA.DELETE",
  37: "SET.DATABASE",
  38: "SET.CRITERIA",
  39: "SORT",
  40: "DATA.SERIES",
  41: "TABLE",
  42: "FORMAT.NUMBER",
  43: "ALIGNMENT",
  44: "STYLE",
  45: "BORDER",
  46: "CELL.PROTECTION",
  47: "COLUMN.WIDTH",
  48: "UNDO",
  49: "CUT",
  50: "COPY",
  51: "PASTE",
  52: "CLEAR",
  53: "PASTE.SPECIAL",
  54: "EDIT.DELETE",
  55: "INSERT",
  56: "FILL.RIGHT",
  57: "FILL.DOWN",
  61: "DEFINE.NAME",
  62: "CREATE.NAMES",
  63: "FORMULA.GOTO",
  64: "FORMULA.FIND",
  65: "SELECT.LAST.CELL",
  66: "SHOW.ACTIVE.CELL",
  67: "GALLERY.AREA",
  68: "GALLERY.BAR",
  69: "GALLERY.COLUMN",
  70: "GALLERY.LINE",
  71: "GALLERY.PIE",
  72: "GALLERY.SCATTER",
  73: "COMBINATION",
  74: "PREFERRED",
  75: "ADD.OVERLAY",
  76: "GRIDLINES",
  77: "SET.PREFERRED",
  78: "AXES",
  79: "LEGEND",
  80: "ATTACH.TEXT",
  81: "ADD.ARROW",
  82: "SELECT.CHART",
  83: "SELECT.PLOT.AREA",
  84: "PATTERNS",
  85: "MAIN.CHART",
  86: "OVERLAY",
  87: "SCALE",
  88: "FORMAT.LEGEND",
  89: "FORMAT.TEXT",
  90: "EDIT.REPEAT",
  91: "PARSE",
  92: "JUSTIFY",
  93: "HIDE",
  94: "UNHIDE",
  95: "WORKSPACE",
  96: "FORMULA",
  97: "FORMULA.FILL",
  98: "FORMULA.ARRAY",
  99: "DATA.FIND.NEXT",
  100: "DATA.FIND.PREV",
  101: "FORMULA.FIND.NEXT",
  102: "FORMULA.FIND.PREV",
  103: "ACTIVATE",
  104: "ACTIVATE.NEXT",
  105: "ACTIVATE.PREV",
  106: "UNLOCKED.NEXT",
  107: "UNLOCKED.PREV",
  108: "COPY.PICTURE",
  109: "SELECT",
  110: "DELETE.NAME",
  111: "DELETE.FORMAT",
  112: "VLINE",
  113: "HLINE",
  114: "VPAGE",
  115: "HPAGE",
  116: "VSCROLL",
  117: "HSCROLL",
  118: "ALERT",
  119: "NEW",
  120: "CANCEL.COPY",
  121: "SHOW.CLIPBOARD",
  122: "MESSAGE",
  124: "PASTE.LINK",
  125: "APP.ACTIVATE",
  126: "DELETE.ARROW",
  127: "ROW.HEIGHT",
  128: "FORMAT.MOVE",
  129: "FORMAT.SIZE",
  130: "FORMULA.REPLACE",
  131: "SEND.KEYS",
  132: "SELECT.SPECIAL",
  133: "APPLY.NAMES",
  134: "REPLACE.FONT",
  135: "FREEZE.PANES",
  136: "SHOW.INFO",
  137: "SPLIT",
  138: "ON.WINDOW",
  139: "ON.DATA",
  140: "DISABLE.INPUT",
  142: "OUTLINE",
  143: "LIST.NAMES",
  144: "FILE.CLOSE",
  145: "SAVE.WORKBOOK",
  146: "DATA.FORM",
  147: "COPY.CHART",
  148: "ON.TIME",
  149: "WAIT",
  150: "FORMAT.FONT",
  151: "FILL.UP",
  152: "FILL.LEFT",
  153: "DELETE.OVERLAY",
  155: "SHORT.MENUS",
  159: "SET.UPDATE.STATUS",
  161: "COLOR.PALETTE",
  162: "DELETE.STYLE",
  163: "WINDOW.RESTORE",
  164: "WINDOW.MAXIMIZE",
  166: "CHANGE.LINK",
  167: "CALCULATE.DOCUMENT",
  168: "ON.KEY",
  169: "APP.RESTORE",
  170: "APP.MOVE",
  171: "APP.SIZE",
  172: "APP.MINIMIZE",
  173: "APP.MAXIMIZE",
  174: "BRING.TO.FRONT",
  175: "SEND.TO.BACK",
  185: "MAIN.CHART.TYPE",
  186: "OVERLAY.CHART.TYPE",
  187: "SELECT.END",
  188: "OPEN.MAIL",
  189: "SEND.MAIL",
  190: "STANDARD.FONT",
  191: "CONSOLIDATE",
  192: "SORT.SPECIAL",
  193: "GALLERY.3D.AREA",
  194: "GALLERY.3D.COLUMN",
  195: "GALLERY.3D.LINE",
  196: "GALLERY.3D.PIE",
  197: "VIEW.3D",
  198: "GOAL.SEEK",
  199: "WORKGROUP",
  200: "FILL.GROUP",
  201: "UPDATE.LINK",
  202: "PROMOTE",
  203: "DEMOTE",
  204: "SHOW.DETAIL",
  206: "UNGROUP",
  207: "OBJECT.PROPERTIES",
  208: "SAVE.NEW.OBJECT",
  209: "SHARE",
  210: "SHARE.NAME",
  211: "DUPLICATE",
  212: "APPLY.STYLE",
  213: "ASSIGN.TO.OBJECT",
  214: "OBJECT.PROTECTION",
  215: "HIDE.OBJECT",
  216: "SET.EXTRACT",
  217: "CREATE.PUBLISHER",
  218: "SUBSCRIBE.TO",
  219: "ATTRIBUTES",
  220: "SHOW.TOOLBAR",
  222: "PRINT.PREVIEW",
  223: "EDIT.COLOR",
  224: "SHOW.LEVELS",
  225: "FORMAT.MAIN",
  226: "FORMAT.OVERLAY",
  227: "ON.RECALC",
  228: "EDIT.SERIES",
  229: "DEFINE.STYLE",
  240: "LINE.PRINT",
  243: "ENTER.DATA",
  249: "GALLERY.RADAR",
  250: "MERGE.STYLES",
  251: "EDITION.OPTIONS",
  252: "PASTE.PICTURE",
  253: "PASTE.PICTURE.LINK",
  254: "SPELLING",
  256: "ZOOM",
  259: "INSERT.OBJECT",
  260: "WINDOW.MINIMIZE",
  265: "SOUND.NOTE",
  266: "SOUND.PLAY",
  267: "FORMAT.SHAPE",
  268: "EXTEND.POLYGON",
  269: "FORMAT.AUTO",
  272: "GALLERY.3D.BAR",
  273: "GALLERY.3D.SURFACE",
  274: "FILL.AUTO",
  276: "CUSTOMIZE.TOOLBAR",
  277: "ADD.TOOL",
  278: "EDIT.OBJECT",
  279: "ON.DOUBLECLICK",
  280: "ON.ENTRY",
  281: "WORKBOOK.ADD",
  282: "WORKBOOK.MOVE",
  283: "WORKBOOK.COPY",
  284: "WORKBOOK.OPTIONS",
  285: "SAVE.WORKSPACE",
  288: "CHART.WIZARD",
  289: "DELETE.TOOL",
  290: "MOVE.TOOL",
  291: "WORKBOOK.SELECT",
  292: "WORKBOOK.ACTIVATE",
  293: "ASSIGN.TO.TOOL",
  295: "COPY.TOOL",
  296: "RESET.TOOL",
  297: "CONSTRAIN.NUMERIC",
  298: "PASTE.TOOL",
  302: "WORKBOOK.NEW",
  305: "SCENARIO.CELLS",
  306: "SCENARIO.DELETE",
  307: "SCENARIO.ADD",
  308: "SCENARIO.EDIT",
  309: "SCENARIO.SHOW",
  310: "SCENARIO.SHOW.NEXT",
  311: "SCENARIO.SUMMARY",
  312: "PIVOT.TABLE.WIZARD",
  313: "PIVOT.FIELD.PROPERTIES",
  314: "PIVOT.FIELD",
  315: "PIVOT.ITEM",
  316: "PIVOT.ADD.FIELDS",
  318: "OPTIONS.CALCULATION",
  319: "OPTIONS.EDIT",
  320: "OPTIONS.VIEW",
  321: "ADDIN.MANAGER",
  322: "MENU.EDITOR",
  323: "ATTACH.TOOLBARS",
  324: "VBAActivate",
  325: "OPTIONS.CHART",
  328: "VBA.INSERT.FILE",
  330: "VBA.PROCEDURE.DEFINITION",
  336: "ROUTING.SLIP",
  338: "ROUTE.DOCUMENT",
  339: "MAIL.LOGON",
  342: "INSERT.PICTURE",
  343: "EDIT.TOOL",
  344: "GALLERY.DOUGHNUT",
  350: "CHART.TREND",
  352: "PIVOT.ITEM.PROPERTIES",
  354: "WORKBOOK.INSERT",
  355: "OPTIONS.TRANSITION",
  356: "OPTIONS.GENERAL",
  370: "FILTER.ADVANCED",
  373: "MAIL.ADD.MAILER",
  374: "MAIL.DELETE.MAILER",
  375: "MAIL.REPLY",
  376: "MAIL.REPLY.ALL",
  377: "MAIL.FORWARD",
  378: "MAIL.NEXT.LETTER",
  379: "DATA.LABEL",
  380: "INSERT.TITLE",
  381: "FONT.PROPERTIES",
  382: "MACRO.OPTIONS",
  383: "WORKBOOK.HIDE",
  384: "WORKBOOK.UNHIDE",
  385: "WORKBOOK.DELETE",
  386: "WORKBOOK.NAME",
  388: "GALLERY.CUSTOM",
  390: "ADD.CHART.AUTOFORMAT",
  391: "DELETE.CHART.AUTOFORMAT",
  392: "CHART.ADD.DATA",
  393: "AUTO.OUTLINE",
  394: "TAB.ORDER",
  395: "SHOW.DIALOG",
  396: "SELECT.ALL",
  397: "UNGROUP.SHEETS",
  398: "SUBTOTAL.CREATE",
  399: "SUBTOTAL.REMOVE",
  400: "RENAME.OBJECT",
  412: "WORKBOOK.SCROLL",
  413: "WORKBOOK.NEXT",
  414: "WORKBOOK.PREV",
  415: "WORKBOOK.TAB.SPLIT",
  416: "FULL.SCREEN",
  417: "WORKBOOK.PROTECT",
  420: "SCROLLBAR.PROPERTIES",
  421: "PIVOT.SHOW.PAGES",
  422: "TEXT.TO.COLUMNS",
  423: "FORMAT.CHARTTYPE",
  424: "LINK.FORMAT",
  425: "TRACER.DISPLAY",
  430: "TRACER.NAVIGATE",
  431: "TRACER.CLEAR",
  432: "TRACER.ERROR",
  433: "PIVOT.FIELD.GROUP",
  434: "PIVOT.FIELD.UNGROUP",
  435: "CHECKBOX.PROPERTIES",
  436: "LABEL.PROPERTIES",
  437: "LISTBOX.PROPERTIES",
  438: "EDITBOX.PROPERTIES",
  439: "PIVOT.REFRESH",
  440: "LINK.COMBO",
  441: "OPEN.TEXT",
  442: "HIDE.DIALOG",
  443: "SET.DIALOG.FOCUS",
  444: "ENABLE.OBJECT",
  445: "PUSHBUTTON.PROPERTIES",
  446: "SET.DIALOG.DEFAULT",
  447: "FILTER",
  448: "FILTER.SHOW.ALL",
  449: "CLEAR.OUTLINE",
  450: "FUNCTION.WIZARD",
  451: "ADD.LIST.ITEM",
  452: "SET.LIST.ITEM",
  453: "REMOVE.LIST.ITEM",
  454: "SELECT.LIST.ITEM",
  455: "SET.CONTROL.VALUE",
  456: "SAVE.COPY.AS",
  458: "OPTIONS.LISTS.ADD",
  459: "OPTIONS.LISTS.DELETE",
  460: "SERIES.AXES",
  461: "SERIES.X",
  462: "SERIES.Y",
  463: "ERRORBAR.X",
  464: "ERRORBAR.Y",
  465: "FORMAT.CHART",
  466: "SERIES.ORDER",
  467: "MAIL.LOGOFF",
  468: "CLEAR.ROUTING.SLIP",
  469: "APP.ACTIVATE.MICROSOFT",
  470: "MAIL.EDIT.MAILER",
  471: "ON.SHEET",
  472: "STANDARD.WIDTH",
  473: "SCENARIO.MERGE",
  474: "SUMMARY.INFO",
  475: "FIND.FILE",
  476: "ACTIVE.CELL.FONT",
  477: "ENABLE.TIPWIZARD",
  478: "VBA.MAKE.ADDIN",
  480: "INSERTDATATABLE",
  481: "WORKGROUP.OPTIONS",
  482: "MAIL.SEND.MAILER",
  485: "AUTOCORRECT",
  489: "POST.DOCUMENT",
  491: "PICKLIST",
  493: "VIEW.SHOW",
  494: "VIEW.DEFINE",
  495: "VIEW.DELETE",
  509: "SHEET.BACKGROUND",
  510: "INSERT.MAP.OBJECT",
  511: "OPTIONS.MENONO",
  517: "MSOCHECKS",
  518: "NORMAL",
  519: "LAYOUT",
  520: "RM.PRINT.AREA",
  521: "CLEAR.PRINT.AREA",
  522: "ADD.PRINT.AREA",
  523: "MOVE.BRK",
  545: "HIDECURR.NOTE",
  546: "HIDEALL.NOTES",
  547: "DELETE.NOTE",
  548: "TRAVERSE.NOTES",
  549: "ACTIVATE.NOTES",
  620: "PROTECT.REVISIONS",
  621: "UNPROTECT.REVISIONS",
  647: "OPTIONS.ME",
  653: "WEB.PUBLISH",
  667: "NEWWEBQUERY",
  673: "PIVOT.TABLE.CHART",
  753: "OPTIONS.SAVE",
  755: "OPTIONS.SPELL",
  808: "HIDEALL.INKANNOTS"
}, ts = {
  0: "COUNT",
  1: "IF",
  2: "ISNA",
  3: "ISERROR",
  4: "SUM",
  5: "AVERAGE",
  6: "MIN",
  7: "MAX",
  8: "ROW",
  9: "COLUMN",
  10: "NA",
  11: "NPV",
  12: "STDEV",
  13: "DOLLAR",
  14: "FIXED",
  15: "SIN",
  16: "COS",
  17: "TAN",
  18: "ATAN",
  19: "PI",
  20: "SQRT",
  21: "EXP",
  22: "LN",
  23: "LOG10",
  24: "ABS",
  25: "INT",
  26: "SIGN",
  27: "ROUND",
  28: "LOOKUP",
  29: "INDEX",
  30: "REPT",
  31: "MID",
  32: "LEN",
  33: "VALUE",
  34: "TRUE",
  35: "FALSE",
  36: "AND",
  37: "OR",
  38: "NOT",
  39: "MOD",
  40: "DCOUNT",
  41: "DSUM",
  42: "DAVERAGE",
  43: "DMIN",
  44: "DMAX",
  45: "DSTDEV",
  46: "VAR",
  47: "DVAR",
  48: "TEXT",
  49: "LINEST",
  50: "TREND",
  51: "LOGEST",
  52: "GROWTH",
  53: "GOTO",
  54: "HALT",
  55: "RETURN",
  56: "PV",
  57: "FV",
  58: "NPER",
  59: "PMT",
  60: "RATE",
  61: "MIRR",
  62: "IRR",
  63: "RAND",
  64: "MATCH",
  65: "DATE",
  66: "TIME",
  67: "DAY",
  68: "MONTH",
  69: "YEAR",
  70: "WEEKDAY",
  71: "HOUR",
  72: "MINUTE",
  73: "SECOND",
  74: "NOW",
  75: "AREAS",
  76: "ROWS",
  77: "COLUMNS",
  78: "OFFSET",
  79: "ABSREF",
  80: "RELREF",
  81: "ARGUMENT",
  82: "SEARCH",
  83: "TRANSPOSE",
  84: "ERROR",
  85: "STEP",
  86: "TYPE",
  87: "ECHO",
  88: "SET.NAME",
  89: "CALLER",
  90: "DEREF",
  91: "WINDOWS",
  92: "SERIES",
  93: "DOCUMENTS",
  94: "ACTIVE.CELL",
  95: "SELECTION",
  96: "RESULT",
  97: "ATAN2",
  98: "ASIN",
  99: "ACOS",
  100: "CHOOSE",
  101: "HLOOKUP",
  102: "VLOOKUP",
  103: "LINKS",
  104: "INPUT",
  105: "ISREF",
  106: "GET.FORMULA",
  107: "GET.NAME",
  108: "SET.VALUE",
  109: "LOG",
  110: "EXEC",
  111: "CHAR",
  112: "LOWER",
  113: "UPPER",
  114: "PROPER",
  115: "LEFT",
  116: "RIGHT",
  117: "EXACT",
  118: "TRIM",
  119: "REPLACE",
  120: "SUBSTITUTE",
  121: "CODE",
  122: "NAMES",
  123: "DIRECTORY",
  124: "FIND",
  125: "CELL",
  126: "ISERR",
  127: "ISTEXT",
  128: "ISNUMBER",
  129: "ISBLANK",
  130: "T",
  131: "N",
  132: "FOPEN",
  133: "FCLOSE",
  134: "FSIZE",
  135: "FREADLN",
  136: "FREAD",
  137: "FWRITELN",
  138: "FWRITE",
  139: "FPOS",
  140: "DATEVALUE",
  141: "TIMEVALUE",
  142: "SLN",
  143: "SYD",
  144: "DDB",
  145: "GET.DEF",
  146: "REFTEXT",
  147: "TEXTREF",
  148: "INDIRECT",
  149: "REGISTER",
  150: "CALL",
  151: "ADD.BAR",
  152: "ADD.MENU",
  153: "ADD.COMMAND",
  154: "ENABLE.COMMAND",
  155: "CHECK.COMMAND",
  156: "RENAME.COMMAND",
  157: "SHOW.BAR",
  158: "DELETE.MENU",
  159: "DELETE.COMMAND",
  160: "GET.CHART.ITEM",
  161: "DIALOG.BOX",
  162: "CLEAN",
  163: "MDETERM",
  164: "MINVERSE",
  165: "MMULT",
  166: "FILES",
  167: "IPMT",
  168: "PPMT",
  169: "COUNTA",
  170: "CANCEL.KEY",
  171: "FOR",
  172: "WHILE",
  173: "BREAK",
  174: "NEXT",
  175: "INITIATE",
  176: "REQUEST",
  177: "POKE",
  178: "EXECUTE",
  179: "TERMINATE",
  180: "RESTART",
  181: "HELP",
  182: "GET.BAR",
  183: "PRODUCT",
  184: "FACT",
  185: "GET.CELL",
  186: "GET.WORKSPACE",
  187: "GET.WINDOW",
  188: "GET.DOCUMENT",
  189: "DPRODUCT",
  190: "ISNONTEXT",
  191: "GET.NOTE",
  192: "NOTE",
  193: "STDEVP",
  194: "VARP",
  195: "DSTDEVP",
  196: "DVARP",
  197: "TRUNC",
  198: "ISLOGICAL",
  199: "DCOUNTA",
  200: "DELETE.BAR",
  201: "UNREGISTER",
  204: "USDOLLAR",
  205: "FINDB",
  206: "SEARCHB",
  207: "REPLACEB",
  208: "LEFTB",
  209: "RIGHTB",
  210: "MIDB",
  211: "LENB",
  212: "ROUNDUP",
  213: "ROUNDDOWN",
  214: "ASC",
  215: "DBCS",
  216: "RANK",
  219: "ADDRESS",
  220: "DAYS360",
  221: "TODAY",
  222: "VDB",
  223: "ELSE",
  224: "ELSE.IF",
  225: "END.IF",
  226: "FOR.CELL",
  227: "MEDIAN",
  228: "SUMPRODUCT",
  229: "SINH",
  230: "COSH",
  231: "TANH",
  232: "ASINH",
  233: "ACOSH",
  234: "ATANH",
  235: "DGET",
  236: "CREATE.OBJECT",
  237: "VOLATILE",
  238: "LAST.ERROR",
  239: "CUSTOM.UNDO",
  240: "CUSTOM.REPEAT",
  241: "FORMULA.CONVERT",
  242: "GET.LINK.INFO",
  243: "TEXT.BOX",
  244: "INFO",
  245: "GROUP",
  246: "GET.OBJECT",
  247: "DB",
  248: "PAUSE",
  251: "RESUME",
  252: "FREQUENCY",
  253: "ADD.TOOLBAR",
  254: "DELETE.TOOLBAR",
  255: "User",
  256: "RESET.TOOLBAR",
  257: "EVALUATE",
  258: "GET.TOOLBAR",
  259: "GET.TOOL",
  260: "SPELLING.CHECK",
  261: "ERROR.TYPE",
  262: "APP.TITLE",
  263: "WINDOW.TITLE",
  264: "SAVE.TOOLBAR",
  265: "ENABLE.TOOL",
  266: "PRESS.TOOL",
  267: "REGISTER.ID",
  268: "GET.WORKBOOK",
  269: "AVEDEV",
  270: "BETADIST",
  271: "GAMMALN",
  272: "BETAINV",
  273: "BINOMDIST",
  274: "CHIDIST",
  275: "CHIINV",
  276: "COMBIN",
  277: "CONFIDENCE",
  278: "CRITBINOM",
  279: "EVEN",
  280: "EXPONDIST",
  281: "FDIST",
  282: "FINV",
  283: "FISHER",
  284: "FISHERINV",
  285: "FLOOR",
  286: "GAMMADIST",
  287: "GAMMAINV",
  288: "CEILING",
  289: "HYPGEOMDIST",
  290: "LOGNORMDIST",
  291: "LOGINV",
  292: "NEGBINOMDIST",
  293: "NORMDIST",
  294: "NORMSDIST",
  295: "NORMINV",
  296: "NORMSINV",
  297: "STANDARDIZE",
  298: "ODD",
  299: "PERMUT",
  300: "POISSON",
  301: "TDIST",
  302: "WEIBULL",
  303: "SUMXMY2",
  304: "SUMX2MY2",
  305: "SUMX2PY2",
  306: "CHITEST",
  307: "CORREL",
  308: "COVAR",
  309: "FORECAST",
  310: "FTEST",
  311: "INTERCEPT",
  312: "PEARSON",
  313: "RSQ",
  314: "STEYX",
  315: "SLOPE",
  316: "TTEST",
  317: "PROB",
  318: "DEVSQ",
  319: "GEOMEAN",
  320: "HARMEAN",
  321: "SUMSQ",
  322: "KURT",
  323: "SKEW",
  324: "ZTEST",
  325: "LARGE",
  326: "SMALL",
  327: "QUARTILE",
  328: "PERCENTILE",
  329: "PERCENTRANK",
  330: "MODE",
  331: "TRIMMEAN",
  332: "TINV",
  334: "MOVIE.COMMAND",
  335: "GET.MOVIE",
  336: "CONCATENATE",
  337: "POWER",
  338: "PIVOT.ADD.DATA",
  339: "GET.PIVOT.TABLE",
  340: "GET.PIVOT.FIELD",
  341: "GET.PIVOT.ITEM",
  342: "RADIANS",
  343: "DEGREES",
  344: "SUBTOTAL",
  345: "SUMIF",
  346: "COUNTIF",
  347: "COUNTBLANK",
  348: "SCENARIO.GET",
  349: "OPTIONS.LISTS.GET",
  350: "ISPMT",
  351: "DATEDIF",
  352: "DATESTRING",
  353: "NUMBERSTRING",
  354: "ROMAN",
  355: "OPEN.DIALOG",
  356: "SAVE.DIALOG",
  357: "VIEW.GET",
  358: "GETPIVOTDATA",
  359: "HYPERLINK",
  360: "PHONETIC",
  361: "AVERAGEA",
  362: "MAXA",
  363: "MINA",
  364: "STDEVPA",
  365: "VARPA",
  366: "STDEVA",
  367: "VARA",
  368: "BAHTTEXT",
  369: "THAIDAYOFWEEK",
  370: "THAIDIGIT",
  371: "THAIMONTHOFYEAR",
  372: "THAINUMSOUND",
  373: "THAINUMSTRING",
  374: "THAISTRINGLENGTH",
  375: "ISTHAIDIGIT",
  376: "ROUNDBAHTDOWN",
  377: "ROUNDBAHTUP",
  378: "THAIYEAR",
  379: "RTD",
  380: "CUBEVALUE",
  381: "CUBEMEMBER",
  382: "CUBEMEMBERPROPERTY",
  383: "CUBERANKEDMEMBER",
  384: "HEX2BIN",
  385: "HEX2DEC",
  386: "HEX2OCT",
  387: "DEC2BIN",
  388: "DEC2HEX",
  389: "DEC2OCT",
  390: "OCT2BIN",
  391: "OCT2HEX",
  392: "OCT2DEC",
  393: "BIN2DEC",
  394: "BIN2OCT",
  395: "BIN2HEX",
  396: "IMSUB",
  397: "IMDIV",
  398: "IMPOWER",
  399: "IMABS",
  400: "IMSQRT",
  401: "IMLN",
  402: "IMLOG2",
  403: "IMLOG10",
  404: "IMSIN",
  405: "IMCOS",
  406: "IMEXP",
  407: "IMARGUMENT",
  408: "IMCONJUGATE",
  409: "IMAGINARY",
  410: "IMREAL",
  411: "COMPLEX",
  412: "IMSUM",
  413: "IMPRODUCT",
  414: "SERIESSUM",
  415: "FACTDOUBLE",
  416: "SQRTPI",
  417: "QUOTIENT",
  418: "DELTA",
  419: "GESTEP",
  420: "ISEVEN",
  421: "ISODD",
  422: "MROUND",
  423: "ERF",
  424: "ERFC",
  425: "BESSELJ",
  426: "BESSELK",
  427: "BESSELY",
  428: "BESSELI",
  429: "XIRR",
  430: "XNPV",
  431: "PRICEMAT",
  432: "YIELDMAT",
  433: "INTRATE",
  434: "RECEIVED",
  435: "DISC",
  436: "PRICEDISC",
  437: "YIELDDISC",
  438: "TBILLEQ",
  439: "TBILLPRICE",
  440: "TBILLYIELD",
  441: "PRICE",
  442: "YIELD",
  443: "DOLLARDE",
  444: "DOLLARFR",
  445: "NOMINAL",
  446: "EFFECT",
  447: "CUMPRINC",
  448: "CUMIPMT",
  449: "EDATE",
  450: "EOMONTH",
  451: "YEARFRAC",
  452: "COUPDAYBS",
  453: "COUPDAYS",
  454: "COUPDAYSNC",
  455: "COUPNCD",
  456: "COUPNUM",
  457: "COUPPCD",
  458: "DURATION",
  459: "MDURATION",
  460: "ODDLPRICE",
  461: "ODDLYIELD",
  462: "ODDFPRICE",
  463: "ODDFYIELD",
  464: "RANDBETWEEN",
  465: "WEEKNUM",
  466: "AMORDEGRC",
  467: "AMORLINC",
  468: "CONVERT",
  724: "SHEETJS",
  469: "ACCRINT",
  470: "ACCRINTM",
  471: "WORKDAY",
  472: "NETWORKDAYS",
  473: "GCD",
  474: "MULTINOMIAL",
  475: "LCM",
  476: "FVSCHEDULE",
  477: "CUBEKPIMEMBER",
  478: "CUBESET",
  479: "CUBESETCOUNT",
  480: "IFERROR",
  481: "COUNTIFS",
  482: "SUMIFS",
  483: "AVERAGEIF",
  484: "AVERAGEIFS"
}, Eh = {
  2: 1,
  3: 1,
  10: 0,
  15: 1,
  16: 1,
  17: 1,
  18: 1,
  19: 0,
  20: 1,
  21: 1,
  22: 1,
  23: 1,
  24: 1,
  25: 1,
  26: 1,
  27: 2,
  30: 2,
  31: 3,
  32: 1,
  33: 1,
  34: 0,
  35: 0,
  38: 1,
  39: 2,
  40: 3,
  41: 3,
  42: 3,
  43: 3,
  44: 3,
  45: 3,
  47: 3,
  48: 2,
  53: 1,
  61: 3,
  63: 0,
  65: 3,
  66: 3,
  67: 1,
  68: 1,
  69: 1,
  70: 1,
  71: 1,
  72: 1,
  73: 1,
  74: 0,
  75: 1,
  76: 1,
  77: 1,
  79: 2,
  80: 2,
  83: 1,
  85: 0,
  86: 1,
  89: 0,
  90: 1,
  94: 0,
  95: 0,
  97: 2,
  98: 1,
  99: 1,
  101: 3,
  102: 3,
  105: 1,
  106: 1,
  108: 2,
  111: 1,
  112: 1,
  113: 1,
  114: 1,
  117: 2,
  118: 1,
  119: 4,
  121: 1,
  126: 1,
  127: 1,
  128: 1,
  129: 1,
  130: 1,
  131: 1,
  133: 1,
  134: 1,
  135: 1,
  136: 2,
  137: 2,
  138: 2,
  140: 1,
  141: 1,
  142: 3,
  143: 4,
  144: 4,
  161: 1,
  162: 1,
  163: 1,
  164: 1,
  165: 2,
  172: 1,
  175: 2,
  176: 2,
  177: 3,
  178: 2,
  179: 1,
  184: 1,
  186: 1,
  189: 3,
  190: 1,
  195: 3,
  196: 3,
  197: 1,
  198: 1,
  199: 3,
  201: 1,
  207: 4,
  210: 3,
  211: 1,
  212: 2,
  213: 2,
  214: 1,
  215: 1,
  225: 0,
  229: 1,
  230: 1,
  231: 1,
  232: 1,
  233: 1,
  234: 1,
  235: 3,
  244: 1,
  247: 4,
  252: 2,
  257: 1,
  261: 1,
  271: 1,
  273: 4,
  274: 2,
  275: 2,
  276: 2,
  277: 3,
  278: 3,
  279: 1,
  280: 3,
  281: 3,
  282: 3,
  283: 1,
  284: 1,
  285: 2,
  286: 4,
  287: 3,
  288: 2,
  289: 4,
  290: 3,
  291: 3,
  292: 3,
  293: 4,
  294: 1,
  295: 3,
  296: 1,
  297: 3,
  298: 1,
  299: 2,
  300: 3,
  301: 3,
  302: 4,
  303: 2,
  304: 2,
  305: 2,
  306: 2,
  307: 2,
  308: 2,
  309: 3,
  310: 2,
  311: 2,
  312: 2,
  313: 2,
  314: 2,
  315: 2,
  316: 4,
  325: 2,
  326: 2,
  327: 2,
  328: 2,
  331: 2,
  332: 2,
  337: 2,
  342: 1,
  343: 1,
  346: 2,
  347: 1,
  350: 4,
  351: 3,
  352: 1,
  353: 2,
  360: 1,
  368: 1,
  369: 1,
  370: 1,
  371: 1,
  372: 1,
  373: 1,
  374: 1,
  375: 1,
  376: 1,
  377: 1,
  378: 1,
  382: 3,
  385: 1,
  392: 1,
  393: 1,
  396: 2,
  397: 2,
  398: 2,
  399: 1,
  400: 1,
  401: 1,
  402: 1,
  403: 1,
  404: 1,
  405: 1,
  406: 1,
  407: 1,
  408: 1,
  409: 1,
  410: 1,
  414: 4,
  415: 1,
  416: 1,
  417: 2,
  420: 1,
  421: 1,
  422: 2,
  424: 1,
  425: 2,
  426: 2,
  427: 2,
  428: 2,
  430: 3,
  438: 3,
  439: 3,
  440: 3,
  443: 2,
  444: 2,
  445: 2,
  446: 2,
  447: 6,
  448: 6,
  449: 2,
  450: 2,
  464: 2,
  468: 3,
  476: 2,
  479: 1,
  480: 2,
  65535: 0
};
function Nn(e) {
  return e.slice(0, 3) == "of:" && (e = e.slice(3)), e.charCodeAt(0) == 61 && (e = e.slice(1), e.charCodeAt(0) == 61 && (e = e.slice(1))), e = e.replace(/COM\.MICROSOFT\./g, ""), e = e.replace(/\[((?:\.[A-Z]+[0-9]+)(?::\.[A-Z]+[0-9]+)?)\]/g, function(a, r) {
    return r.replace(/\./g, "");
  }), e = e.replace(/\$'([^']|'')+'/g, function(a) {
    return a.slice(1);
  }), e = e.replace(/\$([^\]\. #$]+)/g, function(a, r) {
    return r.match(/^([A-Z]{1,2}|[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D])?(10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5})?$/) ? a : r;
  }), e = e.replace(/\[.(#[A-Z]*[?!])\]/g, "$1"), e.replace(/[;~]/g, ",").replace(/\|/g, ";");
}
function a0(e) {
  e = e.replace(/\$'([^']|'')+'/g, function(t) {
    return t.slice(1);
  }), e = e.replace(/\$([^\]\. #$]+)/g, function(t, n) {
    return n.match(/^([A-Z]{1,2}|[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D])?(10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5})?$/) ? t : n;
  });
  var a = e.split(":"), r = a[0].split(".")[0];
  return [r, a[0].split(".")[1] + (a.length > 1 ? ":" + (a[1].split(".")[1] || a[1].split(".")[0]) : "")];
}
var Ja = {}, Ra = {};
function Za(e, a) {
  if (e) {
    var r = [0.7, 0.7, 0.75, 0.75, 0.3, 0.3];
    a == "xlml" && (r = [1, 1, 1, 1, 0.5, 0.5]), e.left == null && (e.left = r[0]), e.right == null && (e.right = r[1]), e.top == null && (e.top = r[2]), e.bottom == null && (e.bottom = r[3]), e.header == null && (e.header = r[4]), e.footer == null && (e.footer = r[5]);
  }
}
function ns(e, a, r, t, n, i, f) {
  try {
    t.cellNF && (e.z = ge[a]);
  } catch (c) {
    if (t.WTF) throw c;
  }
  if (!(e.t === "z" && !t.cellStyles)) {
    if (e.t === "d" && typeof e.v == "string" && (e.v = cr(e.v)), (!t || t.cellText !== !1) && e.t !== "z") try {
      if (ge[a] == null && va(uf[a] || "General", a), e.t === "e") e.w = e.w || Ar[e.v];
      else if (a === 0)
        if (e.t === "n")
          (e.v | 0) === e.v ? e.w = e.v.toString(10) : e.w = at(e.v);
        else if (e.t === "d") {
          var s = ar(e.v, !!f);
          (s | 0) === s ? e.w = s.toString(10) : e.w = at(s);
        } else {
          if (e.v === void 0) return "";
          e.w = _a(e.v, Ra);
        }
      else e.t === "d" ? e.w = Fr(a, ar(e.v, !!f), Ra) : e.w = Fr(a, e.v, Ra);
    } catch (c) {
      if (t.WTF) throw c;
    }
    if (t.cellStyles && r != null)
      try {
        e.s = i.Fills[r], e.s.fgColor && e.s.fgColor.theme && !e.s.fgColor.rgb && (e.s.fgColor.rgb = bt(n.themeElements.clrScheme[e.s.fgColor.theme].rgb, e.s.fgColor.tint || 0), t.WTF && (e.s.fgColor.raw_rgb = n.themeElements.clrScheme[e.s.fgColor.theme].rgb)), e.s.bgColor && e.s.bgColor.theme && (e.s.bgColor.rgb = bt(n.themeElements.clrScheme[e.s.bgColor.theme].rgb, e.s.bgColor.tint || 0), t.WTF && (e.s.bgColor.raw_rgb = n.themeElements.clrScheme[e.s.bgColor.theme].rgb));
      } catch (c) {
        if (t.WTF && i.Fills) throw c;
      }
  }
}
function Th(e, a) {
  var r = Ke(a);
  r.s.r <= r.e.r && r.s.c <= r.e.c && r.s.r >= 0 && r.s.c >= 0 && (e["!ref"] = ye(r));
}
var wh = /<(?:\w+:)?mergeCell ref=["'][A-Z0-9:]+['"]\s*[\/]?>/g, Fh = /<(?:\w+:)?hyperlink [^<>]*>/mg, Ah = /"(\w*:\w*)"/, Sh = /<(?:\w+:)?col\b[^<>]*[\/]?>/g, Ch = /<(?:\w+:)?autoFilter[^>]*/g, yh = /<(?:\w+:)?pageMargins[^<>]*\/>/g, is = /<(?:\w+:)?sheetPr\b[^<>]*?\/>/;
function Dh(e, a, r, t, n, i, f) {
  if (!e) return e;
  t || (t = { "!id": {} });
  var s = {};
  a.dense && (s["!data"] = []);
  var c = { s: { r: 2e6, c: 2e6 }, e: { r: 0, c: 0 } }, o = "", l = "", v = ir(e, "sheetData");
  v ? (o = e.slice(0, v.index), l = e.slice(v.index + v[0].length)) : o = l = e;
  var d = o.match(is);
  d ? N0(d[0], s, n, r) : (d = ir(o, "sheetPr")) && Ih(d[0], d[1] || "", s, n, r);
  var u = (o.match(/<(?:\w*:)?dimension/) || { index: -1 }).index;
  if (u > 0) {
    var p = o.slice(u, u + 50).match(Ah);
    p && !(a && a.nodim) && Th(s, p[1]);
  }
  var _ = ir(o, "sheetViews");
  _ && _[1] && Lh(_[1], n);
  var x = [];
  if (a.cellStyles) {
    var h = o.match(Sh);
    h && Nh(x, h);
  }
  v && Bh(v[1], s, a, c, i, f, n);
  var E = l.match(Ch);
  E && (s["!autofilter"] = Ph(E[0]));
  var g = [], y = l.match(wh);
  if (y) for (u = 0; u != y.length; ++u)
    g[u] = Ke(y[u].slice(y[u].indexOf("=") + 2));
  var P = l.match(Fh);
  P && Oh(s, P, t);
  var M = l.match(yh);
  M && (s["!margins"] = Rh(le(M[0])));
  var I;
  if ((I = l.match(/legacyDrawing r:id="(.*?)"/)) && (s["!legrel"] = I[1]), a && a.nodim && (c.s.c = c.s.r = 0), !s["!ref"] && c.e.c >= c.s.c && c.e.r >= c.s.r && (s["!ref"] = ye(c)), a.sheetRows > 0 && s["!ref"]) {
    var N = Ke(s["!ref"]);
    a.sheetRows <= +N.e.r && (N.e.r = a.sheetRows - 1, N.e.r > c.e.r && (N.e.r = c.e.r), N.e.r < N.s.r && (N.s.r = N.e.r), N.e.c > c.e.c && (N.e.c = c.e.c), N.e.c < N.s.c && (N.s.c = N.e.c), s["!fullref"] = s["!ref"], s["!ref"] = ye(N));
  }
  return x.length > 0 && (s["!cols"] = x), g.length > 0 && (s["!merges"] = g), t["!id"][s["!legrel"]] && (s["!legdrawel"] = t["!id"][s["!legrel"]]), s;
}
function N0(e, a, r, t) {
  var n = le(e);
  r.Sheets[t] || (r.Sheets[t] = {}), n.codeName && (r.Sheets[t].CodeName = Ce(Ue(n.codeName)));
}
function Ih(e, a, r, t, n) {
  N0(e.slice(0, e.indexOf(">")), r, t, n);
}
function Oh(e, a, r) {
  for (var t = e["!data"] != null, n = 0; n != a.length; ++n) {
    var i = le(Ue(a[n]), !0);
    if (!i.ref) return;
    var f = ((r || {})["!id"] || [])[i.id];
    f ? (i.Target = f.Target, i.location && (i.Target += "#" + Ce(i.location))) : (i.Target = "#" + Ce(i.location), f = { Target: i.Target, TargetMode: "Internal" }), i.Rel = f, i.tooltip && (i.Tooltip = i.tooltip, delete i.tooltip);
    for (var s = Ke(i.ref), c = s.s.r; c <= s.e.r; ++c) for (var o = s.s.c; o <= s.e.c; ++o) {
      var l = Pe(o) + Me(c);
      t ? (e["!data"][c] || (e["!data"][c] = []), e["!data"][c][o] || (e["!data"][c][o] = { t: "z", v: void 0 }), e["!data"][c][o].l = i) : (e[l] || (e[l] = { t: "z", v: void 0 }), e[l].l = i);
    }
  }
}
function Rh(e) {
  var a = {};
  return ["left", "right", "top", "bottom", "header", "footer"].forEach(function(r) {
    e[r] && (a[r] = parseFloat(e[r]));
  }), a;
}
function Nh(e, a) {
  for (var r = !1, t = 0; t != a.length; ++t) {
    var n = le(a[t], !0);
    n.hidden && (n.hidden = Be(n.hidden));
    var i = parseInt(n.min, 10) - 1, f = parseInt(n.max, 10) - 1;
    for (n.outlineLevel && (n.level = +n.outlineLevel || 0), delete n.min, delete n.max, n.width = +n.width, !r && n.width && (r = !0, I0(n.width)), ba(n); i <= f; ) e[i++] = er(n);
  }
}
function Ph(e) {
  var a = { ref: (e.match(/ref="([^"]*)"/) || [])[1] };
  return a;
}
var bh = /<(?:\w:)?sheetView(?:[^<>a-z][^<>]*)?\/?>/g;
function Lh(e, a) {
  a.Views || (a.Views = [{}]), (e.match(bh) || []).forEach(function(r, t) {
    var n = le(r);
    a.Views[t] || (a.Views[t] = {}), +n.zoomScale && (a.Views[t].zoom = +n.zoomScale), n.rightToLeft && Be(n.rightToLeft) && (a.Views[t].RTL = !0);
  });
}
var Bh = /* @__PURE__ */ (function() {
  var e = /<(?:\w+:)?c[ \/>]/, a = /<\/(?:\w+:)?row>/, r = /r=["']([^"']*)["']/, t = /ref=["']([^"']*)["']/;
  return function(i, f, s, c, o, l, v) {
    for (var d = 0, u = "", p = [], _ = [], x = 0, h = 0, E = 0, g = "", y, P, M = 0, I = 0, N, O, B = 0, b = 0, G = Array.isArray(l.CellXf), z, fe = [], j = [], he = f["!data"] != null, J = [], ne = {}, pe = !1, X = !!s.sheetStubs, ke = !!((v || {}).WBProps || {}).date1904, _e = i.split(a), de = 0, ce = _e.length; de != ce; ++de) {
      u = _e[de].trim();
      var Te = u.length;
      if (Te !== 0) {
        var me = 0;
        e: for (d = 0; d < Te; ++d) switch (
          /*x.charCodeAt(ri)*/
          u[d]
        ) {
          case ">":
            if (
              /*x.charCodeAt(ri-1) != 47*/
              u[d - 1] != "/"
            ) {
              ++d;
              break e;
            }
            if (s && s.cellStyles) {
              if (P = le(u.slice(me, d), !0), M = P.r != null ? parseInt(P.r, 10) : M + 1, I = -1, s.sheetRows && s.sheetRows < M) continue;
              ne = {}, pe = !1, P.ht && (pe = !0, ne.hpt = parseFloat(P.ht), ne.hpx = st(ne.hpt)), P.hidden && Be(P.hidden) && (pe = !0, ne.hidden = !0), P.outlineLevel != null && (pe = !0, ne.level = +P.outlineLevel), pe && (J[M - 1] = ne);
            }
            break;
          case "<":
            me = d;
            break;
        }
        if (me >= d) break;
        if (P = le(u.slice(me, d), !0), M = P.r != null ? parseInt(P.r, 10) : M + 1, I = -1, !(s.sheetRows && s.sheetRows < M)) {
          s.nodim || (c.s.r > M - 1 && (c.s.r = M - 1), c.e.r < M - 1 && (c.e.r = M - 1)), s && s.cellStyles && (ne = {}, pe = !1, P.ht && (pe = !0, ne.hpt = parseFloat(P.ht), ne.hpx = st(ne.hpt)), P.hidden && Be(P.hidden) && (pe = !0, ne.hidden = !0), P.outlineLevel != null && (pe = !0, ne.level = +P.outlineLevel), pe && (J[M - 1] = ne)), p = u.slice(d).split(e);
          for (var Fe = 0; Fe != p.length && p[Fe].trim().charAt(0) == "<"; ++Fe) ;
          for (p = p.slice(Fe), d = 0; d != p.length; ++d)
            if (u = p[d].trim(), u.length !== 0) {
              if (_ = u.match(r), x = d, h = 0, E = 0, u = "<c " + (u.slice(0, 1) == "<" ? ">" : "") + u, _ != null && _.length === 2) {
                for (x = 0, g = _[1], h = 0; h != g.length && !((E = g.charCodeAt(h) - 64) < 1 || E > 26); ++h)
                  x = 26 * x + E;
                --x, I = x;
              } else ++I;
              for (h = 0; h != u.length && u.charCodeAt(h) !== 62; ++h) ;
              if (++h, P = le(u.slice(0, h), !0), P.r || (P.r = Ne({ r: M - 1, c: I })), g = u.slice(h), y = { t: "" }, (_ = ir(g, "v")) != null && /*::cref != null && */
              _[1] !== "" && (y.v = Ce(_[1])), s.cellFormula) {
                if ((_ = ir(g, "f")) != null) {
                  if (_[1] == "")
                    /*::cref != null && cref[0] != null && */
                    _[0].indexOf('t="shared"') > -1 && (O = le(_[0]), j[O.si] && (y.f = yn(j[O.si][1], j[O.si][2], P.r)));
                  else if (y.f = Ce(Ue(_[1]), !0), s.xlfn || (y.f = Dn(y.f)), /*::cref != null && cref[0] != null && */
                  _[0].indexOf('t="array"') > -1)
                    y.F = (g.match(t) || [])[1], y.F.indexOf(":") > -1 && fe.push([Ke(y.F), y.F]);
                  else if (
                    /*::cref != null && cref[0] != null && */
                    _[0].indexOf('t="shared"') > -1
                  ) {
                    O = le(_[0]);
                    var S = Ce(Ue(_[1]));
                    s.xlfn || (S = Dn(S)), j[parseInt(O.si, 10)] = [O, S, P.r];
                  }
                } else (_ = g.match(/<f[^<>]*\/>/)) && (O = le(_[0]), j[O.si] && (y.f = yn(j[O.si][1], j[O.si][2], P.r)));
                var L = dr(P.r);
                for (h = 0; h < fe.length; ++h)
                  L.r >= fe[h][0].s.r && L.r <= fe[h][0].e.r && L.c >= fe[h][0].s.c && L.c <= fe[h][0].e.c && (y.F = fe[h][1]);
              }
              if (P.t == null && y.v === void 0)
                if (y.f || y.F)
                  y.v = 0, y.t = "n";
                else if (X) y.t = "z";
                else continue;
              else y.t = P.t || "n";
              switch (c.s.c > I && (c.s.c = I), c.e.c < I && (c.e.c = I), y.t) {
                case "n":
                  if (y.v == "" || y.v == null) {
                    if (!X) continue;
                    y.t = "z";
                  } else y.v = parseFloat(y.v);
                  break;
                case "s":
                  if (typeof y.v > "u") {
                    if (!X) continue;
                    y.t = "z";
                  } else
                    N = Ja[parseInt(y.v, 10)], y.v = N.t, y.r = N.r, s.cellHTML && (y.h = N.h);
                  break;
                case "str":
                  y.t = "s", y.v = y.v != null ? Ce(Ue(y.v), !0) : "", s.cellHTML && (y.h = Ga(y.v));
                  break;
                case "inlineStr":
                  _ = ir(g, "is"), y.t = "s", _ != null && (N = D0(_[1])) ? (y.v = N.t, s.cellHTML && (y.h = N.h)) : y.v = "";
                  break;
                case "b":
                  y.v = Be(y.v);
                  break;
                case "d":
                  s.cellDates ? y.v = cr(y.v, ke) : (y.v = ar(cr(y.v, ke), ke), y.t = "n");
                  break;
                /* error string in .w, number in .v */
                case "e":
                  (!s || s.cellText !== !1) && (y.w = y.v), y.v = sr[y.v];
                  break;
              }
              if (B = b = 0, z = null, G && P.s !== void 0 && (z = l.CellXf[P.s], z != null && (z.numFmtId != null && (B = z.numFmtId), s.cellStyles && z.fillId != null && (b = z.fillId))), ns(y, B, b, s, o, l, ke), s.cellDates && G && y.t == "n" && Br(ge[B]) && (y.v = ia(y.v + (ke ? 1462 : 0)), y.t = typeof y.v == "number" ? "n" : "d"), P.cm && s.xlmeta) {
                var R = (s.xlmeta.Cell || [])[+P.cm - 1];
                R && R.type == "XLDAPR" && (y.D = !0);
              }
              var D;
              s.nodim && (D = dr(P.r), c.s.r > D.r && (c.s.r = D.r), c.e.r < D.r && (c.e.r = D.r)), he ? (D = dr(P.r), f["!data"][D.r] || (f["!data"][D.r] = []), f["!data"][D.r][D.c] = y) : f[P.r] = y;
            }
        }
      }
    }
    J.length > 0 && (f["!rows"] = J);
  };
})();
function Mh(e, a) {
  var r = {}, t = e.l + a;
  r.r = e.read_shift(4), e.l += 4;
  var n = e.read_shift(2);
  e.l += 1;
  var i = e.read_shift(1);
  return e.l = t, i & 7 && (r.level = i & 7), i & 16 && (r.hidden = !0), i & 32 && (r.hpt = n / 20), r;
}
var Uh = Aa;
function Hh() {
}
function Wh(e, a) {
  var r = {}, t = e[e.l];
  return ++e.l, r.above = !(t & 64), r.left = !(t & 128), e.l += 18, r.name = dc(e), r;
}
function Vh(e) {
  var a = Ur(e);
  return [a];
}
function Gh(e) {
  var a = Fa(e);
  return [a];
}
function Xh(e) {
  var a = Ur(e), r = e.read_shift(1);
  return [a, r, "b"];
}
function zh(e) {
  var a = Fa(e), r = e.read_shift(1);
  return [a, r, "b"];
}
function $h(e) {
  var a = Ur(e), r = e.read_shift(1);
  return [a, r, "e"];
}
function Kh(e) {
  var a = Fa(e), r = e.read_shift(1);
  return [a, r, "e"];
}
function Yh(e) {
  var a = Ur(e), r = e.read_shift(4);
  return [a, r, "s"];
}
function jh(e) {
  var a = Fa(e), r = e.read_shift(4);
  return [a, r, "s"];
}
function Jh(e) {
  var a = Ur(e), r = xr(e);
  return [a, r, "n"];
}
function ss(e) {
  var a = Fa(e), r = xr(e);
  return [a, r, "n"];
}
function Zh(e) {
  var a = Ur(e), r = Gt(e);
  return [a, r, "n"];
}
function qh(e) {
  var a = Fa(e), r = Gt(e);
  return [a, r, "n"];
}
function Qh(e) {
  var a = Ur(e), r = S0(e);
  return [a, r, "is"];
}
function ex(e) {
  var a = Ur(e), r = vr(e);
  return [a, r, "str"];
}
function rx(e) {
  var a = Fa(e), r = vr(e);
  return [a, r, "str"];
}
function ax(e, a, r) {
  var t = e.l + a, n = Ur(e);
  n.r = r["!row"];
  var i = e.read_shift(1), f = [n, i, "b"];
  if (r.cellFormula) {
    e.l += 2;
    var s = $t(e, t - e.l, r);
    f[3] = hr(s, null, n, r.supbooks, r);
  } else e.l = t;
  return f;
}
function tx(e, a, r) {
  var t = e.l + a, n = Ur(e);
  n.r = r["!row"];
  var i = e.read_shift(1), f = [n, i, "e"];
  if (r.cellFormula) {
    e.l += 2;
    var s = $t(e, t - e.l, r);
    f[3] = hr(s, null, n, r.supbooks, r);
  } else e.l = t;
  return f;
}
function nx(e, a, r) {
  var t = e.l + a, n = Ur(e);
  n.r = r["!row"];
  var i = xr(e), f = [n, i, "n"];
  if (r.cellFormula) {
    e.l += 2;
    var s = $t(e, t - e.l, r);
    f[3] = hr(s, null, n, r.supbooks, r);
  } else e.l = t;
  return f;
}
function ix(e, a, r) {
  var t = e.l + a, n = Ur(e);
  n.r = r["!row"];
  var i = vr(e), f = [n, i, "str"];
  if (r.cellFormula) {
    e.l += 2;
    var s = $t(e, t - e.l, r);
    f[3] = hr(s, null, n, r.supbooks, r);
  } else e.l = t;
  return f;
}
var sx = Aa;
function fx(e, a) {
  var r = e.l + a, t = Aa(e), n = Vt(e), i = vr(e), f = vr(e), s = vr(e);
  e.l = r;
  var c = { rfx: t, relId: n, loc: i, display: s };
  return f && (c.Tooltip = f), c;
}
function cx() {
}
function ox(e, a, r) {
  var t = e.l + a, n = Ai(e), i = e.read_shift(1), f = [n];
  if (f[2] = i, r.cellFormula) {
    var s = gh(e, t - e.l, r);
    f[1] = s;
  } else e.l = t;
  return f;
}
function lx(e, a, r) {
  var t = e.l + a, n = Aa(e), i = [n];
  if (r.cellFormula) {
    var f = _h(e, t - e.l, r);
    i[1] = f, e.l = t;
  } else e.l = t;
  return i;
}
var ux = ["left", "right", "top", "bottom", "header", "footer"];
function hx(e) {
  var a = {};
  return ux.forEach(function(r) {
    a[r] = xr(e);
  }), a;
}
function xx(e) {
  var a = e.read_shift(2);
  return e.l += 28, { RTL: a & 32 };
}
function dx() {
}
function vx() {
}
function px(e, a, r, t, n, i, f) {
  if (!e) return e;
  var s = a || {};
  t || (t = { "!id": {} });
  var c = {};
  s.dense && (c["!data"] = []);
  var o, l = { s: { r: 2e6, c: 2e6 }, e: { r: 0, c: 0 } }, v = !1, d = !1, u, p, _, x, h, E, g, y, P, M = [];
  s.biff = 12, s["!row"] = 0;
  var I = 0, N = !1, O = [], B = {}, b = s.supbooks || /*::(*/
  n.supbooks || [[]];
  if (b.sharedf = B, b.arrayf = O, b.SheetNames = n.SheetNames || n.Sheets.map(function(pe) {
    return pe.name;
  }), !s.supbooks && (s.supbooks = b, n.Names))
    for (var G = 0; G < n.Names.length; ++G) b[0][G + 1] = n.Names[G];
  var z = [], fe = [], j = !1;
  Mt[16] = { n: "BrtShortReal", f: ss };
  var he, J = 1462 * +!!((n || {}).WBProps || {}).date1904;
  if (ra(e, function(X, ke, _e) {
    if (!d)
      switch (_e) {
        case 148:
          o = X;
          break;
        case 0:
          u = X, s.sheetRows && s.sheetRows <= u.r && (d = !0), y = Me(x = u.r), s["!row"] = u.r, (X.hidden || X.hpt || X.level != null) && (X.hpt && (X.hpx = st(X.hpt)), fe[X.r] = X);
          break;
        case 2:
        /* 'BrtCellRk' */
        case 3:
        /* 'BrtCellError' */
        case 4:
        /* 'BrtCellBool' */
        case 5:
        /* 'BrtCellReal' */
        case 6:
        /* 'BrtCellSt' */
        case 7:
        /* 'BrtCellIsst' */
        case 8:
        /* 'BrtFmlaString' */
        case 9:
        /* 'BrtFmlaNum' */
        case 10:
        /* 'BrtFmlaBool' */
        case 11:
        /* 'BrtFmlaError' */
        case 13:
        /* 'BrtShortRk' */
        case 14:
        /* 'BrtShortError' */
        case 15:
        /* 'BrtShortBool' */
        case 16:
        /* 'BrtShortReal' */
        case 17:
        /* 'BrtShortSt' */
        case 18:
        /* 'BrtShortIsst' */
        case 62:
          switch (p = { t: X[2] }, X[2]) {
            case "n":
              p.v = X[1];
              break;
            case "s":
              g = Ja[X[1]], p.v = g.t, p.r = g.r;
              break;
            case "b":
              p.v = !!X[1];
              break;
            case "e":
              p.v = X[1], s.cellText !== !1 && (p.w = Ar[p.v]);
              break;
            case "str":
              p.t = "s", p.v = X[1];
              break;
            case "is":
              p.t = "s", p.v = X[1].t;
              break;
          }
          if ((_ = f.CellXf[X[0].iStyleRef]) && ns(p, _.numFmtId, null, s, i, f, J > 0), h = X[0].c == -1 ? h + 1 : X[0].c, s.dense ? (c["!data"][x] || (c["!data"][x] = []), c["!data"][x][h] = p) : c[Pe(h) + y] = p, s.cellFormula) {
            for (N = !1, I = 0; I < O.length; ++I) {
              var de = O[I];
              u.r >= de[0].s.r && u.r <= de[0].e.r && h >= de[0].s.c && h <= de[0].e.c && (p.F = ye(de[0]), N = !0);
            }
            !N && X.length > 3 && (p.f = X[3]);
          }
          if (l.s.r > u.r && (l.s.r = u.r), l.s.c > h && (l.s.c = h), l.e.r < u.r && (l.e.r = u.r), l.e.c < h && (l.e.c = h), s.cellDates && _ && p.t == "n" && Br(ge[_.numFmtId])) {
            var ce = Kr(p.v + J);
            ce && (p.t = "d", p.v = new Date(Date.UTC(ce.y, ce.m - 1, ce.d, ce.H, ce.M, ce.S, ce.u)));
          }
          he && (he.type == "XLDAPR" && (p.D = !0), he = void 0);
          break;
        case 1:
        /* 'BrtCellBlank' */
        case 12:
          if (!s.sheetStubs || v) break;
          p = { t: "z", v: void 0 }, h = X[0].c == -1 ? h + 1 : X[0].c, s.dense ? (c["!data"][x] || (c["!data"][x] = []), c["!data"][x][h] = p) : c[Pe(h) + y] = p, l.s.r > u.r && (l.s.r = u.r), l.s.c > h && (l.s.c = h), l.e.r < u.r && (l.e.r = u.r), l.e.c < h && (l.e.c = h), he && (he.type == "XLDAPR" && (p.D = !0), he = void 0);
          break;
        case 176:
          M.push(X);
          break;
        case 49:
          he = ((s.xlmeta || {}).Cell || [])[X - 1];
          break;
        case 494:
          var Te = t["!id"][X.relId];
          for (Te ? (X.Target = Te.Target, X.loc && (X.Target += "#" + X.loc), X.Rel = Te) : X.relId == "" && (X.Target = "#" + X.loc), x = X.rfx.s.r; x <= X.rfx.e.r; ++x) for (h = X.rfx.s.c; h <= X.rfx.e.c; ++h)
            s.dense ? (c["!data"][x] || (c["!data"][x] = []), c["!data"][x][h] || (c["!data"][x][h] = { t: "z", v: void 0 }), c["!data"][x][h].l = X) : (E = Pe(h) + Me(x), c[E] || (c[E] = { t: "z", v: void 0 }), c[E].l = X);
          break;
        case 426:
          if (!s.cellFormula) break;
          O.push(X), P = s.dense ? c["!data"][x][h] : c[Pe(h) + y], P.f = hr(X[1], l, { r: u.r, c: h }, b, s), P.F = ye(X[0]);
          break;
        case 427:
          if (!s.cellFormula) break;
          B[Ne(X[0].s)] = X[1], P = s.dense ? c["!data"][x][h] : c[Pe(h) + y], P.f = hr(X[1], l, { r: u.r, c: h }, b, s);
          break;
        /* identical to 'ColInfo' in XLS */
        case 60:
          if (!s.cellStyles) break;
          for (; X.e >= X.s; )
            z[X.e--] = { width: X.w / 256, hidden: !!(X.flags & 1), level: X.level }, j || (j = !0, I0(X.w / 256)), ba(z[X.e + 1]);
          break;
        case 551:
          X && (c["!legrel"] = X);
          break;
        case 161:
          c["!autofilter"] = { ref: ye(X) };
          break;
        case 476:
          c["!margins"] = X;
          break;
        case 147:
          n.Sheets[r] || (n.Sheets[r] = {}), X.name && (n.Sheets[r].CodeName = X.name), (X.above || X.left) && (c["!outline"] = { above: X.above, left: X.left });
          break;
        case 137:
          n.Views || (n.Views = [{}]), n.Views[0] || (n.Views[0] = {}), X.RTL && (n.Views[0].RTL = !0);
          break;
        case 485:
          break;
        case 64:
        /* 'BrtDVal' */
        case 1053:
          break;
        case 151:
          break;
        case 152:
        /* 'BrtSel' */
        case 175:
        /* 'BrtAFilterDateGroupItem' */
        case 644:
        /* 'BrtActiveX' */
        case 625:
        /* 'BrtBigName' */
        case 562:
        /* 'BrtBkHim' */
        case 396:
        /* 'BrtBrk' */
        case 1112:
        /* 'BrtCFIcon' */
        case 1146:
        /* 'BrtCFRuleExt' */
        case 471:
        /* 'BrtCFVO' */
        case 1050:
        /* 'BrtCFVO14' */
        case 649:
        /* 'BrtCellIgnoreEC' */
        case 1105:
        /* 'BrtCellIgnoreEC14' */
        case 589:
        /* 'BrtCellSmartTagProperty' */
        case 607:
        /* 'BrtCellWatch' */
        case 564:
        /* 'BrtColor' */
        case 1055:
        /* 'BrtColor14' */
        case 168:
        /* 'BrtColorFilter' */
        case 174:
        /* 'BrtCustomFilter' */
        case 1180:
        /* 'BrtCustomFilter14' */
        case 499:
        /* 'BrtDRef' */
        case 507:
        /* 'BrtDXF' */
        case 550:
        /* 'BrtDrawing' */
        case 171:
        /* 'BrtDynamicFilter' */
        case 167:
        /* 'BrtFilter' */
        case 1177:
        /* 'BrtFilter14' */
        case 169:
        /* 'BrtIconFilter' */
        case 1181:
        /* 'BrtIconFilter14' */
        case 552:
        /* 'BrtLegacyDrawingHF' */
        case 661:
        /* 'BrtListPart' */
        case 639:
        /* 'BrtOleObject' */
        case 478:
        /* 'BrtPageSetup' */
        case 537:
        /* 'BrtPhoneticInfo' */
        case 477:
        /* 'BrtPrintOptions' */
        case 536:
        /* 'BrtRangeProtection' */
        case 1103:
        /* 'BrtRangeProtection14' */
        case 680:
        /* 'BrtRangeProtectionIso' */
        case 1104:
        /* 'BrtRangeProtectionIso14' */
        case 1024:
        /* 'BrtRwDescent' */
        case 663:
        /* 'BrtSheetCalcProp' */
        case 535:
        /* 'BrtSheetProtection' */
        case 678:
        /* 'BrtSheetProtectionIso' */
        case 504:
        /* 'BrtSlc' */
        case 1043:
        /* 'BrtSparkline' */
        case 428:
        /* 'BrtTable' */
        case 170:
        /* 'BrtTop10Filter' */
        case 3072:
        /* 'BrtUid' */
        case 50:
        /* 'BrtValueMeta' */
        case 2070:
        /* 'BrtWebExtension' */
        case 1045:
          break;
        case 35:
          v = !0;
          break;
        case 36:
          v = !1;
          break;
        case 37:
          v = !0;
          break;
        case 38:
          v = !1;
          break;
        default:
          if (!ke.T) {
            if (!v || s.WTF) throw new Error("Unexpected record 0x" + _e.toString(16));
          }
      }
  }, s), delete s.supbooks, delete s["!row"], !c["!ref"] && (l.s.r < 2e6 || o && (o.e.r > 0 || o.e.c > 0 || o.s.r > 0 || o.s.c > 0)) && (c["!ref"] = ye(o || l)), s.sheetRows && c["!ref"]) {
    var ne = Ke(c["!ref"]);
    s.sheetRows <= +ne.e.r && (ne.e.r = s.sheetRows - 1, ne.e.r > l.e.r && (ne.e.r = l.e.r), ne.e.r < ne.s.r && (ne.s.r = ne.e.r), ne.e.c > l.e.c && (ne.e.c = l.e.c), ne.e.c < ne.s.c && (ne.s.c = ne.e.c), c["!fullref"] = c["!ref"], c["!ref"] = ye(ne));
  }
  return M.length > 0 && (c["!merges"] = M), z.length > 0 && (c["!cols"] = z), fe.length > 0 && (c["!rows"] = fe), t["!id"][c["!legrel"]] && (c["!legdrawel"] = t["!id"][c["!legrel"]]), c;
}
function gx(e) {
  var a = [], r = e.match(/^<c:numCache>/), t;
  (e.match(/<c:pt idx="(\d*)"[^<>\/]*><c:v>([^<])<\/c:v><\/c:pt>/mg) || []).forEach(function(i) {
    var f = i.match(/<c:pt idx="(\d*)"[^<>\/]*><c:v>([^<]*)<\/c:v><\/c:pt>/);
    f && (a[+f[1]] = r ? +f[2] : f[2]);
  });
  var n = Ce((pa(e, "c:formatCode") || ["", "General"])[1]);
  return (E0(e, "<c:f>", "</c:f>") || []).forEach(function(i) {
    t = i.replace(/<[^<>]*>/g, "");
  }), [a, n, t];
}
function mx(e, a, r, t, n, i) {
  var f = i || { "!type": "chart" };
  if (!e) return i;
  var s = 0, c = 0, o = "A", l = { s: { r: 2e6, c: 2e6 }, e: { r: 0, c: 0 } };
  return (E0(e, "<c:numCache>", "</c:numCache>") || []).forEach(function(v) {
    var d = gx(v);
    l.s.r = l.s.c = 0, l.e.c = s, o = Pe(s), d[0].forEach(function(u, p) {
      f["!data"] ? (f["!data"][p] || (f["!data"][p] = []), f["!data"][p][s] = { t: "n", v: u, z: d[1] }) : f[o + Me(p)] = { t: "n", v: u, z: d[1] }, c = p;
    }), l.e.r < c && (l.e.r = c), ++s;
  }), s > 0 && (f["!ref"] = ye(l)), f;
}
function _x(e, a, r, t, n) {
  if (!e) return e;
  t || (t = { "!id": {} });
  var i = { "!type": "chart", "!drawel": null, "!rel": "" }, f, s = e.match(is);
  return s && N0(s[0], i, n, r), (f = e.match(/drawing r:id="(.*?)"/)) && (i["!rel"] = f[1]), t["!id"][i["!rel"]] && (i["!drawel"] = t["!id"][i["!rel"]]), i;
}
function kx(e, a) {
  e.l += 10;
  var r = vr(e);
  return { name: r };
}
function Ex(e, a, r, t, n) {
  if (!e) return e;
  t || (t = { "!id": {} });
  var i = { "!type": "chart", "!drawel": null, "!rel": "" }, f = !1;
  return ra(e, function(c, o, l) {
    switch (l) {
      case 550:
        i["!rel"] = c;
        break;
      case 651:
        n.Sheets[r] || (n.Sheets[r] = {}), c.name && (n.Sheets[r].CodeName = c.name);
        break;
      case 562:
      /* 'BrtBkHim' */
      case 652:
      /* 'BrtCsPageSetup' */
      case 669:
      /* 'BrtCsProtection' */
      case 679:
      /* 'BrtCsProtectionIso' */
      case 551:
      /* 'BrtLegacyDrawing' */
      case 552:
      /* 'BrtLegacyDrawingHF' */
      case 476:
      /* 'BrtMargins' */
      case 3072:
        break;
      case 35:
        f = !0;
        break;
      case 36:
        f = !1;
        break;
      case 37:
        break;
      case 38:
        break;
      default:
        if (!(o.T > 0)) {
          if (!(o.T < 0)) {
            if (!f || a.WTF) throw new Error("Unexpected record 0x" + l.toString(16));
          }
        }
    }
  }, a), t["!id"][i["!rel"]] && (i["!drawel"] = t["!id"][i["!rel"]]), i;
}
var fs = [
  ["allowRefreshQuery", !1, "bool"],
  ["autoCompressPictures", !0, "bool"],
  ["backupFile", !1, "bool"],
  ["checkCompatibility", !1, "bool"],
  ["CodeName", ""],
  ["date1904", !1, "bool"],
  ["defaultThemeVersion", 0, "int"],
  ["filterPrivacy", !1, "bool"],
  ["hidePivotFieldList", !1, "bool"],
  ["promptedSolutions", !1, "bool"],
  ["publishItems", !1, "bool"],
  ["refreshAllConnections", !1, "bool"],
  ["saveExternalLinkValues", !0, "bool"],
  ["showBorderUnselectedTables", !0, "bool"],
  ["showInkAnnotation", !0, "bool"],
  ["showObjects", "all"],
  ["showPivotChartFilter", !1, "bool"],
  ["updateLinks", "userSet"]
], Tx = [
  ["activeTab", 0, "int"],
  ["autoFilterDateGrouping", !0, "bool"],
  ["firstSheet", 0, "int"],
  ["minimized", !1, "bool"],
  ["showHorizontalScroll", !0, "bool"],
  ["showSheetTabs", !0, "bool"],
  ["showVerticalScroll", !0, "bool"],
  ["tabRatio", 600, "int"],
  ["visibility", "visible"]
  //window{Height,Width}, {x,y}Window
], wx = [
  //['state', 'visible']
], Fx = [
  ["calcCompleted", "true"],
  ["calcMode", "auto"],
  ["calcOnSave", "true"],
  ["concurrentCalc", "true"],
  ["fullCalcOnLoad", "false"],
  ["fullPrecision", "true"],
  ["iterate", "false"],
  ["iterateCount", "100"],
  ["iterateDelta", "0.001"],
  ["refMode", "A1"]
];
function Pn(e, a) {
  for (var r = 0; r != e.length; ++r)
    for (var t = e[r], n = 0; n != a.length; ++n) {
      var i = a[n];
      if (t[i[0]] == null) t[i[0]] = i[1];
      else switch (i[2]) {
        case "bool":
          typeof t[i[0]] == "string" && (t[i[0]] = Be(t[i[0]]));
          break;
        case "int":
          typeof t[i[0]] == "string" && (t[i[0]] = parseInt(t[i[0]], 10));
          break;
      }
    }
}
function bn(e, a) {
  for (var r = 0; r != a.length; ++r) {
    var t = a[r];
    if (e[t[0]] == null) e[t[0]] = t[1];
    else switch (t[2]) {
      case "bool":
        typeof e[t[0]] == "string" && (e[t[0]] = Be(e[t[0]]));
        break;
      case "int":
        typeof e[t[0]] == "string" && (e[t[0]] = parseInt(e[t[0]], 10));
        break;
    }
  }
}
function cs(e) {
  bn(e.WBProps, fs), bn(e.CalcPr, Fx), Pn(e.WBView, Tx), Pn(e.Sheets, wx), Ra.date1904 = Be(e.WBProps.date1904);
}
var Ax = /* @__PURE__ */ ":][*?/\\".split("");
function Sx(e, a) {
  try {
    if (e == "") throw new Error("Sheet name cannot be blank");
    if (e.length > 31) throw new Error("Sheet name cannot exceed 31 chars");
    if (e.charCodeAt(0) == 39 || e.charCodeAt(e.length - 1) == 39) throw new Error("Sheet name cannot start or end with apostrophe (')");
    if (e.toLowerCase() == "history") throw new Error("Sheet name cannot be 'History'");
    Ax.forEach(function(r) {
      if (e.indexOf(r) != -1)
        throw new Error("Sheet name cannot contain : \\ / ? * [ ]");
    });
  } catch (r) {
    throw r;
  }
  return !0;
}
var Cx = /<\w+:workbook/;
function yx(e, a) {
  if (!e) throw new Error("Could not find file");
  var r = (
    /*::(*/
    { AppVersion: {}, WBProps: {}, WBView: [], Sheets: [], CalcPr: {}, Names: [], xmlns: "" }
  ), t = !1, n = "xmlns", i = {}, f = 0;
  if (e.replace(or, function(c, o) {
    var l = le(c);
    switch (Mr(l[0])) {
      case "<?xml":
        break;
      /* 18.2.27 workbook CT_Workbook 1 */
      case "<workbook":
        c.match(Cx) && (n = "xmlns" + c.match(/<(\w+):/)[1]), r.xmlns = l[n];
        break;
      case "</workbook>":
        break;
      /* 18.2.13 fileVersion CT_FileVersion ? */
      case "<fileVersion":
        delete l[0], r.AppVersion = l;
        break;
      case "<fileVersion/>":
      case "</fileVersion>":
        break;
      /* 18.2.12 fileSharing CT_FileSharing ? */
      case "<fileSharing":
        break;
      case "<fileSharing/>":
        break;
      /* 18.2.28 workbookPr CT_WorkbookPr ? */
      case "<workbookPr":
      case "<workbookPr/>":
        fs.forEach(function(v) {
          if (l[v[0]] != null)
            switch (v[2]) {
              case "bool":
                r.WBProps[v[0]] = Be(l[v[0]]);
                break;
              case "int":
                r.WBProps[v[0]] = parseInt(l[v[0]], 10);
                break;
              default:
                r.WBProps[v[0]] = l[v[0]];
            }
        }), l.codeName && (r.WBProps.CodeName = Ue(l.codeName));
        break;
      case "</workbookPr>":
        break;
      /* 18.2.29 workbookProtection CT_WorkbookProtection ? */
      case "<workbookProtection":
        break;
      case "<workbookProtection/>":
        break;
      /* 18.2.1  bookViews CT_BookViews ? */
      case "<bookViews":
      case "<bookViews>":
      case "</bookViews>":
        break;
      /* 18.2.30   workbookView CT_BookView + */
      case "<workbookView":
      case "<workbookView/>":
        delete l[0], r.WBView.push(l);
        break;
      case "</workbookView>":
        break;
      /* 18.2.20 sheets CT_Sheets 1 */
      case "<sheets":
      case "<sheets>":
      case "</sheets>":
        break;
      // aggregate sheet
      /* 18.2.19   sheet CT_Sheet + */
      case "<sheet":
        switch (l.state) {
          case "hidden":
            l.Hidden = 1;
            break;
          case "veryHidden":
            l.Hidden = 2;
            break;
          default:
            l.Hidden = 0;
        }
        delete l.state, l.name = Ce(Ue(l.name)), delete l[0], r.Sheets.push(l);
        break;
      case "</sheet>":
        break;
      /* 18.2.15 functionGroups CT_FunctionGroups ? */
      case "<functionGroups":
      case "<functionGroups/>":
        break;
      /* 18.2.14   functionGroup CT_FunctionGroup + */
      case "<functionGroup":
        break;
      /* 18.2.9  externalReferences CT_ExternalReferences ? */
      case "<externalReferences":
      case "</externalReferences>":
      case "<externalReferences>":
        break;
      /* 18.2.8    externalReference CT_ExternalReference + */
      case "<externalReference":
        break;
      /* 18.2.6  definedNames CT_DefinedNames ? */
      case "<definedNames/>":
        break;
      case "<definedNames>":
      case "<definedNames":
        t = !0;
        break;
      case "</definedNames>":
        t = !1;
        break;
      /* 18.2.5    definedName CT_DefinedName + */
      case "<definedName":
        i = {}, i.Name = Ue(l.name), l.comment && (i.Comment = l.comment), l.localSheetId && (i.Sheet = +l.localSheetId), Be(l.hidden || "0") && (i.Hidden = !0), f = o + c.length;
        break;
      case "</definedName>":
        i.Ref = Ce(Ue(e.slice(f, o))), r.Names.push(i);
        break;
      case "<definedName/>":
        break;
      /* 18.2.2  calcPr CT_CalcPr ? */
      case "<calcPr":
        delete l[0], r.CalcPr = l;
        break;
      case "<calcPr/>":
        delete l[0], r.CalcPr = l;
        break;
      case "</calcPr>":
        break;
      /* 18.2.16 oleSize CT_OleSize ? (ref required) */
      case "<oleSize":
        break;
      /* 18.2.4  customWorkbookViews CT_CustomWorkbookViews ? */
      case "<customWorkbookViews>":
      case "</customWorkbookViews>":
      case "<customWorkbookViews":
        break;
      /* 18.2.3  customWorkbookView CT_CustomWorkbookView + */
      case "<customWorkbookView":
      case "</customWorkbookView>":
        break;
      /* 18.2.18 pivotCaches CT_PivotCaches ? */
      case "<pivotCaches>":
      case "</pivotCaches>":
      case "<pivotCaches":
        break;
      /* 18.2.17 pivotCache CT_PivotCache ? */
      case "<pivotCache":
        break;
      /* 18.2.21 smartTagPr CT_SmartTagPr ? */
      case "<smartTagPr":
      case "<smartTagPr/>":
        break;
      /* 18.2.23 smartTagTypes CT_SmartTagTypes ? */
      case "<smartTagTypes":
      case "<smartTagTypes>":
      case "</smartTagTypes>":
        break;
      /* 18.2.22 smartTagType CT_SmartTagType ? */
      case "<smartTagType":
        break;
      /* 18.2.24 webPublishing CT_WebPublishing ? */
      case "<webPublishing":
      case "<webPublishing/>":
        break;
      /* 18.2.11 fileRecoveryPr CT_FileRecoveryPr ? */
      case "<fileRecoveryPr":
      case "<fileRecoveryPr/>":
        break;
      /* 18.2.26 webPublishObjects CT_WebPublishObjects ? */
      case "<webPublishObjects>":
      case "<webPublishObjects":
      case "</webPublishObjects>":
        break;
      /* 18.2.25 webPublishObject CT_WebPublishObject ? */
      case "<webPublishObject":
        break;
      /* 18.2.10 extLst CT_ExtensionList ? */
      case "<extLst":
      case "<extLst>":
      case "</extLst>":
      case "<extLst/>":
        break;
      /* 18.2.7  ext CT_Extension + */
      case "<ext":
        t = !0;
        break;
      //TODO: check with versions of excel
      case "</ext>":
        t = !1;
        break;
      /* Others */
      case "<ArchID":
        break;
      case "<AlternateContent":
      case "<AlternateContent>":
        t = !0;
        break;
      case "</AlternateContent>":
        t = !1;
        break;
      /* TODO */
      case "<revisionPtr":
        break;
      default:
        if (!t && a.WTF) throw new Error("unrecognized " + l[0] + " in workbook");
    }
    return c;
  }), jf.indexOf(r.xmlns) === -1) throw new Error("Unknown Namespace: " + r.xmlns);
  return cs(r), r;
}
function Dx(e, a) {
  var r = {};
  return r.Hidden = e.read_shift(4), r.iTabID = e.read_shift(4), r.strRelID = f0(e), r.name = vr(e), r;
}
function Ix(e, a) {
  var r = {}, t = e.read_shift(4);
  r.defaultThemeVersion = e.read_shift(4);
  var n = a > 8 ? vr(e) : "";
  return n.length > 0 && (r.CodeName = n), r.autoCompressPictures = !!(t & 65536), r.backupFile = !!(t & 64), r.checkCompatibility = !!(t & 4096), r.date1904 = !!(t & 1), r.filterPrivacy = !!(t & 8), r.hidePivotFieldList = !!(t & 1024), r.promptedSolutions = !!(t & 16), r.publishItems = !!(t & 2048), r.refreshAllConnections = !!(t & 262144), r.saveExternalLinkValues = !!(t & 128), r.showBorderUnselectedTables = !!(t & 4), r.showInkAnnotation = !!(t & 32), r.showObjects = ["all", "placeholders", "none"][t >> 13 & 3], r.showPivotChartFilter = !!(t & 32768), r.updateLinks = ["userSet", "never", "always"][t >> 8 & 3], r;
}
function Ox(e, a) {
  var r = {};
  return e.read_shift(4), r.ArchID = e.read_shift(4), e.l += a - 8, r;
}
function Rx(e, a, r) {
  var t = e.l + a, n = e.read_shift(4);
  e.l += 1;
  var i = e.read_shift(4), f = vc(e), s, c = "";
  try {
    s = mh(e, 0, r);
    try {
      c = Vt(e);
    } catch {
    }
  } catch {
    console.error("Could not parse defined name " + f);
  }
  n & 32 && (f = "_xlnm." + f), e.l = t;
  var o = { Name: f, Ptg: s, Flags: n };
  return i < 268435455 && (o.Sheet = i), c && (o.Comment = c), o;
}
function Nx(e, a) {
  var r = { AppVersion: {}, WBProps: {}, WBView: [], Sheets: [], CalcPr: {}, xmlns: "" }, t = [], n = !1;
  a || (a = {}), a.biff = 12;
  var i = [], f = [[]];
  return f.SheetNames = [], f.XTI = [], Mt[16] = { n: "BrtFRTArchID$", f: Ox }, ra(e, function(c, o, l) {
    switch (l) {
      case 156:
        f.SheetNames.push(c.name), r.Sheets.push(c);
        break;
      case 153:
        r.WBProps = c;
        break;
      case 39:
        c.Sheet != null && (a.SID = c.Sheet), c.Ref = c.Ptg ? hr(c.Ptg, null, null, f, a) : "#REF!", delete a.SID, delete c.Ptg, i.push(c);
        break;
      case 1036:
        break;
      case 357:
      /* 'BrtSupSelf' */
      case 358:
      /* 'BrtSupSame' */
      case 355:
      /* 'BrtSupBookSrc' */
      case 667:
        f[0].length ? f.push([l, c]) : f[0] = [l, c], f[f.length - 1].XTI = [];
        break;
      case 362:
        f.length === 0 && (f[0] = [], f[0].XTI = []), f[f.length - 1].XTI = f[f.length - 1].XTI.concat(c), f.XTI = f.XTI.concat(c);
        break;
      case 361:
        break;
      case 2071:
      /* 'BrtAbsPath15' */
      case 158:
      /* 'BrtBookView' */
      case 143:
      /* 'BrtBeginBundleShs' */
      case 664:
      /* 'BrtBeginFnGroup' */
      case 353:
        break;
      /* case 'BrtModelTimeGroupingCalcCol' */
      case 3072:
      /* 'BrtUid' */
      case 3073:
      /* 'BrtRevisionPtr' */
      case 534:
      /* 'BrtBookProtection' */
      case 677:
      /* 'BrtBookProtectionIso' */
      case 157:
      /* 'BrtCalcProp' */
      case 610:
      /* 'BrtCrashRecErr' */
      case 2050:
      /* 'BrtDecoupledPivotCacheID' */
      case 155:
      /* 'BrtFileRecover' */
      case 548:
      /* 'BrtFileSharing' */
      case 676:
      /* 'BrtFileSharingIso' */
      case 128:
      /* 'BrtFileVersion' */
      case 665:
      /* 'BrtFnGroup' */
      case 2128:
      /* 'BrtModelRelationship' */
      case 2125:
      /* 'BrtModelTable' */
      case 549:
      /* 'BrtOleSize' */
      case 2053:
      /* 'BrtPivotTableRef' */
      case 596:
      /* 'BrtSmartTagType' */
      case 2076:
      /* 'BrtTableSlicerCacheID' */
      case 2075:
      /* 'BrtTableSlicerCacheIDs' */
      case 2082:
      /* 'BrtTimelineCachePivotCacheID' */
      case 397:
      /* 'BrtUserBookView' */
      case 154:
      /* 'BrtWbFactoid' */
      case 1117:
      /* 'BrtWbProp14' */
      case 553:
      /* 'BrtWebOpt' */
      case 2091:
        break;
      case 35:
        t.push(l), n = !0;
        break;
      case 36:
        t.pop(), n = !1;
        break;
      case 37:
        t.push(l), n = !0;
        break;
      case 38:
        t.pop(), n = !1;
        break;
      case 16:
        break;
      default:
        if (!o.T) {
          if (!n || a.WTF && t[t.length - 1] != 37 && t[t.length - 1] != 35) throw new Error("Unexpected record 0x" + l.toString(16));
        }
    }
  }, a), cs(r), r.Names = i, r.supbooks = f, r;
}
function Px(e, a, r) {
  return a.slice(-4) === ".bin" ? Nx(e, r) : yx(e, r);
}
function bx(e, a, r, t, n, i, f, s) {
  return a.slice(-4) === ".bin" ? px(e, t, r, n, i, f, s) : Dh(e, t, r, n, i, f, s);
}
function Lx(e, a, r, t, n, i, f, s) {
  return a.slice(-4) === ".bin" ? Ex(e, t, r, n, i) : _x(e, t, r, n, i);
}
function Bx(e, a, r, t, n, i, f, s) {
  return a.slice(-4) === ".bin" ? j1() : J1();
}
function Mx(e, a, r, t, n, i, f, s) {
  return a.slice(-4) === ".bin" ? K1() : Y1();
}
function Ux(e, a, r, t) {
  return a.slice(-4) === ".bin" ? v1(e, r, t) : o1(e, r, t);
}
function Hx(e, a, r) {
  return a.slice(-4) === ".bin" ? Il(e, r) : yl(e, r);
}
function Wx(e, a, r) {
  return a.slice(-4) === ".bin" ? X1(e, r) : U1(e, r);
}
function Vx(e, a, r) {
  return a.slice(-4) === ".bin" ? b1(e) : N1(e);
}
function Gx(e, a, r, t) {
  return r.slice(-4) === ".bin" ? L1(e, a, r, t) : void 0;
}
function Xx(e, a, r) {
  return a.slice(-4) === ".bin" ? O1(e, a, r) : R1(e, a, r);
}
var os = /\b((?:\w+:)?[\w]+)=((?:")([^"]*)(?:")|(?:')([^']*)(?:'))/g, ls = /\b((?:\w+:)?[\w]+)=((?:")(?:[^"]*)(?:")|(?:')(?:[^']*)(?:'))/;
function Wr(e, a) {
  var r = e.split(/\s+/), t = [];
  if (t[0] = r[0], r.length === 1) return t;
  var n = e.match(os), i, f, s, c;
  if (n) for (c = 0; c != n.length; ++c)
    i = n[c].match(ls), (f = i[1].indexOf(":")) === -1 ? t[i[1]] = i[2].slice(1, i[2].length - 1) : (i[1].slice(0, 6) === "xmlns:" ? s = "xmlns" + i[1].slice(6) : s = i[1].slice(f + 1), t[s] = i[2].slice(1, i[2].length - 1));
  return t;
}
function zx(e) {
  var a = e.split(/\s+/), r = {};
  if (a.length === 1) return r;
  var t = e.match(os), n, i, f, s;
  if (t) for (s = 0; s != t.length; ++s)
    n = t[s].match(ls), (i = n[1].indexOf(":")) === -1 ? r[n[1]] = n[2].slice(1, n[2].length - 1) : (n[1].slice(0, 6) === "xmlns:" ? f = "xmlns" + n[1].slice(6) : f = n[1].slice(i + 1), r[f] = n[2].slice(1, n[2].length - 1));
  return r;
}
var qa;
function $x(e, a, r) {
  var t = qa[e] || Ce(e);
  return t === "General" ? _a(a) : Fr(t, a, { date1904: !!r });
}
function Kx(e, a, r, t) {
  var n = t;
  switch ((r[0].match(/dt:dt="([\w.]+)"/) || ["", ""])[1]) {
    case "boolean":
      n = Be(t);
      break;
    case "i2":
    case "int":
      n = parseInt(t, 10);
      break;
    case "r4":
    case "float":
      n = parseFloat(t);
      break;
    case "date":
    case "dateTime.tz":
      n = cr(t);
      break;
    case "i8":
    case "string":
    case "fixed":
    case "uuid":
    case "bin.base64":
      break;
    default:
      throw new Error("bad custprop:" + r[0]);
  }
  e[Ce(a)] = n;
}
function Yx(e, a, r, t) {
  if (e.t !== "z") {
    if (!r || r.cellText !== !1) try {
      e.t === "e" ? e.w = e.w || Ar[e.v] : a === "General" ? e.t === "n" ? (e.v | 0) === e.v ? e.w = e.v.toString(10) : e.w = at(e.v) : e.w = _a(e.v) : e.w = $x(a || "General", e.v, t);
    } catch (f) {
      if (r.WTF) throw f;
    }
    try {
      var n = qa[a] || a || "General";
      if (r.cellNF && (e.z = n), r.cellDates && e.t == "n" && Br(n)) {
        var i = Kr(e.v + (t ? 1462 : 0));
        i && (e.t = "d", e.v = new Date(Date.UTC(i.y, i.m - 1, i.d, i.H, i.M, i.S, i.u)));
      }
    } catch (f) {
      if (r.WTF) throw f;
    }
  }
}
function jx(e, a, r) {
  if (r.cellStyles && a.Interior) {
    var t = a.Interior;
    t.Pattern && (t.patternType = t1[t.Pattern] || t.Pattern);
  }
  e[a.ID] = a;
}
function Jx(e, a, r, t, n, i, f, s, c, o, l) {
  var v = "General", d = t.StyleID, u = {};
  o = o || {};
  var p = [], _ = 0;
  for (d === void 0 && s && (d = s.StyleID), d === void 0 && f && (d = f.StyleID); i[d] !== void 0; ) {
    var x = i[d];
    if (x.nf && (v = x.nf), x.Interior && p.push(x.Interior), !x.Parent) break;
    d = x.Parent;
  }
  switch (r.Type) {
    case "Boolean":
      t.t = "b", t.v = Be(e);
      break;
    case "String":
      t.t = "s", t.r = en(Ce(e)), t.v = e.indexOf("<") > -1 ? Ce(a || e).replace(/<[^<>]*>/g, "") : t.r;
      break;
    case "DateTime":
      e.slice(-1) != "Z" && (e += "Z"), t.v = ar(cr(e, l), l), t.v !== t.v && (t.v = Ce(e)), (!v || v == "General") && (v = "yyyy-mm-dd");
    /* falls through */
    case "Number":
      t.v === void 0 && (t.v = +e), t.t || (t.t = "n");
      break;
    case "Error":
      t.t = "e", t.v = sr[e], o.cellText !== !1 && (t.w = e);
      break;
    default:
      e == "" && a == "" ? t.t = "z" : (t.t = "s", t.v = en(a || e));
      break;
  }
  if (Yx(t, v, o, l), o.cellFormula !== !1)
    if (t.Formula) {
      var h = Ce(t.Formula);
      h.charCodeAt(0) == 61 && (h = h.slice(1)), t.f = ma(h, n), delete t.Formula, t.ArrayRange == "RC" ? t.F = ma("RC:RC", n) : t.ArrayRange && (t.F = ma(t.ArrayRange, n), c.push([Ke(t.F), t.F]));
    } else
      for (_ = 0; _ < c.length; ++_)
        n.r >= c[_][0].s.r && n.r <= c[_][0].e.r && n.c >= c[_][0].s.c && n.c <= c[_][0].e.c && (t.F = c[_][1]);
  o.cellStyles && (p.forEach(function(E) {
    !u.patternType && E.patternType && (u.patternType = E.patternType);
  }), t.s = u), t.StyleID !== void 0 && (t.ixfe = t.StyleID);
}
function Zx(e) {
  return yi.indexOf("_xlnm." + e) > -1 ? "_xlnm." + e : e;
}
function qx(e) {
  e.t = e.v || "", e.t = e.t.replace(/\r\n/g, `
`).replace(/\r/g, `
`), e.v = e.w = e.ixfe = void 0;
}
function t0(e, a) {
  var r = a || {};
  Qn();
  var t = Ha(Wt(e));
  (r.type == "binary" || r.type == "array" || r.type == "base64") && (t = Ue(t));
  var n = t.slice(0, 1024).toLowerCase(), i = !1;
  if (n = n.replace(/".*?"/g, ""), (n.indexOf(">") & 1023) > Math.min(n.indexOf(",") & 1023, n.indexOf(";") & 1023)) {
    var f = er(r);
    return f.type = "string", nt.to_workbook(t, f);
  }
  if (n.indexOf("<?xml") == -1 && ["html", "table", "head", "meta", "script", "style", "div"].forEach(function(xe) {
    n.indexOf("<" + xe) >= 0 && (i = !0);
  }), i) return fd(t, r);
  qa = {
    "General Number": "General",
    "General Date": ge[22],
    "Long Date": "dddd, mmmm dd, yyyy",
    "Medium Date": ge[15],
    "Short Date": ge[14],
    "Long Time": ge[19],
    "Medium Time": ge[18],
    "Short Time": ge[20],
    Currency: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
    Fixed: ge[2],
    Standard: ge[4],
    Percent: ge[10],
    Scientific: ge[11],
    "Yes/No": '"Yes";"Yes";"No";@',
    "True/False": '"True";"True";"False";@',
    "On/Off": '"Yes";"Yes";"No";@'
  };
  var s, c = [], o, l = {}, v = [], d = {}, u = "";
  r.dense && (d["!data"] = []);
  var p = {}, _ = {}, x = Wr('<Data ss:Type="String">'), h = 0, E = 0, g = 0, y = { s: { r: 2e6, c: 2e6 }, e: { r: 0, c: 0 } }, P = {}, M = {}, I = "", N = 0, O = [], B = {}, b = {}, G = 0, z = [], fe = [], j = {}, he = [], J, ne = !1, pe = [], X = [], ke = {}, _e = 0, de = 0, ce = { Sheets: [], WBProps: { date1904: !1 } }, Te = {};
  qe.lastIndex = 0, t = ot(t, "<!--", "-->");
  for (var me = ""; s = qe.exec(t); ) switch (s[3] = (me = s[3]).toLowerCase()) {
    case "data":
      if (me == "data") {
        if (s[1] === "/") {
          if ((o = c.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
        } else s[0].charAt(s[0].length - 2) !== "/" && c.push([s[3], !0]);
        break;
      }
      if (c[c.length - 1][1]) break;
      s[1] === "/" ? Jx(t.slice(h, s.index), I, x, c[c.length - 1][0] == /*"Comment"*/
      "comment" ? j : p, { c: E, r: g }, P, he[E], _, pe, r, ce.WBProps.date1904) : (I = "", x = Wr(s[0]), h = s.index + s[0].length);
      break;
    case "cell":
      if (s[1] === "/")
        if (fe.length > 0 && (p.c = fe), (!r.sheetRows || r.sheetRows > g) && p.v !== void 0 && (r.dense ? (d["!data"][g] || (d["!data"][g] = []), d["!data"][g][E] = p) : d[Pe(E) + Me(g)] = p), p.HRef && (p.l = { Target: Ce(p.HRef) }, p.HRefScreenTip && (p.l.Tooltip = p.HRefScreenTip), delete p.HRef, delete p.HRefScreenTip), (p.MergeAcross || p.MergeDown) && (_e = E + (parseInt(p.MergeAcross, 10) | 0), de = g + (parseInt(p.MergeDown, 10) | 0), (_e > E || de > g) && O.push({ s: { c: E, r: g }, e: { c: _e, r: de } })), !r.sheetStubs)
          p.MergeAcross ? E = _e + 1 : ++E;
        else if (p.MergeAcross || p.MergeDown) {
          for (var Fe = E; Fe <= _e; ++Fe)
            for (var S = g; S <= de; ++S)
              (Fe > E || S > g) && (r.dense ? (d["!data"][S] || (d["!data"][S] = []), d["!data"][S][Fe] = { t: "z" }) : d[Pe(Fe) + Me(S)] = { t: "z" });
          E = _e + 1;
        } else ++E;
      else
        p = zx(s[0]), p.Index && (E = +p.Index - 1), E < y.s.c && (y.s.c = E), E > y.e.c && (y.e.c = E), s[0].slice(-2) === "/>" && ++E, fe = [];
      break;
    case "row":
      s[1] === "/" || s[0].slice(-2) === "/>" ? (g < y.s.r && (y.s.r = g), g > y.e.r && (y.e.r = g), s[0].slice(-2) === "/>" && (_ = Wr(s[0]), _.Index && (g = +_.Index - 1)), E = 0, ++g) : (_ = Wr(s[0]), _.Index && (g = +_.Index - 1), ke = {}, (_.AutoFitHeight == "0" || _.Height) && (ke.hpx = parseInt(_.Height, 10), ke.hpt = Yi(ke.hpx), X[g] = ke), _.Hidden == "1" && (ke.hidden = !0, X[g] = ke));
      break;
    case "worksheet":
      if (s[1] === "/") {
        if ((o = c.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
        v.push(u), y.s.r <= y.e.r && y.s.c <= y.e.c && (d["!ref"] = ye(y), r.sheetRows && r.sheetRows <= y.e.r && (d["!fullref"] = d["!ref"], y.e.r = r.sheetRows - 1, d["!ref"] = ye(y))), O.length && (d["!merges"] = O), he.length > 0 && (d["!cols"] = he), X.length > 0 && (d["!rows"] = X), l[u] = d;
      } else
        y = { s: { r: 2e6, c: 2e6 }, e: { r: 0, c: 0 } }, g = E = 0, c.push([s[3], !1]), o = Wr(s[0]), u = Ce(o.Name), d = {}, r.dense && (d["!data"] = []), O = [], pe = [], X = [], Te = { name: u, Hidden: 0 }, ce.Sheets.push(Te);
      break;
    case "table":
      if (s[1] === "/") {
        if ((o = c.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
      } else {
        if (s[0].slice(-2) == "/>") break;
        c.push([s[3], !1]), he = [], ne = !1;
      }
      break;
    case "style":
      s[1] === "/" ? jx(P, M, r) : M = Wr(s[0]);
      break;
    case "numberformat":
      M.nf = Ce(Wr(s[0]).Format || "General"), qa[M.nf] && (M.nf = qa[M.nf]);
      for (var L = 0; L != 392 && ge[L] != M.nf; ++L) ;
      if (L == 392) {
        for (L = 57; L != 392; ++L) if (ge[L] == null) {
          va(M.nf, L);
          break;
        }
      }
      break;
    case "column":
      if (c[c.length - 1][0] !== /*'Table'*/
      "table" || s[1] === "/") break;
      if (J = Wr(s[0]), J.Hidden && (J.hidden = !0, delete J.Hidden), J.Width && (J.wpx = parseInt(J.Width, 10)), !ne && J.wpx > 10) {
        ne = !0, _r = $i;
        for (var R = 0; R < he.length; ++R) he[R] && ba(he[R]);
      }
      ne && ba(J), he[J.Index - 1 || he.length] = J;
      for (var D = 0; D < +J.Span; ++D) he[he.length] = er(J);
      break;
    case "namedrange":
      if (s[1] === "/") break;
      ce.Names || (ce.Names = []);
      var Y = le(s[0]), w = {
        Name: Zx(Y.Name),
        Ref: ma(Y.RefersTo.slice(1), { r: 0, c: 0 })
      };
      ce.Sheets.length > 0 && (w.Sheet = ce.Sheets.length - 1), ce.Names.push(w);
      break;
    case "namedcell":
      break;
    case "b":
      break;
    case "i":
      break;
    case "u":
      break;
    case "s":
      break;
    case "em":
      break;
    case "h2":
      break;
    case "h3":
      break;
    case "sub":
      break;
    case "sup":
      break;
    case "span":
      break;
    case "alignment":
      break;
    case "borders":
      break;
    case "border":
      break;
    case "font":
      if (s[0].slice(-2) === "/>") break;
      s[1] === "/" ? I += t.slice(N, s.index) : N = s.index + s[0].length;
      break;
    case "interior":
      if (!r.cellStyles) break;
      M.Interior = Wr(s[0]);
      break;
    case "protection":
      break;
    case "author":
    case "title":
    case "description":
    case "created":
    case "keywords":
    case "subject":
    case "category":
    case "company":
    case "lastauthor":
    case "lastsaved":
    case "lastprinted":
    case "version":
    case "revision":
    case "totaltime":
    case "hyperlinkbase":
    case "manager":
    case "contentstatus":
    case "identifier":
    case "language":
    case "appname":
      if (s[0].slice(-2) === "/>") break;
      s[1] === "/" ? Uc(B, me, t.slice(G, s.index)) : G = s.index + s[0].length;
      break;
    case "paragraphs":
      break;
    case "styles":
    case "workbook":
      if (s[1] === "/") {
        if ((o = c.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
      } else c.push([s[3], !1]);
      break;
    case "comment":
      if (s[1] === "/") {
        if ((o = c.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
        qx(j), fe.push(j);
      } else
        c.push([s[3], !1]), o = Wr(s[0]), Be(o.ShowAlways || "0") || (fe.hidden = !0), j = { a: o.Author };
      break;
    case "autofilter":
      if (s[1] === "/") {
        if ((o = c.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
      } else if (s[0].charAt(s[0].length - 2) !== "/") {
        var te = Wr(s[0]);
        d["!autofilter"] = { ref: ma(te.Range).replace(/\$/g, "") }, c.push([s[3], !0]);
      }
      break;
    case "name":
      break;
    case "datavalidation":
      if (s[1] === "/") {
        if ((o = c.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
      } else
        s[0].charAt(s[0].length - 2) !== "/" && c.push([s[3], !0]);
      break;
    case "pixelsperinch":
      break;
    case "componentoptions":
    case "documentproperties":
    case "customdocumentproperties":
    case "officedocumentsettings":
    case "pivottable":
    case "pivotcache":
    case "names":
    case "mapinfo":
    case "pagebreaks":
    case "querytable":
    case "sorting":
    case "schema":
    //case 'data' /*case 'data'*/:
    case "conditionalformatting":
    case "smarttagtype":
    case "smarttags":
    case "excelworkbook":
    case "workbookoptions":
    case "worksheetoptions":
      if (s[1] === "/") {
        if ((o = c.pop())[0] !== s[3]) throw new Error("Bad state: " + o.join("|"));
      } else s[0].charAt(s[0].length - 2) !== "/" && c.push([s[3], !0]);
      break;
    case "null":
      break;
    default:
      if (c.length == 0 && s[3] == "document" || c.length == 0 && s[3] == "uof") return Hn(t, r);
      var ie = !0;
      switch (c[c.length - 1][0]) {
        /* OfficeDocumentSettings */
        case "officedocumentsettings":
          switch (s[3]) {
            case "allowpng":
              break;
            case "removepersonalinformation":
              break;
            case "downloadcomponents":
              break;
            case "locationofcomponents":
              break;
            case "colors":
              break;
            case "color":
              break;
            case "index":
              break;
            case "rgb":
              break;
            case "targetscreensize":
              break;
            case "readonlyrecommended":
              break;
            default:
              ie = !1;
          }
          break;
        /* ComponentOptions */
        case "componentoptions":
          switch (s[3]) {
            case "toolbar":
              break;
            case "hideofficelogo":
              break;
            case "spreadsheetautofit":
              break;
            case "label":
              break;
            case "caption":
              break;
            case "maxheight":
              break;
            case "maxwidth":
              break;
            case "nextsheetnumber":
              break;
            default:
              ie = !1;
          }
          break;
        /* ExcelWorkbook */
        case "excelworkbook":
          switch (s[3]) {
            case "date1904":
              ce.WBProps.date1904 = !0;
              break;
            case "hidehorizontalscrollbar":
              break;
            case "hideverticalscrollbar":
              break;
            case "hideworkbooktabs":
              break;
            case "windowheight":
              break;
            case "windowwidth":
              break;
            case "windowtopx":
              break;
            case "windowtopy":
              break;
            case "tabratio":
              break;
            case "protectstructure":
              break;
            case "protectwindow":
              break;
            case "protectwindows":
              break;
            case "activesheet":
              break;
            case "displayinknotes":
              break;
            case "firstvisiblesheet":
              break;
            case "supbook":
              break;
            case "sheetname":
              break;
            case "sheetindex":
              break;
            case "sheetindexfirst":
              break;
            case "sheetindexlast":
              break;
            case "dll":
              break;
            case "acceptlabelsinformulas":
              break;
            case "donotsavelinkvalues":
              break;
            case "iteration":
              break;
            case "maxiterations":
              break;
            case "maxchange":
              break;
            case "path":
              break;
            case "xct":
              break;
            case "count":
              break;
            case "selectedsheets":
              break;
            case "calculation":
              break;
            case "uncalced":
              break;
            case "startupprompt":
              break;
            case "crn":
              break;
            case "externname":
              break;
            case "formula":
              break;
            case "colfirst":
              break;
            case "collast":
              break;
            case "wantadvise":
              break;
            case "boolean":
              break;
            case "error":
              break;
            case "text":
              break;
            case "ole":
              break;
            case "noautorecover":
              break;
            case "publishobjects":
              break;
            case "donotcalculatebeforesave":
              break;
            case "number":
              break;
            case "refmoder1c1":
              break;
            case "embedsavesmarttags":
              break;
            default:
              ie = !1;
          }
          break;
        /* WorkbookOptions */
        case "workbookoptions":
          switch (s[3]) {
            case "owcversion":
              break;
            case "height":
              break;
            case "width":
              break;
            default:
              ie = !1;
          }
          break;
        /* WorksheetOptions */
        case "worksheetoptions":
          switch (s[3]) {
            case "visible":
              if (s[0].slice(-2) !== "/>") if (s[1] === "/") switch (t.slice(G, s.index)) {
                case "SheetHidden":
                  Te.Hidden = 1;
                  break;
                case "SheetVeryHidden":
                  Te.Hidden = 2;
                  break;
              }
              else G = s.index + s[0].length;
              break;
            case "header":
              d["!margins"] || Za(d["!margins"] = {}, "xlml"), isNaN(+le(s[0]).Margin) || (d["!margins"].header = +le(s[0]).Margin);
              break;
            case "footer":
              d["!margins"] || Za(d["!margins"] = {}, "xlml"), isNaN(+le(s[0]).Margin) || (d["!margins"].footer = +le(s[0]).Margin);
              break;
            case "pagemargins":
              var Q = le(s[0]);
              d["!margins"] || Za(d["!margins"] = {}, "xlml"), isNaN(+Q.Top) || (d["!margins"].top = +Q.Top), isNaN(+Q.Left) || (d["!margins"].left = +Q.Left), isNaN(+Q.Right) || (d["!margins"].right = +Q.Right), isNaN(+Q.Bottom) || (d["!margins"].bottom = +Q.Bottom);
              break;
            case "displayrighttoleft":
              ce.Views || (ce.Views = []), ce.Views[0] || (ce.Views[0] = {}), ce.Views[0].RTL = !0;
              break;
            case "freezepanes":
              break;
            case "frozennosplit":
              break;
            case "splithorizontal":
            case "splitvertical":
              break;
            case "donotdisplaygridlines":
              break;
            case "activerow":
              break;
            case "activecol":
              break;
            case "toprowbottompane":
              break;
            case "leftcolumnrightpane":
              break;
            case "unsynced":
              break;
            case "print":
              break;
            case "printerrors":
              break;
            case "panes":
              break;
            case "scale":
              break;
            case "pane":
              break;
            case "number":
              break;
            case "layout":
              break;
            case "pagesetup":
              break;
            case "selected":
              break;
            case "protectobjects":
              break;
            case "enableselection":
              break;
            case "protectscenarios":
              break;
            case "validprinterinfo":
              break;
            case "horizontalresolution":
              break;
            case "verticalresolution":
              break;
            case "numberofcopies":
              break;
            case "activepane":
              break;
            case "toprowvisible":
              break;
            case "leftcolumnvisible":
              break;
            case "fittopage":
              break;
            case "rangeselection":
              break;
            case "papersizeindex":
              break;
            case "pagelayoutzoom":
              break;
            case "pagebreakzoom":
              break;
            case "filteron":
              break;
            case "fitwidth":
              break;
            case "fitheight":
              break;
            case "commentslayout":
              break;
            case "zoom":
              break;
            case "lefttoright":
              break;
            case "gridlines":
              break;
            case "allowsort":
              break;
            case "allowfilter":
              break;
            case "allowinsertrows":
              break;
            case "allowdeleterows":
              break;
            case "allowinsertcols":
              break;
            case "allowdeletecols":
              break;
            case "allowinserthyperlinks":
              break;
            case "allowformatcells":
              break;
            case "allowsizecols":
              break;
            case "allowsizerows":
              break;
            case "nosummaryrowsbelowdetail":
              d["!outline"] || (d["!outline"] = {}), d["!outline"].above = !0;
              break;
            case "tabcolorindex":
              break;
            case "donotdisplayheadings":
              break;
            case "showpagelayoutzoom":
              break;
            case "nosummarycolumnsrightdetail":
              d["!outline"] || (d["!outline"] = {}), d["!outline"].left = !0;
              break;
            case "blackandwhite":
              break;
            case "donotdisplayzeros":
              break;
            case "displaypagebreak":
              break;
            case "rowcolheadings":
              break;
            case "donotdisplayoutline":
              break;
            case "noorientation":
              break;
            case "allowusepivottables":
              break;
            case "zeroheight":
              break;
            case "viewablerange":
              break;
            case "selection":
              break;
            case "protectcontents":
              break;
            default:
              ie = !1;
          }
          break;
        /* PivotTable */
        case "pivottable":
        case "pivotcache":
          switch (s[3]) {
            case "immediateitemsondrop":
              break;
            case "showpagemultipleitemlabel":
              break;
            case "compactrowindent":
              break;
            case "location":
              break;
            case "pivotfield":
              break;
            case "orientation":
              break;
            case "layoutform":
              break;
            case "layoutsubtotallocation":
              break;
            case "layoutcompactrow":
              break;
            case "position":
              break;
            case "pivotitem":
              break;
            case "datatype":
              break;
            case "datafield":
              break;
            case "sourcename":
              break;
            case "parentfield":
              break;
            case "ptlineitems":
              break;
            case "ptlineitem":
              break;
            case "countofsameitems":
              break;
            case "item":
              break;
            case "itemtype":
              break;
            case "ptsource":
              break;
            case "cacheindex":
              break;
            case "consolidationreference":
              break;
            case "filename":
              break;
            case "reference":
              break;
            case "nocolumngrand":
              break;
            case "norowgrand":
              break;
            case "blanklineafteritems":
              break;
            case "hidden":
              break;
            case "subtotal":
              break;
            case "basefield":
              break;
            case "mapchilditems":
              break;
            case "function":
              break;
            case "refreshonfileopen":
              break;
            case "printsettitles":
              break;
            case "mergelabels":
              break;
            case "defaultversion":
              break;
            case "refreshname":
              break;
            case "refreshdate":
              break;
            case "refreshdatecopy":
              break;
            case "versionlastrefresh":
              break;
            case "versionlastupdate":
              break;
            case "versionupdateablemin":
              break;
            case "versionrefreshablemin":
              break;
            case "calculation":
              break;
            default:
              ie = !1;
          }
          break;
        /* PageBreaks */
        case "pagebreaks":
          switch (s[3]) {
            case "colbreaks":
              break;
            case "colbreak":
              break;
            case "rowbreaks":
              break;
            case "rowbreak":
              break;
            case "colstart":
              break;
            case "colend":
              break;
            case "rowend":
              break;
            default:
              ie = !1;
          }
          break;
        /* AutoFilter */
        case "autofilter":
          switch (s[3]) {
            case "autofiltercolumn":
              break;
            case "autofiltercondition":
              break;
            case "autofilterand":
              break;
            case "autofilteror":
              break;
            default:
              ie = !1;
          }
          break;
        /* QueryTable */
        case "querytable":
          switch (s[3]) {
            case "id":
              break;
            case "autoformatfont":
              break;
            case "autoformatpattern":
              break;
            case "querysource":
              break;
            case "querytype":
              break;
            case "enableredirections":
              break;
            case "refreshedinxl9":
              break;
            case "urlstring":
              break;
            case "htmltables":
              break;
            case "connection":
              break;
            case "commandtext":
              break;
            case "refreshinfo":
              break;
            case "notitles":
              break;
            case "nextid":
              break;
            case "columninfo":
              break;
            case "overwritecells":
              break;
            case "donotpromptforfile":
              break;
            case "textwizardsettings":
              break;
            case "source":
              break;
            case "number":
              break;
            case "decimal":
              break;
            case "thousandseparator":
              break;
            case "trailingminusnumbers":
              break;
            case "formatsettings":
              break;
            case "fieldtype":
              break;
            case "delimiters":
              break;
            case "tab":
              break;
            case "comma":
              break;
            case "autoformatname":
              break;
            case "versionlastedit":
              break;
            case "versionlastrefresh":
              break;
            default:
              ie = !1;
          }
          break;
        case "datavalidation":
          switch (s[3]) {
            case "range":
              break;
            case "type":
              break;
            case "min":
              break;
            case "max":
              break;
            case "sort":
              break;
            case "descending":
              break;
            case "order":
              break;
            case "casesensitive":
              break;
            case "value":
              break;
            case "errorstyle":
              break;
            case "errormessage":
              break;
            case "errortitle":
              break;
            case "inputmessage":
              break;
            case "inputtitle":
              break;
            case "combohide":
              break;
            case "inputhide":
              break;
            case "condition":
              break;
            case "qualifier":
              break;
            case "useblank":
              break;
            case "value1":
              break;
            case "value2":
              break;
            case "format":
              break;
            case "cellrangelist":
              break;
            default:
              ie = !1;
          }
          break;
        case "sorting":
        case "conditionalformatting":
          switch (s[3]) {
            case "range":
              break;
            case "type":
              break;
            case "min":
              break;
            case "max":
              break;
            case "sort":
              break;
            case "descending":
              break;
            case "order":
              break;
            case "casesensitive":
              break;
            case "value":
              break;
            case "errorstyle":
              break;
            case "errormessage":
              break;
            case "errortitle":
              break;
            case "cellrangelist":
              break;
            case "inputmessage":
              break;
            case "inputtitle":
              break;
            case "combohide":
              break;
            case "inputhide":
              break;
            case "condition":
              break;
            case "qualifier":
              break;
            case "useblank":
              break;
            case "value1":
              break;
            case "value2":
              break;
            case "format":
              break;
            default:
              ie = !1;
          }
          break;
        /* MapInfo (schema) */
        case "mapinfo":
        case "schema":
        case "data":
          switch (s[3]) {
            case "map":
              break;
            case "entry":
              break;
            case "range":
              break;
            case "xpath":
              break;
            case "field":
              break;
            case "xsdtype":
              break;
            case "filteron":
              break;
            case "aggregate":
              break;
            case "elementtype":
              break;
            case "attributetype":
              break;
            /* These are from xsd (XML Schema Definition) */
            case "schema":
            case "element":
            case "complextype":
            case "datatype":
            case "all":
            case "attribute":
            case "extends":
              break;
            case "row":
              break;
            default:
              ie = !1;
          }
          break;
        /* SmartTags (can be anything) */
        case "smarttags":
          break;
        default:
          ie = !1;
          break;
      }
      if (ie || s[3].match(/!\[CDATA/)) break;
      if (!c[c.length - 1][1]) throw "Unrecognized tag: " + s[3] + "|" + c.join("|");
      if (c[c.length - 1][0] === /*'CustomDocumentProperties'*/
      "customdocumentproperties") {
        if (s[0].slice(-2) === "/>") break;
        s[1] === "/" ? Kx(b, me, z, t.slice(G, s.index)) : (z = s, G = s.index + s[0].length);
        break;
      }
      if (r.WTF) throw "Unrecognized tag: " + s[3] + "|" + c.join("|");
  }
  var ve = {};
  return !r.bookSheets && !r.bookProps && (ve.Sheets = l), ve.SheetNames = v, ve.Workbook = ce, ve.SSF = er(ge), ve.Props = B, ve.Custprops = b, ve.bookType = "xlml", ve;
}
function l0(e, a) {
  switch (P0(a = a || {}), a.type || "base64") {
    case "base64":
      return t0(Or(e), a);
    case "binary":
    case "buffer":
    case "file":
      return t0(e, a);
    case "array":
      return t0(ea(e), a);
  }
}
function Qx(e) {
  var a = {}, r = e.content;
  if (r.l = 28, a.AnsiUserType = r.read_shift(0, "lpstr-ansi"), a.AnsiClipboardFormat = mc(r), r.length - r.l <= 4) return a;
  var t = r.read_shift(4);
  if (t == 0 || t > 40 || (r.l -= 4, a.Reserved1 = r.read_shift(0, "lpstr-ansi"), r.length - r.l <= 4) || (t = r.read_shift(4), t !== 1907505652) || (a.UnicodeClipboardFormat = _c(r), t = r.read_shift(4), t == 0 || t > 40)) return a;
  r.l -= 4, a.Reserved2 = r.read_shift(0, "lpwstr");
}
var ed = [60, 1084, 2066, 2165, 2175];
function rd(e, a, r, t, n) {
  var i = t, f = [], s = r.slice(r.l, r.l + i);
  if (n && n.enc && n.enc.insitu && s.length > 0) switch (e) {
    case 9:
    case 521:
    case 1033:
    case 2057:
    case 47:
    case 405:
    case 225:
    case 406:
    case 312:
    case 404:
    case 10:
      break;
    case 133:
      break;
    default:
      n.enc.insitu(s);
  }
  f.push(s), r.l += i;
  for (var c = Zr(r, r.l), o = u0[c], l = 0; o != null && ed.indexOf(c) > -1; )
    i = Zr(r, r.l + 2), l = r.l + 4, c == 2066 ? l += 4 : (c == 2165 || c == 2175) && (l += 12), s = r.slice(l, r.l + 4 + i), f.push(s), r.l += 4 + i, o = u0[c = Zr(r, r.l)];
  var v = ta(f);
  rr(v, 0);
  var d = 0;
  v.lens = [];
  for (var u = 0; u < f.length; ++u)
    v.lens.push(d), d += f[u].length;
  if (v.length < t) throw "XLS Record 0x" + e.toString(16) + " Truncated: " + v.length + " < " + t;
  return a.f(v, v.length, n);
}
function zr(e, a, r) {
  if (e.t !== "z" && e.XF) {
    var t = 0;
    try {
      t = e.z || e.XF.numFmtId || 0, a.cellNF && e.z == null && (e.z = ge[t]);
    } catch (i) {
      if (a.WTF) throw i;
    }
    if (!a || a.cellText !== !1) try {
      e.t === "e" ? e.w = e.w || Ar[e.v] : t === 0 || t == "General" ? e.t === "n" ? (e.v | 0) === e.v ? e.w = e.v.toString(10) : e.w = at(e.v) : e.w = _a(e.v) : e.w = Fr(t, e.v, { date1904: !!r, dateNF: a && a.dateNF });
    } catch (i) {
      if (a.WTF) throw i;
    }
    if (a.cellDates && t && e.t == "n" && Br(ge[t] || String(t))) {
      var n = Kr(e.v + (r ? 1462 : 0));
      n && (e.t = "d", e.v = new Date(Date.UTC(n.y, n.m - 1, n.d, n.H, n.M, n.S, n.u)));
    }
  }
}
function Ct(e, a, r) {
  return { v: e, ixfe: a, t: r };
}
function ad(e, a) {
  var r = { opts: {} }, t = {}, n = {};
  a.dense && (n["!data"] = []);
  var i = {}, f = {}, s = null, c = [], o = "", l = {}, v, d = "", u, p, _, x, h = {}, E = [], g, y, P = [], M = [], I = { Sheets: [], WBProps: { date1904: !1 }, Views: [{}] }, N = {}, O = !1, B = function(se) {
    return se < 8 ? ga[se] : se < 64 && M[se - 8] || ga[se];
  }, b = function(se, be) {
    var Ye = se.XF.data;
    if (!(!Ye || !Ye.patternType || !be || !be.cellStyles)) {
      se.s = {}, se.s.patternType = Ye.patternType;
      var je;
      (je = it(B(Ye.icvFore))) && (se.s.fgColor = { rgb: je }), (je = it(B(Ye.icvBack))) && (se.s.bgColor = { rgb: je });
    }
  }, G = function(se, be, Ye) {
    if (!(!O && _e > 1) && !(Ye.sheetRows && se.r >= Ye.sheetRows)) {
      if (Ye.cellStyles && be.XF && be.XF.data && b(be, Ye), delete be.ixfe, delete be.XF, v = se, d = Ne(se), (!f || !f.s || !f.e) && (f = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }), se.r < f.s.r && (f.s.r = se.r), se.c < f.s.c && (f.s.c = se.c), se.r + 1 > f.e.r && (f.e.r = se.r + 1), se.c + 1 > f.e.c && (f.e.c = se.c + 1), Ye.cellFormula && be.f) {
        for (var je = 0; je < E.length; ++je)
          if (!(E[je][0].s.c > se.c || E[je][0].s.r > se.r) && !(E[je][0].e.c < se.c || E[je][0].e.r < se.r)) {
            be.F = ye(E[je][0]), (E[je][0].s.c != se.c || E[je][0].s.r != se.r) && delete be.f, be.f && (be.f = "" + hr(E[je][1], f, se, X, z));
            break;
          }
      }
      Ye.dense ? (n["!data"][se.r] || (n["!data"][se.r] = []), n["!data"][se.r][se.c] = be) : n[d] = be;
    }
  }, z = {
    enc: !1,
    // encrypted
    sbcch: 0,
    // cch in the preceding SupBook
    snames: [],
    // sheetnames
    sharedf: h,
    // shared formulae by address
    arrayf: E,
    // array formulae array
    rrtabid: [],
    // RRTabId
    lastuser: "",
    // Last User from WriteAccess
    biff: 8,
    // BIFF version
    codepage: 0,
    // CP from CodePage record
    winlocked: 0,
    // fLockWn from WinProtect
    cellStyles: !!a && !!a.cellStyles,
    WTF: !!a && !!a.wtf
  };
  a.password && (z.password = a.password);
  var fe, j = [], he = [], J = [], ne = [], pe = !1, X = [];
  X.SheetNames = z.snames, X.sharedf = z.sharedf, X.arrayf = z.arrayf, X.names = [], X.XTI = [];
  var ke = 0, _e = 0, de = 0, ce = [], Te = [], me;
  z.codepage = 1200, Vr(1200);
  for (var Fe = !1; e.l < e.length - 1; ) {
    var S = e.l, L = e.read_shift(2);
    if (L === 0 && ke === 10) break;
    var R = e.l === e.length ? 0 : e.read_shift(2), D = u0[L];
    if (_e == 0 && [9, 521, 1033, 2057].indexOf(L) == -1) break;
    if (D && D.f) {
      if (a.bookSheets && ke === 133 && L !== 133)
        break;
      if (ke = L, D.r === 2 || D.r == 12) {
        var Y = e.read_shift(2);
        if (R -= 2, !z.enc && Y !== L && ((Y & 255) << 8 | Y >> 8) !== L) throw new Error("rt mismatch: " + Y + "!=" + L);
        D.r == 12 && (e.l += 10, R -= 10);
      }
      var w = {};
      if (L === 10 ? w = /*::(*/
      D.f(e, R, z) : w = /*::(*/
      rd(L, D, e, R, z), _e == 0 && [9, 521, 1033, 2057].indexOf(ke) === -1) continue;
      switch (L) {
        case 34:
          r.opts.Date1904 = I.WBProps.date1904 = w;
          break;
        case 134:
          r.opts.WriteProtect = !0;
          break;
        case 47:
          if (z.enc || (e.l = 0), z.enc = w, !a.password) throw new Error("File is password-protected");
          if (w.valid == null) throw new Error("Encryption scheme unsupported");
          if (!w.valid) throw new Error("Password is incorrect");
          break;
        case 92:
          z.lastuser = w;
          break;
        case 66:
          var te = Number(w);
          switch (te) {
            case 21010:
              te = 1200;
              break;
            case 32768:
              te = 1e4;
              break;
            case 32769:
              te = 1252;
              break;
          }
          Vr(z.codepage = te), Fe = !0;
          break;
        case 317:
          z.rrtabid = w;
          break;
        case 25:
          z.winlocked = w;
          break;
        case 439:
          r.opts.RefreshAll = w;
          break;
        case 12:
          r.opts.CalcCount = w;
          break;
        case 16:
          r.opts.CalcDelta = w;
          break;
        case 17:
          r.opts.CalcIter = w;
          break;
        case 13:
          r.opts.CalcMode = w;
          break;
        case 14:
          r.opts.CalcPrecision = w;
          break;
        case 95:
          r.opts.CalcSaveRecalc = w;
          break;
        case 15:
          z.CalcRefMode = w;
          break;
        // TODO: implement R1C1
        case 2211:
          r.opts.FullCalc = w;
          break;
        case 129:
          w.fDialog && (n["!type"] = "dialog"), w.fBelow || ((n["!outline"] || (n["!outline"] = {})).above = !0), w.fRight || ((n["!outline"] || (n["!outline"] = {})).left = !0);
          break;
        // TODO
        case 67:
        /* BIFF2XF */
        case 579:
        /* BIFF3XF */
        case 1091:
        /* BIFF4XF */
        case 224:
          P.push(w);
          break;
        case 430:
          X.push([w]), X[X.length - 1].XTI = [];
          break;
        case 35:
        case 547:
          X[X.length - 1].push(w);
          break;
        case 24:
        case 536:
          me = {
            Name: w.Name,
            Ref: hr(w.rgce, f, null, X, z)
          }, w.itab > 0 && (me.Sheet = w.itab - 1), X.names.push(me), X[0] || (X[0] = [], X[0].XTI = []), X[X.length - 1].push(w), w.Name == "_xlnm._FilterDatabase" && w.itab > 0 && w.rgce && w.rgce[0] && w.rgce[0][0] && w.rgce[0][0][0] == "PtgArea3d" && (Te[w.itab - 1] = { ref: ye(w.rgce[0][0][1][2]) });
          break;
        case 22:
          z.ExternCount = w;
          break;
        case 23:
          X.length == 0 && (X[0] = [], X[0].XTI = []), X[X.length - 1].XTI = X[X.length - 1].XTI.concat(w), X.XTI = X.XTI.concat(w);
          break;
        case 2196:
          if (z.biff < 8) break;
          me != null && (me.Comment = w[1]);
          break;
        case 18:
          n["!protect"] = w;
          break;
        /* for sheet or book */
        case 19:
          w !== 0 && z.WTF && console.error("Password verifier: " + w);
          break;
        case 133:
          i[z.biff == 4 ? z.snames.length : w.pos] = w, z.snames.push(w.name);
          break;
        case 10:
          {
            if (--_e ? !O : O) break;
            if (f.e) {
              if (f.e.r > 0 && f.e.c > 0) {
                if (f.e.r--, f.e.c--, n["!ref"] = ye(f), a.sheetRows && a.sheetRows <= f.e.r) {
                  var ie = f.e.r;
                  f.e.r = a.sheetRows - 1, n["!fullref"] = n["!ref"], n["!ref"] = ye(f), f.e.r = ie;
                }
                f.e.r++, f.e.c++;
              }
              j.length > 0 && (n["!merges"] = j), he.length > 0 && (n["!objects"] = he), J.length > 0 && (n["!cols"] = J), ne.length > 0 && (n["!rows"] = ne), I.Sheets.push(N);
            }
            o === "" ? l = n : t[o] = n, n = {}, a.dense && (n["!data"] = []);
          }
          break;
        case 9:
        case 521:
        case 1033:
        case 2057:
          {
            if (z.biff === 8 && (z.biff = {
              9: 2,
              521: 3,
              1033: 4
            }[L] || {
              512: 2,
              768: 3,
              1024: 4,
              1280: 5,
              1536: 8,
              2: 2,
              7: 2
            }[w.BIFFVer] || 8), z.biffguess = w.BIFFVer == 0, w.BIFFVer == 0 && w.dt == 4096 && (z.biff = 5, Fe = !0, Vr(z.codepage = 28591)), z.biff == 4 && w.dt & 256 && (O = !0), z.biff == 8 && w.BIFFVer == 0 && w.dt == 16 && (z.biff = 2), _e++ && !O) break;
            if (n = {}, a.dense && (n["!data"] = []), z.biff < 8 && !Fe && (Fe = !0, Vr(z.codepage = a.codepage || 1252)), z.biff == 4 && O)
              o = (i[z.snames.indexOf(o) + 1] || { name: "" }).name;
            else if (z.biff < 5 || w.BIFFVer == 0 && w.dt == 4096) {
              o === "" && (o = "Sheet1"), f = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } };
              var Q = { pos: e.l - R, name: o };
              i[Q.pos] = Q, z.snames.push(o);
            } else o = (i[S] || { name: "" }).name;
            w.dt == 32 && (n["!type"] = "chart"), w.dt == 64 && (n["!type"] = "macro"), j = [], he = [], z.arrayf = E = [], J = [], ne = [], pe = !1, N = { Hidden: (i[S] || { hs: 0 }).hs, name: o };
          }
          break;
        case 515:
        case 3:
        case 2:
          n["!type"] == "chart" && (a.dense ? (n["!data"][w.r] || [])[w.c] : n[Pe(w.c) + Me(w.r)]) && ++w.c, g = { ixfe: w.ixfe, XF: P[w.ixfe] || {}, v: w.val, t: "n" }, de > 0 && (g.z = g.XF && g.XF.numFmtId && ce[g.XF.numFmtId] || ce[g.ixfe >> 8 & 63]), zr(g, a, r.opts.Date1904), G({ c: w.c, r: w.r }, g, a);
          break;
        case 5:
        case 517:
          g = { ixfe: w.ixfe, XF: P[w.ixfe], v: w.val, t: w.t }, de > 0 && (g.z = g.XF && g.XF.numFmtId && ce[g.XF.numFmtId] || ce[g.ixfe >> 8 & 63]), zr(g, a, r.opts.Date1904), G({ c: w.c, r: w.r }, g, a);
          break;
        case 638:
          g = { ixfe: w.ixfe, XF: P[w.ixfe], v: w.rknum, t: "n" }, de > 0 && (g.z = g.XF && g.XF.numFmtId && ce[g.XF.numFmtId] || ce[g.ixfe >> 8 & 63]), zr(g, a, r.opts.Date1904), G({ c: w.c, r: w.r }, g, a);
          break;
        case 189:
          for (var ve = w.c; ve <= w.C; ++ve) {
            var xe = w.rkrec[ve - w.c][0];
            g = { ixfe: xe, XF: P[xe], v: w.rkrec[ve - w.c][1], t: "n" }, de > 0 && (g.z = g.XF && g.XF.numFmtId && ce[g.XF.numFmtId] || ce[g.ixfe >> 8 & 63]), zr(g, a, r.opts.Date1904), G({ c: ve, r: w.r }, g, a);
          }
          break;
        case 6:
        case 518:
        case 1030:
          {
            if (w.val == "String") {
              s = w;
              break;
            }
            if (g = Ct(w.val, w.cell.ixfe, w.tt), g.XF = P[g.ixfe], a.cellFormula) {
              var Ee = w.formula;
              if (Ee && Ee[0] && Ee[0][0] && Ee[0][0][0] == "PtgExp") {
                var Le = Ee[0][0][1][0], He = Ee[0][0][1][1], Xe = Ne({ r: Le, c: He });
                h[Xe] ? g.f = "" + hr(w.formula, f, w.cell, X, z) : g.F = ((a.dense ? (n["!data"][Le] || [])[He] : n[Xe]) || {}).F;
              } else g.f = "" + hr(w.formula, f, w.cell, X, z);
            }
            de > 0 && (g.z = g.XF && g.XF.numFmtId && ce[g.XF.numFmtId] || ce[g.ixfe >> 8 & 63]), zr(g, a, r.opts.Date1904), G(w.cell, g, a), s = w;
          }
          break;
        case 7:
        case 519:
          if (s)
            s.val = w, g = Ct(w, s.cell.ixfe, "s"), g.XF = P[g.ixfe], a.cellFormula && (g.f = "" + hr(s.formula, f, s.cell, X, z)), de > 0 && (g.z = g.XF && g.XF.numFmtId && ce[g.XF.numFmtId] || ce[g.ixfe >> 8 & 63]), zr(g, a, r.opts.Date1904), G(s.cell, g, a), s = null;
          else throw new Error("String record expects Formula");
          break;
        case 33:
        case 545:
          {
            E.push(w);
            var ue = Ne(w[0].s);
            if (u = a.dense ? (n["!data"][w[0].s.r] || [])[w[0].s.c] : n[ue], a.cellFormula && u) {
              if (!s || !ue || !u) break;
              u.f = "" + hr(w[1], f, w[0], X, z), u.F = ye(w[0]);
            }
          }
          break;
        case 1212:
          {
            if (!a.cellFormula) break;
            if (d) {
              if (!s) break;
              h[Ne(s.cell)] = w[0], u = a.dense ? (n["!data"][s.cell.r] || [])[s.cell.c] : n[Ne(s.cell)], (u || {}).f = "" + hr(w[0], f, v, X, z);
            }
          }
          break;
        case 253:
          g = Ct(c[w.isst].t, w.ixfe, "s"), c[w.isst].h && (g.h = c[w.isst].h), g.XF = P[g.ixfe], de > 0 && (g.z = g.XF && g.XF.numFmtId && ce[g.XF.numFmtId] || ce[g.ixfe >> 8 & 63]), zr(g, a, r.opts.Date1904), G({ c: w.c, r: w.r }, g, a);
          break;
        case 513:
          a.sheetStubs && (g = { ixfe: w.ixfe, XF: P[w.ixfe], t: "z" }, de > 0 && (g.z = g.XF && g.XF.numFmtId && ce[g.XF.numFmtId] || ce[g.ixfe >> 8 & 63]), zr(g, a, r.opts.Date1904), G({ c: w.c, r: w.r }, g, a));
          break;
        case 190:
          if (a.sheetStubs)
            for (var De = w.c; De <= w.C; ++De) {
              var re = w.ixfe[De - w.c];
              g = { ixfe: re, XF: P[re], t: "z" }, de > 0 && (g.z = g.XF && g.XF.numFmtId && ce[g.XF.numFmtId] || ce[g.ixfe >> 8 & 63]), zr(g, a, r.opts.Date1904), G({ c: De, r: w.r }, g, a);
            }
          break;
        case 214:
        case 516:
        case 4:
          g = Ct(w.val, w.ixfe, "s"), g.XF = P[g.ixfe], de > 0 && (g.z = g.XF && g.XF.numFmtId && ce[g.XF.numFmtId] || ce[g.ixfe >> 8 & 63]), zr(g, a, r.opts.Date1904), G({ c: w.c, r: w.r }, g, a);
          break;
        case 0:
        case 512:
          _e === 1 && (f = w);
          break;
        case 252:
          c = w;
          break;
        case 1054:
          if (z.biff >= 3 && z.biff <= 4) {
            ce[de++] = w[1];
            for (var Sr = 0; Sr < de + 163 && ge[Sr] != w[1]; ++Sr) ;
            Sr >= 163 && va(w[1], de + 163);
          } else va(w[1], w[0]);
          break;
        case 30:
          {
            ce[de++] = w;
            for (var gr = 0; gr < de + 163 && ge[gr] != w; ++gr) ;
            gr >= 163 && va(w, de + 163);
          }
          break;
        case 229:
          j = j.concat(w);
          break;
        case 93:
          he[w.cmo[0]] = z.lastobj = w;
          break;
        case 438:
          z.lastobj.TxO = w;
          break;
        case 127:
          z.lastobj.ImData = w;
          break;
        case 440:
          for (x = w[0].s.r; x <= w[0].e.r; ++x)
            for (_ = w[0].s.c; _ <= w[0].e.c; ++_)
              u = a.dense ? (n["!data"][x] || [])[_] : n[Ne({ c: _, r: x })], u && (u.l = w[1]);
          break;
        case 2048:
          for (x = w[0].s.r; x <= w[0].e.r; ++x)
            for (_ = w[0].s.c; _ <= w[0].e.c; ++_)
              u = a.dense ? (n["!data"][x] || [])[_] : n[Ne({ c: _, r: x })], u && u.l && (u.l.Tooltip = w[1]);
          break;
        case 28:
          {
            if (u = a.dense ? (n["!data"][w[0].r] || [])[w[0].c] : n[Ne(w[0])], u || (a.dense ? (n["!data"][w[0].r] || (n["!data"][w[0].r] = []), u = n["!data"][w[0].r][w[0].c] = { t: "z" }) : u = n[Ne(w[0])] = { t: "z" }, f.e.r = Math.max(f.e.r, w[0].r), f.s.r = Math.min(f.s.r, w[0].r), f.e.c = Math.max(f.e.c, w[0].c), f.s.c = Math.min(f.s.c, w[0].c)), u.c || (u.c = []), z.biff <= 5 && z.biff >= 2) p = { a: "SheetJ5", t: w[1] };
            else {
              var We = he[w[2]];
              p = { a: w[1], t: We.TxO.t }, w[3] != null && !(w[3] & 2) && (u.c.hidden = !0);
            }
            u.c.push(p);
          }
          break;
        case 2173:
          C1(P[w.ixfe], w.ext);
          break;
        case 125:
          {
            if (!z.cellStyles) break;
            for (; w.e >= w.s; )
              J[w.e--] = { width: w.w / 256, level: w.level || 0, hidden: !!(w.flags & 1) }, pe || (pe = !0, I0(w.w / 256)), ba(J[w.e + 1]);
          }
          break;
        case 520:
          {
            var Hr = {};
            w.level != null && (ne[w.r] = Hr, Hr.level = w.level), w.hidden && (ne[w.r] = Hr, Hr.hidden = !0), w.hpt && (ne[w.r] = Hr, Hr.hpt = w.hpt, Hr.hpx = st(w.hpt));
          }
          break;
        case 38:
        case 39:
        case 40:
        case 41:
          n["!margins"] || Za(n["!margins"] = {}), n["!margins"][{ 38: "left", 39: "right", 40: "top", 41: "bottom" }[L]] = w;
          break;
        case 161:
          n["!margins"] || Za(n["!margins"] = {}), n["!margins"].header = w.header, n["!margins"].footer = w.footer;
          break;
        case 574:
          w.RTL && (I.Views[0].RTL = !0);
          break;
        case 146:
          M = w;
          break;
        case 2198:
          fe = w;
          break;
        case 140:
          y = w;
          break;
        case 442:
          o ? N.CodeName = w || N.name : I.WBProps.CodeName = w || "ThisWorkbook";
          break;
      }
    } else
      D || console.error("Missing Info for XLS Record 0x" + L.toString(16)), e.l += R;
  }
  return r.SheetNames = Lr(i).sort(function(Er, se) {
    return Number(Er) - Number(se);
  }).map(function(Er) {
    return i[Er].name;
  }), a.bookSheets || (r.Sheets = t), !r.SheetNames.length && l["!ref"] ? (r.SheetNames.push("Sheet1"), r.Sheets && (r.Sheets.Sheet1 = l)) : r.Preamble = l, r.Sheets && Te.forEach(function(Er, se) {
    r.Sheets[r.SheetNames[se]]["!autofilter"] = Er;
  }), r.Strings = c, r.SSF = er(ge), z.enc && (r.Encryption = z.enc), fe && (r.Themes = fe), r.Metadata = {}, y !== void 0 && (r.Metadata.Country = y), X.names.length > 0 && (I.Names = X.names), r.Workbook = I, r;
}
var Ln = {
  SI: "e0859ff2f94f6810ab9108002b27b3d9",
  DSI: "02d5cdd59c2e1b10939708002b2cf9ae",
  UDI: "05d5cdd59c2e1b10939708002b2cf9ae"
};
function td(e, a, r) {
  var t = Oe.find(e, "/!DocumentSummaryInformation");
  if (t && t.size > 0) try {
    var n = mn(t, Ac, Ln.DSI);
    for (var i in n) a[i] = n[i];
  } catch (o) {
    if (r.WTF) throw o;
  }
  var f = Oe.find(e, "/!SummaryInformation");
  if (f && f.size > 0) try {
    var s = mn(f, Sc, Ln.SI);
    for (var c in s) a[c] == null && (a[c] = s[c]);
  } catch (o) {
    if (r.WTF) throw o;
  }
  a.HeadingPairs && a.TitlesOfParts && (Ii(a.HeadingPairs, a.TitlesOfParts, a, r), delete a.HeadingPairs, delete a.TitlesOfParts);
}
function us(e, a) {
  a || (a = {}), P0(a), Vn(), a.codepage && d0(a.codepage);
  var r, t;
  if (e.FullPaths) {
    if (Oe.find(e, "/encryption")) throw new Error("File is password-protected");
    r = Oe.find(e, "!CompObj"), t = Oe.find(e, "/Workbook") || Oe.find(e, "/Book");
  } else {
    switch (a.type) {
      case "base64":
        e = yr(Or(e));
        break;
      case "binary":
        e = yr(e);
        break;
      case "buffer":
        break;
      case "array":
        Array.isArray(e) || (e = Array.prototype.slice.call(e));
        break;
    }
    rr(e, 0), t = { content: e };
  }
  var n, i;
  if (r && Qx(r), a.bookProps && !a.bookSheets) n = {};
  else {
    var f = Se ? "buffer" : "array";
    if (t && t.content) n = ad(t.content, a);
    else if ((i = Oe.find(e, "PerfectOffice_MAIN")) && i.content) n = ja.to_workbook(i.content, (a.type = f, a));
    else if ((i = Oe.find(e, "NativeContent_MAIN")) && i.content) n = ja.to_workbook(i.content, (a.type = f, a));
    else throw (i = Oe.find(e, "MN0")) && i.content ? new Error("Unsupported Works 4 for Mac file") : new Error("Cannot find Workbook stream");
    a.bookVBA && e.FullPaths && Oe.find(e, "/_VBA_PROJECT_CUR/VBA/dir") && (n.vbaraw = $1(e));
  }
  var s = {};
  return e.FullPaths && td(
    /*::((*/
    e,
    s,
    a
  ), n.Props = n.Custprops = s, a.bookFiles && (n.cfb = e), n;
}
var Mt = {
  0: {
    /* n:"BrtRowHdr", */
    f: Mh
  },
  1: {
    /* n:"BrtCellBlank", */
    f: Vh
  },
  2: {
    /* n:"BrtCellRk", */
    f: Zh
  },
  3: {
    /* n:"BrtCellError", */
    f: $h
  },
  4: {
    /* n:"BrtCellBool", */
    f: Xh
  },
  5: {
    /* n:"BrtCellReal", */
    f: Jh
  },
  6: {
    /* n:"BrtCellSt", */
    f: ex
  },
  7: {
    /* n:"BrtCellIsst", */
    f: Yh
  },
  8: {
    /* n:"BrtFmlaString", */
    f: ix
  },
  9: {
    /* n:"BrtFmlaNum", */
    f: nx
  },
  10: {
    /* n:"BrtFmlaBool", */
    f: ax
  },
  11: {
    /* n:"BrtFmlaError", */
    f: tx
  },
  12: {
    /* n:"BrtShortBlank", */
    f: Gh
  },
  13: {
    /* n:"BrtShortRk", */
    f: qh
  },
  14: {
    /* n:"BrtShortError", */
    f: Kh
  },
  15: {
    /* n:"BrtShortBool", */
    f: zh
  },
  16: {
    /* n:"BrtShortReal", */
    f: ss
  },
  17: {
    /* n:"BrtShortSt", */
    f: rx
  },
  18: {
    /* n:"BrtShortIsst", */
    f: jh
  },
  19: {
    /* n:"BrtSSTItem", */
    f: S0
  },
  20: {
    /* n:"BrtPCDIMissing" */
  },
  21: {
    /* n:"BrtPCDINumber" */
  },
  22: {
    /* n:"BrtPCDIBoolean" */
  },
  23: {
    /* n:"BrtPCDIError" */
  },
  24: {
    /* n:"BrtPCDIString" */
  },
  25: {
    /* n:"BrtPCDIDatetime" */
  },
  26: {
    /* n:"BrtPCDIIndex" */
  },
  27: {
    /* n:"BrtPCDIAMissing" */
  },
  28: {
    /* n:"BrtPCDIANumber" */
  },
  29: {
    /* n:"BrtPCDIABoolean" */
  },
  30: {
    /* n:"BrtPCDIAError" */
  },
  31: {
    /* n:"BrtPCDIAString" */
  },
  32: {
    /* n:"BrtPCDIADatetime" */
  },
  33: {
    /* n:"BrtPCRRecord" */
  },
  34: {
    /* n:"BrtPCRRecordDt" */
  },
  35: {
    /* n:"BrtFRTBegin", */
    T: 1
  },
  36: {
    /* n:"BrtFRTEnd", */
    T: -1
  },
  37: {
    /* n:"BrtACBegin", */
    T: 1
  },
  38: {
    /* n:"BrtACEnd", */
    T: -1
  },
  39: {
    /* n:"BrtName", */
    f: Rx
  },
  40: {
    /* n:"BrtIndexRowBlock" */
  },
  42: {
    /* n:"BrtIndexBlock" */
  },
  43: {
    /* n:"BrtFont", */
    f: u1
  },
  44: {
    /* n:"BrtFmt", */
    f: l1
  },
  45: {
    /* n:"BrtFill", */
    f: h1
  },
  46: {
    /* n:"BrtBorder", */
    f: d1
  },
  47: {
    /* n:"BrtXF", */
    f: x1
  },
  48: {
    /* n:"BrtStyle" */
  },
  49: {
    /* n:"BrtCellMeta", */
    f: uc
  },
  50: {
    /* n:"BrtValueMeta" */
  },
  51: {
    /* n:"BrtMdb" */
    f: D1
  },
  52: {
    /* n:"BrtBeginFmd", */
    T: 1
  },
  53: {
    /* n:"BrtEndFmd", */
    T: -1
  },
  54: {
    /* n:"BrtBeginMdx", */
    T: 1
  },
  55: {
    /* n:"BrtEndMdx", */
    T: -1
  },
  56: {
    /* n:"BrtBeginMdxTuple", */
    T: 1
  },
  57: {
    /* n:"BrtEndMdxTuple", */
    T: -1
  },
  58: {
    /* n:"BrtMdxMbrIstr" */
  },
  59: {
    /* n:"BrtStr" */
  },
  60: {
    /* n:"BrtColInfo", */
    f: Wi
  },
  62: {
    /* n:"BrtCellRString", */
    f: Qh
  },
  63: {
    /* n:"BrtCalcChainItem$", */
    f: P1
  },
  64: {
    /* n:"BrtDVal", */
    f: dx
  },
  65: {
    /* n:"BrtSxvcellNum" */
  },
  66: {
    /* n:"BrtSxvcellStr" */
  },
  67: {
    /* n:"BrtSxvcellBool" */
  },
  68: {
    /* n:"BrtSxvcellErr" */
  },
  69: {
    /* n:"BrtSxvcellDate" */
  },
  70: {
    /* n:"BrtSxvcellNil" */
  },
  128: {
    /* n:"BrtFileVersion" */
  },
  129: {
    /* n:"BrtBeginSheet", */
    T: 1
  },
  130: {
    /* n:"BrtEndSheet", */
    T: -1
  },
  131: {
    /* n:"BrtBeginBook", */
    T: 1,
    f: pr,
    p: 0
  },
  132: {
    /* n:"BrtEndBook", */
    T: -1
  },
  133: {
    /* n:"BrtBeginWsViews", */
    T: 1
  },
  134: {
    /* n:"BrtEndWsViews", */
    T: -1
  },
  135: {
    /* n:"BrtBeginBookViews", */
    T: 1
  },
  136: {
    /* n:"BrtEndBookViews", */
    T: -1
  },
  137: {
    /* n:"BrtBeginWsView", */
    T: 1,
    f: xx
  },
  138: {
    /* n:"BrtEndWsView", */
    T: -1
  },
  139: {
    /* n:"BrtBeginCsViews", */
    T: 1
  },
  140: {
    /* n:"BrtEndCsViews", */
    T: -1
  },
  141: {
    /* n:"BrtBeginCsView", */
    T: 1
  },
  142: {
    /* n:"BrtEndCsView", */
    T: -1
  },
  143: {
    /* n:"BrtBeginBundleShs", */
    T: 1
  },
  144: {
    /* n:"BrtEndBundleShs", */
    T: -1
  },
  145: {
    /* n:"BrtBeginSheetData", */
    T: 1
  },
  146: {
    /* n:"BrtEndSheetData", */
    T: -1
  },
  147: {
    /* n:"BrtWsProp", */
    f: Wh
  },
  148: {
    /* n:"BrtWsDim", */
    f: Uh,
    p: 16
  },
  151: {
    /* n:"BrtPane", */
    f: cx
  },
  152: {
    /* n:"BrtSel" */
  },
  153: {
    /* n:"BrtWbProp", */
    f: Ix
  },
  154: {
    /* n:"BrtWbFactoid" */
  },
  155: {
    /* n:"BrtFileRecover" */
  },
  156: {
    /* n:"BrtBundleSh", */
    f: Dx
  },
  157: {
    /* n:"BrtCalcProp" */
  },
  158: {
    /* n:"BrtBookView" */
  },
  159: {
    /* n:"BrtBeginSst", */
    T: 1,
    f: Dl
  },
  160: {
    /* n:"BrtEndSst", */
    T: -1
  },
  161: {
    /* n:"BrtBeginAFilter", */
    T: 1,
    f: Aa
  },
  162: {
    /* n:"BrtEndAFilter", */
    T: -1
  },
  163: {
    /* n:"BrtBeginFilterColumn", */
    T: 1
  },
  164: {
    /* n:"BrtEndFilterColumn", */
    T: -1
  },
  165: {
    /* n:"BrtBeginFilters", */
    T: 1
  },
  166: {
    /* n:"BrtEndFilters", */
    T: -1
  },
  167: {
    /* n:"BrtFilter" */
  },
  168: {
    /* n:"BrtColorFilter" */
  },
  169: {
    /* n:"BrtIconFilter" */
  },
  170: {
    /* n:"BrtTop10Filter" */
  },
  171: {
    /* n:"BrtDynamicFilter" */
  },
  172: {
    /* n:"BrtBeginCustomFilters", */
    T: 1
  },
  173: {
    /* n:"BrtEndCustomFilters", */
    T: -1
  },
  174: {
    /* n:"BrtCustomFilter" */
  },
  175: {
    /* n:"BrtAFilterDateGroupItem" */
  },
  176: {
    /* n:"BrtMergeCell", */
    f: sx
  },
  177: {
    /* n:"BrtBeginMergeCells", */
    T: 1
  },
  178: {
    /* n:"BrtEndMergeCells", */
    T: -1
  },
  179: {
    /* n:"BrtBeginPivotCacheDef", */
    T: 1
  },
  180: {
    /* n:"BrtEndPivotCacheDef", */
    T: -1
  },
  181: {
    /* n:"BrtBeginPCDFields", */
    T: 1
  },
  182: {
    /* n:"BrtEndPCDFields", */
    T: -1
  },
  183: {
    /* n:"BrtBeginPCDField", */
    T: 1
  },
  184: {
    /* n:"BrtEndPCDField", */
    T: -1
  },
  185: {
    /* n:"BrtBeginPCDSource", */
    T: 1
  },
  186: {
    /* n:"BrtEndPCDSource", */
    T: -1
  },
  187: {
    /* n:"BrtBeginPCDSRange", */
    T: 1
  },
  188: {
    /* n:"BrtEndPCDSRange", */
    T: -1
  },
  189: {
    /* n:"BrtBeginPCDFAtbl", */
    T: 1
  },
  190: {
    /* n:"BrtEndPCDFAtbl", */
    T: -1
  },
  191: {
    /* n:"BrtBeginPCDIRun", */
    T: 1
  },
  192: {
    /* n:"BrtEndPCDIRun", */
    T: -1
  },
  193: {
    /* n:"BrtBeginPivotCacheRecords", */
    T: 1
  },
  194: {
    /* n:"BrtEndPivotCacheRecords", */
    T: -1
  },
  195: {
    /* n:"BrtBeginPCDHierarchies", */
    T: 1
  },
  196: {
    /* n:"BrtEndPCDHierarchies", */
    T: -1
  },
  197: {
    /* n:"BrtBeginPCDHierarchy", */
    T: 1
  },
  198: {
    /* n:"BrtEndPCDHierarchy", */
    T: -1
  },
  199: {
    /* n:"BrtBeginPCDHFieldsUsage", */
    T: 1
  },
  200: {
    /* n:"BrtEndPCDHFieldsUsage", */
    T: -1
  },
  201: {
    /* n:"BrtBeginExtConnection", */
    T: 1
  },
  202: {
    /* n:"BrtEndExtConnection", */
    T: -1
  },
  203: {
    /* n:"BrtBeginECDbProps", */
    T: 1
  },
  204: {
    /* n:"BrtEndECDbProps", */
    T: -1
  },
  205: {
    /* n:"BrtBeginECOlapProps", */
    T: 1
  },
  206: {
    /* n:"BrtEndECOlapProps", */
    T: -1
  },
  207: {
    /* n:"BrtBeginPCDSConsol", */
    T: 1
  },
  208: {
    /* n:"BrtEndPCDSConsol", */
    T: -1
  },
  209: {
    /* n:"BrtBeginPCDSCPages", */
    T: 1
  },
  210: {
    /* n:"BrtEndPCDSCPages", */
    T: -1
  },
  211: {
    /* n:"BrtBeginPCDSCPage", */
    T: 1
  },
  212: {
    /* n:"BrtEndPCDSCPage", */
    T: -1
  },
  213: {
    /* n:"BrtBeginPCDSCPItem", */
    T: 1
  },
  214: {
    /* n:"BrtEndPCDSCPItem", */
    T: -1
  },
  215: {
    /* n:"BrtBeginPCDSCSets", */
    T: 1
  },
  216: {
    /* n:"BrtEndPCDSCSets", */
    T: -1
  },
  217: {
    /* n:"BrtBeginPCDSCSet", */
    T: 1
  },
  218: {
    /* n:"BrtEndPCDSCSet", */
    T: -1
  },
  219: {
    /* n:"BrtBeginPCDFGroup", */
    T: 1
  },
  220: {
    /* n:"BrtEndPCDFGroup", */
    T: -1
  },
  221: {
    /* n:"BrtBeginPCDFGItems", */
    T: 1
  },
  222: {
    /* n:"BrtEndPCDFGItems", */
    T: -1
  },
  223: {
    /* n:"BrtBeginPCDFGRange", */
    T: 1
  },
  224: {
    /* n:"BrtEndPCDFGRange", */
    T: -1
  },
  225: {
    /* n:"BrtBeginPCDFGDiscrete", */
    T: 1
  },
  226: {
    /* n:"BrtEndPCDFGDiscrete", */
    T: -1
  },
  227: {
    /* n:"BrtBeginPCDSDTupleCache", */
    T: 1
  },
  228: {
    /* n:"BrtEndPCDSDTupleCache", */
    T: -1
  },
  229: {
    /* n:"BrtBeginPCDSDTCEntries", */
    T: 1
  },
  230: {
    /* n:"BrtEndPCDSDTCEntries", */
    T: -1
  },
  231: {
    /* n:"BrtBeginPCDSDTCEMembers", */
    T: 1
  },
  232: {
    /* n:"BrtEndPCDSDTCEMembers", */
    T: -1
  },
  233: {
    /* n:"BrtBeginPCDSDTCEMember", */
    T: 1
  },
  234: {
    /* n:"BrtEndPCDSDTCEMember", */
    T: -1
  },
  235: {
    /* n:"BrtBeginPCDSDTCQueries", */
    T: 1
  },
  236: {
    /* n:"BrtEndPCDSDTCQueries", */
    T: -1
  },
  237: {
    /* n:"BrtBeginPCDSDTCQuery", */
    T: 1
  },
  238: {
    /* n:"BrtEndPCDSDTCQuery", */
    T: -1
  },
  239: {
    /* n:"BrtBeginPCDSDTCSets", */
    T: 1
  },
  240: {
    /* n:"BrtEndPCDSDTCSets", */
    T: -1
  },
  241: {
    /* n:"BrtBeginPCDSDTCSet", */
    T: 1
  },
  242: {
    /* n:"BrtEndPCDSDTCSet", */
    T: -1
  },
  243: {
    /* n:"BrtBeginPCDCalcItems", */
    T: 1
  },
  244: {
    /* n:"BrtEndPCDCalcItems", */
    T: -1
  },
  245: {
    /* n:"BrtBeginPCDCalcItem", */
    T: 1
  },
  246: {
    /* n:"BrtEndPCDCalcItem", */
    T: -1
  },
  247: {
    /* n:"BrtBeginPRule", */
    T: 1
  },
  248: {
    /* n:"BrtEndPRule", */
    T: -1
  },
  249: {
    /* n:"BrtBeginPRFilters", */
    T: 1
  },
  250: {
    /* n:"BrtEndPRFilters", */
    T: -1
  },
  251: {
    /* n:"BrtBeginPRFilter", */
    T: 1
  },
  252: {
    /* n:"BrtEndPRFilter", */
    T: -1
  },
  253: {
    /* n:"BrtBeginPNames", */
    T: 1
  },
  254: {
    /* n:"BrtEndPNames", */
    T: -1
  },
  255: {
    /* n:"BrtBeginPName", */
    T: 1
  },
  256: {
    /* n:"BrtEndPName", */
    T: -1
  },
  257: {
    /* n:"BrtBeginPNPairs", */
    T: 1
  },
  258: {
    /* n:"BrtEndPNPairs", */
    T: -1
  },
  259: {
    /* n:"BrtBeginPNPair", */
    T: 1
  },
  260: {
    /* n:"BrtEndPNPair", */
    T: -1
  },
  261: {
    /* n:"BrtBeginECWebProps", */
    T: 1
  },
  262: {
    /* n:"BrtEndECWebProps", */
    T: -1
  },
  263: {
    /* n:"BrtBeginEcWpTables", */
    T: 1
  },
  264: {
    /* n:"BrtEndECWPTables", */
    T: -1
  },
  265: {
    /* n:"BrtBeginECParams", */
    T: 1
  },
  266: {
    /* n:"BrtEndECParams", */
    T: -1
  },
  267: {
    /* n:"BrtBeginECParam", */
    T: 1
  },
  268: {
    /* n:"BrtEndECParam", */
    T: -1
  },
  269: {
    /* n:"BrtBeginPCDKPIs", */
    T: 1
  },
  270: {
    /* n:"BrtEndPCDKPIs", */
    T: -1
  },
  271: {
    /* n:"BrtBeginPCDKPI", */
    T: 1
  },
  272: {
    /* n:"BrtEndPCDKPI", */
    T: -1
  },
  273: {
    /* n:"BrtBeginDims", */
    T: 1
  },
  274: {
    /* n:"BrtEndDims", */
    T: -1
  },
  275: {
    /* n:"BrtBeginDim", */
    T: 1
  },
  276: {
    /* n:"BrtEndDim", */
    T: -1
  },
  277: {
    /* n:"BrtIndexPartEnd" */
  },
  278: {
    /* n:"BrtBeginStyleSheet", */
    T: 1
  },
  279: {
    /* n:"BrtEndStyleSheet", */
    T: -1
  },
  280: {
    /* n:"BrtBeginSXView", */
    T: 1
  },
  281: {
    /* n:"BrtEndSXVI", */
    T: -1
  },
  282: {
    /* n:"BrtBeginSXVI", */
    T: 1
  },
  283: {
    /* n:"BrtBeginSXVIs", */
    T: 1
  },
  284: {
    /* n:"BrtEndSXVIs", */
    T: -1
  },
  285: {
    /* n:"BrtBeginSXVD", */
    T: 1
  },
  286: {
    /* n:"BrtEndSXVD", */
    T: -1
  },
  287: {
    /* n:"BrtBeginSXVDs", */
    T: 1
  },
  288: {
    /* n:"BrtEndSXVDs", */
    T: -1
  },
  289: {
    /* n:"BrtBeginSXPI", */
    T: 1
  },
  290: {
    /* n:"BrtEndSXPI", */
    T: -1
  },
  291: {
    /* n:"BrtBeginSXPIs", */
    T: 1
  },
  292: {
    /* n:"BrtEndSXPIs", */
    T: -1
  },
  293: {
    /* n:"BrtBeginSXDI", */
    T: 1
  },
  294: {
    /* n:"BrtEndSXDI", */
    T: -1
  },
  295: {
    /* n:"BrtBeginSXDIs", */
    T: 1
  },
  296: {
    /* n:"BrtEndSXDIs", */
    T: -1
  },
  297: {
    /* n:"BrtBeginSXLI", */
    T: 1
  },
  298: {
    /* n:"BrtEndSXLI", */
    T: -1
  },
  299: {
    /* n:"BrtBeginSXLIRws", */
    T: 1
  },
  300: {
    /* n:"BrtEndSXLIRws", */
    T: -1
  },
  301: {
    /* n:"BrtBeginSXLICols", */
    T: 1
  },
  302: {
    /* n:"BrtEndSXLICols", */
    T: -1
  },
  303: {
    /* n:"BrtBeginSXFormat", */
    T: 1
  },
  304: {
    /* n:"BrtEndSXFormat", */
    T: -1
  },
  305: {
    /* n:"BrtBeginSXFormats", */
    T: 1
  },
  306: {
    /* n:"BrtEndSxFormats", */
    T: -1
  },
  307: {
    /* n:"BrtBeginSxSelect", */
    T: 1
  },
  308: {
    /* n:"BrtEndSxSelect", */
    T: -1
  },
  309: {
    /* n:"BrtBeginISXVDRws", */
    T: 1
  },
  310: {
    /* n:"BrtEndISXVDRws", */
    T: -1
  },
  311: {
    /* n:"BrtBeginISXVDCols", */
    T: 1
  },
  312: {
    /* n:"BrtEndISXVDCols", */
    T: -1
  },
  313: {
    /* n:"BrtEndSXLocation", */
    T: -1
  },
  314: {
    /* n:"BrtBeginSXLocation", */
    T: 1
  },
  315: {
    /* n:"BrtEndSXView", */
    T: -1
  },
  316: {
    /* n:"BrtBeginSXTHs", */
    T: 1
  },
  317: {
    /* n:"BrtEndSXTHs", */
    T: -1
  },
  318: {
    /* n:"BrtBeginSXTH", */
    T: 1
  },
  319: {
    /* n:"BrtEndSXTH", */
    T: -1
  },
  320: {
    /* n:"BrtBeginISXTHRws", */
    T: 1
  },
  321: {
    /* n:"BrtEndISXTHRws", */
    T: -1
  },
  322: {
    /* n:"BrtBeginISXTHCols", */
    T: 1
  },
  323: {
    /* n:"BrtEndISXTHCols", */
    T: -1
  },
  324: {
    /* n:"BrtBeginSXTDMPS", */
    T: 1
  },
  325: {
    /* n:"BrtEndSXTDMPs", */
    T: -1
  },
  326: {
    /* n:"BrtBeginSXTDMP", */
    T: 1
  },
  327: {
    /* n:"BrtEndSXTDMP", */
    T: -1
  },
  328: {
    /* n:"BrtBeginSXTHItems", */
    T: 1
  },
  329: {
    /* n:"BrtEndSXTHItems", */
    T: -1
  },
  330: {
    /* n:"BrtBeginSXTHItem", */
    T: 1
  },
  331: {
    /* n:"BrtEndSXTHItem", */
    T: -1
  },
  332: {
    /* n:"BrtBeginMetadata", */
    T: 1
  },
  333: {
    /* n:"BrtEndMetadata", */
    T: -1
  },
  334: {
    /* n:"BrtBeginEsmdtinfo", */
    T: 1
  },
  335: {
    /* n:"BrtMdtinfo", */
    f: y1
  },
  336: {
    /* n:"BrtEndEsmdtinfo", */
    T: -1
  },
  337: {
    /* n:"BrtBeginEsmdb", */
    f: I1,
    T: 1
  },
  338: {
    /* n:"BrtEndEsmdb", */
    T: -1
  },
  339: {
    /* n:"BrtBeginEsfmd", */
    T: 1
  },
  340: {
    /* n:"BrtEndEsfmd", */
    T: -1
  },
  341: {
    /* n:"BrtBeginSingleCells", */
    T: 1
  },
  342: {
    /* n:"BrtEndSingleCells", */
    T: -1
  },
  343: {
    /* n:"BrtBeginList", */
    T: 1
  },
  344: {
    /* n:"BrtEndList", */
    T: -1
  },
  345: {
    /* n:"BrtBeginListCols", */
    T: 1
  },
  346: {
    /* n:"BrtEndListCols", */
    T: -1
  },
  347: {
    /* n:"BrtBeginListCol", */
    T: 1
  },
  348: {
    /* n:"BrtEndListCol", */
    T: -1
  },
  349: {
    /* n:"BrtBeginListXmlCPr", */
    T: 1
  },
  350: {
    /* n:"BrtEndListXmlCPr", */
    T: -1
  },
  351: {
    /* n:"BrtListCCFmla" */
  },
  352: {
    /* n:"BrtListTrFmla" */
  },
  353: {
    /* n:"BrtBeginExternals", */
    T: 1
  },
  354: {
    /* n:"BrtEndExternals", */
    T: -1
  },
  355: {
    /* n:"BrtSupBookSrc", */
    f: f0
  },
  357: {
    /* n:"BrtSupSelf" */
  },
  358: {
    /* n:"BrtSupSame" */
  },
  359: {
    /* n:"BrtSupTabs" */
  },
  360: {
    /* n:"BrtBeginSupBook", */
    T: 1
  },
  361: {
    /* n:"BrtPlaceholderName" */
  },
  362: {
    /* n:"BrtExternSheet", */
    f: Hi
  },
  363: {
    /* n:"BrtExternTableStart" */
  },
  364: {
    /* n:"BrtExternTableEnd" */
  },
  366: {
    /* n:"BrtExternRowHdr" */
  },
  367: {
    /* n:"BrtExternCellBlank" */
  },
  368: {
    /* n:"BrtExternCellReal" */
  },
  369: {
    /* n:"BrtExternCellBool" */
  },
  370: {
    /* n:"BrtExternCellError" */
  },
  371: {
    /* n:"BrtExternCellString" */
  },
  372: {
    /* n:"BrtBeginEsmdx", */
    T: 1
  },
  373: {
    /* n:"BrtEndEsmdx", */
    T: -1
  },
  374: {
    /* n:"BrtBeginMdxSet", */
    T: 1
  },
  375: {
    /* n:"BrtEndMdxSet", */
    T: -1
  },
  376: {
    /* n:"BrtBeginMdxMbrProp", */
    T: 1
  },
  377: {
    /* n:"BrtEndMdxMbrProp", */
    T: -1
  },
  378: {
    /* n:"BrtBeginMdxKPI", */
    T: 1
  },
  379: {
    /* n:"BrtEndMdxKPI", */
    T: -1
  },
  380: {
    /* n:"BrtBeginEsstr", */
    T: 1
  },
  381: {
    /* n:"BrtEndEsstr", */
    T: -1
  },
  382: {
    /* n:"BrtBeginPRFItem", */
    T: 1
  },
  383: {
    /* n:"BrtEndPRFItem", */
    T: -1
  },
  384: {
    /* n:"BrtBeginPivotCacheIDs", */
    T: 1
  },
  385: {
    /* n:"BrtEndPivotCacheIDs", */
    T: -1
  },
  386: {
    /* n:"BrtBeginPivotCacheID", */
    T: 1
  },
  387: {
    /* n:"BrtEndPivotCacheID", */
    T: -1
  },
  388: {
    /* n:"BrtBeginISXVIs", */
    T: 1
  },
  389: {
    /* n:"BrtEndISXVIs", */
    T: -1
  },
  390: {
    /* n:"BrtBeginColInfos", */
    T: 1
  },
  391: {
    /* n:"BrtEndColInfos", */
    T: -1
  },
  392: {
    /* n:"BrtBeginRwBrk", */
    T: 1
  },
  393: {
    /* n:"BrtEndRwBrk", */
    T: -1
  },
  394: {
    /* n:"BrtBeginColBrk", */
    T: 1
  },
  395: {
    /* n:"BrtEndColBrk", */
    T: -1
  },
  396: {
    /* n:"BrtBrk" */
  },
  397: {
    /* n:"BrtUserBookView" */
  },
  398: {
    /* n:"BrtInfo" */
  },
  399: {
    /* n:"BrtCUsr" */
  },
  400: {
    /* n:"BrtUsr" */
  },
  401: {
    /* n:"BrtBeginUsers", */
    T: 1
  },
  403: {
    /* n:"BrtEOF" */
  },
  404: {
    /* n:"BrtUCR" */
  },
  405: {
    /* n:"BrtRRInsDel" */
  },
  406: {
    /* n:"BrtRREndInsDel" */
  },
  407: {
    /* n:"BrtRRMove" */
  },
  408: {
    /* n:"BrtRREndMove" */
  },
  409: {
    /* n:"BrtRRChgCell" */
  },
  410: {
    /* n:"BrtRREndChgCell" */
  },
  411: {
    /* n:"BrtRRHeader" */
  },
  412: {
    /* n:"BrtRRUserView" */
  },
  413: {
    /* n:"BrtRRRenSheet" */
  },
  414: {
    /* n:"BrtRRInsertSh" */
  },
  415: {
    /* n:"BrtRRDefName" */
  },
  416: {
    /* n:"BrtRRNote" */
  },
  417: {
    /* n:"BrtRRConflict" */
  },
  418: {
    /* n:"BrtRRTQSIF" */
  },
  419: {
    /* n:"BrtRRFormat" */
  },
  420: {
    /* n:"BrtRREndFormat" */
  },
  421: {
    /* n:"BrtRRAutoFmt" */
  },
  422: {
    /* n:"BrtBeginUserShViews", */
    T: 1
  },
  423: {
    /* n:"BrtBeginUserShView", */
    T: 1
  },
  424: {
    /* n:"BrtEndUserShView", */
    T: -1
  },
  425: {
    /* n:"BrtEndUserShViews", */
    T: -1
  },
  426: {
    /* n:"BrtArrFmla", */
    f: ox
  },
  427: {
    /* n:"BrtShrFmla", */
    f: lx
  },
  428: {
    /* n:"BrtTable" */
  },
  429: {
    /* n:"BrtBeginExtConnections", */
    T: 1
  },
  430: {
    /* n:"BrtEndExtConnections", */
    T: -1
  },
  431: {
    /* n:"BrtBeginPCDCalcMems", */
    T: 1
  },
  432: {
    /* n:"BrtEndPCDCalcMems", */
    T: -1
  },
  433: {
    /* n:"BrtBeginPCDCalcMem", */
    T: 1
  },
  434: {
    /* n:"BrtEndPCDCalcMem", */
    T: -1
  },
  435: {
    /* n:"BrtBeginPCDHGLevels", */
    T: 1
  },
  436: {
    /* n:"BrtEndPCDHGLevels", */
    T: -1
  },
  437: {
    /* n:"BrtBeginPCDHGLevel", */
    T: 1
  },
  438: {
    /* n:"BrtEndPCDHGLevel", */
    T: -1
  },
  439: {
    /* n:"BrtBeginPCDHGLGroups", */
    T: 1
  },
  440: {
    /* n:"BrtEndPCDHGLGroups", */
    T: -1
  },
  441: {
    /* n:"BrtBeginPCDHGLGroup", */
    T: 1
  },
  442: {
    /* n:"BrtEndPCDHGLGroup", */
    T: -1
  },
  443: {
    /* n:"BrtBeginPCDHGLGMembers", */
    T: 1
  },
  444: {
    /* n:"BrtEndPCDHGLGMembers", */
    T: -1
  },
  445: {
    /* n:"BrtBeginPCDHGLGMember", */
    T: 1
  },
  446: {
    /* n:"BrtEndPCDHGLGMember", */
    T: -1
  },
  447: {
    /* n:"BrtBeginQSI", */
    T: 1
  },
  448: {
    /* n:"BrtEndQSI", */
    T: -1
  },
  449: {
    /* n:"BrtBeginQSIR", */
    T: 1
  },
  450: {
    /* n:"BrtEndQSIR", */
    T: -1
  },
  451: {
    /* n:"BrtBeginDeletedNames", */
    T: 1
  },
  452: {
    /* n:"BrtEndDeletedNames", */
    T: -1
  },
  453: {
    /* n:"BrtBeginDeletedName", */
    T: 1
  },
  454: {
    /* n:"BrtEndDeletedName", */
    T: -1
  },
  455: {
    /* n:"BrtBeginQSIFs", */
    T: 1
  },
  456: {
    /* n:"BrtEndQSIFs", */
    T: -1
  },
  457: {
    /* n:"BrtBeginQSIF", */
    T: 1
  },
  458: {
    /* n:"BrtEndQSIF", */
    T: -1
  },
  459: {
    /* n:"BrtBeginAutoSortScope", */
    T: 1
  },
  460: {
    /* n:"BrtEndAutoSortScope", */
    T: -1
  },
  461: {
    /* n:"BrtBeginConditionalFormatting", */
    T: 1
  },
  462: {
    /* n:"BrtEndConditionalFormatting", */
    T: -1
  },
  463: {
    /* n:"BrtBeginCFRule", */
    T: 1
  },
  464: {
    /* n:"BrtEndCFRule", */
    T: -1
  },
  465: {
    /* n:"BrtBeginIconSet", */
    T: 1
  },
  466: {
    /* n:"BrtEndIconSet", */
    T: -1
  },
  467: {
    /* n:"BrtBeginDatabar", */
    T: 1
  },
  468: {
    /* n:"BrtEndDatabar", */
    T: -1
  },
  469: {
    /* n:"BrtBeginColorScale", */
    T: 1
  },
  470: {
    /* n:"BrtEndColorScale", */
    T: -1
  },
  471: {
    /* n:"BrtCFVO" */
  },
  472: {
    /* n:"BrtExternValueMeta" */
  },
  473: {
    /* n:"BrtBeginColorPalette", */
    T: 1
  },
  474: {
    /* n:"BrtEndColorPalette", */
    T: -1
  },
  475: {
    /* n:"BrtIndexedColor" */
  },
  476: {
    /* n:"BrtMargins", */
    f: hx
  },
  477: {
    /* n:"BrtPrintOptions" */
  },
  478: {
    /* n:"BrtPageSetup" */
  },
  479: {
    /* n:"BrtBeginHeaderFooter", */
    T: 1
  },
  480: {
    /* n:"BrtEndHeaderFooter", */
    T: -1
  },
  481: {
    /* n:"BrtBeginSXCrtFormat", */
    T: 1
  },
  482: {
    /* n:"BrtEndSXCrtFormat", */
    T: -1
  },
  483: {
    /* n:"BrtBeginSXCrtFormats", */
    T: 1
  },
  484: {
    /* n:"BrtEndSXCrtFormats", */
    T: -1
  },
  485: {
    /* n:"BrtWsFmtInfo", */
    f: Hh
  },
  486: {
    /* n:"BrtBeginMgs", */
    T: 1
  },
  487: {
    /* n:"BrtEndMGs", */
    T: -1
  },
  488: {
    /* n:"BrtBeginMGMaps", */
    T: 1
  },
  489: {
    /* n:"BrtEndMGMaps", */
    T: -1
  },
  490: {
    /* n:"BrtBeginMG", */
    T: 1
  },
  491: {
    /* n:"BrtEndMG", */
    T: -1
  },
  492: {
    /* n:"BrtBeginMap", */
    T: 1
  },
  493: {
    /* n:"BrtEndMap", */
    T: -1
  },
  494: {
    /* n:"BrtHLink", */
    f: fx
  },
  495: {
    /* n:"BrtBeginDCon", */
    T: 1
  },
  496: {
    /* n:"BrtEndDCon", */
    T: -1
  },
  497: {
    /* n:"BrtBeginDRefs", */
    T: 1
  },
  498: {
    /* n:"BrtEndDRefs", */
    T: -1
  },
  499: {
    /* n:"BrtDRef" */
  },
  500: {
    /* n:"BrtBeginScenMan", */
    T: 1
  },
  501: {
    /* n:"BrtEndScenMan", */
    T: -1
  },
  502: {
    /* n:"BrtBeginSct", */
    T: 1
  },
  503: {
    /* n:"BrtEndSct", */
    T: -1
  },
  504: {
    /* n:"BrtSlc" */
  },
  505: {
    /* n:"BrtBeginDXFs", */
    T: 1
  },
  506: {
    /* n:"BrtEndDXFs", */
    T: -1
  },
  507: {
    /* n:"BrtDXF" */
  },
  508: {
    /* n:"BrtBeginTableStyles", */
    T: 1
  },
  509: {
    /* n:"BrtEndTableStyles", */
    T: -1
  },
  510: {
    /* n:"BrtBeginTableStyle", */
    T: 1
  },
  511: {
    /* n:"BrtEndTableStyle", */
    T: -1
  },
  512: {
    /* n:"BrtTableStyleElement" */
  },
  513: {
    /* n:"BrtTableStyleClient" */
  },
  514: {
    /* n:"BrtBeginVolDeps", */
    T: 1
  },
  515: {
    /* n:"BrtEndVolDeps", */
    T: -1
  },
  516: {
    /* n:"BrtBeginVolType", */
    T: 1
  },
  517: {
    /* n:"BrtEndVolType", */
    T: -1
  },
  518: {
    /* n:"BrtBeginVolMain", */
    T: 1
  },
  519: {
    /* n:"BrtEndVolMain", */
    T: -1
  },
  520: {
    /* n:"BrtBeginVolTopic", */
    T: 1
  },
  521: {
    /* n:"BrtEndVolTopic", */
    T: -1
  },
  522: {
    /* n:"BrtVolSubtopic" */
  },
  523: {
    /* n:"BrtVolRef" */
  },
  524: {
    /* n:"BrtVolNum" */
  },
  525: {
    /* n:"BrtVolErr" */
  },
  526: {
    /* n:"BrtVolStr" */
  },
  527: {
    /* n:"BrtVolBool" */
  },
  528: {
    /* n:"BrtBeginCalcChain$", */
    T: 1
  },
  529: {
    /* n:"BrtEndCalcChain$", */
    T: -1
  },
  530: {
    /* n:"BrtBeginSortState", */
    T: 1
  },
  531: {
    /* n:"BrtEndSortState", */
    T: -1
  },
  532: {
    /* n:"BrtBeginSortCond", */
    T: 1
  },
  533: {
    /* n:"BrtEndSortCond", */
    T: -1
  },
  534: {
    /* n:"BrtBookProtection" */
  },
  535: {
    /* n:"BrtSheetProtection" */
  },
  536: {
    /* n:"BrtRangeProtection" */
  },
  537: {
    /* n:"BrtPhoneticInfo" */
  },
  538: {
    /* n:"BrtBeginECTxtWiz", */
    T: 1
  },
  539: {
    /* n:"BrtEndECTxtWiz", */
    T: -1
  },
  540: {
    /* n:"BrtBeginECTWFldInfoLst", */
    T: 1
  },
  541: {
    /* n:"BrtEndECTWFldInfoLst", */
    T: -1
  },
  542: {
    /* n:"BrtBeginECTwFldInfo", */
    T: 1
  },
  548: {
    /* n:"BrtFileSharing" */
  },
  549: {
    /* n:"BrtOleSize" */
  },
  550: {
    /* n:"BrtDrawing", */
    f: f0
  },
  551: {
    /* n:"BrtLegacyDrawing", */
    f: Vt
  },
  552: {
    /* n:"BrtLegacyDrawingHF" */
  },
  553: {
    /* n:"BrtWebOpt" */
  },
  554: {
    /* n:"BrtBeginWebPubItems", */
    T: 1
  },
  555: {
    /* n:"BrtEndWebPubItems", */
    T: -1
  },
  556: {
    /* n:"BrtBeginWebPubItem", */
    T: 1
  },
  557: {
    /* n:"BrtEndWebPubItem", */
    T: -1
  },
  558: {
    /* n:"BrtBeginSXCondFmt", */
    T: 1
  },
  559: {
    /* n:"BrtEndSXCondFmt", */
    T: -1
  },
  560: {
    /* n:"BrtBeginSXCondFmts", */
    T: 1
  },
  561: {
    /* n:"BrtEndSXCondFmts", */
    T: -1
  },
  562: {
    /* n:"BrtBkHim" */
  },
  564: {
    /* n:"BrtColor" */
  },
  565: {
    /* n:"BrtBeginIndexedColors", */
    T: 1
  },
  566: {
    /* n:"BrtEndIndexedColors", */
    T: -1
  },
  569: {
    /* n:"BrtBeginMRUColors", */
    T: 1
  },
  570: {
    /* n:"BrtEndMRUColors", */
    T: -1
  },
  572: {
    /* n:"BrtMRUColor" */
  },
  573: {
    /* n:"BrtBeginDVals", */
    T: 1
  },
  574: {
    /* n:"BrtEndDVals", */
    T: -1
  },
  577: {
    /* n:"BrtSupNameStart" */
  },
  578: {
    /* n:"BrtSupNameValueStart" */
  },
  579: {
    /* n:"BrtSupNameValueEnd" */
  },
  580: {
    /* n:"BrtSupNameNum" */
  },
  581: {
    /* n:"BrtSupNameErr" */
  },
  582: {
    /* n:"BrtSupNameSt" */
  },
  583: {
    /* n:"BrtSupNameNil" */
  },
  584: {
    /* n:"BrtSupNameBool" */
  },
  585: {
    /* n:"BrtSupNameFmla" */
  },
  586: {
    /* n:"BrtSupNameBits" */
  },
  587: {
    /* n:"BrtSupNameEnd" */
  },
  588: {
    /* n:"BrtEndSupBook", */
    T: -1
  },
  589: {
    /* n:"BrtCellSmartTagProperty" */
  },
  590: {
    /* n:"BrtBeginCellSmartTag", */
    T: 1
  },
  591: {
    /* n:"BrtEndCellSmartTag", */
    T: -1
  },
  592: {
    /* n:"BrtBeginCellSmartTags", */
    T: 1
  },
  593: {
    /* n:"BrtEndCellSmartTags", */
    T: -1
  },
  594: {
    /* n:"BrtBeginSmartTags", */
    T: 1
  },
  595: {
    /* n:"BrtEndSmartTags", */
    T: -1
  },
  596: {
    /* n:"BrtSmartTagType" */
  },
  597: {
    /* n:"BrtBeginSmartTagTypes", */
    T: 1
  },
  598: {
    /* n:"BrtEndSmartTagTypes", */
    T: -1
  },
  599: {
    /* n:"BrtBeginSXFilters", */
    T: 1
  },
  600: {
    /* n:"BrtEndSXFilters", */
    T: -1
  },
  601: {
    /* n:"BrtBeginSXFILTER", */
    T: 1
  },
  602: {
    /* n:"BrtEndSXFilter", */
    T: -1
  },
  603: {
    /* n:"BrtBeginFills", */
    T: 1
  },
  604: {
    /* n:"BrtEndFills", */
    T: -1
  },
  605: {
    /* n:"BrtBeginCellWatches", */
    T: 1
  },
  606: {
    /* n:"BrtEndCellWatches", */
    T: -1
  },
  607: {
    /* n:"BrtCellWatch" */
  },
  608: {
    /* n:"BrtBeginCRErrs", */
    T: 1
  },
  609: {
    /* n:"BrtEndCRErrs", */
    T: -1
  },
  610: {
    /* n:"BrtCrashRecErr" */
  },
  611: {
    /* n:"BrtBeginFonts", */
    T: 1
  },
  612: {
    /* n:"BrtEndFonts", */
    T: -1
  },
  613: {
    /* n:"BrtBeginBorders", */
    T: 1
  },
  614: {
    /* n:"BrtEndBorders", */
    T: -1
  },
  615: {
    /* n:"BrtBeginFmts", */
    T: 1
  },
  616: {
    /* n:"BrtEndFmts", */
    T: -1
  },
  617: {
    /* n:"BrtBeginCellXFs", */
    T: 1
  },
  618: {
    /* n:"BrtEndCellXFs", */
    T: -1
  },
  619: {
    /* n:"BrtBeginStyles", */
    T: 1
  },
  620: {
    /* n:"BrtEndStyles", */
    T: -1
  },
  625: {
    /* n:"BrtBigName" */
  },
  626: {
    /* n:"BrtBeginCellStyleXFs", */
    T: 1
  },
  627: {
    /* n:"BrtEndCellStyleXFs", */
    T: -1
  },
  628: {
    /* n:"BrtBeginComments", */
    T: 1
  },
  629: {
    /* n:"BrtEndComments", */
    T: -1
  },
  630: {
    /* n:"BrtBeginCommentAuthors", */
    T: 1
  },
  631: {
    /* n:"BrtEndCommentAuthors", */
    T: -1
  },
  632: {
    /* n:"BrtCommentAuthor", */
    f: G1
  },
  633: {
    /* n:"BrtBeginCommentList", */
    T: 1
  },
  634: {
    /* n:"BrtEndCommentList", */
    T: -1
  },
  635: {
    /* n:"BrtBeginComment", */
    T: 1,
    f: V1
  },
  636: {
    /* n:"BrtEndComment", */
    T: -1
  },
  637: {
    /* n:"BrtCommentText", */
    f: xc
  },
  638: {
    /* n:"BrtBeginOleObjects", */
    T: 1
  },
  639: {
    /* n:"BrtOleObject" */
  },
  640: {
    /* n:"BrtEndOleObjects", */
    T: -1
  },
  641: {
    /* n:"BrtBeginSxrules", */
    T: 1
  },
  642: {
    /* n:"BrtEndSxRules", */
    T: -1
  },
  643: {
    /* n:"BrtBeginActiveXControls", */
    T: 1
  },
  644: {
    /* n:"BrtActiveX" */
  },
  645: {
    /* n:"BrtEndActiveXControls", */
    T: -1
  },
  646: {
    /* n:"BrtBeginPCDSDTCEMembersSortBy", */
    T: 1
  },
  648: {
    /* n:"BrtBeginCellIgnoreECs", */
    T: 1
  },
  649: {
    /* n:"BrtCellIgnoreEC" */
  },
  650: {
    /* n:"BrtEndCellIgnoreECs", */
    T: -1
  },
  651: {
    /* n:"BrtCsProp", */
    f: kx
  },
  652: {
    /* n:"BrtCsPageSetup" */
  },
  653: {
    /* n:"BrtBeginUserCsViews", */
    T: 1
  },
  654: {
    /* n:"BrtEndUserCsViews", */
    T: -1
  },
  655: {
    /* n:"BrtBeginUserCsView", */
    T: 1
  },
  656: {
    /* n:"BrtEndUserCsView", */
    T: -1
  },
  657: {
    /* n:"BrtBeginPcdSFCIEntries", */
    T: 1
  },
  658: {
    /* n:"BrtEndPCDSFCIEntries", */
    T: -1
  },
  659: {
    /* n:"BrtPCDSFCIEntry" */
  },
  660: {
    /* n:"BrtBeginListParts", */
    T: 1
  },
  661: {
    /* n:"BrtListPart" */
  },
  662: {
    /* n:"BrtEndListParts", */
    T: -1
  },
  663: {
    /* n:"BrtSheetCalcProp" */
  },
  664: {
    /* n:"BrtBeginFnGroup", */
    T: 1
  },
  665: {
    /* n:"BrtFnGroup" */
  },
  666: {
    /* n:"BrtEndFnGroup", */
    T: -1
  },
  667: {
    /* n:"BrtSupAddin" */
  },
  668: {
    /* n:"BrtSXTDMPOrder" */
  },
  669: {
    /* n:"BrtCsProtection" */
  },
  671: {
    /* n:"BrtBeginWsSortMap", */
    T: 1
  },
  672: {
    /* n:"BrtEndWsSortMap", */
    T: -1
  },
  673: {
    /* n:"BrtBeginRRSort", */
    T: 1
  },
  674: {
    /* n:"BrtEndRRSort", */
    T: -1
  },
  675: {
    /* n:"BrtRRSortItem" */
  },
  676: {
    /* n:"BrtFileSharingIso" */
  },
  677: {
    /* n:"BrtBookProtectionIso" */
  },
  678: {
    /* n:"BrtSheetProtectionIso" */
  },
  679: {
    /* n:"BrtCsProtectionIso" */
  },
  680: {
    /* n:"BrtRangeProtectionIso" */
  },
  681: {
    /* n:"BrtDValList" */
  },
  1024: {
    /* n:"BrtRwDescent" */
  },
  1025: {
    /* n:"BrtKnownFonts" */
  },
  1026: {
    /* n:"BrtBeginSXTupleSet", */
    T: 1
  },
  1027: {
    /* n:"BrtEndSXTupleSet", */
    T: -1
  },
  1028: {
    /* n:"BrtBeginSXTupleSetHeader", */
    T: 1
  },
  1029: {
    /* n:"BrtEndSXTupleSetHeader", */
    T: -1
  },
  1030: {
    /* n:"BrtSXTupleSetHeaderItem" */
  },
  1031: {
    /* n:"BrtBeginSXTupleSetData", */
    T: 1
  },
  1032: {
    /* n:"BrtEndSXTupleSetData", */
    T: -1
  },
  1033: {
    /* n:"BrtBeginSXTupleSetRow", */
    T: 1
  },
  1034: {
    /* n:"BrtEndSXTupleSetRow", */
    T: -1
  },
  1035: {
    /* n:"BrtSXTupleSetRowItem" */
  },
  1036: {
    /* n:"BrtNameExt" */
  },
  1037: {
    /* n:"BrtPCDH14" */
  },
  1038: {
    /* n:"BrtBeginPCDCalcMem14", */
    T: 1
  },
  1039: {
    /* n:"BrtEndPCDCalcMem14", */
    T: -1
  },
  1040: {
    /* n:"BrtSXTH14" */
  },
  1041: {
    /* n:"BrtBeginSparklineGroup", */
    T: 1
  },
  1042: {
    /* n:"BrtEndSparklineGroup", */
    T: -1
  },
  1043: {
    /* n:"BrtSparkline" */
  },
  1044: {
    /* n:"BrtSXDI14" */
  },
  1045: {
    /* n:"BrtWsFmtInfoEx14" */
  },
  1046: {
    /* n:"BrtBeginConditionalFormatting14", */
    T: 1
  },
  1047: {
    /* n:"BrtEndConditionalFormatting14", */
    T: -1
  },
  1048: {
    /* n:"BrtBeginCFRule14", */
    T: 1
  },
  1049: {
    /* n:"BrtEndCFRule14", */
    T: -1
  },
  1050: {
    /* n:"BrtCFVO14" */
  },
  1051: {
    /* n:"BrtBeginDatabar14", */
    T: 1
  },
  1052: {
    /* n:"BrtBeginIconSet14", */
    T: 1
  },
  1053: {
    /* n:"BrtDVal14", */
    f: vx
  },
  1054: {
    /* n:"BrtBeginDVals14", */
    T: 1
  },
  1055: {
    /* n:"BrtColor14" */
  },
  1056: {
    /* n:"BrtBeginSparklines", */
    T: 1
  },
  1057: {
    /* n:"BrtEndSparklines", */
    T: -1
  },
  1058: {
    /* n:"BrtBeginSparklineGroups", */
    T: 1
  },
  1059: {
    /* n:"BrtEndSparklineGroups", */
    T: -1
  },
  1061: {
    /* n:"BrtSXVD14" */
  },
  1062: {
    /* n:"BrtBeginSXView14", */
    T: 1
  },
  1063: {
    /* n:"BrtEndSXView14", */
    T: -1
  },
  1064: {
    /* n:"BrtBeginSXView16", */
    T: 1
  },
  1065: {
    /* n:"BrtEndSXView16", */
    T: -1
  },
  1066: {
    /* n:"BrtBeginPCD14", */
    T: 1
  },
  1067: {
    /* n:"BrtEndPCD14", */
    T: -1
  },
  1068: {
    /* n:"BrtBeginExtConn14", */
    T: 1
  },
  1069: {
    /* n:"BrtEndExtConn14", */
    T: -1
  },
  1070: {
    /* n:"BrtBeginSlicerCacheIDs", */
    T: 1
  },
  1071: {
    /* n:"BrtEndSlicerCacheIDs", */
    T: -1
  },
  1072: {
    /* n:"BrtBeginSlicerCacheID", */
    T: 1
  },
  1073: {
    /* n:"BrtEndSlicerCacheID", */
    T: -1
  },
  1075: {
    /* n:"BrtBeginSlicerCache", */
    T: 1
  },
  1076: {
    /* n:"BrtEndSlicerCache", */
    T: -1
  },
  1077: {
    /* n:"BrtBeginSlicerCacheDef", */
    T: 1
  },
  1078: {
    /* n:"BrtEndSlicerCacheDef", */
    T: -1
  },
  1079: {
    /* n:"BrtBeginSlicersEx", */
    T: 1
  },
  1080: {
    /* n:"BrtEndSlicersEx", */
    T: -1
  },
  1081: {
    /* n:"BrtBeginSlicerEx", */
    T: 1
  },
  1082: {
    /* n:"BrtEndSlicerEx", */
    T: -1
  },
  1083: {
    /* n:"BrtBeginSlicer", */
    T: 1
  },
  1084: {
    /* n:"BrtEndSlicer", */
    T: -1
  },
  1085: {
    /* n:"BrtSlicerCachePivotTables" */
  },
  1086: {
    /* n:"BrtBeginSlicerCacheOlapImpl", */
    T: 1
  },
  1087: {
    /* n:"BrtEndSlicerCacheOlapImpl", */
    T: -1
  },
  1088: {
    /* n:"BrtBeginSlicerCacheLevelsData", */
    T: 1
  },
  1089: {
    /* n:"BrtEndSlicerCacheLevelsData", */
    T: -1
  },
  1090: {
    /* n:"BrtBeginSlicerCacheLevelData", */
    T: 1
  },
  1091: {
    /* n:"BrtEndSlicerCacheLevelData", */
    T: -1
  },
  1092: {
    /* n:"BrtBeginSlicerCacheSiRanges", */
    T: 1
  },
  1093: {
    /* n:"BrtEndSlicerCacheSiRanges", */
    T: -1
  },
  1094: {
    /* n:"BrtBeginSlicerCacheSiRange", */
    T: 1
  },
  1095: {
    /* n:"BrtEndSlicerCacheSiRange", */
    T: -1
  },
  1096: {
    /* n:"BrtSlicerCacheOlapItem" */
  },
  1097: {
    /* n:"BrtBeginSlicerCacheSelections", */
    T: 1
  },
  1098: {
    /* n:"BrtSlicerCacheSelection" */
  },
  1099: {
    /* n:"BrtEndSlicerCacheSelections", */
    T: -1
  },
  1100: {
    /* n:"BrtBeginSlicerCacheNative", */
    T: 1
  },
  1101: {
    /* n:"BrtEndSlicerCacheNative", */
    T: -1
  },
  1102: {
    /* n:"BrtSlicerCacheNativeItem" */
  },
  1103: {
    /* n:"BrtRangeProtection14" */
  },
  1104: {
    /* n:"BrtRangeProtectionIso14" */
  },
  1105: {
    /* n:"BrtCellIgnoreEC14" */
  },
  1111: {
    /* n:"BrtList14" */
  },
  1112: {
    /* n:"BrtCFIcon" */
  },
  1113: {
    /* n:"BrtBeginSlicerCachesPivotCacheIDs", */
    T: 1
  },
  1114: {
    /* n:"BrtEndSlicerCachesPivotCacheIDs", */
    T: -1
  },
  1115: {
    /* n:"BrtBeginSlicers", */
    T: 1
  },
  1116: {
    /* n:"BrtEndSlicers", */
    T: -1
  },
  1117: {
    /* n:"BrtWbProp14" */
  },
  1118: {
    /* n:"BrtBeginSXEdit", */
    T: 1
  },
  1119: {
    /* n:"BrtEndSXEdit", */
    T: -1
  },
  1120: {
    /* n:"BrtBeginSXEdits", */
    T: 1
  },
  1121: {
    /* n:"BrtEndSXEdits", */
    T: -1
  },
  1122: {
    /* n:"BrtBeginSXChange", */
    T: 1
  },
  1123: {
    /* n:"BrtEndSXChange", */
    T: -1
  },
  1124: {
    /* n:"BrtBeginSXChanges", */
    T: 1
  },
  1125: {
    /* n:"BrtEndSXChanges", */
    T: -1
  },
  1126: {
    /* n:"BrtSXTupleItems" */
  },
  1128: {
    /* n:"BrtBeginSlicerStyle", */
    T: 1
  },
  1129: {
    /* n:"BrtEndSlicerStyle", */
    T: -1
  },
  1130: {
    /* n:"BrtSlicerStyleElement" */
  },
  1131: {
    /* n:"BrtBeginStyleSheetExt14", */
    T: 1
  },
  1132: {
    /* n:"BrtEndStyleSheetExt14", */
    T: -1
  },
  1133: {
    /* n:"BrtBeginSlicerCachesPivotCacheID", */
    T: 1
  },
  1134: {
    /* n:"BrtEndSlicerCachesPivotCacheID", */
    T: -1
  },
  1135: {
    /* n:"BrtBeginConditionalFormattings", */
    T: 1
  },
  1136: {
    /* n:"BrtEndConditionalFormattings", */
    T: -1
  },
  1137: {
    /* n:"BrtBeginPCDCalcMemExt", */
    T: 1
  },
  1138: {
    /* n:"BrtEndPCDCalcMemExt", */
    T: -1
  },
  1139: {
    /* n:"BrtBeginPCDCalcMemsExt", */
    T: 1
  },
  1140: {
    /* n:"BrtEndPCDCalcMemsExt", */
    T: -1
  },
  1141: {
    /* n:"BrtPCDField14" */
  },
  1142: {
    /* n:"BrtBeginSlicerStyles", */
    T: 1
  },
  1143: {
    /* n:"BrtEndSlicerStyles", */
    T: -1
  },
  1144: {
    /* n:"BrtBeginSlicerStyleElements", */
    T: 1
  },
  1145: {
    /* n:"BrtEndSlicerStyleElements", */
    T: -1
  },
  1146: {
    /* n:"BrtCFRuleExt" */
  },
  1147: {
    /* n:"BrtBeginSXCondFmt14", */
    T: 1
  },
  1148: {
    /* n:"BrtEndSXCondFmt14", */
    T: -1
  },
  1149: {
    /* n:"BrtBeginSXCondFmts14", */
    T: 1
  },
  1150: {
    /* n:"BrtEndSXCondFmts14", */
    T: -1
  },
  1152: {
    /* n:"BrtBeginSortCond14", */
    T: 1
  },
  1153: {
    /* n:"BrtEndSortCond14", */
    T: -1
  },
  1154: {
    /* n:"BrtEndDVals14", */
    T: -1
  },
  1155: {
    /* n:"BrtEndIconSet14", */
    T: -1
  },
  1156: {
    /* n:"BrtEndDatabar14", */
    T: -1
  },
  1157: {
    /* n:"BrtBeginColorScale14", */
    T: 1
  },
  1158: {
    /* n:"BrtEndColorScale14", */
    T: -1
  },
  1159: {
    /* n:"BrtBeginSxrules14", */
    T: 1
  },
  1160: {
    /* n:"BrtEndSxrules14", */
    T: -1
  },
  1161: {
    /* n:"BrtBeginPRule14", */
    T: 1
  },
  1162: {
    /* n:"BrtEndPRule14", */
    T: -1
  },
  1163: {
    /* n:"BrtBeginPRFilters14", */
    T: 1
  },
  1164: {
    /* n:"BrtEndPRFilters14", */
    T: -1
  },
  1165: {
    /* n:"BrtBeginPRFilter14", */
    T: 1
  },
  1166: {
    /* n:"BrtEndPRFilter14", */
    T: -1
  },
  1167: {
    /* n:"BrtBeginPRFItem14", */
    T: 1
  },
  1168: {
    /* n:"BrtEndPRFItem14", */
    T: -1
  },
  1169: {
    /* n:"BrtBeginCellIgnoreECs14", */
    T: 1
  },
  1170: {
    /* n:"BrtEndCellIgnoreECs14", */
    T: -1
  },
  1171: {
    /* n:"BrtDxf14" */
  },
  1172: {
    /* n:"BrtBeginDxF14s", */
    T: 1
  },
  1173: {
    /* n:"BrtEndDxf14s", */
    T: -1
  },
  1177: {
    /* n:"BrtFilter14" */
  },
  1178: {
    /* n:"BrtBeginCustomFilters14", */
    T: 1
  },
  1180: {
    /* n:"BrtCustomFilter14" */
  },
  1181: {
    /* n:"BrtIconFilter14" */
  },
  1182: {
    /* n:"BrtPivotCacheConnectionName" */
  },
  2048: {
    /* n:"BrtBeginDecoupledPivotCacheIDs", */
    T: 1
  },
  2049: {
    /* n:"BrtEndDecoupledPivotCacheIDs", */
    T: -1
  },
  2050: {
    /* n:"BrtDecoupledPivotCacheID" */
  },
  2051: {
    /* n:"BrtBeginPivotTableRefs", */
    T: 1
  },
  2052: {
    /* n:"BrtEndPivotTableRefs", */
    T: -1
  },
  2053: {
    /* n:"BrtPivotTableRef" */
  },
  2054: {
    /* n:"BrtSlicerCacheBookPivotTables" */
  },
  2055: {
    /* n:"BrtBeginSxvcells", */
    T: 1
  },
  2056: {
    /* n:"BrtEndSxvcells", */
    T: -1
  },
  2057: {
    /* n:"BrtBeginSxRow", */
    T: 1
  },
  2058: {
    /* n:"BrtEndSxRow", */
    T: -1
  },
  2060: {
    /* n:"BrtPcdCalcMem15" */
  },
  2067: {
    /* n:"BrtQsi15" */
  },
  2068: {
    /* n:"BrtBeginWebExtensions", */
    T: 1
  },
  2069: {
    /* n:"BrtEndWebExtensions", */
    T: -1
  },
  2070: {
    /* n:"BrtWebExtension" */
  },
  2071: {
    /* n:"BrtAbsPath15" */
  },
  2072: {
    /* n:"BrtBeginPivotTableUISettings", */
    T: 1
  },
  2073: {
    /* n:"BrtEndPivotTableUISettings", */
    T: -1
  },
  2075: {
    /* n:"BrtTableSlicerCacheIDs" */
  },
  2076: {
    /* n:"BrtTableSlicerCacheID" */
  },
  2077: {
    /* n:"BrtBeginTableSlicerCache", */
    T: 1
  },
  2078: {
    /* n:"BrtEndTableSlicerCache", */
    T: -1
  },
  2079: {
    /* n:"BrtSxFilter15" */
  },
  2080: {
    /* n:"BrtBeginTimelineCachePivotCacheIDs", */
    T: 1
  },
  2081: {
    /* n:"BrtEndTimelineCachePivotCacheIDs", */
    T: -1
  },
  2082: {
    /* n:"BrtTimelineCachePivotCacheID" */
  },
  2083: {
    /* n:"BrtBeginTimelineCacheIDs", */
    T: 1
  },
  2084: {
    /* n:"BrtEndTimelineCacheIDs", */
    T: -1
  },
  2085: {
    /* n:"BrtBeginTimelineCacheID", */
    T: 1
  },
  2086: {
    /* n:"BrtEndTimelineCacheID", */
    T: -1
  },
  2087: {
    /* n:"BrtBeginTimelinesEx", */
    T: 1
  },
  2088: {
    /* n:"BrtEndTimelinesEx", */
    T: -1
  },
  2089: {
    /* n:"BrtBeginTimelineEx", */
    T: 1
  },
  2090: {
    /* n:"BrtEndTimelineEx", */
    T: -1
  },
  2091: {
    /* n:"BrtWorkBookPr15" */
  },
  2092: {
    /* n:"BrtPCDH15" */
  },
  2093: {
    /* n:"BrtBeginTimelineStyle", */
    T: 1
  },
  2094: {
    /* n:"BrtEndTimelineStyle", */
    T: -1
  },
  2095: {
    /* n:"BrtTimelineStyleElement" */
  },
  2096: {
    /* n:"BrtBeginTimelineStylesheetExt15", */
    T: 1
  },
  2097: {
    /* n:"BrtEndTimelineStylesheetExt15", */
    T: -1
  },
  2098: {
    /* n:"BrtBeginTimelineStyles", */
    T: 1
  },
  2099: {
    /* n:"BrtEndTimelineStyles", */
    T: -1
  },
  2100: {
    /* n:"BrtBeginTimelineStyleElements", */
    T: 1
  },
  2101: {
    /* n:"BrtEndTimelineStyleElements", */
    T: -1
  },
  2102: {
    /* n:"BrtDxf15" */
  },
  2103: {
    /* n:"BrtBeginDxfs15", */
    T: 1
  },
  2104: {
    /* n:"BrtEndDxfs15", */
    T: -1
  },
  2105: {
    /* n:"BrtSlicerCacheHideItemsWithNoData" */
  },
  2106: {
    /* n:"BrtBeginItemUniqueNames", */
    T: 1
  },
  2107: {
    /* n:"BrtEndItemUniqueNames", */
    T: -1
  },
  2108: {
    /* n:"BrtItemUniqueName" */
  },
  2109: {
    /* n:"BrtBeginExtConn15", */
    T: 1
  },
  2110: {
    /* n:"BrtEndExtConn15", */
    T: -1
  },
  2111: {
    /* n:"BrtBeginOledbPr15", */
    T: 1
  },
  2112: {
    /* n:"BrtEndOledbPr15", */
    T: -1
  },
  2113: {
    /* n:"BrtBeginDataFeedPr15", */
    T: 1
  },
  2114: {
    /* n:"BrtEndDataFeedPr15", */
    T: -1
  },
  2115: {
    /* n:"BrtTextPr15" */
  },
  2116: {
    /* n:"BrtRangePr15" */
  },
  2117: {
    /* n:"BrtDbCommand15" */
  },
  2118: {
    /* n:"BrtBeginDbTables15", */
    T: 1
  },
  2119: {
    /* n:"BrtEndDbTables15", */
    T: -1
  },
  2120: {
    /* n:"BrtDbTable15" */
  },
  2121: {
    /* n:"BrtBeginDataModel", */
    T: 1
  },
  2122: {
    /* n:"BrtEndDataModel", */
    T: -1
  },
  2123: {
    /* n:"BrtBeginModelTables", */
    T: 1
  },
  2124: {
    /* n:"BrtEndModelTables", */
    T: -1
  },
  2125: {
    /* n:"BrtModelTable" */
  },
  2126: {
    /* n:"BrtBeginModelRelationships", */
    T: 1
  },
  2127: {
    /* n:"BrtEndModelRelationships", */
    T: -1
  },
  2128: {
    /* n:"BrtModelRelationship" */
  },
  2129: {
    /* n:"BrtBeginECTxtWiz15", */
    T: 1
  },
  2130: {
    /* n:"BrtEndECTxtWiz15", */
    T: -1
  },
  2131: {
    /* n:"BrtBeginECTWFldInfoLst15", */
    T: 1
  },
  2132: {
    /* n:"BrtEndECTWFldInfoLst15", */
    T: -1
  },
  2133: {
    /* n:"BrtBeginECTWFldInfo15", */
    T: 1
  },
  2134: {
    /* n:"BrtFieldListActiveItem" */
  },
  2135: {
    /* n:"BrtPivotCacheIdVersion" */
  },
  2136: {
    /* n:"BrtSXDI15" */
  },
  2137: {
    /* n:"BrtBeginModelTimeGroupings", */
    T: 1
  },
  2138: {
    /* n:"BrtEndModelTimeGroupings", */
    T: -1
  },
  2139: {
    /* n:"BrtBeginModelTimeGrouping", */
    T: 1
  },
  2140: {
    /* n:"BrtEndModelTimeGrouping", */
    T: -1
  },
  2141: {
    /* n:"BrtModelTimeGroupingCalcCol" */
  },
  3072: {
    /* n:"BrtUid" */
  },
  3073: {
    /* n:"BrtRevisionPtr" */
  },
  4096: {
    /* n:"BrtBeginDynamicArrayPr", */
    T: 1
  },
  4097: {
    /* n:"BrtEndDynamicArrayPr", */
    T: -1
  },
  5002: {
    /* n:"BrtBeginRichValueBlock", */
    T: 1
  },
  5003: {
    /* n:"BrtEndRichValueBlock", */
    T: -1
  },
  5081: {
    /* n:"BrtBeginRichFilters", */
    T: 1
  },
  5082: {
    /* n:"BrtEndRichFilters", */
    T: -1
  },
  5083: {
    /* n:"BrtRichFilter" */
  },
  5084: {
    /* n:"BrtBeginRichFilterColumn", */
    T: 1
  },
  5085: {
    /* n:"BrtEndRichFilterColumn", */
    T: -1
  },
  5086: {
    /* n:"BrtBeginCustomRichFilters", */
    T: 1
  },
  5087: {
    /* n:"BrtEndCustomRichFilters", */
    T: -1
  },
  5088: {
    /* n:"BrtCustomRichFilter" */
  },
  5089: {
    /* n:"BrtTop10RichFilter" */
  },
  5090: {
    /* n:"BrtDynamicRichFilter" */
  },
  5092: {
    /* n:"BrtBeginRichSortCondition", */
    T: 1
  },
  5093: {
    /* n:"BrtEndRichSortCondition", */
    T: -1
  },
  5094: {
    /* n:"BrtRichFilterDateGroupItem" */
  },
  5095: {
    /* n:"BrtBeginCalcFeatures", */
    T: 1
  },
  5096: {
    /* n:"BrtEndCalcFeatures", */
    T: -1
  },
  5097: {
    /* n:"BrtCalcFeature" */
  },
  5099: {
    /* n:"BrtExternalLinksPr" */
  },
  65535: { n: "" }
}, u0 = {
  /* [MS-XLS] 2.3 Record Enumeration 2021-08-17 */
  6: {
    /* n:"Formula", */
    f: r0
  },
  10: {
    /* n:"EOF", */
    f: aa
  },
  12: {
    /* n:"CalcCount", */
    f: ze
  },
  //
  13: {
    /* n:"CalcMode", */
    f: ze
  },
  //
  14: {
    /* n:"CalcPrecision", */
    f: $e
  },
  //
  15: {
    /* n:"CalcRefMode", */
    f: $e
  },
  //
  16: {
    /* n:"CalcDelta", */
    f: xr
  },
  //
  17: {
    /* n:"CalcIter", */
    f: $e
  },
  //
  18: {
    /* n:"Protect", */
    f: $e
  },
  19: {
    /* n:"Password", */
    f: ze
  },
  20: {
    /* n:"Header", */
    f: En
  },
  21: {
    /* n:"Footer", */
    f: En
  },
  23: {
    /* n:"ExternSheet", */
    f: Hi
  },
  24: {
    /* n:"Lbl", */
    f: wn
  },
  25: {
    /* n:"WinProtect", */
    f: $e
  },
  26: {
    /* n:"VerticalPageBreaks", */
  },
  27: {
    /* n:"HorizontalPageBreaks", */
  },
  28: {
    /* n:"Note", */
    f: Xo
  },
  29: {
    /* n:"Selection", */
  },
  34: {
    /* n:"Date1904", */
    f: $e
  },
  35: {
    /* n:"ExternName", */
    f: Tn
  },
  38: {
    /* n:"LeftMargin", */
    f: xr
  },
  // *
  39: {
    /* n:"RightMargin", */
    f: xr
  },
  // *
  40: {
    /* n:"TopMargin", */
    f: xr
  },
  // *
  41: {
    /* n:"BottomMargin", */
    f: xr
  },
  // *
  42: {
    /* n:"PrintRowCol", */
    f: $e
  },
  43: {
    /* n:"PrintGrid", */
    f: $e
  },
  47: {
    /* n:"FilePass", */
    f: Yl
  },
  49: {
    /* n:"Font", */
    f: wo
  },
  51: {
    /* n:"PrintSize", */
    f: ze
  },
  60: {
    /* n:"Continue", */
  },
  61: {
    /* n:"Window1", */
    f: ko
  },
  64: {
    /* n:"Backup", */
    f: $e
  },
  65: {
    /* n:"Pane", */
    f: To
  },
  66: {
    /* n:"CodePage", */
    f: ze
  },
  77: {
    /* n:"Pls", */
  },
  80: {
    /* n:"DCon", */
  },
  81: {
    /* n:"DConRef", */
  },
  82: {
    /* n:"DConName", */
  },
  85: {
    /* n:"DefColWidth", */
    f: ze
  },
  89: {
    /* n:"XCT", */
  },
  90: {
    /* n:"CRN", */
  },
  91: {
    /* n:"FileSharing", */
  },
  92: {
    /* n:"WriteAccess", */
    f: uo
  },
  93: {
    /* n:"Obj", */
    f: $o
  },
  94: {
    /* n:"Uncalced", */
  },
  95: {
    /* n:"CalcSaveRecalc", */
    f: $e
  },
  //
  96: {
    /* n:"Template", */
  },
  97: {
    /* n:"Intl", */
  },
  99: {
    /* n:"ObjProtect", */
    f: $e
  },
  125: {
    /* n:"ColInfo", */
    f: Wi
  },
  128: {
    /* n:"Guts", */
    f: Lo
  },
  129: {
    /* n:"WsBool", */
    f: ho
  },
  130: {
    /* n:"GridSet", */
    f: ze
  },
  131: {
    /* n:"HCenter", */
    f: $e
  },
  132: {
    /* n:"VCenter", */
    f: $e
  },
  133: {
    /* n:"BoundSheet8", */
    f: xo
  },
  134: {
    /* n:"WriteProtect", */
  },
  140: {
    /* n:"Country", */
    f: qo
  },
  141: {
    /* n:"HideObj", */
    f: ze
  },
  144: {
    /* n:"Sort", */
  },
  146: {
    /* n:"Palette", */
    f: el
  },
  151: {
    /* n:"Sync", */
  },
  152: {
    /* n:"LPr", */
  },
  153: {
    /* n:"DxGCol", */
  },
  154: {
    /* n:"FnGroupName", */
  },
  155: {
    /* n:"FilterMode", */
  },
  156: {
    /* n:"BuiltInFnGroupCount", */
    f: ze
  },
  157: {
    /* n:"AutoFilterInfo", */
  },
  158: {
    /* n:"AutoFilter", */
  },
  160: {
    /* n:"Scl", */
    f: il
  },
  161: {
    /* n:"Setup", */
    f: al
  },
  174: {
    /* n:"ScenMan", */
  },
  175: {
    /* n:"SCENARIO", */
  },
  176: {
    /* n:"SxView", */
  },
  177: {
    /* n:"Sxvd", */
  },
  178: {
    /* n:"SXVI", */
  },
  180: {
    /* n:"SxIvd", */
  },
  181: {
    /* n:"SXLI", */
  },
  182: {
    /* n:"SXPI", */
  },
  184: {
    /* n:"DocRoute", */
  },
  185: {
    /* n:"RecipName", */
  },
  189: {
    /* n:"MulRk", */
    f: Do
  },
  190: {
    /* n:"MulBlank", */
    f: Io
  },
  193: {
    /* n:"Mms", */
    f: aa
  },
  197: {
    /* n:"SXDI", */
  },
  198: {
    /* n:"SXDB", */
  },
  199: {
    /* n:"SXFDB", */
  },
  200: {
    /* n:"SXDBB", */
  },
  201: {
    /* n:"SXNum", */
  },
  202: {
    /* n:"SxBool", */
    f: $e
  },
  203: {
    /* n:"SxErr", */
  },
  204: {
    /* n:"SXInt", */
  },
  205: {
    /* n:"SXString", */
  },
  206: {
    /* n:"SXDtr", */
  },
  207: {
    /* n:"SxNil", */
  },
  208: {
    /* n:"SXTbl", */
  },
  209: {
    /* n:"SXTBRGIITM", */
  },
  210: {
    /* n:"SxTbpg", */
  },
  211: {
    /* n:"ObProj", */
  },
  213: {
    /* n:"SXStreamID", */
  },
  215: {
    /* n:"DBCell", */
  },
  216: {
    /* n:"SXRng", */
  },
  217: {
    /* n:"SxIsxoper", */
  },
  218: {
    /* n:"BookBool", */
    f: ze
  },
  220: {
    /* n:"DbOrParamQry", */
  },
  221: {
    /* n:"ScenarioProtect", */
    f: $e
  },
  222: {
    /* n:"OleObjectSize", */
  },
  224: {
    /* n:"XF", */
    f: Ro
  },
  225: {
    /* n:"InterfaceHdr", */
    f: lo
  },
  226: {
    /* n:"InterfaceEnd", */
    f: aa
  },
  227: {
    /* n:"SXVS", */
  },
  229: {
    /* n:"MergeCells", */
    f: zo
  },
  233: {
    /* n:"BkHim", */
  },
  235: {
    /* n:"MsoDrawingGroup", */
  },
  236: {
    /* n:"MsoDrawing", */
  },
  237: {
    /* n:"MsoDrawingSelection", */
  },
  239: {
    /* n:"PhoneticInfo", */
  },
  240: {
    /* n:"SxRule", */
  },
  241: {
    /* n:"SXEx", */
  },
  242: {
    /* n:"SxFilt", */
  },
  244: {
    /* n:"SxDXF", */
  },
  245: {
    /* n:"SxItm", */
  },
  246: {
    /* n:"SxName", */
  },
  247: {
    /* n:"SxSelect", */
  },
  248: {
    /* n:"SXPair", */
  },
  249: {
    /* n:"SxFmla", */
  },
  251: {
    /* n:"SxFormat", */
  },
  252: {
    /* n:"SST", */
    f: vo
  },
  253: {
    /* n:"LabelSst", */
    f: Fo
  },
  255: {
    /* n:"ExtSST", */
    f: po
  },
  256: {
    /* n:"SXVDEx", */
  },
  259: {
    /* n:"SXFormula", */
  },
  290: {
    /* n:"SXDBEx", */
  },
  311: {
    /* n:"RRDInsDel", */
  },
  312: {
    /* n:"RRDHead", */
  },
  315: {
    /* n:"RRDChgCell", */
  },
  317: {
    /* n:"RRTabId", */
    f: Ni
  },
  318: {
    /* n:"RRDRenSheet", */
  },
  319: {
    /* n:"RRSort", */
  },
  320: {
    /* n:"RRDMove", */
  },
  330: {
    /* n:"RRFormat", */
  },
  331: {
    /* n:"RRAutoFmt", */
  },
  333: {
    /* n:"RRInsertSh", */
  },
  334: {
    /* n:"RRDMoveBegin", */
  },
  335: {
    /* n:"RRDMoveEnd", */
  },
  336: {
    /* n:"RRDInsDelBegin", */
  },
  337: {
    /* n:"RRDInsDelEnd", */
  },
  338: {
    /* n:"RRDConflict", */
  },
  339: {
    /* n:"RRDDefName", */
  },
  340: {
    /* n:"RRDRstEtxp", */
  },
  351: {
    /* n:"LRng", */
  },
  352: {
    /* n:"UsesELFs", */
    f: $e
  },
  353: {
    /* n:"DSF", */
    f: aa
  },
  401: {
    /* n:"CUsr", */
  },
  402: {
    /* n:"CbUsr", */
  },
  403: {
    /* n:"UsrInfo", */
  },
  404: {
    /* n:"UsrExcl", */
  },
  405: {
    /* n:"FileLock", */
  },
  406: {
    /* n:"RRDInfo", */
  },
  407: {
    /* n:"BCUsrs", */
  },
  408: {
    /* n:"UsrChk", */
  },
  425: {
    /* n:"UserBView", */
  },
  426: {
    /* n:"UserSViewBegin", */
  },
  427: {
    /* n:"UserSViewEnd", */
  },
  428: {
    /* n:"RRDUserView", */
  },
  429: {
    /* n:"Qsi", */
  },
  430: {
    /* n:"SupBook", */
    f: Uo
  },
  431: {
    /* n:"Prot4Rev", */
    f: $e
  },
  432: {
    /* n:"CondFmt", */
  },
  433: {
    /* n:"CF", */
  },
  434: {
    /* n:"DVal", */
  },
  437: {
    /* n:"DConBin", */
  },
  438: {
    /* n:"TxO", */
    f: jo
  },
  439: {
    /* n:"RefreshAll", */
    f: $e
  },
  //
  440: {
    /* n:"HLink", */
    f: Jo
  },
  441: {
    /* n:"Lel", */
  },
  442: {
    /* n:"CodeName", */
    f: ut
  },
  443: {
    /* n:"SXFDBType", */
  },
  444: {
    /* n:"Prot4RevPass", */
    f: ze
  },
  445: {
    /* n:"ObNoMacros", */
  },
  446: {
    /* n:"Dv", */
  },
  448: {
    /* n:"Excel9File", */
    f: aa
  },
  449: {
    /* n:"RecalcId", */
    f: _o,
    r: 2
  },
  450: {
    /* n:"EntExU2", */
    f: aa
  },
  512: {
    /* n:"Dimensions", */
    f: kn
  },
  513: {
    /* n:"Blank", */
    f: nl
  },
  515: {
    /* n:"Number", */
    f: Mo
  },
  516: {
    /* n:"Label", */
    f: Ao
  },
  517: {
    /* n:"BoolErr", */
    f: Bo
  },
  519: {
    /* n:"String", */
    f: sl
  },
  520: {
    /* n:"Row", */
    f: go
  },
  523: {
    /* n:"Index", */
  },
  545: {
    /* n:"Array", */
    f: An
  },
  549: {
    /* n:"DefaultRowHeight", */
    f: _n
  },
  566: {
    /* n:"Table", */
  },
  574: {
    /* n:"Window2", */
    f: Eo
  },
  638: {
    /* n:"RK", */
    f: yo
  },
  659: {
    /* n:"Style", */
  },
  1048: {
    /* n:"BigName", */
  },
  1054: {
    /* n:"Format", */
    f: So
  },
  1084: {
    /* n:"ContinueBigName", */
  },
  1212: {
    /* n:"ShrFmla", */
    f: Wo
  },
  2048: {
    /* n:"HLinkTooltip", */
    f: Zo
  },
  2049: {
    /* n:"WebPub", */
  },
  2050: {
    /* n:"QsiSXTag", */
  },
  2051: {
    /* n:"DBQueryExt", */
  },
  2052: {
    /* n:"ExtString", */
  },
  2053: {
    /* n:"TxtQry", */
  },
  2054: {
    /* n:"Qsir", */
  },
  2055: {
    /* n:"Qsif", */
  },
  2056: {
    /* n:"RRDTQSIF", */
  },
  2057: {
    /* n:"BOF", */
    f: wt
  },
  2058: {
    /* n:"OleDbConn", */
  },
  2059: {
    /* n:"WOpt", */
  },
  2060: {
    /* n:"SXViewEx", */
  },
  2061: {
    /* n:"SXTH", */
  },
  2062: {
    /* n:"SXPIEx", */
  },
  2063: {
    /* n:"SXVDTEx", */
  },
  2064: {
    /* n:"SXViewEx9", */
  },
  2066: {
    /* n:"ContinueFrt", */
  },
  2067: {
    /* n:"RealTimeData", */
  },
  2128: {
    /* n:"ChartFrtInfo", */
  },
  2129: {
    /* n:"FrtWrapper", */
  },
  2130: {
    /* n:"StartBlock", */
  },
  2131: {
    /* n:"EndBlock", */
  },
  2132: {
    /* n:"StartObject", */
  },
  2133: {
    /* n:"EndObject", */
  },
  2134: {
    /* n:"CatLab", */
  },
  2135: {
    /* n:"YMult", */
  },
  2136: {
    /* n:"SXViewLink", */
  },
  2137: {
    /* n:"PivotChartBits", */
  },
  2138: {
    /* n:"FrtFontList", */
  },
  2146: {
    /* n:"SheetExt", */
  },
  2147: {
    /* n:"BookExt", */
    r: 12
  },
  2148: {
    /* n:"SXAddl", */
  },
  2149: {
    /* n:"CrErr", */
  },
  2150: {
    /* n:"HFPicture", */
  },
  2151: {
    /* n:"FeatHdr", */
    f: aa
  },
  2152: {
    /* n:"Feat", */
  },
  2154: {
    /* n:"DataLabExt", */
  },
  2155: {
    /* n:"DataLabExtContents", */
  },
  2156: {
    /* n:"CellWatch", */
  },
  2161: {
    /* n:"FeatHdr11", */
  },
  2162: {
    /* n:"Feature11", */
  },
  2164: {
    /* n:"DropDownObjIds", */
  },
  2165: {
    /* n:"ContinueFrt11", */
  },
  2166: {
    /* n:"DConn", */
  },
  2167: {
    /* n:"List12", */
  },
  2168: {
    /* n:"Feature12", */
  },
  2169: {
    /* n:"CondFmt12", */
  },
  2170: {
    /* n:"CF12", */
  },
  2171: {
    /* n:"CFEx", */
  },
  2172: {
    /* n:"XFCRC", */
    f: rl,
    r: 12
  },
  2173: {
    /* n:"XFExt", */
    f: S1,
    r: 12
  },
  2174: {
    /* n:"AutoFilter12", */
  },
  2175: {
    /* n:"ContinueFrt12", */
  },
  2180: {
    /* n:"MDTInfo", */
  },
  2181: {
    /* n:"MDXStr", */
  },
  2182: {
    /* n:"MDXTuple", */
  },
  2183: {
    /* n:"MDXSet", */
  },
  2184: {
    /* n:"MDXProp", */
  },
  2185: {
    /* n:"MDXKPI", */
  },
  2186: {
    /* n:"MDB", */
  },
  2187: {
    /* n:"PLV", */
  },
  2188: {
    /* n:"Compat12", */
    f: $e,
    r: 12
  },
  2189: {
    /* n:"DXF", */
  },
  2190: {
    /* n:"TableStyles", */
    r: 12
  },
  2191: {
    /* n:"TableStyle", */
  },
  2192: {
    /* n:"TableStyleElement", */
  },
  2194: {
    /* n:"StyleExt", */
  },
  2195: {
    /* n:"NamePublish", */
  },
  2196: {
    /* n:"NameCmt", */
    f: Ho,
    r: 12
  },
  2197: {
    /* n:"SortData", */
  },
  2198: {
    /* n:"Theme", */
    f: k1,
    r: 12
  },
  2199: {
    /* n:"GUIDTypeLib", */
  },
  2200: {
    /* n:"FnGrp12", */
  },
  2201: {
    /* n:"NameFnGrp12", */
  },
  2202: {
    /* n:"MTRSettings", */
    f: Vo,
    r: 12
  },
  2203: {
    /* n:"CompressPictures", */
    f: aa
  },
  2204: {
    /* n:"HeaderFooter", */
  },
  2205: {
    /* n:"CrtLayout12", */
  },
  2206: {
    /* n:"CrtMlFrt", */
  },
  2207: {
    /* n:"CrtMlFrtContinue", */
  },
  2211: {
    /* n:"ForceFullCalculation", */
    f: mo
  },
  2212: {
    /* n:"ShapePropsStream", */
  },
  2213: {
    /* n:"TextPropsStream", */
  },
  2214: {
    /* n:"RichTextStream", */
  },
  2215: {
    /* n:"CrtLayout12A", */
  },
  4097: {
    /* n:"Units", */
  },
  4098: {
    /* n:"Chart", */
  },
  4099: {
    /* n:"Series", */
  },
  4102: {
    /* n:"DataFormat", */
  },
  4103: {
    /* n:"LineFormat", */
  },
  4105: {
    /* n:"MarkerFormat", */
  },
  4106: {
    /* n:"AreaFormat", */
  },
  4107: {
    /* n:"PieFormat", */
  },
  4108: {
    /* n:"AttachedLabel", */
  },
  4109: {
    /* n:"SeriesText", */
  },
  4116: {
    /* n:"ChartFormat", */
  },
  4117: {
    /* n:"Legend", */
  },
  4118: {
    /* n:"SeriesList", */
  },
  4119: {
    /* n:"Bar", */
  },
  4120: {
    /* n:"Line", */
  },
  4121: {
    /* n:"Pie", */
  },
  4122: {
    /* n:"Area", */
  },
  4123: {
    /* n:"Scatter", */
  },
  4124: {
    /* n:"CrtLine", */
  },
  4125: {
    /* n:"Axis", */
  },
  4126: {
    /* n:"Tick", */
  },
  4127: {
    /* n:"ValueRange", */
  },
  4128: {
    /* n:"CatSerRange", */
  },
  4129: {
    /* n:"AxisLine", */
  },
  4130: {
    /* n:"CrtLink", */
  },
  4132: {
    /* n:"DefaultText", */
  },
  4133: {
    /* n:"Text", */
  },
  4134: {
    /* n:"FontX", */
    f: ze
  },
  4135: {
    /* n:"ObjectLink", */
  },
  4146: {
    /* n:"Frame", */
  },
  4147: {
    /* n:"Begin", */
  },
  4148: {
    /* n:"End", */
  },
  4149: {
    /* n:"PlotArea", */
  },
  4154: {
    /* n:"Chart3d", */
  },
  4156: {
    /* n:"PicF", */
  },
  4157: {
    /* n:"DropBar", */
  },
  4158: {
    /* n:"Radar", */
  },
  4159: {
    /* n:"Surf", */
  },
  4160: {
    /* n:"RadarArea", */
  },
  4161: {
    /* n:"AxisParent", */
  },
  4163: {
    /* n:"LegendException", */
  },
  4164: {
    /* n:"ShtProps", */
    f: tl
  },
  4165: {
    /* n:"SerToCrt", */
  },
  4166: {
    /* n:"AxesUsed", */
  },
  4168: {
    /* n:"SBaseRef", */
  },
  4170: {
    /* n:"SerParent", */
  },
  4171: {
    /* n:"SerAuxTrend", */
  },
  4174: {
    /* n:"IFmtRecord", */
  },
  4175: {
    /* n:"Pos", */
  },
  4176: {
    /* n:"AlRuns", */
  },
  4177: {
    /* n:"BRAI", */
  },
  4187: {
    /* n:"SerAuxErrBar", */
  },
  4188: {
    /* n:"ClrtClient", */
    f: Qo
  },
  4189: {
    /* n:"SerFmt", */
  },
  4191: {
    /* n:"Chart3DBarShape", */
  },
  4192: {
    /* n:"Fbi", */
  },
  4193: {
    /* n:"BopPop", */
  },
  4194: {
    /* n:"AxcExt", */
  },
  4195: {
    /* n:"Dat", */
  },
  4196: {
    /* n:"PlotGrowth", */
  },
  4197: {
    /* n:"SIIndex", */
  },
  4198: {
    /* n:"GelFrame", */
  },
  4199: {
    /* n:"BopPopCustom", */
  },
  4200: {
    /* n:"Fbi2", */
  },
  0: {
    /* n:"Dimensions", */
    f: kn
  },
  1: {
    /* n:"BIFF2BLANK", */
  },
  2: {
    /* n:"BIFF2INT", */
    f: ll
  },
  3: {
    /* n:"BIFF2NUM", */
    f: ol
  },
  4: {
    /* n:"BIFF2STR", */
    f: cl
  },
  5: {
    /* n:"BIFF2BOOLERR", */
    f: hl
  },
  7: {
    /* n:"String", */
    f: ul
  },
  8: {
    /* n:"BIFF2ROW", */
  },
  9: {
    /* n:"BOF", */
    f: wt
  },
  11: {
    /* n:"Index", */
  },
  22: {
    /* n:"ExternCount", */
    f: ze
  },
  30: {
    /* n:"BIFF2FORMAT", */
    f: Co
  },
  31: {
    /* n:"BIFF2FMTCNT", */
  },
  /* 16-bit cnt of BIFF2FORMAT records */
  32: {
    /* n:"BIFF2COLINFO", */
  },
  33: {
    /* n:"Array", */
    f: An
  },
  36: {
    /* n:"COLWIDTH", */
  },
  37: {
    /* n:"DefaultRowHeight", */
    f: _n
  },
  // 0x002c ??
  // 0x002d ??
  // 0x002e ??
  // 0x0030 FONTCOUNT: number of fonts
  50: {
    /* n:"BIFF2FONTXTRA", */
    f: xl
  },
  // 0x0035: INFOOPTS
  // 0x0036: TABLE (BIFF2 only)
  // 0x0037: TABLE2 (BIFF2 only)
  // 0x0038: WNDESK
  // 0x0039 ??
  // 0x003a: BEGINPREF
  // 0x003b: ENDPREF
  62: {
    /* n:"BIFF2WINDOW2", */
  },
  // 0x003f ??
  // 0x0046: SHOWSCROLL
  // 0x0047: SHOWFORMULA
  // 0x0048: STATUSBAR
  // 0x0049: SHORTMENUS
  // 0x004A:
  // 0x004B:
  // 0x004C:
  // 0x004E:
  // 0x004F:
  // 0x0058: TOOLBAR (BIFF3)
  /* - - - */
  52: {
    /* n:"DDEObjName", */
  },
  67: {
    /* n:"BIFF2XF", */
    f: No
  },
  68: {
    /* n:"BIFF2XFINDEX", */
    f: ze
  },
  69: {
    /* n:"BIFF2FONTCLR", */
  },
  86: {
    /* n:"BIFF4FMTCNT", */
  },
  /* 16-bit cnt, similar to BIFF2 */
  126: {
    /* n:"RK", */
  },
  /* Not necessarily same as 0x027e */
  127: {
    /* n:"ImData", */
    f: fl
  },
  135: {
    /* n:"Addin", */
  },
  136: {
    /* n:"Edg", */
  },
  137: {
    /* n:"Pub", */
  },
  // 0x8A
  // 0x8B LH: alternate menu key flag (BIFF3/4)
  // 0x8E
  143: {
    /* n:"BIFF4SheetInfo", */
    f: vl
  },
  145: {
    /* n:"Sub", */
  },
  // 0x93 STYLE
  148: {
    /* n:"LHRecord", */
  },
  149: {
    /* n:"LHNGraph", */
  },
  150: {
    /* n:"Sound", */
  },
  // 0xA2 FNPROTO: function prototypes (BIFF4)
  // 0xA3
  // 0xA8
  169: {
    /* n:"CoordList", */
  },
  171: {
    /* n:"GCW", */
  },
  188: {
    /* n:"ShrFmla", */
  },
  /* Not necessarily same as 0x04bc */
  191: {
    /* n:"ToolbarHdr", */
  },
  192: {
    /* n:"ToolbarEnd", */
  },
  194: {
    /* n:"AddMenu", */
  },
  195: {
    /* n:"DelMenu", */
  },
  214: {
    /* n:"RString", */
    f: dl
  },
  223: {
    /* n:"UDDesc", */
  },
  234: {
    /* n:"TabIdConf", */
  },
  354: {
    /* n:"XL5Modify", */
  },
  421: {
    /* n:"FileSharing2", */
  },
  518: {
    /* n:"Formula", */
    f: r0
  },
  521: {
    /* n:"BOF", */
    f: wt
  },
  536: {
    /* n:"Lbl", */
    f: wn
  },
  547: {
    /* n:"ExternName", */
    f: Tn
  },
  561: {
    /* n:"Font", */
  },
  579: {
    /* n:"BIFF3XF", */
    f: Po
  },
  1030: {
    /* n:"Formula", */
    f: r0
  },
  1033: {
    /* n:"BOF", */
    f: wt
  },
  1091: {
    /* n:"BIFF4XF", */
    f: bo
  },
  2157: {
    /* n:"FeatInfo", */
  },
  2163: {
    /* n:"FeatInfo11", */
  },
  2177: {
    /* n:"SXAddl12", */
  },
  2240: {
    /* n:"AutoWebPub", */
  },
  2241: {
    /* n:"ListObj", */
  },
  2242: {
    /* n:"ListField", */
  },
  2243: {
    /* n:"ListDV", */
  },
  2244: {
    /* n:"ListCondFmt", */
  },
  2245: {
    /* n:"ListCF", */
  },
  2246: {
    /* n:"FMQry", */
  },
  2247: {
    /* n:"FMSQry", */
  },
  2248: {
    /* n:"PLV", */
  },
  2249: {
    /* n:"LnExt", */
  },
  2250: {
    /* n:"MkrExt", */
  },
  2251: {
    /* n:"CrtCoopt", */
  },
  2262: {
    /* n:"FRTArchId$", */
    r: 12
  },
  /* --- multiplan 4 records --- */
  101: {
    /* n:"", */
  },
  // one per window
  102: {
    /* n:"", */
  },
  // calc settings
  105: {
    /* n:"", */
  },
  // print header
  106: {
    /* n:"", */
  },
  // print footer
  107: {
    /* n:"", */
  },
  // print settings
  109: {
    /* n:"", */
  },
  // one per window
  112: {
    /* n:"", */
  },
  // includes default col width
  114: {
    /* n:"", */
  },
  // includes selected cell
  29282: {}
};
function Cr(e, a, r, t) {
  var n = a;
  if (!isNaN(n)) {
    var i = (r || []).length || 0, f = e.next(4);
    f.write_shift(2, n), f.write_shift(2, i), /*:: len != null &&*/
    i > 0 && Ti(r) && e.push(r);
  }
}
function Bn(e, a) {
  var r = a || {}, t = r.dense != null ? r.dense : Us, n = {};
  t && (n["!data"] = []), e = ot(e, "<!--", "-->");
  var i = e.match(/<table/i);
  if (!i) throw new Error("Invalid HTML: could not find <table>");
  var f = e.match(/<\/table/i), s = i.index, c = f && f.index || e.length, o = Df(e.slice(s, c), /(:?<tr[^<>]*>)/i, "<tr>"), l = -1, v = 0, d = 0, u = 0, p = { s: { r: 1e7, c: 1e7 }, e: { r: 0, c: 0 } }, _ = [];
  for (s = 0; s < o.length; ++s) {
    var x = o[s].trim(), h = x.slice(0, 3).toLowerCase();
    if (h == "<tr") {
      if (++l, r.sheetRows && r.sheetRows <= l) {
        --l;
        break;
      }
      v = 0;
      continue;
    }
    if (!(h != "<td" && h != "<th")) {
      var E = x.split(/<\/t[dh]>/i);
      for (c = 0; c < E.length; ++c) {
        var g = E[c].trim();
        if (g.match(/<t[dh]/i)) {
          for (var y = g, P = 0; y.charAt(0) == "<" && (P = y.indexOf(">")) > -1; ) y = y.slice(P + 1);
          for (var M = 0; M < _.length; ++M) {
            var I = _[M];
            I.s.c == v && I.s.r < l && l <= I.e.r && (v = I.e.c + 1, M = -1);
          }
          var N = le(g.slice(0, g.indexOf(">")));
          u = N.colspan ? +N.colspan : 1, ((d = +N.rowspan) > 1 || u > 1) && _.push({ s: { r: l, c: v }, e: { r: l + (d || 1) - 1, c: v + u - 1 } });
          var O = N.t || N["data-t"] || "";
          if (!y.length) {
            v += u;
            continue;
          }
          if (y = oi(y), p.s.r > l && (p.s.r = l), p.e.r < l && (p.e.r = l), p.s.c > v && (p.s.c = v), p.e.c < v && (p.e.c = v), !y.length) {
            v += u;
            continue;
          }
          var B = { t: "s", v: y };
          r.raw || !y.trim().length || O == "s" || (y === "TRUE" ? B = { t: "b", v: !0 } : y === "FALSE" ? B = { t: "b", v: !1 } : isNaN(Ir(y)) ? isNaN(tt(y).getDate()) ? y.charCodeAt(0) == 35 && sr[y] != null && (B.t = "e", B.w = y, B.v = sr[y]) : (B = { t: "d", v: cr(y) }, r.UTC === !1 && (B.v = Ea(B.v)), r.cellDates || (B = { t: "n", v: ar(B.v) }), B.z = r.dateNF || ge[14]) : B = { t: "n", v: Ir(y) }), B.cellText !== !1 && (B.w = y), t ? (n["!data"][l] || (n["!data"][l] = []), n["!data"][l][v] = B) : n[Ne({ r: l, c: v })] = B, v += u;
        }
      }
    }
  }
  return n["!ref"] = ye(p), _.length && (n["!merges"] = _), n;
}
function nd(e, a, r, t) {
  for (var n = e["!merges"] || [], i = [], f = {}, s = e["!data"] != null, c = a.s.c; c <= a.e.c; ++c) {
    for (var o = 0, l = 0, v = 0; v < n.length; ++v)
      if (!(n[v].s.r > r || n[v].s.c > c) && !(n[v].e.r < r || n[v].e.c < c)) {
        if (n[v].s.r < r || n[v].s.c < c) {
          o = -1;
          break;
        }
        o = n[v].e.r - n[v].s.r + 1, l = n[v].e.c - n[v].s.c + 1;
        break;
      }
    if (!(o < 0)) {
      var d = Pe(c) + Me(r), u = s ? (e["!data"][r] || [])[c] : e[d];
      u && u.t == "n" && u.v != null && !isFinite(u.v) && (isNaN(u.v) ? u = { t: "e", v: 36, w: Ar[36] } : u = { t: "e", v: 7, w: Ar[7] });
      var p = u && u.v != null && (u.h || Ga(u.w || (fa(u), u.w) || "")) || "";
      f = {}, o > 1 && (f.rowspan = o), l > 1 && (f.colspan = l), t.editable ? p = '<span contenteditable="true">' + p + "</span>" : u && (f["data-t"] = u && u.t || "z", u.v != null && (f["data-v"] = Ga(u.v instanceof Date ? u.v.toISOString() : u.v)), u.z != null && (f["data-z"] = u.z), u.l && (u.l.Target || "#").charAt(0) != "#" && (p = '<a href="' + Ga(u.l.Target) + '">' + p + "</a>")), f.id = (t.id || "sjs") + "-" + d, i.push(Kf("td", p, f));
    }
  }
  var _ = "<tr>";
  return _ + i.join("") + "</tr>";
}
var id = '<html><head><meta charset="utf-8"/><title>SheetJS Table Export</title></head><body>', sd = "</body></html>";
function fd(e, a) {
  var r = Rf(e, "table");
  if (!r || r.length == 0) throw new Error("Invalid HTML: could not find <table>");
  if (r.length == 1) {
    var t = la(Bn(r[0], a), a);
    return t.bookType = "html", t;
  }
  var n = L0();
  return r.forEach(function(i, f) {
    vt(n, Bn(i, a), "Sheet" + (f + 1));
  }), n.bookType = "html", n;
}
function cd(e, a, r) {
  var t = [];
  return t.join("") + "<table" + (r && r.id ? ' id="' + r.id + '"' : "") + ">";
}
function od(e, a) {
  var r = a || {}, t = r.header != null ? r.header : id, n = r.footer != null ? r.footer : sd, i = [t], f = wa(e["!ref"] || "A1");
  if (i.push(cd(e, f, r)), e["!ref"]) for (var s = f.s.r; s <= f.e.r; ++s) i.push(nd(e, f, s, r));
  return i.push("</table>" + n), i.join("");
}
function hs(e, a, r) {
  var t = a.rows;
  if (!t)
    throw "Unsupported origin when " + a.tagName + " is not a TABLE";
  var n = r || {}, i = e["!data"] != null, f = 0, s = 0;
  if (n.origin != null)
    if (typeof n.origin == "number") f = n.origin;
    else {
      var c = typeof n.origin == "string" ? dr(n.origin) : n.origin;
      f = c.r, s = c.c;
    }
  var o = Math.min(n.sheetRows || 1e7, t.length), l = { s: { r: 0, c: 0 }, e: { r: f, c: s } };
  if (e["!ref"]) {
    var v = wa(e["!ref"]);
    l.s.r = Math.min(l.s.r, v.s.r), l.s.c = Math.min(l.s.c, v.s.c), l.e.r = Math.max(l.e.r, v.e.r), l.e.c = Math.max(l.e.c, v.e.c), f == -1 && (l.e.r = f = v.e.r + 1);
  }
  var d = [], u = 0, p = e["!rows"] || (e["!rows"] = []), _ = 0, x = 0, h = 0, E = 0, g = 0, y = 0;
  for (e["!cols"] || (e["!cols"] = []); _ < t.length && x < o; ++_) {
    var P = t[_];
    if (Mn(P)) {
      if (n.display) continue;
      p[x] = { hidden: !0 };
    }
    var M = P.cells;
    for (h = E = 0; h < M.length; ++h) {
      var I = M[h];
      if (!(n.display && Mn(I))) {
        var N = I.hasAttribute("data-v") ? I.getAttribute("data-v") : I.hasAttribute("v") ? I.getAttribute("v") : oi(I.innerHTML), O = I.getAttribute("data-z") || I.getAttribute("z");
        for (u = 0; u < d.length; ++u) {
          var B = d[u];
          B.s.c == E + s && B.s.r < x + f && x + f <= B.e.r && (E = B.e.c + 1 - s, u = -1);
        }
        y = +I.getAttribute("colspan") || 1, ((g = +I.getAttribute("rowspan") || 1) > 1 || y > 1) && d.push({ s: { r: x + f, c: E + s }, e: { r: x + f + (g || 1) - 1, c: E + s + (y || 1) - 1 } });
        var b = { t: "s", v: N }, G = I.getAttribute("data-t") || I.getAttribute("t") || "";
        N != null && (N.length == 0 ? b.t = G || "z" : n.raw || N.trim().length == 0 || G == "s" || (G == "e" && Ar[+N] ? b = { t: "e", v: +N, w: Ar[+N] } : N === "TRUE" ? b = { t: "b", v: !0 } : N === "FALSE" ? b = { t: "b", v: !1 } : isNaN(Ir(N)) ? isNaN(tt(N).getDate()) ? N.charCodeAt(0) == 35 && sr[N] != null && (b = { t: "e", v: sr[N], w: N }) : (b = { t: "d", v: cr(N) }, n.UTC && (b.v = Ht(b.v)), n.cellDates || (b = { t: "n", v: ar(b.v) }), b.z = n.dateNF || ge[14]) : b = { t: "n", v: Ir(N) })), b.z === void 0 && O != null && (b.z = O);
        var z = "", fe = I.getElementsByTagName("A");
        if (fe && fe.length) for (var j = 0; j < fe.length && !(fe[j].hasAttribute("href") && (z = fe[j].getAttribute("href"), z.charAt(0) != "#")); ++j) ;
        z && z.charAt(0) != "#" && z.slice(0, 11).toLowerCase() != "javascript:" && (b.l = { Target: z }), i ? (e["!data"][x + f] || (e["!data"][x + f] = []), e["!data"][x + f][E + s] = b) : e[Ne({ c: E + s, r: x + f })] = b, l.e.c < E + s && (l.e.c = E + s), E += y;
      }
    }
    ++x;
  }
  return d.length && (e["!merges"] = (e["!merges"] || []).concat(d)), l.e.r = Math.max(l.e.r, x - 1 + f), e["!ref"] = ye(l), x >= o && (e["!fullref"] = ye((l.e.r = t.length - _ + x - 1 + f, l))), e;
}
function xs(e, a) {
  var r = a || {}, t = {};
  return r.dense && (t["!data"] = []), hs(t, e, a);
}
function ld(e, a) {
  var r = la(xs(e, a), a);
  return r;
}
function Mn(e) {
  var a = "", r = ud(e);
  return r && (a = r(e).getPropertyValue("display")), a || (a = e.style && e.style.display), a === "none";
}
function ud(e) {
  return e.ownerDocument.defaultView && typeof e.ownerDocument.defaultView.getComputedStyle == "function" ? e.ownerDocument.defaultView.getComputedStyle : typeof getComputedStyle == "function" ? getComputedStyle : null;
}
function hd(e) {
  var a = e.replace(/[\t\r\n]/g, " ").trim().replace(/ +/g, " ").replace(/<text:s\/>/g, " ").replace(/<text:s text:c="(\d+)"\/>/g, function(t, n) {
    return Array(parseInt(n, 10) + 1).join(" ");
  }).replace(/<text:tab[^<>]*\/>/g, "	").replace(/<text:line-break\/>/g, `
`), r = Ce(a.replace(/<[^<>]*>/g, ""));
  return [r];
}
function ds(e, a, r) {
  var t = r || {}, n = Wt(e);
  qe.lastIndex = 0, n = k0(ot(n, "<!--", "-->"));
  for (var i, f, s = "", c = "", o, l = 0, v = -1, d = ""; i = qe.exec(n); )
    switch (i[3] = i[3].replace(/_[\s\S]*$/, "")) {
      /* Number Format Definitions */
      case "number-style":
      // <number:number-style> 16.29.2
      case "currency-style":
      // <number:currency-style> 16.29.8
      case "percentage-style":
      // <number:percentage-style> 16.29.10
      case "date-style":
      // <number:date-style> 16.29.11
      case "time-style":
      // <number:time-style> 16.29.19
      case "text-style":
        i[1] === "/" ? (f["truncate-on-overflow"] == "false" && (s.match(/h/) ? s = s.replace(/h+/, "[$&]") : s.match(/m/) ? s = s.replace(/m+/, "[$&]") : s.match(/s/) && (s = s.replace(/s+/, "[$&]"))), t[f.name] = s, s = "") : i[0].charAt(i[0].length - 2) !== "/" && (s = "", f = le(i[0], !1));
        break;
      // LibreOffice bug https://bugs.documentfoundation.org/show_bug.cgi?id=149484
      case "boolean-style":
        i[1] === "/" ? (t[f.name] = "General", s = "") : i[0].charAt(i[0].length - 2) !== "/" && (s = "", f = le(i[0], !1));
        break;
      /* Number Format Elements */
      case "boolean":
        s += "General";
        break;
      case "text":
        i[1] === "/" ? (d = n.slice(v, qe.lastIndex - i[0].length), d == "%" && f[0] == "<number:percentage-style" ? s += "%" : s += '"' + d.replace(/"/g, '""') + '"') : i[0].charAt(i[0].length - 2) !== "/" && (v = qe.lastIndex);
        break;
      case "day":
        switch (o = le(i[0], !1), o.style) {
          case "short":
            s += "d";
            break;
          case "long":
            s += "dd";
            break;
          default:
            s += "dd";
            break;
        }
        break;
      case "day-of-week":
        switch (o = le(i[0], !1), o.style) {
          case "short":
            s += "ddd";
            break;
          case "long":
            s += "dddd";
            break;
          default:
            s += "ddd";
            break;
        }
        break;
      case "era":
        switch (o = le(i[0], !1), o.style) {
          case "short":
            s += "ee";
            break;
          case "long":
            s += "eeee";
            break;
          default:
            s += "eeee";
            break;
        }
        break;
      case "hours":
        switch (o = le(i[0], !1), o.style) {
          case "short":
            s += "h";
            break;
          case "long":
            s += "hh";
            break;
          default:
            s += "hh";
            break;
        }
        break;
      case "minutes":
        switch (o = le(i[0], !1), o.style) {
          case "short":
            s += "m";
            break;
          case "long":
            s += "mm";
            break;
          default:
            s += "mm";
            break;
        }
        break;
      case "month":
        switch (o = le(i[0], !1), o.textual && (s += "mm"), o.style) {
          case "short":
            s += "m";
            break;
          case "long":
            s += "mm";
            break;
          default:
            s += "m";
            break;
        }
        break;
      case "seconds":
        {
          switch (o = le(i[0], !1), o.style) {
            case "short":
              s += "s";
              break;
            case "long":
              s += "ss";
              break;
            default:
              s += "ss";
              break;
          }
          o["decimal-places"] && (s += "." + Ie("0", +o["decimal-places"]));
        }
        break;
      case "year":
        switch (o = le(i[0], !1), o.style) {
          case "short":
            s += "yy";
            break;
          case "long":
            s += "yyyy";
            break;
          default:
            s += "yy";
            break;
        }
        break;
      case "am-pm":
        s += "AM/PM";
        break;
      case "week-of-year":
      // <number:week-of-year> 16.29.17
      case "quarter":
        console.error("Excel does not support ODS format token " + i[3]);
        break;
      case "fill-character":
        i[1] === "/" ? (d = n.slice(v, qe.lastIndex - i[0].length), s += '"' + d.replace(/"/g, '""') + '"*') : i[0].charAt(i[0].length - 2) !== "/" && (v = qe.lastIndex);
        break;
      case "scientific-number":
        o = le(i[0], !1), s += "0." + Ie("0", +o["min-decimal-places"] || +o["decimal-places"] || 2) + Ie("?", +o["decimal-places"] - +o["min-decimal-places"] || 0) + "E" + (Be(o["forced-exponent-sign"]) ? "+" : "") + Ie("0", +o["min-exponent-digits"] || 2);
        break;
      case "fraction":
        o = le(i[0], !1), +o["min-integer-digits"] ? s += Ie("0", +o["min-integer-digits"]) : s += "#", s += " ", s += Ie("?", +o["min-numerator-digits"] || 1), s += "/", +o["denominator-value"] ? s += o["denominator-value"] : s += Ie("?", +o["min-denominator-digits"] || 1);
        break;
      case "currency-symbol":
        i[1] === "/" ? s += '"' + n.slice(v, qe.lastIndex - i[0].length).replace(/"/g, '""') + '"' : i[0].charAt(i[0].length - 2) !== "/" ? v = qe.lastIndex : s += "$";
        break;
      case "text-properties":
        switch (o = le(i[0], !1), (o.color || "").toLowerCase().replace("#", "")) {
          case "ff0000":
          case "red":
            s = "[Red]" + s;
            break;
        }
        break;
      case "text-content":
        s += "@";
        break;
      case "map":
        o = le(i[0], !1), Ce(o.condition) == "value()>=0" ? s = t[o["apply-style-name"]] + ";" + s : console.error("ODS number format may be incorrect: " + o.condition);
        break;
      case "number":
        if (i[1] === "/") break;
        o = le(i[0], !1), c = "", c += Ie("0", +o["min-integer-digits"] || 1), Be(o.grouping) && (c = Jr(Ie("#", Math.max(0, 4 - c.length)) + c)), (+o["min-decimal-places"] || +o["decimal-places"]) && (c += "."), +o["min-decimal-places"] && (c += Ie("0", +o["min-decimal-places"] || 1)), +o["decimal-places"] - (+o["min-decimal-places"] || 0) && (c += Ie("0", +o["decimal-places"] - (+o["min-decimal-places"] || 0))), s += c;
        break;
      case "embedded-text":
        i[1] === "/" ? l == 0 ? s += '"' + n.slice(v, qe.lastIndex - i[0].length).replace(/"/g, '""') + '"' : s = s.slice(0, l) + '"' + n.slice(v, qe.lastIndex - i[0].length).replace(/"/g, '""') + '"' + s.slice(l) : i[0].charAt(i[0].length - 2) !== "/" && (v = qe.lastIndex, l = -+le(i[0], !1).position || 0);
        break;
    }
  return t;
}
function vs(e, a, r) {
  var t = a || {}, n = Wt(e), i = [], f, s, c, o = "", l = 0, v, d, u = {}, p = [], _ = {};
  t.dense && (_["!data"] = []);
  var x, h, E = { value: "" }, g = {}, y = "", P = 0, M = "", I = 0, N = [], O = [], B = -1, b = -1, G = { s: { r: 1e6, c: 1e7 }, e: { r: 0, c: 0 } }, z = 0, fe = r || {}, j = {}, he = [], J = {}, ne = 0, pe = 0, X = [], ke = 1, _e = 1, de = [], ce = { Names: [], WBProps: {} }, Te = {}, me = ["", ""], Fe = [], S = {}, L = "", R = 0, D = !1, Y = !1, w = 0;
  for (qe.lastIndex = 0, n = k0(ot(n, "<!--", "-->")); x = qe.exec(n); ) switch (x[3] = x[3].replace(/_[\s\S]*$/, "")) {
    case "table":
    case "工作表":
      x[1] === "/" ? (G.e.c >= G.s.c && G.e.r >= G.s.r ? _["!ref"] = ye(G) : _["!ref"] = "A1:A1", t.sheetRows > 0 && t.sheetRows <= G.e.r && (_["!fullref"] = _["!ref"], G.e.r = t.sheetRows - 1, _["!ref"] = ye(G)), he.length && (_["!merges"] = he), X.length && (_["!rows"] = X), v.name = v.名称 || v.name, typeof JSON < "u" && JSON.stringify(v), p.push(v.name), u[v.name] = _, Y = !1) : x[0].charAt(x[0].length - 2) !== "/" && (v = le(x[0], !1), B = b = -1, G.s.r = G.s.c = 1e7, G.e.r = G.e.c = 0, _ = {}, t.dense && (_["!data"] = []), he = [], X = [], Y = !0);
      break;
    case "table-row-group":
      x[1] === "/" ? --z : ++z;
      break;
    case "table-row":
    case "行":
      if (x[1] === "/") {
        B += ke, ke = 1;
        break;
      }
      if (d = le(x[0], !1), d.行号 ? B = d.行号 - 1 : B == -1 && (B = 0), ke = +d["number-rows-repeated"] || 1, ke < 10) for (w = 0; w < ke; ++w) z > 0 && (X[B + w] = { level: z });
      b = -1;
      break;
    case "covered-table-cell":
      if (x[1] !== "/")
        if (++b, E = le(x[0], !1), _e = parseInt(E["number-columns-repeated"] || "1", 10) || 1, t.sheetStubs) {
          for (; _e-- > 0; )
            t.dense ? (_["!data"][B] || (_["!data"][B] = []), _["!data"][B][b] = { t: "z" }) : _[Ne({ r: B, c: b })] = { t: "z" }, ++b;
          --b;
        } else b += _e - 1;
      y = "", N = [];
      break;
    /* stub */
    case "table-cell":
    case "数据":
      if (x[0].charAt(x[0].length - 2) === "/")
        ++b, E = le(x[0], !1), _e = parseInt(E["number-columns-repeated"] || "1", 10) || 1, h = {
          t: "z",
          v: null
          /*:: , z:null, w:"",c:[]*/
        }, E.formula && t.cellFormula != !1 && (h.f = Nn(Ce(E.formula))), E["style-name"] && j[E["style-name"]] && (h.z = j[E["style-name"]]), (E.数据类型 || E["value-type"]) == "string" && (h.t = "s", h.v = Ce(E["string-value"] || ""), t.dense ? (_["!data"][B] || (_["!data"][B] = []), _["!data"][B][b] = h) : _[Pe(b) + Me(B)] = h), b += _e - 1;
      else if (x[1] !== "/") {
        ++b, y = M = "", P = I = 0, N = [], O = [], _e = 1;
        var te = ke ? B + ke - 1 : B;
        if (b > G.e.c && (G.e.c = b), b < G.s.c && (G.s.c = b), B < G.s.r && (G.s.r = B), te > G.e.r && (G.e.r = te), E = le(x[0], !1), g = Uf(x[0]), Fe = [], S = {}, h = {
          t: E.数据类型 || E["value-type"],
          v: null
          /*:: , z:null, w:"",c:[]*/
        }, E["style-name"] && j[E["style-name"]] && (h.z = j[E["style-name"]]), t.cellFormula)
          if (E.formula && (E.formula = Ce(E.formula)), E["number-matrix-columns-spanned"] && E["number-matrix-rows-spanned"] && (ne = parseInt(E["number-matrix-rows-spanned"], 10) || 0, pe = parseInt(E["number-matrix-columns-spanned"], 10) || 0, J = { s: { r: B, c: b }, e: { r: B + ne - 1, c: b + pe - 1 } }, h.F = ye(J), de.push([J, h.F])), E.formula) h.f = Nn(E.formula);
          else for (w = 0; w < de.length; ++w)
            B >= de[w][0].s.r && B <= de[w][0].e.r && b >= de[w][0].s.c && b <= de[w][0].e.c && (h.F = de[w][1]);
        switch ((E["number-columns-spanned"] || E["number-rows-spanned"]) && (ne = parseInt(E["number-rows-spanned"] || "1", 10) || 1, pe = parseInt(E["number-columns-spanned"] || "1", 10) || 1, ne * pe > 1 && (J = { s: { r: B, c: b }, e: { r: B + ne - 1, c: b + pe - 1 } }, he.push(J))), E["number-columns-repeated"] && (_e = parseInt(E["number-columns-repeated"], 10)), h.t) {
          case "boolean":
            h.t = "b", h.v = Be(E["boolean-value"]) || +E["boolean-value"] >= 1;
            break;
          case "float":
            h.t = "n", h.v = parseFloat(E.value), t.cellDates && h.z && Br(h.z) && (h.v = ia(h.v + (ce.WBProps.date1904 ? 1462 : 0)), h.t = typeof h.v == "number" ? "n" : "d");
            break;
          case "percentage":
            h.t = "n", h.v = parseFloat(E.value);
            break;
          case "currency":
            h.t = "n", h.v = parseFloat(E.value);
            break;
          case "date":
            h.t = "d", h.v = cr(E["date-value"], ce.WBProps.date1904), t.cellDates || (h.t = "n", h.v = ar(h.v, ce.WBProps.date1904)), h.z || (h.z = "m/d/yy");
            break;
          /* NOTE: for `time`, Excel ODS export incorrectly uses durations relative to 1900 epoch even if 1904 is specified */
          case "time":
            h.t = "n", h.v = _f(E["time-value"]) / 86400, t.cellDates && (h.v = ia(h.v), h.t = typeof h.v == "number" ? "n" : "d"), h.z || (h.z = "HH:MM:SS");
            break;
          case "number":
            h.t = "n", h.v = parseFloat(E.数据数值);
            break;
          default:
            if (h.t === "string" || h.t === "text" || !h.t)
              h.t = "s", E["string-value"] != null && (y = Ce(E["string-value"]), N = []);
            else throw new Error("Unsupported value type " + h.t);
        }
      } else {
        if (D = !1, g["calcext:value-type"] == "error" && sr[y] != null && (h.t = "e", h.w = y, h.v = sr[y]), h.t === "s" && (h.v = y || "", N.length && (h.R = N), D = P == 0), Te.Target && (h.l = Te), Fe.length > 0 && (h.c = Fe, Fe = []), y && t.cellText !== !1 && (h.w = y), D && (h.t = "z", delete h.v), (!D || t.sheetStubs) && !(t.sheetRows && t.sheetRows <= B))
          for (var ie = 0; ie < ke; ++ie) {
            if (_e = parseInt(E["number-columns-repeated"] || "1", 10), t.dense)
              for (_["!data"][B + ie] || (_["!data"][B + ie] = []), _["!data"][B + ie][b] = ie == 0 ? h : er(h); --_e > 0; ) _["!data"][B + ie][b + _e] = er(h);
            else
              for (_[Ne({ r: B + ie, c: b })] = h; --_e > 0; ) _[Ne({ r: B + ie, c: b + _e })] = er(h);
            G.e.c <= b && (G.e.c = b);
          }
        _e = parseInt(E["number-columns-repeated"] || "1", 10), b += _e - 1, _e = 0, h = {
          /*:: t:"", v:null, z:null, w:"",c:[]*/
        }, y = "", N = [];
      }
      Te = {};
      break;
    // 9.1.4 <table:table-cell>
    /* pure state */
    case "document":
    // TODO: <office:document> is the root for FODS
    case "document-content":
    case "电子表格文档":
    // 3.1.3.2 <office:document-content>
    case "spreadsheet":
    case "主体":
    // 3.7 <office:spreadsheet>
    case "scripts":
    // 3.12 <office:scripts>
    case "styles":
    // TODO <office:styles>
    case "font-face-decls":
    // 3.14 <office:font-face-decls>
    case "master-styles":
      if (x[1] === "/") {
        if ((f = i.pop())[0] !== x[3]) throw "Bad state: " + f;
      } else x[0].charAt(x[0].length - 2) !== "/" && i.push([x[3], !0]);
      break;
    case "annotation":
      if (x[1] === "/") {
        if ((f = i.pop())[0] !== x[3]) throw "Bad state: " + f;
        S.t = y, N.length && (S.R = N), S.a = L, Fe.push(S), y = M, P = I, N = O;
      } else if (x[0].charAt(x[0].length - 2) !== "/") {
        i.push([x[3], !1]);
        var Q = le(x[0], !0);
        Q.display && Be(Q.display) || (Fe.hidden = !0), M = y, I = P, O = N, y = "", P = 0, N = [];
      }
      L = "", R = 0;
      break;
    case "creator":
      x[1] === "/" ? L = n.slice(R, x.index) : R = x.index + x[0].length;
      break;
    /* ignore state */
    case "meta":
    case "元数据":
    // TODO: <office:meta> <uof:元数据> FODS/UOF
    case "settings":
    // TODO: <office:settings>
    case "config-item-set":
    // TODO: <office:config-item-set>
    case "config-item-map-indexed":
    // TODO: <office:config-item-map-indexed>
    case "config-item-map-entry":
    // TODO: <office:config-item-map-entry>
    case "config-item-map-named":
    // TODO: <office:config-item-map-entry>
    case "shapes":
    // 9.2.8 <table:shapes>
    case "frame":
    // 10.4.2 <draw:frame>
    case "text-box":
    // 10.4.3 <draw:text-box>
    case "image":
    // 10.4.4 <draw:image>
    case "data-pilot-tables":
    // 9.6.2 <table:data-pilot-tables>
    case "list-style":
    // 16.30 <text:list-style>
    case "form":
    // 13.13 <form:form>
    case "dde-links":
    // 9.8 <table:dde-links>
    case "event-listeners":
    // TODO
    case "chart":
      if (x[1] === "/") {
        if ((f = i.pop())[0] !== x[3]) throw "Bad state: " + f;
      } else x[0].charAt(x[0].length - 2) !== "/" && i.push([x[3], !1]);
      y = "", P = 0, N = [];
      break;
    case "scientific-number":
    // <number:scientific-number>
    case "currency-symbol":
    // <number:currency-symbol>
    case "fill-character":
      break;
    case "text-style":
    // 16.27.25 <number:text-style>
    case "boolean-style":
    // 16.27.23 <number:boolean-style>
    case "number-style":
    // 16.27.2 <number:number-style>
    case "currency-style":
    // 16.29.8 <number:currency-style>
    case "percentage-style":
    // 16.27.9 <number:percentage-style>
    case "date-style":
    // 16.27.10 <number:date-style>
    case "time-style":
      if (x[1] === "/") {
        var ve = qe.lastIndex;
        ds(n.slice(c, qe.lastIndex), a, fe), qe.lastIndex = ve;
      } else x[0].charAt(x[0].length - 2) !== "/" && (c = qe.lastIndex - x[0].length);
      break;
    case "script":
      break;
    // 3.13 <office:script>
    case "libraries":
      break;
    // TODO: <ooo:libraries>
    case "automatic-styles":
      break;
    // 3.15.3 <office:automatic-styles>
    case "default-style":
    // TODO: <style:default-style>
    case "page-layout":
      break;
    // TODO: <style:page-layout>
    case "style":
      {
        var xe = le(x[0], !1);
        xe.family == "table-cell" && fe[xe["data-style-name"]] && (j[xe.name] = fe[xe["data-style-name"]]);
      }
      break;
    case "map":
      break;
    // 16.3 <style:map>
    case "font-face":
      break;
    // 16.21 <style:font-face>
    case "paragraph-properties":
      break;
    // 17.6 <style:paragraph-properties>
    case "table-properties":
      break;
    // 17.15 <style:table-properties>
    case "table-column-properties":
      break;
    // 17.16 <style:table-column-properties>
    case "table-row-properties":
      break;
    // 17.17 <style:table-row-properties>
    case "table-cell-properties":
      break;
    // 17.18 <style:table-cell-properties>
    case "number":
      break;
    case "fraction":
      break;
    // TODO 16.27.6 <number:fraction>
    case "day":
    // 16.27.11 <number:day>
    case "month":
    // 16.27.12 <number:month>
    case "year":
    // 16.27.13 <number:year>
    case "era":
    // 16.27.14 <number:era>
    case "day-of-week":
    // 16.27.15 <number:day-of-week>
    case "week-of-year":
    // 16.27.16 <number:week-of-year>
    case "quarter":
    // 16.27.17 <number:quarter>
    case "hours":
    // 16.27.19 <number:hours>
    case "minutes":
    // 16.27.20 <number:minutes>
    case "seconds":
    // 16.27.21 <number:seconds>
    case "am-pm":
      break;
    case "boolean":
      break;
    // 16.27.24 <number:boolean>
    case "text":
      if (x[0].slice(-2) === "/>") break;
      if (x[1] === "/") switch (i[i.length - 1][0]) {
        case "number-style":
        case "date-style":
        case "time-style":
          o += n.slice(l, x.index);
          break;
      }
      else l = x.index + x[0].length;
      break;
    case "named-range":
      s = le(x[0], !1), me = a0(s["cell-range-address"]);
      var Ee = { Name: s.name, Ref: me[0] + "!" + me[1] };
      Y && (Ee.Sheet = p.length), ce.Names.push(Ee);
      break;
    case "text-content":
      break;
    // 16.27.27 <number:text-content>
    case "text-properties":
      break;
    // 16.27.27 <style:text-properties>
    case "embedded-text":
      break;
    // 16.27.4 <number:embedded-text>
    case "body":
    case "电子表格":
      break;
    // 3.3 16.9.6 19.726.3
    case "forms":
      break;
    // 12.25.2 13.2
    case "table-column":
      break;
    // 9.1.6 <table:table-column>
    case "table-header-rows":
      break;
    // 9.1.7 <table:table-header-rows>
    case "table-rows":
      break;
    // 9.1.12 <table:table-rows>
    /* TODO: outline levels */
    case "table-column-group":
      break;
    // 9.1.10 <table:table-column-group>
    case "table-header-columns":
      break;
    // 9.1.11 <table:table-header-columns>
    case "table-columns":
      break;
    // 9.1.12 <table:table-columns>
    case "null-date":
      switch (s = le(x[0], !1), s["date-value"]) {
        case "1904-01-01":
          ce.WBProps.date1904 = !0;
          break;
      }
      break;
    case "graphic-properties":
      break;
    // 17.21 <style:graphic-properties>
    case "calculation-settings":
      break;
    // 9.4.1 <table:calculation-settings>
    case "named-expressions":
      break;
    // 9.4.11 <table:named-expressions>
    case "label-range":
      break;
    // 9.4.9 <table:label-range>
    case "label-ranges":
      break;
    // 9.4.10 <table:label-ranges>
    case "named-expression":
      break;
    // 9.4.13 <table:named-expression>
    case "sort":
      break;
    // 9.4.19 <table:sort>
    case "sort-by":
      break;
    // 9.4.20 <table:sort-by>
    case "sort-groups":
      break;
    // 9.4.22 <table:sort-groups>
    case "tab":
      break;
    // 6.1.4 <text:tab>
    case "line-break":
      break;
    // 6.1.5 <text:line-break>
    case "span":
      break;
    // 6.1.7 <text:span>
    case "p":
    case "文本串":
      if (["master-styles"].indexOf(i[i.length - 1][0]) > -1) break;
      if (x[1] === "/" && (!E || !E["string-value"])) {
        var Le = hd(n.slice(P, x.index));
        y = (y.length > 0 ? y + `
` : "") + Le[0];
      } else x[0].slice(-2) == "/>" ? y += `
` : (le(x[0], !1), P = x.index + x[0].length);
      break;
    // <text:p>
    case "s":
      break;
    // <text:s>
    case "database-range":
      if (x[1] === "/") break;
      try {
        me = a0(le(x[0])["target-range-address"]), u[me[0]]["!autofilter"] = { ref: me[1] };
      } catch {
      }
      break;
    case "date":
      break;
    // <*:date>
    case "object":
      break;
    // 10.4.6.2 <draw:object>
    case "title":
    case "标题":
      break;
    // <*:title> OR <uof:标题>
    case "desc":
      break;
    // <*:desc>
    case "binary-data":
      break;
    // 10.4.5 TODO: b64 blob
    /* 9.2 Advanced Tables */
    case "table-source":
      break;
    // 9.2.6
    case "scenario":
      break;
    // 9.2.6
    case "iteration":
      break;
    // 9.4.3 <table:iteration>
    case "content-validations":
      break;
    // 9.4.4 <table:
    case "content-validation":
      break;
    // 9.4.5 <table:
    case "help-message":
      break;
    // 9.4.6 <table:
    case "error-message":
      break;
    // 9.4.7 <table:
    case "database-ranges":
      break;
    // 9.4.14 <table:database-ranges>
    /* 9.5 Filters */
    case "filter":
      break;
    // 9.5.2 <table:filter>
    case "filter-and":
      break;
    // 9.5.3 <table:filter-and>
    case "filter-or":
      break;
    // 9.5.4 <table:filter-or>
    case "filter-condition":
      break;
    // 9.5.5 <table:filter-condition>
    case "filter-set-item":
      break;
    // 9.5.6 <table:filter-condition>
    case "list-level-style-bullet":
      break;
    // 16.31 <text:
    case "list-level-style-number":
      break;
    // 16.32 <text:
    case "list-level-properties":
      break;
    // 17.19 <style:
    /* 7.3 Document Fields */
    case "sender-firstname":
    // 7.3.6.2
    case "sender-lastname":
    // 7.3.6.3
    case "sender-initials":
    // 7.3.6.4
    case "sender-title":
    // 7.3.6.5
    case "sender-position":
    // 7.3.6.6
    case "sender-email":
    // 7.3.6.7
    case "sender-phone-private":
    // 7.3.6.8
    case "sender-fax":
    // 7.3.6.9
    case "sender-company":
    // 7.3.6.10
    case "sender-phone-work":
    // 7.3.6.11
    case "sender-street":
    // 7.3.6.12
    case "sender-city":
    // 7.3.6.13
    case "sender-postal-code":
    // 7.3.6.14
    case "sender-country":
    // 7.3.6.15
    case "sender-state-or-province":
    // 7.3.6.16
    case "author-name":
    // 7.3.7.1
    case "author-initials":
    // 7.3.7.2
    case "chapter":
    // 7.3.8
    case "file-name":
    // 7.3.9
    case "template-name":
    // 7.3.9
    case "sheet-name":
      break;
    case "event-listener":
      break;
    /* TODO: FODS Properties */
    case "initial-creator":
    case "creation-date":
    case "print-date":
    case "generator":
    case "document-statistic":
    case "user-defined":
    case "editing-duration":
    case "editing-cycles":
      break;
    /* TODO: FODS Config */
    case "config-item":
      break;
    /* TODO: style tokens */
    case "page-number":
      break;
    // TODO <text:page-number>
    case "page-count":
      break;
    // TODO <text:page-count>
    case "time":
      break;
    // TODO <text:time>
    /* 9.3 Advanced Table Cells */
    case "cell-range-source":
      break;
    // 9.3.1 <table:
    case "detective":
      break;
    // 9.3.2 <table:
    case "operation":
      break;
    // 9.3.3 <table:
    case "highlighted-range":
      break;
    // 9.3.4 <table:
    /* 9.6 Data Pilot Tables <table: */
    case "data-pilot-table":
    // 9.6.3
    case "source-cell-range":
    // 9.6.5
    case "source-service":
    // 9.6.6
    case "data-pilot-field":
    // 9.6.7
    case "data-pilot-level":
    // 9.6.8
    case "data-pilot-subtotals":
    // 9.6.9
    case "data-pilot-subtotal":
    // 9.6.10
    case "data-pilot-members":
    // 9.6.11
    case "data-pilot-member":
    // 9.6.12
    case "data-pilot-display-info":
    // 9.6.13
    case "data-pilot-sort-info":
    // 9.6.14
    case "data-pilot-layout-info":
    // 9.6.15
    case "data-pilot-field-reference":
    // 9.6.16
    case "data-pilot-groups":
    // 9.6.17
    case "data-pilot-group":
    // 9.6.18
    case "data-pilot-group-member":
      break;
    /* 10.3 Drawing Shapes */
    case "rect":
      break;
    /* 14.6 DDE Connections */
    case "dde-connection-decls":
    // 14.6.2 <text:
    case "dde-connection-decl":
    // 14.6.3 <text:
    case "dde-link":
    // 14.6.4 <table:
    case "dde-source":
      break;
    case "properties":
      break;
    // 13.7 <form:properties>
    case "property":
      break;
    // 13.8 <form:property>
    case "a":
      if (x[1] !== "/") {
        if (Te = le(x[0], !1), !Te.href) break;
        Te.Target = Ce(Te.href), delete Te.href, Te.Target.charAt(0) == "#" && Te.Target.indexOf(".") > -1 ? (me = a0(Te.Target.slice(1)), Te.Target = "#" + me[0] + "!" + me[1]) : Te.Target.match(/^\.\.[\\\/]/) && (Te.Target = Te.Target.slice(3));
      }
      break;
    /* non-standard */
    case "table-protection":
      break;
    case "data-pilot-grand-total":
      break;
    // <table:
    case "office-document-common-attrs":
      break;
    // bare
    default:
      switch (x[2]) {
        case "dc:":
        // TODO: properties
        case "calcext:":
        // ignore undocumented extensions
        case "loext:":
        // ignore undocumented extensions
        case "ooo:":
        // ignore undocumented extensions
        case "chartooo:":
        // ignore undocumented extensions
        case "draw:":
        // TODO: drawing
        case "style:":
        // TODO: styles
        case "chart:":
        // TODO: charts
        case "form:":
        // TODO: forms
        case "uof:":
        // TODO: uof
        case "表:":
        // TODO: uof
        case "字:":
          break;
        default:
          if (t.WTF) throw new Error(x);
      }
  }
  var He = {
    Sheets: u,
    SheetNames: p,
    Workbook: ce
  };
  return t.bookSheets && delete /*::(*/
  He.Sheets, He;
}
function Un(e, a) {
  a = a || {}, Pr(e, "META-INF/manifest.xml") && Nc(Ze(e, "META-INF/manifest.xml"), a);
  var r = kr(e, "styles.xml"), t = r && ds(Ue(r)), n = kr(e, "content.xml");
  if (!n) throw new Error("Missing content.xml in ODS / UOF file");
  var i = vs(Ue(n), a, t);
  return Pr(e, "meta.xml") && (i.Props = Di(Ze(e, "meta.xml"))), i.bookType = "ods", i;
}
function Hn(e, a) {
  var r = vs(e, a);
  return r.bookType = "fods", r;
}
/*! sheetjs (C) 2013-present SheetJS -- http://sheetjs.com */
var fr = (function() {
  try {
    return typeof Uint8Array > "u" || typeof Uint8Array.prototype.subarray > "u" ? "slice" : typeof Buffer < "u" ? typeof Buffer.prototype.subarray > "u" ? "slice" : (typeof Buffer.from == "function" ? Buffer.from([72, 62]) : new Buffer([72, 62])) instanceof Uint8Array ? "subarray" : "slice" : "subarray";
  } catch {
    return "slice";
  }
})();
function ft(e) {
  return new DataView(e.buffer, e.byteOffset, e.byteLength);
}
function Na(e) {
  return typeof TextDecoder < "u" ? new TextDecoder().decode(e) : Ue(ea(e));
}
function ps(e) {
  for (var a = 0, r = 0; r < e.length; ++r)
    a += e[r].length;
  var t = new Uint8Array(a), n = 0;
  for (r = 0; r < e.length; ++r) {
    var i = e[r], f = i.length;
    if (f < 250)
      for (var s = 0; s < f; ++s)
        t[n++] = i[s];
    else
      t.set(i, n), n += f;
  }
  return t;
}
function Qa(e) {
  return e -= e >> 1 & 1431655765, e = (e & 858993459) + (e >> 2 & 858993459), (e + (e >> 4) & 252645135) * 16843009 >>> 24;
}
function xd(e, a) {
  for (var r = (e[a + 15] & 127) << 7 | e[a + 14] >> 1, t = e[a + 14] & 1, n = a + 13; n >= a; --n)
    t = t * 256 + e[n];
  return (e[a + 15] & 128 ? -t : t) * Math.pow(10, r - 6176);
}
function Ut(e, a) {
  var r = a.l, t = e[r] & 127;
  e:
    if (e[r++] >= 128 && (t |= (e[r] & 127) << 7, e[r++] < 128 || (t |= (e[r] & 127) << 14, e[r++] < 128) || (t |= (e[r] & 127) << 21, e[r++] < 128) || (t += (e[r] & 127) * Math.pow(2, 28), ++r, e[r++] < 128) || (t += (e[r] & 127) * Math.pow(2, 35), ++r, e[r++] < 128) || (t += (e[r] & 127) * Math.pow(2, 42), ++r, e[r++] < 128)))
      break e;
  return a.l = r, t;
}
function Re(e) {
  var a = 0, r = e[a] & 127;
  return e[a++] < 128 || (r |= (e[a] & 127) << 7, e[a++] < 128) || (r |= (e[a] & 127) << 14, e[a++] < 128) || (r |= (e[a] & 127) << 21, e[a++] < 128) || (r |= (e[a] & 15) << 28), r;
}
function Ae(e) {
  for (var a = [], r = { l: 0 }; r.l < e.length; ) {
    var t = r.l, n = Ut(e, r), i = n & 7;
    n = n / 8 | 0;
    var f, s = r.l;
    switch (i) {
      case 0:
        {
          for (; e[s++] >= 128; )
            ;
          f = e[fr](r.l, s), r.l = s;
        }
        break;
      case 1:
        f = e[fr](s, s + 8), r.l = s + 8;
        break;
      case 2:
        {
          var c = Ut(e, r);
          f = e[fr](r.l, r.l + c), r.l += c;
        }
        break;
      case 5:
        f = e[fr](s, s + 4), r.l = s + 4;
        break;
      default:
        throw new Error("PB Type ".concat(i, " for Field ").concat(n, " at offset ").concat(t));
    }
    var o = { data: f, type: i };
    a[n] == null && (a[n] = []), a[n].push(o);
  }
  return a;
}
function Kt(e, a) {
  return e?.map(function(r) {
    return a(r.data);
  }) || [];
}
function dd(e) {
  for (var a, r = [], t = { l: 0 }; t.l < e.length; ) {
    var n = Ut(e, t), i = Ae(e[fr](t.l, t.l + n));
    t.l += n;
    var f = {
      id: Re(i[1][0].data),
      messages: []
    };
    i[2].forEach(function(s) {
      var c = Ae(s.data), o = Re(c[3][0].data);
      f.messages.push({
        meta: c,
        data: e[fr](t.l, t.l + o)
      }), t.l += o;
    }), (a = i[3]) != null && a[0] && (f.merge = Re(i[3][0].data) >>> 0 > 0), r.push(f);
  }
  return r;
}
function vd(e, a) {
  if (e != 0)
    throw new Error("Unexpected Snappy chunk type ".concat(e));
  for (var r = { l: 0 }, t = Ut(a, r), n = [], i = r.l; i < a.length; ) {
    var f = a[i] & 3;
    if (f == 0) {
      var s = a[i++] >> 2;
      if (s < 60)
        ++s;
      else {
        var c = s - 59;
        s = a[i], c > 1 && (s |= a[i + 1] << 8), c > 2 && (s |= a[i + 2] << 16), c > 3 && (s |= a[i + 3] << 24), s >>>= 0, s++, i += c;
      }
      n.push(a[fr](i, i + s)), i += s;
      continue;
    } else {
      var o = 0, l = 0;
      if (f == 1 ? (l = (a[i] >> 2 & 7) + 4, o = (a[i++] & 224) << 3, o |= a[i++]) : (l = (a[i++] >> 2) + 1, f == 2 ? (o = a[i] | a[i + 1] << 8, i += 2) : (o = (a[i] | a[i + 1] << 8 | a[i + 2] << 16 | a[i + 3] << 24) >>> 0, i += 4)), o == 0)
        throw new Error("Invalid offset 0");
      for (var v = n.length - 1, d = o; v >= 0 && d >= n[v].length; )
        d -= n[v].length, --v;
      if (v < 0)
        if (d == 0)
          d = n[v = 0].length;
        else
          throw new Error("Invalid offset beyond length");
      if (l < d)
        n.push(n[v][fr](n[v].length - d, n[v].length - d + l));
      else {
        for (d > 0 && (n.push(n[v][fr](n[v].length - d)), l -= d), ++v; l >= n[v].length; )
          n.push(n[v]), l -= n[v].length, ++v;
        l && n.push(n[v][fr](0, l));
      }
      n.length > 25 && (n = [ps(n)]);
    }
  }
  for (var u = 0, p = 0; p < n.length; ++p)
    u += n[p].length;
  if (u != t)
    throw new Error("Unexpected length: ".concat(u, " != ").concat(t));
  return n;
}
function pd(e) {
  Array.isArray(e) && (e = new Uint8Array(e));
  for (var a = [], r = 0; r < e.length; ) {
    var t = e[r++], n = e[r] | e[r + 1] << 8 | e[r + 2] << 16;
    r += 3, a.push.apply(a, vd(t, e[fr](r, r + n))), r += n;
  }
  if (r !== e.length)
    throw new Error("data is not a valid framed stream!");
  return a.length == 1 ? a[0] : ps(a);
}
var gd = function() {
  return { sst: [], rsst: [], ofmt: [], nfmt: [], fmla: [], ferr: [], cmnt: [] };
};
function gs(e, a, r, t, n) {
  var i, f, s, c, o = a & 255, l = a >> 8, v = l >= 5 ? n : t;
  e:
    if (r & (l > 4 ? 8 : 4) && e.t == "n" && o == 7) {
      var d = (i = v[7]) != null && i[0] ? Re(v[7][0].data) : -1;
      if (d == -1)
        break e;
      var u = (f = v[15]) != null && f[0] ? Re(v[15][0].data) : -1, p = (s = v[16]) != null && s[0] ? Re(v[16][0].data) : -1, _ = (c = v[40]) != null && c[0] ? Re(v[40][0].data) : -1, x = e.v, h = x;
      r:
        if (_) {
          if (x == 0) {
            u = p = 2;
            break r;
          }
          x >= 604800 ? u = 1 : x >= 86400 ? u = 2 : x >= 3600 ? u = 4 : x >= 60 ? u = 8 : x >= 1 ? u = 16 : u = 32, Math.floor(x) != x ? p = 32 : x % 60 ? p = 16 : x % 3600 ? p = 8 : x % 86400 ? p = 4 : x % 604800 && (p = 2), p < u && (p = u);
        }
      if (u == -1 || p == -1)
        break e;
      var E = [], g = [];
      u == 1 && (h = x / 604800, p == 1 ? g.push('d"d"') : (h |= 0, x -= 604800 * h), E.push(h + (d == 2 ? " week" + (h == 1 ? "" : "s") : d == 1 ? "w" : ""))), u <= 2 && p >= 2 && (h = x / 86400, p > 2 && (h |= 0, x -= 86400 * h), g.push('d"d"'), E.push(h + (d == 2 ? " day" + (h == 1 ? "" : "s") : d == 1 ? "d" : ""))), u <= 4 && p >= 4 && (h = x / 3600, p > 4 && (h |= 0, x -= 3600 * h), g.push((u >= 4 ? "[h]" : "h") + '"h"'), E.push(h + (d == 2 ? " hour" + (h == 1 ? "" : "s") : d == 1 ? "h" : ""))), u <= 8 && p >= 8 && (h = x / 60, p > 8 && (h |= 0, x -= 60 * h), g.push((u >= 8 ? "[m]" : "m") + '"m"'), d == 0 ? E.push((u == 8 && p == 8 || h >= 10 ? "" : "0") + h) : E.push(h + (d == 2 ? " minute" + (h == 1 ? "" : "s") : d == 1 ? "m" : ""))), u <= 16 && p >= 16 && (h = x, p > 16 && (h |= 0, x -= h), g.push((u >= 16 ? "[s]" : "s") + '"s"'), d == 0 ? E.push((p == 16 && u == 16 || h >= 10 ? "" : "0") + h) : E.push(h + (d == 2 ? " second" + (h == 1 ? "" : "s") : d == 1 ? "s" : ""))), p >= 32 && (h = Math.round(1e3 * x), u < 32 && g.push('.000"ms"'), d == 0 ? E.push((h >= 100 ? "" : h >= 10 ? "0" : "00") + h) : E.push(h + (d == 2 ? " millisecond" + (h == 1 ? "" : "s") : d == 1 ? "ms" : ""))), e.w = E.join(d == 0 ? ":" : " "), e.z = g.join(d == 0 ? '":"' : " "), d == 0 && (e.w = e.w.replace(/:(\d\d\d)$/, ".$1"));
    }
}
function md(e, a, r, t) {
  var n = ft(e), i = n.getUint32(4, !0), f = -1, s = -1, c = -1, o = NaN, l = 0, v = new Date(Date.UTC(2001, 0, 1)), d = r > 1 ? 12 : 8;
  i & 2 && (c = n.getUint32(d, !0), d += 4), d += Qa(i & (r > 1 ? 3468 : 396)) * 4, i & 512 && (f = n.getUint32(d, !0), d += 4), d += Qa(i & (r > 1 ? 12288 : 4096)) * 4, i & 16 && (s = n.getUint32(d, !0), d += 4), i & 32 && (o = n.getFloat64(d, !0), d += 8), i & 64 && (v.setTime(v.getTime() + (l = n.getFloat64(d, !0)) * 1e3), d += 8), r > 1 && (i = n.getUint32(8, !0) >>> 16, i & 255 && (c == -1 && (c = n.getUint32(d, !0)), d += 4));
  var u, p = e[r >= 4 ? 1 : 2];
  switch (p) {
    case 0:
      return;
    case 2:
      u = { t: "n", v: o };
      break;
    case 3:
      u = { t: "s", v: a.sst[s] };
      break;
    case 5:
      t?.cellDates ? u = { t: "d", v } : u = { t: "n", v: l / 86400 + 35430, z: ge[14] };
      break;
    case 6:
      u = { t: "b", v: o > 0 };
      break;
    case 7:
      u = { t: "n", v: o };
      break;
    case 8:
      u = { t: "e", v: 0 };
      break;
    case 9:
      if (f > -1) {
        var _ = a.rsst[f];
        u = { t: "s", v: _.v }, _.l && (u.l = { Target: _.l });
      } else
        throw new Error("Unsupported cell type ".concat(e[fr](0, 4)));
      break;
    default:
      throw new Error("Unsupported cell type ".concat(e[fr](0, 4)));
  }
  return c > -1 && gs(u, p | r << 8, i, a.ofmt[c], a.nfmt[c]), p == 7 && (u.v /= 86400), u;
}
function _d(e, a, r) {
  var t = ft(e);
  t.getUint32(4, !0);
  var n = t.getUint32(8, !0), i = 12, f = -1, s = -1, c = -1, o = NaN, l = NaN, v = 0, d = new Date(Date.UTC(2001, 0, 1));
  n & 1 && (o = xd(e, i), i += 16), n & 2 && (l = t.getFloat64(i, !0), i += 8), n & 4 && (d.setTime(d.getTime() + (v = t.getFloat64(i, !0)) * 1e3), i += 8), n & 8 && (s = t.getUint32(i, !0), i += 4), n & 16 && (f = t.getUint32(i, !0), i += 4), i += Qa(n & 480) * 4, n & 512 && (t.getUint32(i, !0), i += 4), i += Qa(n & 1024) * 4, n & 2048 && (t.getUint32(i, !0), i += 4);
  var u, p = e[1];
  switch (p) {
    case 0:
      u = { t: "z" };
      break;
    case 2:
      u = { t: "n", v: o };
      break;
    case 3:
      u = { t: "s", v: a.sst[s] };
      break;
    case 5:
      r?.cellDates ? u = { t: "d", v: d } : u = { t: "n", v: v / 86400 + 35430, z: ge[14] };
      break;
    case 6:
      u = { t: "b", v: l > 0 };
      break;
    case 7:
      u = { t: "n", v: l };
      break;
    case 8:
      u = { t: "e", v: 0 };
      break;
    case 9:
      if (f > -1) {
        var _ = a.rsst[f];
        u = { t: "s", v: _.v }, _.l && (u.l = { Target: _.l });
      } else
        throw new Error("Unsupported cell type ".concat(e[1], " : ").concat(n & 31, " : ").concat(e[fr](0, 4)));
      break;
    case 10:
      u = { t: "n", v: o };
      break;
    default:
      throw new Error("Unsupported cell type ".concat(e[1], " : ").concat(n & 31, " : ").concat(e[fr](0, 4)));
  }
  if (i += Qa(n & 4096) * 4, n & 516096 && (c == -1 && (c = t.getUint32(i, !0)), i += 4), n & 524288) {
    var x = t.getUint32(i, !0);
    i += 4, a.cmnt[x] && (u.c = wd(a.cmnt[x]));
  }
  return c > -1 && gs(u, p | 1280, n >> 13, a.ofmt[c], a.nfmt[c]), p == 7 && (u.v /= 86400), u;
}
function kd(e, a, r) {
  switch (e[0]) {
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
      return md(e, a, e[0], r);
    case 5:
      return _d(e, a, r);
    default:
      throw new Error("Unsupported payload version ".concat(e[0]));
  }
}
function nr(e) {
  var a = Ae(e);
  return Re(a[1][0].data);
}
function xa(e, a) {
  var r = Ae(a.data), t = Re(r[1][0].data), n = r[3], i = [];
  return (n || []).forEach(function(f) {
    var s, c, o = Ae(f.data);
    if (o[1]) {
      var l = Re(o[1][0].data) >>> 0;
      switch (t) {
        case 1:
          i[l] = Na(o[3][0].data);
          break;
        case 8:
          {
            var v = e[nr(o[9][0].data)][0], d = Ae(v.data), u = e[nr(d[1][0].data)][0], p = Re(u.meta[1][0].data);
            if (p != 2001)
              throw new Error("2000 unexpected reference to ".concat(p));
            var _ = Ae(u.data), x = { v: _[3].map(function(g) {
              return Na(g.data);
            }).join("") };
            i[l] = x;
            e:
              if ((s = _?.[11]) != null && s[0]) {
                var h = (c = Ae(_[11][0].data)) == null ? void 0 : c[1];
                if (!h)
                  break e;
                h.forEach(function(g) {
                  var y, P, M, I = Ae(g.data);
                  if ((y = I[2]) != null && y[0]) {
                    var N = e[nr((P = I[2]) == null ? void 0 : P[0].data)][0], O = Re(N.meta[1][0].data);
                    switch (O) {
                      case 2032:
                        var B = Ae(N.data);
                        (M = B?.[2]) != null && M[0] && !x.l && (x.l = Na(B[2][0].data));
                        break;
                      case 2039:
                        break;
                      default:
                        console.log("unrecognized ObjectAttribute type ".concat(O));
                    }
                  }
                });
              }
          }
          break;
        case 2:
          i[l] = Ae(o[6][0].data);
          break;
        case 3:
          i[l] = Ae(o[5][0].data);
          break;
        case 10:
          {
            var E = e[nr(o[10][0].data)][0];
            i[l] = ms(e, E.data);
          }
          break;
        default:
          throw t;
      }
    }
  }), i;
}
function Ed(e, a) {
  var r, t, n, i, f, s, c, o, l, v, d, u, p, _, x = Ae(e), h = Re(x[1][0].data) >>> 0, E = Re(x[2][0].data) >>> 0, g = ((t = (r = x[8]) == null ? void 0 : r[0]) == null ? void 0 : t.data) && Re(x[8][0].data) > 0 || !1, y, P;
  if ((i = (n = x[7]) == null ? void 0 : n[0]) != null && i.data && a != 0)
    y = (s = (f = x[7]) == null ? void 0 : f[0]) == null ? void 0 : s.data, P = (o = (c = x[6]) == null ? void 0 : c[0]) == null ? void 0 : o.data;
  else if ((v = (l = x[4]) == null ? void 0 : l[0]) != null && v.data && a != 1)
    y = (u = (d = x[4]) == null ? void 0 : d[0]) == null ? void 0 : u.data, P = (_ = (p = x[3]) == null ? void 0 : p[0]) == null ? void 0 : _.data;
  else
    throw "NUMBERS Tile missing ".concat(a, " cell storage");
  for (var M = g ? 4 : 1, I = ft(y), N = [], O = 0; O < y.length / 2; ++O) {
    var B = I.getUint16(O * 2, !0);
    B < 65535 && N.push([O, B]);
  }
  if (N.length != E)
    throw "Expected ".concat(E, " cells, found ").concat(N.length);
  var b = [];
  for (O = 0; O < N.length - 1; ++O)
    b[N[O][0]] = P[fr](N[O][1] * M, N[O + 1][1] * M);
  return N.length >= 1 && (b[N[N.length - 1][0]] = P[fr](N[N.length - 1][1] * M)), { R: h, cells: b };
}
function Td(e, a) {
  var r, t = Ae(a.data), n = -1;
  (r = t?.[7]) != null && r[0] && (Re(t[7][0].data) >>> 0 ? n = 1 : n = 0);
  var i = Kt(t[5], function(f) {
    return Ed(f, n);
  });
  return {
    nrows: Re(t[4][0].data) >>> 0,
    data: i.reduce(function(f, s) {
      return f[s.R] || (f[s.R] = []), s.cells.forEach(function(c, o) {
        if (f[s.R][o])
          throw new Error("Duplicate cell r=".concat(s.R, " c=").concat(o));
        f[s.R][o] = c;
      }), f;
    }, [])
  };
}
function ms(e, a) {
  var r, t, n, i, f, s, c, o, l, v, d = { t: "", a: "" }, u = Ae(a);
  if ((t = (r = u?.[1]) == null ? void 0 : r[0]) != null && t.data && (d.t = Na((i = (n = u?.[1]) == null ? void 0 : n[0]) == null ? void 0 : i.data) || ""), (s = (f = u?.[3]) == null ? void 0 : f[0]) != null && s.data) {
    var p = e[nr((o = (c = u?.[3]) == null ? void 0 : c[0]) == null ? void 0 : o.data)][0], _ = Ae(p.data);
    (v = (l = _[1]) == null ? void 0 : l[0]) != null && v.data && (d.a = Na(_[1][0].data));
  }
  return u?.[4] && (d.replies = [], u[4].forEach(function(x) {
    var h = e[nr(x.data)][0];
    d.replies.push(ms(e, h.data));
  })), d;
}
function wd(e) {
  var a = [];
  return a.push({ t: e.t || "", a: e.a, T: e.replies && e.replies.length > 0 }), e.replies && e.replies.forEach(function(r) {
    a.push({ t: r.t || "", a: r.a, T: !0 });
  }), a;
}
function Fd(e, a, r, t) {
  var n, i, f, s, c, o, l, v, d, u, p, _, x, h, E = Ae(a.data), g = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } };
  if (g.e.r = (Re(E[6][0].data) >>> 0) - 1, g.e.r < 0)
    throw new Error("Invalid row varint ".concat(E[6][0].data));
  if (g.e.c = (Re(E[7][0].data) >>> 0) - 1, g.e.c < 0)
    throw new Error("Invalid col varint ".concat(E[7][0].data));
  r["!ref"] = ye(g);
  var y = r["!data"] != null, P = r, M = Ae(E[4][0].data), I = gd();
  (n = M[4]) != null && n[0] && (I.sst = xa(e, e[nr(M[4][0].data)][0])), (i = M[6]) != null && i[0] && (I.fmla = xa(e, e[nr(M[6][0].data)][0])), (f = M[11]) != null && f[0] && (I.ofmt = xa(e, e[nr(M[11][0].data)][0])), (s = M[12]) != null && s[0] && (I.ferr = xa(e, e[nr(M[12][0].data)][0])), (c = M[17]) != null && c[0] && (I.rsst = xa(e, e[nr(M[17][0].data)][0])), (o = M[19]) != null && o[0] && (I.cmnt = xa(e, e[nr(M[19][0].data)][0])), (l = M[22]) != null && l[0] && (I.nfmt = xa(e, e[nr(M[22][0].data)][0]));
  var N = Ae(M[3][0].data), O = 0;
  if (!((v = M[9]) != null && v[0]))
    throw "NUMBERS file missing row tree";
  var B = Ae(M[9][0].data)[1].map(function(j) {
    return Ae(j.data);
  });
  if (B.forEach(function(j) {
    O = Re(j[1][0].data);
    var he = Re(j[2][0].data), J = N[1][he];
    if (!J)
      throw "NUMBERS missing tile " + he;
    var ne = Ae(J.data), pe = e[nr(ne[2][0].data)][0], X = Re(pe.meta[1][0].data);
    if (X != 6002)
      throw new Error("6001 unexpected reference to ".concat(X));
    var ke = Td(e, pe);
    ke.data.forEach(function(_e, de) {
      _e.forEach(function(ce, Te) {
        var me = kd(ce, I, t);
        me && (y ? (P["!data"][O + de] || (P["!data"][O + de] = []), P["!data"][O + de][Te] = me) : r[Pe(Te) + Me(O + de)] = me);
      });
    }), O += ke.nrows;
  }), (d = M[13]) != null && d[0]) {
    var b = e[nr(M[13][0].data)][0], G = Re(b.meta[1][0].data);
    if (G != 6144)
      throw new Error("Expected merge type 6144, found ".concat(G));
    r["!merges"] = (u = Ae(b.data)) == null ? void 0 : u[1].map(function(j) {
      var he = Ae(j.data), J = ft(Ae(he[1][0].data)[1][0].data), ne = ft(Ae(he[2][0].data)[1][0].data);
      return {
        s: { r: J.getUint16(0, !0), c: J.getUint16(2, !0) },
        e: {
          r: J.getUint16(0, !0) + ne.getUint16(0, !0) - 1,
          c: J.getUint16(2, !0) + ne.getUint16(2, !0) - 1
        }
      };
    });
  }
  if (!((p = r["!merges"]) != null && p.length) && ((_ = E[47]) != null && _[0])) {
    var z = Ae(E[47][0].data);
    if ((x = z[2]) != null && x[0]) {
      var fe = Ae(z[2][0].data);
      (h = fe[3]) != null && h[0] && (r["!merges"] = Kt(fe[3], function(j) {
        var he, J, ne, pe, X, ke = Ae(j), _e = Ae(ke[2][0].data), de = Ae(_e[1][0].data);
        if ((he = de[1]) != null && he[0]) {
          var ce = Ae(de[1][0].data), Te = Re(ce[1][0].data);
          if (Te == 67) {
            var me = Ae(ce[40][0].data);
            if (!(!((J = me[3]) != null && J[0]) || !((ne = me[4]) != null && ne[0]))) {
              var Fe = Ae(me[3][0].data), S = Ae(me[4][0].data), L = Re(Fe[1][0].data), R = (pe = Fe[2]) != null && pe[0] ? Re(Fe[2][0].data) : L, D = Re(S[1][0].data), Y = (X = S[2]) != null && X[0] ? Re(S[2][0].data) : D;
              return { s: { r: D, c: L }, e: { r: Y, c: R } };
            }
          }
        }
      }).filter(function(j) {
        return j != null;
      }));
    }
  }
}
function Ad(e, a, r) {
  var t = Ae(a.data), n = { "!ref": "A1" };
  r?.dense && (n["!data"] = []);
  var i = e[nr(t[2][0].data)], f = Re(i[0].meta[1][0].data);
  if (f != 6001)
    throw new Error("6000 unexpected reference to ".concat(f));
  return Fd(e, i[0], n, r), n;
}
function Sd(e, a, r) {
  var t, n = Ae(a.data), i = {
    name: (t = n[1]) != null && t[0] ? Na(n[1][0].data) : "",
    sheets: []
  }, f = Kt(n[2], nr);
  return f.forEach(function(s) {
    e[s].forEach(function(c) {
      var o = Re(c.meta[1][0].data);
      o == 6e3 && i.sheets.push(Ad(e, c, r));
    });
  }), i;
}
function Cd(e, a, r) {
  var t, n = L0();
  n.Workbook = { WBProps: { date1904: !0 } };
  var i = Ae(a.data);
  if ((t = i[2]) != null && t[0])
    throw new Error("Keynote presentations are not supported");
  var f = Kt(i[1], nr);
  if (f.forEach(function(s) {
    e[s].forEach(function(c) {
      var o = Re(c.meta[1][0].data);
      if (o == 2) {
        var l = Sd(e, c, r);
        l.sheets.forEach(function(v, d) {
          vt(n, v, d == 0 ? l.name : l.name + "_" + d, !0);
        });
      }
    });
  }), n.SheetNames.length == 0)
    throw new Error("Empty NUMBERS file");
  return n.bookType = "numbers", n;
}
function n0(e, a) {
  var r, t, n, i, f, s, c, o = {}, l = [];
  if (e.FullPaths.forEach(function(d) {
    if (d.match(/\.iwpv2/))
      throw new Error("Unsupported password protection");
  }), e.FileIndex.forEach(function(d) {
    if (d.name.match(/\.iwa$/) && d.content[0] == 0) {
      var u;
      try {
        u = pd(d.content);
      } catch (_) {
        return console.log("?? " + d.content.length + " " + (_.message || _));
      }
      var p;
      try {
        p = dd(u);
      } catch (_) {
        return console.log("## " + (_.message || _));
      }
      p.forEach(function(_) {
        o[_.id] = _.messages, l.push(_.id);
      });
    }
  }), !l.length)
    throw new Error("File has no messages");
  if ((n = (t = (r = o?.[1]) == null ? void 0 : r[0].meta) == null ? void 0 : t[1]) != null && n[0].data && Re(o[1][0].meta[1][0].data) == 1e4)
    throw new Error("Pages documents are not supported");
  var v = ((c = (s = (f = (i = o?.[1]) == null ? void 0 : i[0]) == null ? void 0 : f.meta) == null ? void 0 : s[1]) == null ? void 0 : c[0].data) && Re(o[1][0].meta[1][0].data) == 1 && o[1][0];
  if (v || l.forEach(function(d) {
    o[d].forEach(function(u) {
      var p = Re(u.meta[1][0].data) >>> 0;
      if (p == 1)
        if (!v)
          v = u;
        else
          throw new Error("Document has multiple roots");
    });
  }), !v)
    throw new Error("Cannot find Document root");
  return Cd(o, v, a);
}
function yd(e) {
  return function(r) {
    for (var t = 0; t != e.length; ++t) {
      var n = e[t];
      r[n[0]] === void 0 && (r[n[0]] = n[1]), n[2] === "n" && (r[n[0]] = Number(r[n[0]]));
    }
  };
}
function P0(e) {
  yd([
    ["cellNF", !1],
    /* emit cell number format string as .z */
    ["cellHTML", !0],
    /* emit html string as .h */
    ["cellFormula", !0],
    /* emit formulae as .f */
    ["cellStyles", !1],
    /* emits style/theme as .s */
    ["cellText", !0],
    /* emit formatted text as .w */
    ["cellDates", !1],
    /* emit date cells with type `d` */
    ["sheetStubs", !1],
    /* emit empty cells */
    ["sheetRows", 0, "n"],
    /* read n rows (0 = read all rows) */
    ["bookDeps", !1],
    /* parse calculation chains */
    ["bookSheets", !1],
    /* only try to get sheet names (no Sheets) */
    ["bookProps", !1],
    /* only try to get properties (no Sheets) */
    ["bookFiles", !1],
    /* include raw file structure (keys, files, cfb) */
    ["bookVBA", !1],
    /* include vba raw data (vbaraw) */
    ["password", ""],
    /* password */
    ["WTF", !1]
    /* WTF mode (throws errors) */
  ])(e);
}
function Dd(e) {
  return Ia.WS.indexOf(e) > -1 ? "sheet" : e == Ia.CS ? "chart" : e == Ia.DS ? "dialog" : e == Ia.MS ? "macro" : e && e.length ? e : "sheet";
}
function Id(e, a) {
  if (!e) return 0;
  try {
    e = a.map(function(t) {
      return t.id || (t.id = t.strRelID), [t.name, e["!id"][t.id].Target, Dd(e["!id"][t.id].Type)];
    });
  } catch {
    return null;
  }
  return !e || e.length === 0 ? null : e;
}
function Od(e, a, r, t, n, i, f, s) {
  if (!(!e || !e["!legdrawel"])) {
    var c = Da(e["!legdrawel"].Target, t), o = kr(r, c, !0);
    o && M1(Ue(o), e, s || []);
  }
}
function Rd(e, a, r, t, n, i, f, s, c, o, l, v) {
  try {
    i[t] = Ka(kr(e, r, !0), a);
    var d = Ze(e, a), u;
    switch (s) {
      case "sheet":
        u = bx(d, a, n, c, i[t], o, l, v);
        break;
      case "chart":
        if (u = Lx(d, a, n, c, i[t], o, l, v), !u || !u["!drawel"]) break;
        var p = Da(u["!drawel"].Target, a), _ = c0(p), x = B1(kr(e, p, !0), Ka(kr(e, _, !0), p)), h = Da(x, p), E = c0(h);
        u = mx(kr(e, h, !0), h, c, Ka(kr(e, E, !0), h), o, u);
        break;
      case "macro":
        u = Bx(d, a, n, c, i[t], o, l, v);
        break;
      case "dialog":
        u = Mx(d, a, n, c, i[t], o, l, v);
        break;
      default:
        throw new Error("Unrecognized sheet type " + s);
    }
    f[t] = u;
    var g = [], y = [];
    i && i[t] && Lr(i[t]).forEach(function(P) {
      var M = "";
      if (i[t][P].Type == Ia.CMNT) {
        if (M = Da(i[t][P].Target, a), g = Wx(Ze(e, M, !0), M, c), !g || !g.length) return;
        Cn(u, g, !1);
      }
      i[t][P].Type == Ia.TCMNT && (M = Da(i[t][P].Target, a), y = y.concat(H1(Ze(e, M, !0), c)));
    }), y && y.length && Cn(u, y, !0, c.people || []), Od(u, s, e, a, n, c, o, g);
  } catch (P) {
    if (c.WTF) throw P;
  }
}
function Rr(e) {
  return e.charAt(0) == "/" ? e.slice(1) : e;
}
function Nd(e, a) {
  if (Qn(), a = a || {}, P0(a), Pr(e, "META-INF/manifest.xml") || Pr(e, "objectdata.xml")) return Un(e, a);
  if (Pr(e, "Index/Document.iwa")) {
    if (typeof Uint8Array > "u") throw new Error("NUMBERS file parsing requires Uint8Array support");
    if (typeof n0 < "u") {
      if (e.FileIndex) return n0(e, a);
      var r = Oe.utils.cfb_new();
      return q0(e).forEach(function(j) {
        bf(r, j, Pf(e, j));
      }), n0(r, a);
    }
    throw new Error("Unsupported NUMBERS file");
  }
  if (!Pr(e, "[Content_Types].xml")) {
    if (Pr(e, "index.xml.gz")) throw new Error("Unsupported NUMBERS 08 file");
    if (Pr(e, "index.xml")) throw new Error("Unsupported NUMBERS 09 file");
    var t = Oe.find(e, "Index.zip");
    if (t)
      return a = er(a), delete a.type, typeof t.content == "string" && (a.type = "binary"), typeof Bun < "u" && Buffer.isBuffer(t.content) ? et(new Uint8Array(t.content), a) : et(t.content, a);
    throw new Error("Unsupported ZIP file");
  }
  var n = q0(e), i = Oc(kr(e, "[Content_Types].xml")), f = !1, s, c;
  if (i.workbooks.length === 0 && (c = "xl/workbook.xml", Ze(e, c, !0) && i.workbooks.push(c)), i.workbooks.length === 0) {
    if (c = "xl/workbook.bin", !Ze(e, c, !0)) throw new Error("Could not find workbook");
    i.workbooks.push(c), f = !0;
  }
  i.workbooks[0].slice(-3) == "bin" && (f = !0);
  var o = {}, l = {};
  if (!a.bookSheets && !a.bookProps) {
    if (Ja = [], i.sst) try {
      Ja = Hx(Ze(e, Rr(i.sst)), i.sst, a);
    } catch (j) {
      if (a.WTF) throw j;
    }
    a.cellStyles && i.themes.length && (o = ji(kr(e, i.themes[0].replace(/^\//, ""), !0) || "", a)), i.style && (l = Ux(Ze(e, Rr(i.style)), i.style, o, a));
  }
  i.links.map(function(j) {
    try {
      var he = Ka(kr(e, c0(Rr(j))), j);
      return Gx(Ze(e, Rr(j)), he, j, a);
    } catch {
    }
  });
  var v = Px(Ze(e, Rr(i.workbooks[0])), i.workbooks[0], a), d = {}, u = "";
  i.coreprops.length && (u = Ze(e, Rr(i.coreprops[0]), !0), u && (d = Di(u)), i.extprops.length !== 0 && (u = Ze(e, Rr(i.extprops[0]), !0), u && bc(u, d, a)));
  var p = {};
  (!a.bookSheets || a.bookProps) && i.custprops.length !== 0 && (u = kr(e, Rr(i.custprops[0]), !0), u && (p = Bc(u, a)));
  var _ = {};
  if ((a.bookSheets || a.bookProps) && (v.Sheets ? s = v.Sheets.map(function(he) {
    return he.name;
  }) : d.Worksheets && d.SheetNames.length > 0 && (s = d.SheetNames), a.bookProps && (_.Props = d, _.Custprops = p), a.bookSheets && typeof s < "u" && (_.SheetNames = s), a.bookSheets ? _.SheetNames : a.bookProps))
    return _;
  s = {};
  var x = {};
  a.bookDeps && i.calcchain && (x = Vx(Ze(e, Rr(i.calcchain)), i.calcchain));
  var h = 0, E = {}, g, y;
  {
    var P = v.Sheets;
    d.Worksheets = P.length, d.SheetNames = [];
    for (var M = 0; M != P.length; ++M)
      d.SheetNames[M] = P[M].name;
  }
  var I = f ? "bin" : "xml", N = i.workbooks[0].lastIndexOf("/"), O = (i.workbooks[0].slice(0, N + 1) + "_rels/" + i.workbooks[0].slice(N + 1) + ".rels").replace(/^\//, "");
  Pr(e, O) || (O = "xl/_rels/workbook." + I + ".rels");
  var B = Ka(kr(e, O, !0), O.replace(/_rels.*/, "s5s"));
  (i.metadata || []).length >= 1 && (a.xlmeta = Xx(Ze(e, Rr(i.metadata[0])), i.metadata[0], a)), (i.people || []).length >= 1 && (a.people = W1(Ze(e, Rr(i.people[0])), a)), B && (B = Id(B, v.Sheets));
  var b = Ze(e, "xl/worksheets/sheet.xml", !0) ? 1 : 0;
  e: for (h = 0; h != d.Worksheets; ++h) {
    var G = "sheet";
    if (B && B[h] ? (g = "xl/" + B[h][1].replace(/[\/]?xl\//, ""), Pr(e, g) || (g = B[h][1]), Pr(e, g) || (g = O.replace(/_rels\/[\S\s]*$/, "") + B[h][1]), G = B[h][2]) : (g = "xl/worksheets/sheet" + (h + 1 - b) + "." + I, g = g.replace(/sheet0\./, "sheet.")), y = g.replace(/^(.*)(\/)([^\/]*)$/, "$1/_rels/$3.rels"), a && a.sheets != null) switch (typeof a.sheets) {
      case "number":
        if (h != a.sheets) continue e;
        break;
      case "string":
        if (d.SheetNames[h].toLowerCase() != a.sheets.toLowerCase()) continue e;
        break;
      default:
        if (Array.isArray && Array.isArray(a.sheets)) {
          for (var z = !1, fe = 0; fe != a.sheets.length; ++fe)
            typeof a.sheets[fe] == "number" && a.sheets[fe] == h && (z = 1), typeof a.sheets[fe] == "string" && a.sheets[fe].toLowerCase() == d.SheetNames[h].toLowerCase() && (z = 1);
          if (!z) continue e;
        }
    }
    Rd(e, g, y, d.SheetNames[h], h, E, s, G, a, v, o, l);
  }
  return _ = {
    Directory: i,
    Workbook: v,
    Props: d,
    Custprops: p,
    Deps: x,
    Sheets: s,
    SheetNames: d.SheetNames,
    Strings: Ja,
    Styles: l,
    Themes: o,
    SSF: er(ge)
  }, a && a.bookFiles && (e.files ? (_.keys = n, _.files = e.files) : (_.keys = [], _.files = {}, e.FullPaths.forEach(function(j, he) {
    j = j.replace(/^Root Entry[\/]/, ""), _.keys.push(j), _.files[j] = e.FileIndex[he];
  }))), a && a.bookVBA && (i.vba.length > 0 ? _.vbaraw = Ze(e, Rr(i.vba[0]), !0) : i.defaults && i.defaults.bin === z1 && (_.vbaraw = Ze(e, "xl/vbaProject.bin", !0))), _.bookType = f ? "xlsb" : "xlsx", _;
}
function Pd(e, a) {
  var r = a || {}, t = "Workbook", n = Oe.find(e, t);
  try {
    if (t = "/!DataSpaces/Version", n = Oe.find(e, t), !n || !n.content) throw new Error("ECMA-376 Encrypted file missing " + t);
    if (Ol(n.content), t = "/!DataSpaces/DataSpaceMap", n = Oe.find(e, t), !n || !n.content) throw new Error("ECMA-376 Encrypted file missing " + t);
    var i = Nl(n.content);
    if (i.length !== 1 || i[0].comps.length !== 1 || i[0].comps[0].t !== 0 || i[0].name !== "StrongEncryptionDataSpace" || i[0].comps[0].v !== "EncryptedPackage")
      throw new Error("ECMA-376 Encrypted file bad " + t);
    if (t = "/!DataSpaces/DataSpaceInfo/StrongEncryptionDataSpace", n = Oe.find(e, t), !n || !n.content) throw new Error("ECMA-376 Encrypted file missing " + t);
    var f = Pl(n.content);
    if (f.length != 1 || f[0] != "StrongEncryptionTransform")
      throw new Error("ECMA-376 Encrypted file bad " + t);
    if (t = "/!DataSpaces/TransformInfo/StrongEncryptionTransform/!Primary", n = Oe.find(e, t), !n || !n.content) throw new Error("ECMA-376 Encrypted file missing " + t);
    Ll(n.content);
  } catch {
  }
  if (t = "/EncryptionInfo", n = Oe.find(e, t), !n || !n.content) throw new Error("ECMA-376 Encrypted file missing " + t);
  var s = Bl(n.content);
  if (t = "/EncryptedPackage", n = Oe.find(e, t), !n || !n.content) throw new Error("ECMA-376 Encrypted file missing " + t);
  if (s[0] == 4 && typeof decrypt_agile < "u") return decrypt_agile(s[1], n.content, r.password || "", r);
  if (s[0] == 2 && typeof decrypt_std76 < "u") return decrypt_std76(s[1], n.content, r.password || "", r);
  throw new Error("File is password-protected");
}
function b0(e, a) {
  var r = "";
  switch ((a || {}).type || "base64") {
    case "buffer":
      return [e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7]];
    case "base64":
      r = Or(e.slice(0, 12));
      break;
    case "binary":
      r = e;
      break;
    case "array":
      return [e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7]];
    default:
      throw new Error("Unrecognized type " + (a && a.type || "undefined"));
  }
  return [r.charCodeAt(0), r.charCodeAt(1), r.charCodeAt(2), r.charCodeAt(3), r.charCodeAt(4), r.charCodeAt(5), r.charCodeAt(6), r.charCodeAt(7)];
}
function bd(e, a) {
  return Oe.find(e, "EncryptedPackage") ? Pd(e, a) : us(e, a);
}
function Ld(e, a) {
  var r, t = e, n = a || {};
  return n.type || (n.type = Se && Buffer.isBuffer(e) ? "buffer" : "base64"), r = ii(t, n), Nd(r, n);
}
function _s(e, a) {
  var r = 0;
  e: for (; r < e.length; ) switch (e.charCodeAt(r)) {
    case 10:
    case 13:
    case 32:
      ++r;
      break;
    case 60:
      return l0(e.slice(r), a);
    default:
      break e;
  }
  return nt.to_workbook(e, a);
}
function Bd(e, a) {
  var r = "", t = b0(e, a);
  switch (a.type) {
    case "base64":
      r = Or(e);
      break;
    case "binary":
      r = e;
      break;
    case "buffer":
      r = e.toString("binary");
      break;
    case "array":
      r = ka(e);
      break;
    default:
      throw new Error("Unrecognized type " + a.type);
  }
  return t[0] == 239 && t[1] == 187 && t[2] == 191 && (r = Ue(r)), a.type = "binary", _s(r, a);
}
function Md(e, a) {
  var r = e;
  return a.type == "base64" && (r = Or(r)), typeof ArrayBuffer < "u" && e instanceof ArrayBuffer && (r = new Uint8Array(e)), r = Se && Buffer.isBuffer(e) ? e.slice(2).toString("utf16le") : typeof Uint8Array < "u" && r instanceof Uint8Array ? typeof TextDecoder < "u" ? new TextDecoder("utf-16le").decode(r.slice(2)) : Ms(r.slice(2)) : Gn(r.slice(2)), a.type = "binary", _s(r, a);
}
function Ud(e) {
  return e.match(/[^\x00-\x7F]/) ? Va(e) : e;
}
function i0(e, a, r, t) {
  return t ? (r.type = "string", nt.to_workbook(e, r)) : nt.to_workbook(a, r);
}
function et(e, a) {
  Vn();
  var r = a || {};
  if (r.codepage && console.error("Codepage tables are not loaded.  Non-ASCII characters may not give expected results"), typeof ArrayBuffer < "u" && e instanceof ArrayBuffer) return et(new Uint8Array(e), (r = er(r), r.type = "array", r));
  if (typeof Int8Array < "u" && e instanceof Int8Array) return et(new Uint8Array(e.buffer, e.byteOffset, e.length), r);
  typeof Uint8Array < "u" && e instanceof Uint8Array && !r.type && (r.type = typeof Deno < "u" ? "buffer" : "array");
  var t = e, n = [0, 0, 0, 0], i = !1;
  if (r.cellStyles && (r.cellNF = !0, r.sheetStubs = !0), Ra = {}, r.dateNF && (Ra.dateNF = r.dateNF), r.type || (r.type = Se && Buffer.isBuffer(e) ? "buffer" : "base64"), r.type == "file" && (r.type = Se ? "buffer" : "binary", t = pf(e), typeof Uint8Array < "u" && !Se && (r.type = "array")), r.type == "string" && (i = !0, r.type = "binary", r.codepage = 65001, t = Ud(e)), r.type == "array" && typeof Uint8Array < "u" && e instanceof Uint8Array && typeof ArrayBuffer < "u") {
    var f = new ArrayBuffer(3), s = new Uint8Array(f);
    if (s.foo = "bar", !s.foo)
      return r = er(r), r.type = "array", et(v0(t), r);
  }
  switch ((n = b0(t, r))[0]) {
    case 208:
      if (n[1] === 207 && n[2] === 17 && n[3] === 224 && n[4] === 161 && n[5] === 177 && n[6] === 26 && n[7] === 225) return bd(Oe.read(t, r), r);
      break;
    case 9:
      if (n[1] <= 8) return us(t, r);
      break;
    case 60:
      return l0(t, r);
    case 73:
      if (n[1] === 73 && n[2] === 42 && n[3] === 0) throw new Error("TIFF Image File is not a spreadsheet");
      if (n[1] === 68) return kl(t, r);
      break;
    case 84:
      if (n[1] === 65 && n[2] === 66 && n[3] === 76) return ml.to_workbook(t, r);
      break;
    case 80:
      return n[1] === 75 && n[2] < 9 && n[3] < 9 ? Ld(t, r) : i0(e, t, r, i);
    case 239:
      return n[3] === 60 ? l0(t, r) : i0(e, t, r, i);
    case 255:
      if (n[1] === 254)
        return Md(t, r);
      if (n[1] === 0 && n[2] === 2 && n[3] === 0) return ja.to_workbook(t, r);
      break;
    case 0:
      if (n[1] === 0 && (n[2] >= 2 && n[3] === 0 || n[2] === 0 && (n[3] === 8 || n[3] === 9)))
        return ja.to_workbook(t, r);
      break;
    case 3:
    case 131:
    case 139:
    case 140:
      return Sn.to_workbook(t, r);
    case 123:
      if (n[1] === 92 && n[2] === 114 && n[3] === 116) return Jl(t, r);
      break;
    case 10:
    case 13:
    case 32:
      return Bd(t, r);
    case 137:
      if (n[1] === 80 && n[2] === 78 && n[3] === 71) throw new Error("PNG Image File is not a spreadsheet");
      break;
    case 8:
      if (n[1] === 231) throw new Error("Unsupported Multiplan 1.x file!");
      break;
    case 12:
      if (n[1] === 236) throw new Error("Unsupported Multiplan 2.x file!");
      if (n[1] === 237) throw new Error("Unsupported Multiplan 3.x file!");
      break;
  }
  return pl.indexOf(n[0]) > -1 && n[2] <= 12 && n[3] <= 31 ? Sn.to_workbook(t, r) : i0(e, t, r, i);
}
function Hd(e, a, r, t, n, i, f) {
  var s = Me(r), c = f.defval, o = f.raw || !Object.prototype.hasOwnProperty.call(f, "raw"), l = !0, v = e["!data"] != null, d = n === 1 ? [] : {};
  if (n !== 1)
    if (Object.defineProperty) try {
      Object.defineProperty(d, "__rowNum__", { value: r, enumerable: !1 });
    } catch {
      d.__rowNum__ = r;
    }
    else d.__rowNum__ = r;
  if (!v || e["!data"][r]) for (var u = a.s.c; u <= a.e.c; ++u) {
    var p = v ? (e["!data"][r] || [])[u] : e[t[u] + s];
    if (p == null || p.t === void 0) {
      if (c === void 0) continue;
      i[u] != null && (d[i[u]] = c);
      continue;
    }
    var _ = p.v;
    switch (p.t) {
      case "z":
        if (_ == null) break;
        continue;
      case "e":
        _ = _ == 0 ? null : void 0;
        break;
      case "s":
      case "b":
      case "n":
        if (!p.z || !Br(p.z) || (_ = ia(_), typeof _ == "number")) break;
      /* falls through */
      case "d":
        f && (f.UTC || f.raw === !1) || (_ = Ea(new Date(_)));
        break;
      default:
        throw new Error("unrecognized type " + p.t);
    }
    if (i[u] != null) {
      if (_ == null)
        if (p.t == "e" && _ === null) d[i[u]] = null;
        else if (c !== void 0) d[i[u]] = c;
        else if (o && _ === null) d[i[u]] = null;
        else continue;
      else
        d[i[u]] = (p.t === "n" && typeof f.rawNumbers == "boolean" ? f.rawNumbers : o) ? _ : fa(p, _, f);
      _ != null && (l = !1);
    }
  }
  return { row: d, isempty: l };
}
function h0(e, a) {
  if (e == null || e["!ref"] == null) return [];
  var r = { t: "n", v: 0 }, t = 0, n = 1, i = [], f = 0, s = "", c = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }, o = a || {}, l = o.range != null ? o.range : e["!ref"];
  switch (o.header === 1 ? t = 1 : o.header === "A" ? t = 2 : Array.isArray(o.header) ? t = 3 : o.header == null && (t = 0), typeof l) {
    case "string":
      c = Ke(l);
      break;
    case "number":
      c = Ke(e["!ref"]), c.s.r = l;
      break;
    default:
      c = l;
  }
  t > 0 && (n = 0);
  var v = Me(c.s.r), d = [], u = [], p = 0, _ = 0, x = e["!data"] != null, h = c.s.r, E = 0, g = {};
  x && !e["!data"][h] && (e["!data"][h] = []);
  var y = o.skipHidden && e["!cols"] || [], P = o.skipHidden && e["!rows"] || [];
  for (E = c.s.c; E <= c.e.c; ++E)
    if (!(y[E] || {}).hidden)
      switch (d[E] = Pe(E), r = x ? e["!data"][h][E] : e[d[E] + v], t) {
        case 1:
          i[E] = E - c.s.c;
          break;
        case 2:
          i[E] = d[E];
          break;
        case 3:
          i[E] = o.header[E - c.s.c];
          break;
        default:
          if (r == null && (r = { w: "__EMPTY", t: "s" }), s = f = fa(r, null, o), _ = g[f] || 0, !_) g[f] = 1;
          else {
            do
              s = f + "_" + _++;
            while (g[s]);
            g[f] = _, g[s] = 1;
          }
          i[E] = s;
      }
  for (h = c.s.r + n; h <= c.e.r; ++h)
    if (!(P[h] || {}).hidden) {
      var M = Hd(e, c, h, d, t, i, o);
      (M.isempty === !1 || (t === 1 ? o.blankrows !== !1 : o.blankrows)) && (u[p++] = M.row);
    }
  return u.length = p, u;
}
var Wn = /"/g;
function Wd(e, a, r, t, n, i, f, s, c) {
  for (var o = !0, l = [], v = "", d = Me(r), u = e["!data"] != null, p = u && e["!data"][r] || [], _ = a.s.c; _ <= a.e.c; ++_)
    if (t[_]) {
      var x = u ? p[_] : e[t[_] + d];
      if (x == null) v = "";
      else if (x.v != null) {
        o = !1, v = "" + (c.rawNumbers && x.t == "n" ? x.v : fa(x, null, c));
        for (var h = 0, E = 0; h !== v.length; ++h) if ((E = v.charCodeAt(h)) === n || E === i || E === 34 || c.forceQuotes) {
          v = '"' + v.replace(Wn, '""') + '"';
          break;
        }
        v == "ID" && s == 0 && l.length == 0 && (v = '"ID"');
      } else x.f != null && !x.F ? (o = !1, v = "=" + x.f, v.indexOf(",") >= 0 && (v = '"' + v.replace(Wn, '""') + '"')) : v = "";
      l.push(v);
    }
  if (c.strip) for (; l[l.length - 1] === ""; ) --l.length;
  return c.blankrows === !1 && o ? null : l.join(f);
}
function ks(e, a) {
  var r = [], t = a ?? {};
  if (e == null || e["!ref"] == null) return "";
  for (var n = Ke(e["!ref"]), i = t.FS !== void 0 ? t.FS : ",", f = i.charCodeAt(0), s = t.RS !== void 0 ? t.RS : `
`, c = s.charCodeAt(0), o = "", l = [], v = t.skipHidden && e["!cols"] || [], d = t.skipHidden && e["!rows"] || [], u = n.s.c; u <= n.e.c; ++u) (v[u] || {}).hidden || (l[u] = Pe(u));
  for (var p = 0, _ = n.s.r; _ <= n.e.r; ++_)
    (d[_] || {}).hidden || (o = Wd(e, n, _, l, f, c, i, p, t), o != null && (o || t.blankrows !== !1) && r.push((p++ ? s : "") + o));
  return r.join("");
}
function Vd(e, a) {
  a || (a = {}), a.FS = "	", a.RS = `
`;
  var r = ks(e, a);
  return r;
}
function Gd(e, a) {
  var r = "", t, n = "";
  if (e == null || e["!ref"] == null) return [];
  var i = Ke(e["!ref"]), f = "", s = [], c, o = [], l = e["!data"] != null;
  for (c = i.s.c; c <= i.e.c; ++c) s[c] = Pe(c);
  for (var v = i.s.r; v <= i.e.r; ++v)
    for (f = Me(v), c = i.s.c; c <= i.e.c; ++c)
      if (r = s[c] + f, t = l ? (e["!data"][v] || [])[c] : e[r], n = "", t !== void 0) {
        if (t.F != null) {
          if (r = t.F, !t.f) continue;
          n = t.f, r.indexOf(":") == -1 && (r = r + ":" + r);
        }
        if (t.f != null) n = t.f;
        else {
          if (a && a.values === !1) continue;
          if (t.t == "z") continue;
          if (t.t == "n" && t.v != null) n = "" + t.v;
          else if (t.t == "b") n = t.v ? "TRUE" : "FALSE";
          else if (t.w !== void 0) n = "'" + t.w;
          else {
            if (t.v === void 0) continue;
            t.t == "s" ? n = "'" + t.v : n = "" + t.v;
          }
        }
        o[o.length] = r + "=" + n;
      }
  return o;
}
function Es(e, a, r) {
  var t = r || {}, n = e ? e["!data"] != null : t.dense, i = +!t.skipHeader, f = e || {};
  !e && n && (f["!data"] = []);
  var s = 0, c = 0;
  if (f && t.origin != null)
    if (typeof t.origin == "number") s = t.origin;
    else {
      var o = typeof t.origin == "string" ? dr(t.origin) : t.origin;
      s = o.r, c = o.c;
    }
  var l = { s: { c: 0, r: 0 }, e: { c, r: s + a.length - 1 + i } };
  if (f["!ref"]) {
    var v = Ke(f["!ref"]);
    l.e.c = Math.max(l.e.c, v.e.c), l.e.r = Math.max(l.e.r, v.e.r), s == -1 && (s = v.e.r + 1, l.e.r = s + a.length - 1 + i);
  } else
    s == -1 && (s = 0, l.e.r = a.length - 1 + i);
  var d = t.header || [], u = 0, p = [];
  a.forEach(function(x, h) {
    n && !f["!data"][s + h + i] && (f["!data"][s + h + i] = []), n && (p = f["!data"][s + h + i]), Lr(x).forEach(function(E) {
      (u = d.indexOf(E)) == -1 && (d[u = d.length] = E);
      var g = x[E], y = "z", P = "", M = n ? "" : Pe(c + u) + Me(s + h + i), I = n ? p[c + u] : f[M];
      g && typeof g == "object" && !(g instanceof Date) ? n ? p[c + u] = g : f[M] = g : (typeof g == "number" ? y = "n" : typeof g == "boolean" ? y = "b" : typeof g == "string" ? y = "s" : g instanceof Date ? (y = "d", t.UTC || (g = Ht(g)), t.cellDates || (y = "n", g = ar(g)), P = I != null && I.z && Br(I.z) ? I.z : t.dateNF || ge[14]) : g === null && t.nullError && (y = "e", g = 0), I ? (I.t = y, I.v = g, delete I.w, delete I.R, P && (I.z = P)) : n ? p[c + u] = I = { t: y, v: g } : f[M] = I = { t: y, v: g }, P && (I.z = P));
    });
  }), l.e.c = Math.max(l.e.c, c + d.length - 1);
  var _ = Me(s);
  if (n && !f["!data"][s] && (f["!data"][s] = []), i) for (u = 0; u < d.length; ++u)
    n ? f["!data"][s][u + c] = { t: "s", v: d[u] } : f[Pe(u + c) + _] = { t: "s", v: d[u] };
  return f["!ref"] = ye(l), f;
}
function Xd(e, a) {
  return Es(null, e, a);
}
function ct(e, a, r) {
  if (typeof a == "string") {
    if (e["!data"] != null) {
      var t = dr(a);
      return e["!data"][t.r] || (e["!data"][t.r] = []), e["!data"][t.r][t.c] || (e["!data"][t.r][t.c] = { t: "z" });
    }
    return e[a] || (e[a] = { t: "z" });
  }
  return typeof a != "number" ? ct(e, Ne(a)) : ct(e, Pe(r || 0) + Me(a));
}
function zd(e, a) {
  if (typeof a == "number") {
    if (a >= 0 && e.SheetNames.length > a) return a;
    throw new Error("Cannot find sheet # " + a);
  } else if (typeof a == "string") {
    var r = e.SheetNames.indexOf(a);
    if (r > -1) return r;
    throw new Error("Cannot find sheet name |" + a + "|");
  } else throw new Error("Cannot find sheet |" + a + "|");
}
function L0(e, a) {
  var r = { SheetNames: [], Sheets: {} };
  return e && vt(r, e, a || "Sheet1"), r;
}
function vt(e, a, r, t) {
  var n = 1;
  if (!r) for (; n <= 65535 && e.SheetNames.indexOf(r = "Sheet" + n) != -1; ++n, r = void 0) ;
  if (!r || e.SheetNames.length >= 65535) throw new Error("Too many worksheets");
  if (t && e.SheetNames.indexOf(r) >= 0 && r.length < 32) {
    var i = r.match(/\d+$/);
    n = i && +i[0] || 0;
    var f = i && r.slice(0, i.index) || r;
    for (++n; n <= 65535 && e.SheetNames.indexOf(r = f + n) != -1; ++n) ;
  }
  if (Sx(r), e.SheetNames.indexOf(r) >= 0) throw new Error("Worksheet with name |" + r + "| already exists!");
  return e.SheetNames.push(r), e.Sheets[r] = a, r;
}
function $d(e, a, r) {
  e.Workbook || (e.Workbook = {}), e.Workbook.Sheets || (e.Workbook.Sheets = []);
  var t = zd(e, a);
  switch (e.Workbook.Sheets[t] || (e.Workbook.Sheets[t] = {}), r) {
    case 0:
    case 1:
    case 2:
      break;
    default:
      throw new Error("Bad sheet visibility setting " + r);
  }
  e.Workbook.Sheets[t].Hidden = r;
}
function Kd(e, a) {
  return e.z = a, e;
}
function Ts(e, a, r) {
  return a ? (e.l = { Target: a }, r && (e.l.Tooltip = r)) : delete e.l, e;
}
function Yd(e, a, r) {
  return Ts(e, "#" + a, r);
}
function jd(e, a, r) {
  e.c || (e.c = []), e.c.push({ t: a, a: r || "SheetJS" });
}
function Jd(e, a, r, t) {
  for (var n = typeof a != "string" ? a : Ke(a), i = typeof a == "string" ? a : ye(a), f = n.s.r; f <= n.e.r; ++f) for (var s = n.s.c; s <= n.e.c; ++s) {
    var c = ct(e, f, s);
    c.t = "n", c.F = i, delete c.v, f == n.s.r && s == n.s.c && (c.f = r, t && (c.D = !0));
  }
  var o = wa(e["!ref"]);
  return o.s.r > n.s.r && (o.s.r = n.s.r), o.s.c > n.s.c && (o.s.c = n.s.c), o.e.r < n.e.r && (o.e.r = n.e.r), o.e.c < n.e.c && (o.e.c = n.e.c), e["!ref"] = ye(o), e;
}
var Zd = {
  encode_col: Pe,
  encode_row: Me,
  encode_cell: Ne,
  encode_range: ye,
  decode_col: A0,
  decode_row: F0,
  split_cell: cc,
  decode_cell: dr,
  decode_range: wa,
  format_cell: fa,
  sheet_new: lc,
  sheet_add_aoa: Fi,
  sheet_add_json: Es,
  sheet_add_dom: hs,
  aoa_to_sheet: La,
  json_to_sheet: Xd,
  table_to_sheet: xs,
  table_to_book: ld,
  sheet_to_csv: ks,
  sheet_to_txt: Vd,
  sheet_to_json: h0,
  sheet_to_html: od,
  sheet_to_formulae: Gd,
  sheet_to_row_object_array: h0,
  sheet_get_cell: ct,
  book_new: L0,
  book_append_sheet: vt,
  book_set_sheet_visibility: $d,
  cell_set_number_format: Kd,
  cell_set_hyperlink: Ts,
  cell_set_internal_link: Yd,
  cell_add_comment: jd,
  sheet_set_array_formula: Jd,
  consts: {
    SHEET_VISIBLE: 0,
    SHEET_HIDDEN: 1,
    SHEET_VERY_HIDDEN: 2
  }
};
export {
  lf as S,
  et as r,
  Zd as u
};
