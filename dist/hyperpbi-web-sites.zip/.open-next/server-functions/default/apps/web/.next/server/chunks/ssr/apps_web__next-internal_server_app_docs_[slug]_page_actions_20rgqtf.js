module.exports=[76187,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_docs_%5Bslug%5D_page_actions_20rgqtf.js.map