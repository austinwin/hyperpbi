module.exports=[73997,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_playground_page_actions_0m1ellk.js.map