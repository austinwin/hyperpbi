module.exports=[42,(a,b,c)=>{}];

//# sourceMappingURL=0gy1__next-internal_server_app_playground_project_%5BprojectId%5D_page_actions_1bcvqce.js.map