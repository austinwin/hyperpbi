var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/demo/sensors/[sensorId]/route.js")
R.c("server/chunks/[externals]_next_dist_1ymdeph._.js")
R.c("server/chunks/[root-of-the-server]__0z0-bq_._.js")
R.c("server/chunks/044u_web__next-internal_server_app_api_demo_sensors_[sensorId]_route_actions_111vmbp.js")
R.m(99789)
module.exports=R.m(99789).exports
