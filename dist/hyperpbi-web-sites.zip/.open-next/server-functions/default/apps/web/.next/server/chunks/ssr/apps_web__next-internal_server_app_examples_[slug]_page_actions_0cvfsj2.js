module.exports=[47755,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_examples_%5Bslug%5D_page_actions_0cvfsj2.js.map