module.exports=[41393,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_components_page_actions_1x5r2wf.js.map