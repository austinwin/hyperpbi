module.exports=[78503,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_examples_page_actions_0qlinmq.js.map