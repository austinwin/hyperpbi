globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/W58ZhSVJZ5jdnXJcP95xS/_buildManifest.js",
    "static/W58ZhSVJZ5jdnXJcP95xS/_ssgManifest.js",
    "static/W58ZhSVJZ5jdnXJcP95xS/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ih-0lkvo1tfr.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/2j--sbzsobf4j.js",
    "static/chunks/10lzwjioi-7jo.js",
    "static/chunks/turbopack-1pribsw00e27r.js"
  ]
};
