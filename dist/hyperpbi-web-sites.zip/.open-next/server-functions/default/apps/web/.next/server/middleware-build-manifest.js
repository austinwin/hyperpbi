globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/otyqUrSd4Q_IOw5wg9fq6/_buildManifest.js",
    "static/otyqUrSd4Q_IOw5wg9fq6/_ssgManifest.js",
    "static/otyqUrSd4Q_IOw5wg9fq6/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0sv2bvyc0ah55.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/0cxp-lhga5ih-.js",
    "static/chunks/10lzwjioi-7jo.js",
    "static/chunks/turbopack-0nehwkoy2kzs8.js"
  ]
};
