module.exports=[12879,(e,o,d)=>{}];

//# sourceMappingURL=044u_web__next-internal_server_app_api_demo_sensors_%5BsensorId%5D_route_actions_111vmbp.js.map