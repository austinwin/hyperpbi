var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__1my83lt._.js")
R.c("server/chunks/ssr/node_modules_next_dist_esm_build_templates_app-page_19--w_z.js")
R.c("server/chunks/ssr/[root-of-the-server]__0g5uwrn._.js")
R.c("server/chunks/ssr/[root-of-the-server]__17tcecf._.js")
R.c("server/chunks/ssr/node_modules_next_dist_client_components_builtin_global-error_0-o-goa.js")
R.c("server/chunks/ssr/apps_web__next-internal_server_app__global-error_page_actions_1vxuwj7.js")
R.m(42378)
module.exports=R.m(42378).exports
