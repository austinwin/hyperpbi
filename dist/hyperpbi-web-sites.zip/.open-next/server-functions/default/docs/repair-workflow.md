# Repair workflow

Failed targeted AI mutations preserve the prior dashboard. Repair material includes the discriminated change package, operation, target ID/path/container, and full resulting-dashboard diagnostics. Package shape is validated per operation, nested destinations are checked against canonical descriptor container metadata, and a cloned result is prepared with current data/aliases. After full validation, the same prepared result becomes the working JSON and preview atomically; invalid results never replace the prior draft.

Repair is diagnostic-driven and conservative. HyperPBI never replaces the last valid saved dashboard with invalid input.

In Edit Mode, diagnostics are separated into **Errors** and **Warnings**. Errors block preview and **Save & return**. Warnings remain visible for review but are not presented as equivalent failures. A failed candidate changes the workbench state to **Preview out of date** while the last valid preview stays available for comparison; **Not previewed** means no current candidate has completed preview preparation.

## Workflow

1. Paste one AI response.
2. Extract exactly one JSON object (or one packaged `specification`).
3. Prepare aliases, definitions, patterns, and datasets under the strict schema 2.0 contract.
4. Validate strict schema, fields, references, calculations, interactions, targets, and SVG limits.
5. Review blocking Errors first, then Warnings and any explicitly recorded automatic repairs.
6. Copy the repair prompt to an approved external AI.
7. Paste one complete corrected specification and validate again.

Repair output is complete JSON, not JSON Patch or prose.

## Extractor diagnostics

The extractor accepts a direct object, one fenced block, or one unambiguous balanced object surrounded by prose. It rejects:

- empty responses
- arrays/primitives
- multiple parseable objects or ambiguous fences
- comments
- smart quotes
- truncated/unbalanced JSON
- a package whose `specification`/`config` string cannot be parsed

Those issues are not silently rewritten because doing so can change string content or select the wrong object.

## Allowed automatic preparation repairs

- rename only `meausre→measure`, `catgory→category`, `componets→components`, and `aggregration→aggregation`
- convert unequivocal numeric strings for `span`, `height`, `width`, `limit`, `pageSize`, `maxRows`, `columns`, and `gap`

Every applied repair is returned as a `REPAIR_APPLIED` diagnostic.

## Intentionally forbidden automatic repairs

HyperPBI does not guess fields, aliases, measures, aggregation, dataset sources, definition/pattern names, targets, ArcGIS services, credentials, or business rules. It does not delete components/properties, remove interactions, migrate versions, loosen security, or reinterpret ambiguous syntax.

The external repair prompt follows the same rule: correct only diagnosed issues, preserve valid unrelated content and stable IDs, and return an explicit dashboard schema version 2.0. AI import rejects schema 1.0 and missing versions.

## Structured diagnostics

Diagnostics include a code, severity, JSON pointer-like path, message, and—where available—component ID, received value, suggestions, and auto-fix availability. Dataset and definition cycles show their chain. Unknown fields in a named dataset identify that dataset scope. External-interaction diagnostics distinguish disabled behavior, missing identities, and a field without a Power BI filter target. Selecting an issue should lead to its actionable context rather than replacing the current editor with a generic failure page.

Warnings do not grant permission to remove behavior. Resolve the underlying condition before continuing. After a normal correction, select **Preview changes**; for a targeted AI package, select **Validate resulting dashboard & Preview**. **Preview current** confirms that the visible result matches the working specification and Runtime settings. **Save & return** performs the same guarded validation against the current values and leaves Edit Mode open when an error remains.
