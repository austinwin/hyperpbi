# HyperPBI Map Feature Demo Suite

This kit was generated against the current map contract in `austinwin/hyperpbi`.

## What is included

1. `01-powerbi-multilayer-operations.json`  
   The main operational Web GIS demonstration. It proves that every layer owns its own dynamic bindings; there is no global latitude/longitude limitation.

2. `02-renderer-laboratory.json`  
   A layer-toggle gallery for the stable renderers: simple, unique value, class breaks, continuous color, proportional size, cluster count, and cluster sum.

3. `03-arcgis-scada-service-sources.json`  
   Uses the Houston SCADA MapServer as a feature reference layer and dynamic map image layer, plus an ArcGIS raster tile overlay.

4. `04-arcgis-scada-powerbi-join.json`  
   Joins Power BI rows to ArcGIS geometry and demonstrates normalization, duplicate policies, aggregations, joined styling, labels, popup, tooltip, filtering, and selection.

5. `05-powerbi-location-binding-modes.json`  
   Demonstrates `layer`, `type`, `layerValue`, latitude/longitude, X/Y, GeoJSON geometry, address components, color, size, tooltip, and details bindings.

6. `hyperpbi-map-demo-data.csv`  
   Import this CSV into Power BI to exercise the Power BI examples.

7. `coverage.json`  
   Machine-readable feature coverage and current unsupported capabilities.

## Critical URL correction

The supplied URL is an ArcGIS operation endpoint:

`https://geogimsms.houstontx.gov/arcgis/rest/services/HW/SCADA/MapServer/0/query`

Do not store `/query` as the HyperPBI layer `source.url`.

Use either:

- Map service root plus `layerId`:
  - `url`: `https://geogimsms.houstontx.gov/arcgis/rest/services/HW/SCADA/MapServer`
  - `layerId`: `0`

- Direct feature-layer endpoint:
  - `url`: `https://geogimsms.houstontx.gov/arcgis/rest/services/HW/SCADA/MapServer/0`

HyperPBI builds the query request itself.

## Power BI setup

1. Import `hyperpbi-map-demo-data.csv`.
2. Add every field needed by the selected example to the single HyperPBI **Values** field well.
3. Set all coordinate columns to **Don't summarize**, especially:
   - `facilityLatitude`
   - `facilityLongitude`
   - `incidentLatitude`
   - `incidentLongitude`
   - `x`
   - `y`
4. Paste one JSON specification into HyperPBI.
5. For the Maps package, allow HTTPS access to the required hosts. A restricted package must include:
   - `geogimsms.houstontx.gov`
   - `server.arcgisonline.com`
   - `tile.openstreetmap.org` if using the custom tile example.

## SCADA metadata caveat

The SCADA host could not be resolved from the generation environment, so its live layer metadata and field list were not verified here.

The reference example relies mainly on the service renderer and service labels. It uses `OBJECTID` as the likely object-ID field. In Map Studio, run public service metadata inspection and confirm:

- actual object-ID field
- field aliases
- service geometry type
- service renderer/label availability
- whether the service supports pagination and dynamic export
- the join key that should replace `OBJECTID` if your Power BI model uses a business identifier

The join demo is structurally complete, but it will only match real features when `scadaObjectId` contains values from the confirmed service key.

## Validation policy

The downloadable examples use only stable, implemented map properties so they can be pasted into HyperPBI without capability-limitation warnings. Partial and experimental capabilities are documented in the repository but intentionally excluded from this stable demo suite.

## Features not included because the current schema rejects them

The current implementation does not accept scale/coordinate readout, rectangle/lasso selection, distance/area measurement, time slider, swipe/side-by-side comparison, selected-feature export, print layout, or viewer-to-Studio launch. Adding fake JSON properties for these would be misleading; strict map validation would reject them.

## Recommended demo sequence

1. Start with `01-powerbi-multilayer-operations.json`.
2. Open the layer panel and demonstrate group visibility, opacity, ordering, labels, legend, bookmarks, search, and selection.
3. Switch to `02-renderer-laboratory.json`; keep only one renderer layer visible at a time.
4. Use `03-arcgis-scada-service-sources.json` after Map Studio metadata inspection confirms public access.
5. Finish with `04-arcgis-scada-powerbi-join.json` to demonstrate the Power BI + ArcGIS joined analytical workflow.
